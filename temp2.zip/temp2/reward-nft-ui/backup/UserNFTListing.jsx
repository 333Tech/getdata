<<<<<<< HEAD
import React, { useState, useEffect, useMemo, useContext } from "react";
import AppServices from "../../services/Api";
import Loader from "../Common/Loader";
import TokensTransferModal from "./TokensTransferModal";
import { PublicKey, Keypair } from "@solana/web3.js";
import {
  getOrCreateAssociatedTokenAccount,
  TOKEN_PROGRAM_ID,
  createTransferInstruction,
} from "@solana/spl-token";
import Messages from "../Common/Messages";
import { Modal } from "flowbite-react";
import * as anchor from "@project-serum/anchor";
import * as bs58 from "bs58";
import CONSTANTS from "../../services/Constants";
import { useWallet } from "@solana/wallet-adapter-react";
import * as solanaWeb3 from "@solana/web3.js";
import { Metaplex, walletAdapterIdentity } from "@metaplex-foundation/js";
import HomeNew from "../MintNFT/HomeNew.tsx";
import AppContext from "../../context/AppContext";
import Profile from "../Header/Profile";

const UserNFTListing = ({
  availableTokens,
  connection,
  type,
  user,
  allUsers,
}) => {
  const [openModal, setOpenModal] = useState(false);
  const [benefitModal, setBenefitModal] = useState({});
  const [users, setUsers] = useState(null);
  const [nfts, setNfts] = useState(null);
  const [selfNfts, setSelfNfts] = useState(null);
  const { signTransaction } = useWallet();
  const [message, setMessage] = useState(null);
  const wallet = useWallet();
  const [isLoading, setIsLoading] = useState(false);
  const [achievements, setAchievements] = useState(null);
  const [benefits, setBenefits] = useState(null);
  const [transferEmployee, setTransferEmployee] = useState(null);
  const [dbNftsData, setDbNftsData] = useState(null);
  const context = useContext(AppContext);

  const rpcHost =
    CONSTANTS.SOLANA_RPC_HOST ?? anchor.web3.clusterApiUrl("devnet");
  const getCandyMachineId = () => {
    try {
      return new anchor.web3.PublicKey(CONSTANTS.CANDY_MACHINE_ID);
    } catch (e) {
      console.log("Failed to construct CandyMachineId", e);
      return undefined;
    }
  };

  const candyMachineId = getCandyMachineId();

  const solana = useMemo(() => {
    if (
      !wallet ||
      !wallet.publicKey ||
      !wallet.signAllTransactions ||
      !wallet.signTransaction
    ) {
      return;
    }
    return {
      publicKey: wallet.publicKey,
      signAllTransactions: wallet.signAllTransactions,
      signTransaction: wallet.signTransaction,
    };
  }, [wallet]);

  useEffect(() => {
    getUsers();
    getAchievements();

    getBenefitData();
  }, []);

  useEffect(() => {
    getDBNftData();
  }, [context.timestamp]);

  const sleep = (ms) => {
    return new Promise((resolve) => setTimeout(resolve, ms));
  };

  // Get NFT Owner Details
  const getNFTOwnerData = async (name, res) => {
    //  res > init db nft list on load before state update
    let arr = res ? res : dbNftsData;
    if (arr && arr.length > 0) {
      // let metadata = await dbNftsData.find((item)=> item.name == name)
      for (var i = 0; i < arr.length; i++) {
        if (arr[i].name == name) {
          // metadata.info = await users.find((item)=> item.walletId == metadata?.toWalletId)
          return await arr[i];
        }
      }
    }
  };
  const getWalletNFTData = async (res) => {
    setNfts(null);
    const metaplex = await Metaplex.make(connection).use(
      walletAdapterIdentity(solana)
    );
    setIsLoading(true);
    // const candyMachineObj = await metaplex.candyMachines();
    const data = await metaplex
      .nfts()
      .findAllByOwner({ owner: wallet.publicKey })
      .run();
    console.log("Mint", data);

    async function getMetaDataNFT() {
      let array = [];
      let selfArr = [];
      //This loop will wait for each next() to pass the next iteration
      for (var i = 0; i < data.length; i++) {
        let nftObj = await metaplex
          .nfts()
          .findByMint({ mintAddress: data[i].mintAddress })
          .run();
        let tokenInfo = await getNFTOwnerData(nftObj.name, res);
        if (tokenInfo) {
          array[i] = await nftObj;
          array[i].data = await tokenInfo;
        } else {
          selfArr[i] = await nftObj;
        }
      }
      console.log("array", array);
      await setNfts(array);
      await setSelfNfts(selfArr);
      await setIsLoading(false);
    }
    await getMetaDataNFT();
  };

  // Get List of NFT INFO From DB
  const getDBNftData = () => {
    AppServices._getNFTData().then((res) => {
      setDbNftsData(res);
      type ? getAllNFTsData(res) : getWalletNFTData(res);
    });
  };

  // Get List of All NFT of From CandyMachine
  const getAllNFTsData = async (res) => {
    console.log("getAllNFTsData");
    const metaplex = await Metaplex.make(connection).use(
      walletAdapterIdentity(solana)
    );
    const MAX_NAME_LENGTH = 32;
    const MAX_URI_LENGTH = 200;
    const MAX_SYMBOL_LENGTH = 10;
    const MAX_CREATOR_LEN = 32 + 1 + 1;
    const MAX_CREATOR_LIMIT = 5;
    const MAX_DATA_SIZE =
      4 +
      MAX_NAME_LENGTH +
      4 +
      MAX_SYMBOL_LENGTH +
      4 +
      MAX_URI_LENGTH +
      2 +
      1 +
      4 +
      MAX_CREATOR_LIMIT * MAX_CREATOR_LEN;
    const MAX_METADATA_LEN = 1 + 32 + 32 + MAX_DATA_SIZE + 1 + 1 + 9 + 172;
    const CREATOR_ARRAY_START =
      1 +
      32 +
      32 +
      4 +
      MAX_NAME_LENGTH +
      4 +
      MAX_URI_LENGTH +
      4 +
      MAX_SYMBOL_LENGTH +
      2 +
      1 +
      4;
    const TOKEN_METADATA_PROGRAM = new PublicKey(
      CONSTANTS.TOKEN_METADATA_PROGRAM
    );
    const CANDY_MACHINE_V2_PROGRAM = new PublicKey(
      CONSTANTS.CANDY_MACHINE_V2_PROGRAM
    );
    const candyMachineId = new PublicKey(CONSTANTS.CANDY_MACHINE_ID);

    // Get All Mint Addresses
    const getMintAddresses = async (firstCreatorAddress) => {
      const metadataAccounts = await connection.getProgramAccounts(
        TOKEN_METADATA_PROGRAM,
        {
          // The mint address is located at byte 33 and lasts for 32 bytes.
          dataSlice: { offset: 33, length: 32 },
          filters: [
            // Only get Metadata accounts.
            { dataSize: MAX_METADATA_LEN },
            // Filter using the first creator.
            {
              memcmp: {
                offset: CREATOR_ARRAY_START,
                bytes: firstCreatorAddress.toBase58(),
              },
            },
          ],
        }
      );

      return metadataAccounts.map((metadataAccountInfo) => {
        return bs58.encode(metadataAccountInfo.account.data);
      });
    };

    // Candy Machine Creator
    const getCandyMachineCreator = async (candyMachine) =>
      PublicKey.findProgramAddress(
        [Buffer.from("candy_machine"), candyMachine.toBuffer()],
        CANDY_MACHINE_V2_PROGRAM
      );

    // Init
    (async () => {
      const candyMachineCreator = await getCandyMachineCreator(candyMachineId);
      console.log("candyMachineCreator", candyMachineCreator);
      const dat = await getMintAddresses(candyMachineCreator[0]);
      const mintAddrses = await dat.map((item) => new PublicKey(item));
      async function getMetaDataNFT() {
        const dataAllMint = await metaplex
          .nfts()
          .findAllByMintList({ mints: mintAddrses })
          .run();
        let array = [];
        //This loop will wait for each next() to pass the next iteration
        for (var i = 0; i < dataAllMint.length; i++) {
          let nftObj = await metaplex
            .nfts()
            .findByMint({ mintAddress: dataAllMint[i].mintAddress })
            .run();
          let tokenInfo = await getNFTOwnerData(nftObj.name, res);
          array[i] = await nftObj;
          if (tokenInfo) {
            array[i].data = await tokenInfo;
          }
        }
        setNfts(array);
      }
      await getMetaDataNFT();
    })();
  };

  // Get Users
  const getUsers = async () => {
    // AppServices._getUsersData().then((res) => {
    const employees_from_same_department =
      allUsers?.length > 0 &&
      allUsers.filter(
        (item) =>
          (item.department == user?.department) &
          (item.name != user?.name) &
          (item.role != "Manager")
      );
    setUsers(employees_from_same_department);
    // });
  };

  // Get Achievements
  const getAchievements = async () => {
    AppServices._getAchievementsData().then((res) => {
      setAchievements(res);
    });
  };

  // List of benefits
  const getBenefitData = () => {
    AppServices._getBenefitsData().then((res) => {
      setBenefits(res);
    });
  };

  // Close Modal From Child
  const handleClose = async (payload) => {
    setTransferEmployee(null);
    console.log("payload emp", payload);
    if (payload.obj) {
      setIsLoading(true);
      transferNFTOnly(payload.user, payload.obj);
    }
  };

  // Transfer NFT Only For Employee
  const transferNFTOnly = async (nft, obj) => {
    const pvKey = CONSTANTS.PRIVATE_KEY_MANAGER;
    const fromWallet = Keypair.fromSecretKey(bs58.decode(pvKey));
    const nftPublicKey = nft.mint.address;
    const fromPublicKey = solana.publicKey;
    const toPublicKey = new PublicKey(obj.selectedUser);
    try {
      const associatedDestinationTokenAddr =
        await getOrCreateAssociatedTokenAccount(
          connection,
          fromWallet,
          nftPublicKey,
          toPublicKey,
          signTransaction
        );
      await sleep(1000);
      const fromTokenAccount = await getOrCreateAssociatedTokenAccount(
        connection,
        fromPublicKey,
        nftPublicKey,
        fromPublicKey,
        signTransaction
      );
      await sleep(1000);

      const transaction = await new solanaWeb3.Transaction().add(
        // Sending NFT
        createTransferInstruction(
          // imported from '@solana/spl-token'
          fromTokenAccount.address,
          associatedDestinationTokenAddr.address,
          fromPublicKey,
          1, // tokens have 6 decimals of precision so your amount needs to have the same
          [],
          TOKEN_PROGRAM_ID // imported from '@solana/spl-token'
        )
      );
      await sleep(1000);
      // set a recent block hash on the transaction to make it pass smoothly
      const latestBlockHash = await connection.getLatestBlockhash();
      transaction.recentBlockhash = await latestBlockHash.blockhash;

      // set who is the fee payer for that transaction
      transaction.feePayer = fromPublicKey;

      // sign the transaction using the signTransaction method that we got from the useWallet hook above
      const signed = await signTransaction(transaction);
      // send the signed transaction
      const signature = await connection.sendRawTransaction(signed.serialize());
      // wait for a confirmation to make sure it went to the blockchain (optional)
      await connection.confirmTransaction({
        signature,
        lastValidBlockHeight: latestBlockHash.lastValidBlockHeight,
        blockhash: latestBlockHash.blockhash,
      });
      await sendDataToDB(signature, nft?.name, obj);
    } catch (error) {
      setIsLoading(false);
      displayMessage("There is problem in RPC JSON API", "error");
      console.log("error>>", error);
    }
  };

  //  Send data to db
  const sendDataToDB = async (tx, nft, fields) => {
    const result = await connection.getTransaction(tx);
    let payload = {
      mint: result?.meta?.postTokenBalances[0]?.mint,
      fromWalletId: wallet.publicKey.toString(),
      toWalletId: fields.selectedUser,
      achievement: fields.achievement,
      message: fields.message,
      name: nft,
    };
    console.log("Payload", payload);
    AppServices._postNFTData(payload).then((res) => {
      if (res) {
        setIsLoading(false);
        displayMessage("NFT Transfer Successfully");
        // Sent trigger to context update other info in app
        context.sendUpdateAction(Date.now());
        // Reload NFT Data
        // getWalletNFTData();
      }
    });
  };

  // Get Success/Error Message and Refresh Component
  const displayMessage = (msg, type) => {
    setMessage({ msg, type });
    setTimeout(() => {
      setMessage(null);
    }, 2000);
  };
  const getUserProfile = (walletId) => {
    let userObj = allUsers.filter((item) => item.walletId == walletId);
    console.log("userObj", userObj);
    if (userObj.length > 0) {
      return <Profile user={userObj[0]} />;
    } else {
      return null;
    }
  };

  return (
    <div className="flex flex-col relative justify-center items-center  mx-8 p-2 mt-8">
      <button
        onClick={() => getWalletNFTData()}
        className="absolute top-0 left-4 text-white bg-ing-orange hover:bg-yellow-800  font-medium rounded p-1 text-center mb-5 mt-2"
      >
        Refresh
      </button>
      <div className="flex flex-row  items-start justify-start">
        {/* <h2 className="text-xxl pt-2 mb-5 font-bold">My NFT's</h2> */}
        {message && <Messages msg={message} />}

        <div className="flex items-center justify-center text-2xl text-ing-blue font-bold mb-4">
          {type == "wall" ? "Wall of Fame" : "Received NFT Rewards"}
        </div>
      </div>

      <div>
        <div className="flex flex-col gap-8">
          {!nfts && (
            <div className="">
              <div
                colSpan={6}
                className="whitespace-nowrap font-medium text-zinc-900 dark:text-white text-center"
              >
                <Loader />
              </div>
            </div>
          )}

          {nfts?.length > 0 &&
            nfts.map((item, ind) => {
              //Only Minted NFT From UI
              if (item.json == null && nfts?.length == 1) {
                return (
                  <div key={`nft-table-${ind}`} className="">
                    <div
                      colSpan={6}
                      className="whitespace-nowrap font-medium text-zinc-900 dark:text-white text-center"
                    >
                      No Data Available.
                    </div>
                  </div>
                );
              }
              if (item?.json && item?.data) {
                return (
                  <div
                    key={`nft-table-${ind}`}
                    className="flex relative flex-row items-start justify-between rounded-md shadow-md bg-white p-4"
                  >
                    <div className="flex text-zinc-900 text-xl">
                      {
                        allUsers.filter(
                          (user) =>
                            user.walletId == item.mint.address.toString()
                        ).name
                      }
                    </div>
                    {/* <img
                      className="absolute top-0 right-0 h-16 rounded-full"
                      src={
                        allUsers.filter(
                          (user) => user.walletId == item.address.toString()
                        ).name
                      }
                      alt=""
                    /> */}
                    <div className="flex flex-col w-1/2 font-medium text-zinc-900">
                      <div className="flex items-start text-start text-ing-orange text-lg hover:text-ing-blue font-semibold">
                        <a
                          target="_blank"
                          href={`https://solscan.io/token/${item?.mint?.address?.toString()}?cluster=devnet#metadata`}
                        >
                          {item.name || "NA"}
                        </a>
                      </div>
                      <div className="flex items-start">
                        <img
                          className="h-96 rounded-md"
                          src={
                            item?.json
                              ? item.json?.image
                              : CONSTANTS.IMG_PLACEHOLDER
                          }
                          alt=""
                        />
                      </div>

                      <>
                        <div className="text-start mt-2 text-zinc-600 font-semibold">
                          Achievement {"  :  "}
                          <span className="text-zinc-900 ">
                            {item.data.achievement}
                          </span>
                        </div>
                        <div className="text-start text-zinc-600 font-semibold">
                          Congratulatory message {"  :  "}
                          <span className="text-zinc-900 break-normal">
                            {item.data.message}
                          </span>
                        </div>
                        {type && (
                          <div className="-ml-20 mt-3">
                            {getUserProfile(item.data.toWalletId)}
                          </div>
                        )}
                      </>
                      <div></div>
                    </div>
                    <div className="flex flex-col mt-4">
                      <div className="flex flex-col items-center justify-center  text-zinc-900 ">
                        <div className="text-center mb-2 font-semibold">
                          Layers
                        </div>

                        <div className="flex flex-col">
                          {item?.json?.attributes.map((attr, index) => {
                            return (
                              <div
                                className="grid grid-cols-2 text-start"
                                key={index}
                              >
                                <div className="text-end mr-2">
                                  {attr.trait_type}
                                  {"  :  "}
                                </div>
                                <div className="text-ing-orange">
                                  {attr.value}
                                </div>
                              </div>
                            );
                          })}
                        </div>
                      </div>

                      <div className="flex  flex-col items-center justify-center font-medium text-zinc-900 mt-4">
                        <div className="text-center my-2 font-semibold">
                          Benefits
                        </div>

                        <div className="flex flex-col">
                          {item?.json?.benefits.map((attr, index) => {
                            return (
                              <div className="grid grid-cols-4" key={index}>
                                <div className="  text-end mr-2">
                                  {index + 1} :
                                </div>
                                <div
                                  onClick={() => {
                                    if (type) {
                                      return false;
                                    } else {
                                      setOpenModal(true);
                                      setBenefitModal(
                                        benefits?.filter(
                                          (benefit) =>
                                            benefit.id == attr.benefit
                                        )[0]
                                      );
                                    }
                                  }}
                                  className="text-ing-orange col-span-3 cursor-pointer hover:font-bold"
                                >
                                  {attr.description}
                                </div>
                              </div>
                            );
                          })}
                        </div>
                      </div>
                    </div>
                  </div>
                );
              }
            })}
          {type != "wall" &&
            selfNfts?.length > 0 &&
            selfNfts.map((item, ind) => {
              //Only Minted NFT From UI
              if (item.json == null && selfNfts?.length == 1) {
                return (
                  <div key={`nft-table-${ind}`} className="">
                    <div
                      colSpan={6}
                      className="whitespace-nowrap font-medium text-zinc-900 dark:text-white text-center"
                    >
                      No Data Available.
                    </div>
                  </div>
                );
              }
              if (item.json) {
                return (
                  <div
                    key={`nft-table-${ind}`}
                    className="flex flex-row items-center justify-center rounded-md shadow-md bg-white p-4"
                  >
                    <div className="flex flex-col w-1/2 font-medium text-zinc-900">
                      <div className="flex items-start text-start text-ing-orange text-lg hover:text-ing-blue font-semibold">
                        <a
                          target="_blank"
                          href={`https://solscan.io/token/${item?.mint?.address?.toString()}?cluster=devnet#metadata`}
                        >
                          {item.name || "NA"}
                        </a>
                      </div>
                      <div className="flex items-start">
                        <img
                          className="h-96 rounded-md"
                          src={
                            item?.json
                              ? item.json?.image
                              : CONSTANTS.IMG_PLACEHOLDER
                          }
                          alt=""
                        />
                      </div>
                      <div
                        className="mt-2 items-center w-36 justify-center text-center cursor-pointer hover:opacity-80 p-2 text-white rounded-md bg-gradient-to-r from-[#3f83f8] to-[#7E3AF2] "
                        onClick={() => setTransferEmployee(item)}
                      >
                        Transfer NFT
                      </div>
                    </div>
                    <div className="flex flex-col mt-4">
                      <div className="flex flex-col items-center justify-center  text-zinc-900 ">
                        <div className="text-center mb-2 font-semibold">
                          Layers
                        </div>

                        <div className="flex flex-col">
                          {item?.json?.attributes.map((attr, index) => {
                            return (
                              <div
                                className="grid grid-cols-2 text-start"
                                key={index}
                              >
                                <div className="text-end mr-2">
                                  {attr.trait_type}
                                  {"  :  "}
                                </div>
                                <div className="text-ing-orange">
                                  {attr.value}
                                </div>
                              </div>
                            );
                          })}
                        </div>
                      </div>

                      <div className="flex  flex-col items-center justify-center font-medium text-zinc-900 mt-4">
                        <div className="text-center my-2 font-semibold">
                          Benefits
                        </div>

                        <div className="flex flex-col">
                          {item?.json?.benefits.map((attr, index) => {
                            return (
                              <div className="grid grid-cols-4" key={index}>
                                <div className="  text-end mr-2">
                                  {index + 1} :
                                </div>
                                <div
                                  onClick={() => {
                                    setOpenModal(true);
                                    setBenefitModal(
                                      benefits?.filter(
                                        (benefit) => benefit.id == attr.benefit
                                      )[0]
                                    );
                                  }}
                                  className="text-ing-orange col-span-3 cursor-pointer hover:font-bold"
                                >
                                  {attr.description}
                                </div>
                              </div>
                            );
                          })}
                        </div>
                      </div>
                    </div>
                  </div>
                );
              }
            })}
        </div>
      </div>
      <>
        <Modal show={openModal} size="lg" onClose={() => setOpenModal(false)}>
          <Modal.Header>{benefitModal.name}</Modal.Header>
          <Modal.Body>
            <p className="text-base leading-relaxed text-gray-400">
              {benefitModal.description}
            </p>
            <div className="space-y-6 p-6">
              {benefitModal.id == "benefit_02" && availableTokens == 0 && (
                <p className="text-base leading-relaxed text-blue-400 text-center">
                  You already minted the token.
                </p>
              )}
              {benefitModal.id == "benefit_02" && availableTokens > 0 && (
                <HomeNew
                  tokens={availableTokens}
                  txTimeout={6000}
                  rpcHost={rpcHost}
                  candyMachineId={candyMachineId}
                />
              )}
            </div>
          </Modal.Body>
        </Modal>
      </>
      {achievements && transferEmployee && (
        <TokensTransferModal
          users={users}
          achievements={achievements}
          user={transferEmployee}
          onClose={handleClose}
        />
      )}
      {isLoading && <Loader />}
    </div>
  );
};

export default UserNFTListing;
=======
import React, { useState, useEffect, useMemo, useContext } from "react";
import AppServices from "../../services/Api";
import Loader from "../Common/Loader";
import TokensTransferModal from "./TokensTransferModal";
import { PublicKey, Keypair } from "@solana/web3.js";
import {
  getOrCreateAssociatedTokenAccount,
  TOKEN_PROGRAM_ID,
  createTransferInstruction,
} from "@solana/spl-token";
import Messages from "../Common/Messages";
import { Modal } from "flowbite-react";
import * as anchor from "@project-serum/anchor";
import * as bs58 from "bs58";
import CONSTANTS from "../../services/Constants";
import { useWallet } from "@solana/wallet-adapter-react";
import * as solanaWeb3 from "@solana/web3.js";
import { Metaplex, walletAdapterIdentity } from "@metaplex-foundation/js";
import HomeNew from "../MintNFT/HomeNew.tsx";
import AppContext from '../../context/AppContext';
import Profile from "../Header/Profile";

const UserNFTListing = ({ availableTokens, connection, type, user, allUsers }) => {
  const [openModal, setOpenModal] = useState(false);
  const [benefitModal, setBenefitModal] = useState({});
  const [users, setUsers] = useState(null);
  const [nfts, setNfts] = useState(null);
  const [selfNfts, setSelfNfts] = useState(null);
  const { signTransaction } = useWallet();
  const [message, setMessage] = useState(null);
  const wallet = useWallet();
  const [isLoading, setIsLoading] = useState(false);
  const [achievements, setAchievements] = useState(null);
  const [benefits, setBenefits] = useState(null);
  const [transferEmployee, setTransferEmployee] = useState(null);
  const [dbNftsData, setDbNftsData] = useState(null);
  const context = useContext(AppContext);

  const rpcHost =
    CONSTANTS.SOLANA_RPC_HOST ?? anchor.web3.clusterApiUrl("devnet");
  const getCandyMachineId = () => {
    try {
      return new anchor.web3.PublicKey(CONSTANTS.CANDY_MACHINE_ID);
    } catch (e) {
      console.log("Failed to construct CandyMachineId", e);
      return undefined;
    }
  };

  const candyMachineId = getCandyMachineId();

  const solana = useMemo(() => {
    if (
      !wallet ||
      !wallet.publicKey ||
      !wallet.signAllTransactions ||
      !wallet.signTransaction
    ) {
      return;
    }
    return {
      publicKey: wallet.publicKey,
      signAllTransactions: wallet.signAllTransactions,
      signTransaction: wallet.signTransaction,
    };
  }, [wallet]);

  useEffect(() => {
    getUsers();
    getAchievements();
    
    getBenefitData();
  }, []);

  useEffect(() => {
    getDBNftData()
  }, [context.timestamp]);


  const sleep = (ms) => {
    return new Promise((resolve) => setTimeout(resolve, ms));
  };

  // Get NFT Owner Details
  const getNFTOwnerData = async (name, res) => {
    //  res > init db nft list on load before state update
    let arr = res ? res : dbNftsData;
    if (arr && arr.length > 0) {
      // let metadata = await dbNftsData.find((item)=> item.name == name)
      for (var i = 0; i < arr.length; i++) {
        if (arr[i].name == name) {
          // metadata.info = await users.find((item)=> item.walletId == metadata?.toWalletId)
          return await arr[i];
        }
      }
    }
  };
  const getWalletNFTData = async (res) => {
    setNfts(null);
    const metaplex = await Metaplex.make(connection).use(
      walletAdapterIdentity(solana)
    );
    setIsLoading(true);
    // const candyMachineObj = await metaplex.candyMachines();
    const data = await metaplex
      .nfts()
      .findAllByOwner({ owner: wallet.publicKey })
      .run();
    console.log("Mint", data);

    async function getMetaDataNFT() {
      let array = [];
      let selfArr = [];
      //This loop will wait for each next() to pass the next iteration
      for (var i = 0; i < data.length; i++) {
        let nftObj = await metaplex
          .nfts()
          .findByMint({ mintAddress: data[i].mintAddress })
          .run();
        let tokenInfo = await getNFTOwnerData(nftObj.name, res);
        if (tokenInfo) {
          array[i] = await nftObj;
          array[i].data = await tokenInfo;
        } else {
          selfArr[i] = await nftObj;
        }
      }
      console.log("array",array)
      await setNfts(array);
      await setSelfNfts(selfArr);
      await setIsLoading(false);
    }
    await getMetaDataNFT();
  };

  // Get List of NFT INFO From DB
  const getDBNftData = () => {
    AppServices._getNFTData().then((res) => {
      setDbNftsData(res);
      type ? getAllNFTsData(res) : getWalletNFTData(res);
    });
  };

  // Get List of All NFT of From CandyMachine
  const getAllNFTsData = async (res) => {
    console.log("getAllNFTsData");
    const metaplex = await Metaplex.make(connection).use(
      walletAdapterIdentity(solana)
    );
    const MAX_NAME_LENGTH = 32;
    const MAX_URI_LENGTH = 200;
    const MAX_SYMBOL_LENGTH = 10;
    const MAX_CREATOR_LEN = 32 + 1 + 1;
    const MAX_CREATOR_LIMIT = 5;
    const MAX_DATA_SIZE =
      4 +
      MAX_NAME_LENGTH +
      4 +
      MAX_SYMBOL_LENGTH +
      4 +
      MAX_URI_LENGTH +
      2 +
      1 +
      4 +
      MAX_CREATOR_LIMIT * MAX_CREATOR_LEN;
    const MAX_METADATA_LEN = 1 + 32 + 32 + MAX_DATA_SIZE + 1 + 1 + 9 + 172;
    const CREATOR_ARRAY_START =
      1 +
      32 +
      32 +
      4 +
      MAX_NAME_LENGTH +
      4 +
      MAX_URI_LENGTH +
      4 +
      MAX_SYMBOL_LENGTH +
      2 +
      1 +
      4;
    const TOKEN_METADATA_PROGRAM = new PublicKey(
      CONSTANTS.TOKEN_METADATA_PROGRAM
    );
    const CANDY_MACHINE_V2_PROGRAM = new PublicKey(
      CONSTANTS.CANDY_MACHINE_V2_PROGRAM
    );
    const candyMachineId = new PublicKey(CONSTANTS.CANDY_MACHINE_ID);

    // Get All Mint Addresses
    const getMintAddresses = async (firstCreatorAddress) => {
      const metadataAccounts = await connection.getProgramAccounts(
        TOKEN_METADATA_PROGRAM,
        {
          // The mint address is located at byte 33 and lasts for 32 bytes.
          dataSlice: { offset: 33, length: 32 },
          filters: [
            // Only get Metadata accounts.
            { dataSize: MAX_METADATA_LEN },
            // Filter using the first creator.
            {
              memcmp: {
                offset: CREATOR_ARRAY_START,
                bytes: firstCreatorAddress.toBase58(),
              },
            },
          ],
        }
      );

      return metadataAccounts.map((metadataAccountInfo) => {
        return bs58.encode(metadataAccountInfo.account.data);
      });
    };

    // Candy Machine Creator
    const getCandyMachineCreator = async (candyMachine) =>
      PublicKey.findProgramAddress(
        [Buffer.from("candy_machine"), candyMachine.toBuffer()],
        CANDY_MACHINE_V2_PROGRAM
      );

    // Init
    (async () => {
      const candyMachineCreator = await getCandyMachineCreator(candyMachineId);
      console.log("candyMachineCreator", candyMachineCreator);
      const dat = await getMintAddresses(candyMachineCreator[0]);
      const mintAddrses = await dat.map((item) => new PublicKey(item));
      async function getMetaDataNFT() {
        const dataAllMint = await metaplex
          .nfts()
          .findAllByMintList({ mints: mintAddrses })
          .run();
        let array = [];
        //This loop will wait for each next() to pass the next iteration
        for (var i = 0; i < dataAllMint.length; i++) {
          let nftObj = await metaplex
            .nfts()
            .findByMint({ mintAddress: dataAllMint[i].mintAddress })
            .run();
          let tokenInfo = await getNFTOwnerData(nftObj.name, res);
          array[i] = await nftObj;
          if (tokenInfo) {
            array[i].data = await tokenInfo;
          }
        }
        console.log("array nft", array)
        setNfts(array);
      }
      await getMetaDataNFT();
    })();
  };

  // Get Users
  const getUsers = async () => {
    // AppServices._getUsersData().then((res) => {
      const employees_from_same_department = allUsers?.length > 0  && allUsers.filter(
        (item) =>
          (item.department == user?.department) &
          (item.name != user?.name) &
          (item.role != "Manager")
      );
      setUsers(employees_from_same_department);
    // });
  };



  // Get Achievements
  const getAchievements = async () => {
    AppServices._getAchievementsData().then((res) => {
      setAchievements(res);
    });
  };

  // List of benefits
  const getBenefitData = () => {
    AppServices._getBenefitsData().then((res) => {
      setBenefits(res);
    });
  };


  // Close Modal From Child
  const handleClose = async (payload) => {
    setTransferEmployee(null);
    console.log("payload emp", payload);
    if (payload.obj) {
      setIsLoading(true);
      transferNFTOnly(payload.user, payload.obj);
    }
  };

  // Transfer NFT Only For Employee
  const transferNFTOnly = async (nft, obj) => {
    const pvKey = CONSTANTS.PRIVATE_KEY_MANAGER;
    const fromWallet = Keypair.fromSecretKey(bs58.decode(pvKey));
    const nftPublicKey = nft.mint.address;
    const fromPublicKey = solana.publicKey;
    const toPublicKey = new PublicKey(obj.selectedUser);
    try {
      const associatedDestinationTokenAddr =
        await getOrCreateAssociatedTokenAccount(
          connection,
          fromWallet,
          nftPublicKey,
          toPublicKey,
          signTransaction
        );
      await sleep(1000);
      const fromTokenAccount = await getOrCreateAssociatedTokenAccount(
        connection,
        fromPublicKey,
        nftPublicKey,
        fromPublicKey,
        signTransaction
      );
      await sleep(1000);

      const transaction = await new solanaWeb3.Transaction().add(
        // Sending NFT
        createTransferInstruction(
          // imported from '@solana/spl-token'
          fromTokenAccount.address,
          associatedDestinationTokenAddr.address,
          fromPublicKey,
          1, // tokens have 6 decimals of precision so your amount needs to have the same
          [],
          TOKEN_PROGRAM_ID // imported from '@solana/spl-token'
        )
      );
      await sleep(1000);
      // set a recent block hash on the transaction to make it pass smoothly
      const latestBlockHash = await connection.getLatestBlockhash();
      transaction.recentBlockhash = await latestBlockHash.blockhash;

      // set who is the fee payer for that transaction
      transaction.feePayer = fromPublicKey;

      // sign the transaction using the signTransaction method that we got from the useWallet hook above
      const signed = await signTransaction(transaction);
      // send the signed transaction
      const signature = await connection.sendRawTransaction(signed.serialize());
      // wait for a confirmation to make sure it went to the blockchain (optional)
      await connection.confirmTransaction({
        signature,
        lastValidBlockHeight: latestBlockHash.lastValidBlockHeight,
        blockhash: latestBlockHash.blockhash,
      });
      await sendDataToDB(signature, nft?.name, obj);
    } catch (error) {
      setIsLoading(false);
      displayMessage("There is problem in RPC JSON API", "error");
      console.log("error>>", error);
    }
  };

  //  Send data to db
  const sendDataToDB = async (tx, nft, fields) => {
    const result = await connection.getTransaction(tx);
    let payload = {
      mint: result?.meta?.postTokenBalances[0]?.mint,
      fromWalletId: wallet.publicKey.toString(),
      toWalletId: fields.selectedUser,
      achievement: fields.achievement,
      message: fields.message,
      name: nft
    };
    console.log("Payload", payload);
    AppServices._postNFTData(payload).then((res) => {
      if (res) {
        setIsLoading(false);
        displayMessage("NFT Transfer Successfully");
         // Sent trigger to context update other info in app
         context.sendUpdateAction(Date.now());
        // Reload NFT Data
        // getWalletNFTData();
      }
    });
  };

  // Get Success/Error Message and Refresh Component
  const displayMessage = (msg, type) => {
    setMessage({ msg, type });
    setTimeout(() => {
      setMessage(null);
    }, 2000);
  };
  const getUserProfile = (walletId)=>{
    let userObj = allUsers.filter((item=>item.walletId == walletId));
    console.log("userObj",userObj)
    if(userObj.length > 0){
      return <Profile user={userObj[0]} />
    } else{
      return null

    }
  }

  return (
    <div className="flex flex-col relative justify-center items-center  mx-8 p-2 mt-8">
      <button
        onClick={() => getWalletNFTData()}
        className="absolute top-0 left-4 text-white bg-ing-orange hover:bg-yellow-800  font-medium rounded p-1 text-center mb-5 mt-2"
      >
        Refresh
      </button>
      <div className="flex flex-row  items-start justify-start">
        {/* <h2 className="text-xxl pt-2 mb-5 font-bold">My NFT's</h2> */}
        {message && <Messages msg={message} />}

        <div className="flex items-center justify-center text-2xl text-ing-blue font-bold mb-4">
          {type == "wall" ? "Wall of Fame" : "Received NFT Rewards"}
        </div>
      </div>

      <div>
        <div className="flex flex-col gap-8">
          {!nfts && (
            <div className="">
              <div
                colSpan={6}
                className="whitespace-nowrap font-medium text-zinc-900 dark:text-white text-center"
              >
                <Loader />
              </div>
            </div>
          )}

          {nfts?.length > 0 &&
            nfts.map((item, ind) => {
              //Only Minted NFT From UI
              if (item.json == null && nfts?.length == 1) {
                return (
                  <div key={`nft-table-${ind}`} className="">
                    <div
                      colSpan={6}
                      className="whitespace-nowrap font-medium text-zinc-900 dark:text-white text-center"
                    >
                      No Data Available.
                    </div>
                  </div>
                );
              }
              if (item?.json && item?.data) {
                return (
                  <div
                    key={`nft-table-${ind}`}
                    className="flex relative flex-row items-start justify-between rounded-md shadow-md bg-white p-4"
                  >
                    <div className="flex text-zinc-900 text-xl">
                      {
                        allUsers.filter(
                          (user) =>
                            user.walletId == item.mint.address.toString()
                        ).name
                      }
                    </div>
                    <img
                      className="absolute top-0 right-0 h-16 rounded-full"
                      src={
                        allUsers.filter(
                          (user) => user.walletId == item.address.toString()
                        ).name
                      }
                      alt=""
                    />
                    <div className="flex flex-col  font-medium text-zinc-900">
                      <div className="text-ing-orange text-lg hover:text-ing-blue font-semibold">
                        <a
                          target="_blank"
                          href={`https://solscan.io/token/${item?.mint?.address?.toString()}?cluster=devnet#metadata`}
                        >
                          {item.name || "NA"}
                        </a>
                      </div>
                      <img
                        className="h-96 rounded-md"
                        src={
                          item?.json
                            ? item.json?.image
                            : CONSTANTS.IMG_PLACEHOLDER
                        }
                        alt=""
                      />
                      <>
                      <div className="text-start mt-2 text-zinc-600 font-semibold">
                        Achievement {"  :  "}
                        <span className="text-zinc-900 ">
                          {item.data.achievement}
                        </span>
                      </div>
                      <div className="text-start text-zinc-600 font-semibold">
                        Congratulatory message {"  :  "}
                        <span className="text-zinc-900 ">
                          {item.data.message}
                        </span>
                      </div>
                      {type &&<div className="-ml-20 mt-3">{getUserProfile(item.data.toWalletId)}</div>}
                      </>
                      <div>
                        
                        </div>
                    </div>
                    <div className="flex flex-col mt-4">
                      <div className="flex flex-col items-center justify-center  text-zinc-900 ">
                        <div className="text-center mb-2 font-semibold">
                          Layers
                        </div>

                        <div className="flex flex-col">
                          {item?.json?.attributes.map((attr, index) => {
                            return (
                              <div
                                className="grid grid-cols-2 text-start"
                                key={index}
                              >
                                <div className="text-end mr-2">
                                  {attr.trait_type}
                                  {"  :  "}
                                </div>
                                <div className="text-ing-orange">
                                  {attr.value}
                                </div>
                              </div>
                            );
                          })}
                        </div>
                      </div>

                      <div className="flex  flex-col items-center justify-center font-medium text-zinc-900 mt-4">
                        <div className="text-center my-2 font-semibold">
                          Benefits
                        </div>

                        <div className="flex flex-col">
                          {item?.json?.benefits.map((attr, index) => {
                            return (
                              <div className="grid grid-cols-4" key={index}>
                                <div className="  text-end mr-2">
                                  {index + 1} : 
                                </div>
                                <div
                                  onClick={() => {
                                    if(type){
                                      return false;
                                    } else{
                                    setOpenModal(true);
                                    setBenefitModal(
                                      benefits?.filter(
                                        (benefit) => benefit.id == attr.benefit
                                      )[0]
                                    );
                                  }
                                  }}
                                  className="text-ing-orange col-span-3 cursor-pointer hover:font-bold"
                                >
                                  {attr.description}
                                </div>
                              </div>
                            );
                          })}
                        </div>
                      </div>
                    </div>
                  </div>
                );
              }
            })}
          {type != "wall" &&
            selfNfts?.length > 0 &&
            selfNfts.map((item, ind) => {
              //Only Minted NFT From UI
              if (item.json == null && selfNfts?.length == 1) {
                return (
                  <div key={`nft-table-${ind}`} className="">
                    <div
                      colSpan={6}
                      className="whitespace-nowrap font-medium text-zinc-900 dark:text-white text-center"
                    >
                      No Data Available.
                    </div>
                  </div>
                );
              }
              if (item.json) {
                return (
                  <div
                    key={`nft-table-${ind}`}
                    className="flex flex-row items-center justify-center rounded-md shadow-md bg-white p-4"
                  >
                    <div className="flex flex-col font-medium text-zinc-900">
                      <div className="text-ing-orange text-lg hover:text-ing-blue font-semibold">
                        <a
                          target="_blank"
                          href={`https://solscan.io/token/${item.mint.address.toString()}?cluster=devnet#metadata`}
                        >
                          {item.name || "NA"}
                        </a>
                      </div>

                      <img
                        className="h-96 rounded-md"
                        src={
                          item.json
                            ? item.json?.image
                            : CONSTANTS.IMG_PLACEHOLDER
                        }
                        alt=""
                      />
                      <div
                        className="mt-2 items-center w-36 justify-center text-center cursor-pointer hover:opacity-80 p-2 text-white rounded-md bg-gradient-to-r from-[#3f83f8] to-[#7E3AF2] "
                        onClick={() => setTransferEmployee(item)}
                      >
                        Transfer NFT
                      </div>
                    </div>
                    <div className="flex flex-col mt-4">
                      <div className="flex flex-col items-center justify-center  text-zinc-900 ">
                        <div className="text-center mb-2 font-semibold">
                          Layers
                        </div>

                        <div className="flex flex-col">
                          {item?.json?.attributes.map((attr, index) => {
                            return (
                              <div
                                className="grid grid-cols-2 text-start"
                                key={index}
                              >
                                <div className="text-end mr-2">
                                  {attr.trait_type}
                                  {"  :  "}
                                </div>
                                <div className="text-ing-orange">
                                  {attr.value}
                                </div>
                              </div>
                            );
                          })}
                        </div>
                      </div>

                      <div className="flex  flex-col items-center justify-center font-medium text-zinc-900 mt-4">
                        <div className="text-center my-2 font-semibold">
                          Benefits
                        </div>

                        <div className="flex flex-col">
                          {item?.json?.benefits.map((attr, index) => {
                            return (
                              <div className="grid grid-cols-4" key={index}>
                                <div className="  text-end mr-2">
                                  {index + 1} : {JSON.stringify(attr)}
                                </div>
                                <div
                                  onClick={() => {
                                    setOpenModal(true);
                                    setBenefitModal(
                                      benefits?.filter(
                                        (benefit) => benefit.id == attr.benefit
                                      )[0]
                                    );
                                  }}
                                  className="text-ing-orange col-span-3 cursor-pointer hover:font-bold"
                                >
                                  {attr.description}
                                </div>
                              </div>
                            );
                          })}
                        </div>
                      </div>
                    </div>
                  </div>
                );
              }
            })}
        </div>
      </div>
      <>
        <Modal show={openModal} size="lg" onClose={() => setOpenModal(false)}>
          <Modal.Header>{benefitModal.name}</Modal.Header>
          <Modal.Body>
              <p className="text-base leading-relaxed text-gray-400">
                {benefitModal.description} {benefitModal.id}
              </p>
            <div className="space-y-6 p-6">
            {benefitModal.id == "benefit_02" && availableTokens == 0 && (
              <p className="text-base leading-relaxed text-blue-400 text-center">
                You already minted the token.
              </p>
            )}
              {benefitModal.id == "benefit_01" && availableTokens > 0 && (
                <HomeNew
                  tokens={availableTokens}
                  txTimeout={6000}
                  rpcHost={rpcHost}
                  candyMachineId={candyMachineId}
                />
              )}
            </div>
          </Modal.Body>
        </Modal>
      </>
      {achievements && transferEmployee && (
        <TokensTransferModal
          users={users}
          achievements={achievements}
          user={transferEmployee}
          onClose={handleClose}
        />
      )}
      {isLoading && <Loader />}
    </div>
  );
};

export default UserNFTListing;
>>>>>>> ebff0fb8d0c5dd39848087e43a419e22236bac40
