/** @type {import('tailwindcss').Config} */
module.exports = {
  content: [
    "./src/**/*.{js,jsx,ts,tsx}",
    "./node_modules/flowbite-react/**/*.js",
  ],
  plugins: [require("flowbite/plugin")],
  theme: {
    extend: {
      container: {
        center: true,
        width: {
          DEFAULT: "80rem",
        },
      },
      colors: {
        transparent: "transparent",
        "ing-orange": "#ff6600",
        "ing-yellow": "#e4ad69",
        "ing-grey": "#aba195",
        "ing-blue-light": "#a8aecb",
        "ing-blue-medium": "#5a6a9a",
        "ing-grey-light": "#F7F7F7",
        "ing-line": "#b9bfdb",
        "ing-blue": "#000066",
      },
      fontFamily: {
        sans: ["INGMeWeb-Regular", "Arial,sans-serif"],
        regular: ["INGMeWeb-Regular", "Arial,sans-serif"],
        bold: ["INGMeWeb-Bold", "Arial,sans-serif"],
        serif: ["Arial,sans-serif", "serif"],
      },
    },
  },
};
