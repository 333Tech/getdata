const CONSTANTS = {
    // For syne coin
    // MINT_ADDRESS: "8Cc2oQ2mv8kU4T47FeMXGWMetfNzwbrBgbtpfbRhDa2m",
    // CANDY_MACHINE_ID: "8nTaW49bKG7ZxtXdG4w9BAc7LGyLMTCmBCY8a97HMnc2",

    // For syne NFTs
    MINT_ADDRESS: "AqoyMKVeh5wFWKFuuJYaQks7AFjTTQtAfmeHUFuBfWbU",
    CANDY_MACHINE_ID: "H9e8CL3gp2FgrqBgfbYik4hUpFKZBbeuN8JAnYkTa1m7",
    API_ENDPOINT: "https://ap-south-1.aws.data.mongodb-api.com/app/application-0-apmyv/endpoint/",
    SOLANA_RPC: "https://api.devnet.solana.com",
    SOLANA_RPC_HOST: "https://api.devnet.solana.com",
    SOLANA_NETWORK: "devnet",
    TOKEN_METADATA_PROGRAM: "metaqbxxUerdq28cj1RbAWkYQm3ybzjb6a8bt518x1s",
    CANDY_MACHINE_V2_PROGRAM: "cndy3Z4yapfJBmL3ShUp5exZKqR3z33thTzeNMm2gRZ",
    PRIVATE_KEY_MANAGER: "idxg4GJitWYdBJgEcEBoQJUhLKK6UKxAkxvRjVY8g2pC3czEwuLEbvYiQ3ZutXfBDEzaHRwf6kc5apPwks2dGrv",
    // PRIVATE_KEY_MANAGER: "4RwW8LhdmGJBaXAb5X2kfgwAcvzcrUq96HhibVhKYok9zWwApD4zWcrScGuNeHQwZeqDswHeCjmTqLEnVNH3Uf1i",
    IMG_PLACEHOLDER: "/assets/images/placeholder-token.jpg",
};

export default CONSTANTS;