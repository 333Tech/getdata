import CONSTANTS from './Constants';
const HOST_URL = "/"

function fetchStatusHandler(response) {
    if (response.status === 200) {
        return response;
    } else {
        // throw new Error(response.statusText);
        console.log("Error", response)
    }
}

const AppServices = {
    _getUsersData: () => {
        let url = `${CONSTANTS.API_ENDPOINT}user`;
        // let url = `${HOST_URL}data/users.json`;
        return fetch(url, {
            method: 'GET',
        }).then(
            fetchStatusHandler
        ).then(
            fetchStatusHandler
        ).then(res => res.json());
    },
    _getTeamsData: () => {
        let url = `${HOST_URL}data/teams.json`;
        return fetch(url, {
            method: 'GET',
        }).then(
            fetchStatusHandler
        ).then(
            fetchStatusHandler
        ).then(res => res.json());
    },
    _getAchievementsData: () => {
        let url = `${HOST_URL}data/achivements.json`;
        return fetch(url, {
            method: 'GET',
        }).then(
            fetchStatusHandler
        ).then(
            fetchStatusHandler
        ).then(res => res.json());
    },
    _getBenefitsData: () => {
        let url = `${HOST_URL}data/benefits.json`;
        return fetch(url, {
            method: 'GET',
        }).then(
            fetchStatusHandler
        ).then(
            fetchStatusHandler
        ).then(res => res.json());
    },
    _getNFTData: () => {
        let url = `${CONSTANTS.API_ENDPOINT}nfts`;
        return fetch(url, {
            method: 'GET',
        }).then(
            fetchStatusHandler
        ).then(
            fetchStatusHandler
        ).then(res => res.json());
    },
    _postNFTData: (payload) => {
        let url = `${CONSTANTS.API_ENDPOINT}nfts`;
        return fetch(url, {
            method: 'POST',
            body: JSON.stringify(payload)
        }).then(
            fetchStatusHandler
        ).then(
            fetchStatusHandler
        ).then(res => res.json());
    },
    _getWalletNFTData: (walletId) => {
        let url = `${CONSTANTS.API_ENDPOINT}nfts?walletId=${walletId}`;
        return fetch(url, {
            method: 'GET',
        }).then(
            fetchStatusHandler
        ).then(
            fetchStatusHandler
        ).then(res => res.json());
    },


}

export default AppServices;