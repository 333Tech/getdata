import React, {Component, createContext} from 'react';
 const Context = createContext();
 export class ContextAppStore extends Component {
    state = {timestamp: null};
    _updateUIData = (parent)=>{
        console.log("trigger context component");
        this.setState({timestamp: parent});
    };

    render(){
        return(
            <Context.Provider
                value={{...this.state, sendUpdateAction: this._updateUIData}}>
                {this.props.children}
            </Context.Provider>
        )
    }
 }
 export const AppConsumer = Context.Consumer;
 export default Context;