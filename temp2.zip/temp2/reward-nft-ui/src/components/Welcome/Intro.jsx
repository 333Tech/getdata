import React, { useState, useEffect } from "react";
import { WalletMultiButton } from "@solana/wallet-adapter-react-ui";
import { Modal } from "flowbite-react";
import Logo from "../Header/Logo";

const Intro = () => {
  const [openModal, setOpenModal] = useState(false);
  sessionStorage.clear();

  return (
    <div>
      <div className="flex flex-col items-center mt-8 ">
        <Logo />
      </div>
      <div className="flex justify-center flex-col max-w-xl mx-auto p-10 mt-8 text-zinc-900">
        <div className="flex flex-col justify-center text-center btn-group-items">
          <button
            onClick={() => setOpenModal(true)}
            className="text-white block w-full bg-gradient-to-br from-purple-600 to-blue-500 hover:bg-gradient-to-bl focus:ring-4 focus:ring-blue-300 dark:focus:ring-blue-800 focus:!ring-2 group flex h-min items-center justify-center p-0.5 text-center font-medium focus:z-10 rounded-lg"
            type="button"
          >
            <span className="flex items-center rounded-md text-base px-6 py-3">
              Create Wallet
            </span>
          </button>
          <div className="py-2 text-center leading-relaxed">Or</div>
          <WalletMultiButton />
        </div>
        <>
          <Modal show={openModal} size="lg" onClose={() => setOpenModal(false)}>
            <Modal.Header>How to Create Wallet?</Modal.Header>
            <Modal.Body>
              <div className="space-y-6 p-6">
                <p className="text-base leading-relaxed text-gray-400">
                  A crypto wallet is a device or application that stores a
                  collection of keys and can be used to send, receive, and track
                  ownership of cryptocurrencies. Wallets can take many forms. A
                  wallet might be a directory or file in your computer's file
                  system, a piece of paper, or a specialized device called a
                  hardware wallet. There are also various smartphone apps and
                  computer programs that provide a user-friendly way to create
                  and manage wallets.
                </p>
              </div>
            </Modal.Body>
          </Modal>
        </>
      </div>
    </div>
  );
};

export default Intro;
