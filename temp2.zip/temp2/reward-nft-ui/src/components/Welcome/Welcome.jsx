import React  from "react";
import { useWallet } from "@solana/wallet-adapter-react";
import Intro from "./Intro";
import Dashboard from "../Dashboard/Dashboard";
const Welcome = () => {
  const wallet = useWallet();
  return (
    <div>
      {!wallet?.connected && <Intro />}
      {wallet?.connected && <Dashboard />}
    </div>
  );
};
export default Welcome;
