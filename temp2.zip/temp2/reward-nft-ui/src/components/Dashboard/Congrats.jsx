import React from "react";

const Congrats = ({ tokens }) => {
  return (
    <div className="mt-4 bg-emerald-500 rounded-md p-1 text-white">
      <span className="text-md">
        <span className="font-bold">Congratulations !</span> You have received{" "}
        {tokens} NFT rewards from your manager.
      </span>
    </div>
  );
};

export default Congrats;
