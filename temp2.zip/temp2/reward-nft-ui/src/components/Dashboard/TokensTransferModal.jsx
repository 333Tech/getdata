import React, { useEffect, useState } from "react";
import {
  Button,
  Label,
  Modal,
  Select,
  Table,
  Textarea,
  TextInput,
} from "flowbite-react";

const TokensTransferModal = (props) => {
  const [open, setOpen] = useState(false);
  const [achievement, setAchievement] = useState("");
  const [message, setMessage] = useState("");
  const [selectedUser, setSelectedUser] = useState("");
  const _handleClose = (isClose) => {
    setOpen(false);
    if (isClose) {
      let obj = null;
      props.onClose({ user: props.user, obj });
    } else {
      console.log("achivement", achievement);
      let obj = {
        achievement,
        selectedUser,
        message,
      };
      props.onClose({ user: props.user, obj });
    }
  };

  useEffect(() => {
    props.user ? setOpen(true) : setOpen(false);
  }, [props.user]);

  return (
    <>
      <Modal
        show={open}
        size="md"
        popup={true}
        onClose={() => _handleClose("close")}
      >
        <Modal.Header />
        <Modal.Body>
          {props.user && (
            <div className="space-y-6 px-6 pb-4 sm:pb-6 lg:px-8 xl:pb-8">
              <h3 className="text-xl font-medium text-gray-900 dark:text-white">
                Transfer NFT
              </h3>
              {props.users && (
                <div>
                  <div className="mb-2 block">
                    <Label htmlFor="user" value="Select Wallet" />
                  </div>
                  <Select
                    required={true}
                    value={selectedUser}
                    id="user"
                    onChange={(e) => setSelectedUser(e.target.value)}
                  >
                    <option value="">Please Select</option>
                    {props.users?.map((itm, ind) => {
                      return (
                        <option key={`user-${ind}`} value={itm.walletId}>
                          {itm.name} - {itm.walletId}
                        </option>
                      );
                    })}
                  </Select>
                </div>
              )}
              <div>
                <div className="mb-2 block">
                  <Label htmlFor="achievements" value="Select Achievement" />
                </div>
                <Select
                  required={true}
                  value={achievement}
                  id="achievements"
                  onChange={(e) => setAchievement(e.target.value)}
                >
                  <option value="">Please Select</option>
                  {props.achievements?.map((itm, ind) => {
                    return (
                      <option key={`achv-${ind}`} value={itm.name}>
                        {itm.name}
                      </option>
                    );
                  })}
                </Select>
              </div>
              <div>
                <div className="mb-2 block">
                  <Label htmlFor="message" value="Message" />
                </div>
                <Textarea
                  value={message}
                  onChange={(e) => setMessage(e.target.value)}
                />
              </div>
              <div className="w-full ">
                <Button
                  disabled={
                    achievement == "" || selectedUser == "" || message == ""
                  }
                  onClick={() => _handleClose()}
                >
                  Transfer
                </Button>
              </div>
            </div>
          )}
        </Modal.Body>
      </Modal>
    </>
  );
};

export default TokensTransferModal;
