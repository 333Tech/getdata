import React, { useState, useEffect, useMemo, useContext } from "react";
import AppServices from "../../services/Api";
import Loader from "../Common/Loader";
import TokensTransferModal from "./TokensTransferModal";
import * as bs58 from "bs58";
import Messages from "../Common/Messages";
import CONSTANTS from "../../services/Constants";
import { useWallet } from "@solana/wallet-adapter-react";
import { Metaplex, walletAdapterIdentity } from "@metaplex-foundation/js";
import * as solanaWeb3 from "@solana/web3.js";
import { PublicKey, Keypair } from "@solana/web3.js";
import {
  getOrCreateAssociatedTokenAccount,
  TOKEN_PROGRAM_ID,
  createTransferInstruction,
} from "@solana/spl-token";
import * as splToken from "@solana/spl-token";
import AppContext from "../../context/AppContext";

const ManagerNFTListing = ({ connection, user, allUsers }) => {
  const [users, setUsers] = useState(null);
  const [nfts, setNfts] = useState(null);
  const [isLoading, setIsLoading] = useState(false);
  const [achievements, setAchievements] = useState(null);
  const [transferEmployee, setTransferEmployee] = useState(null);
  const wallet = useWallet();
  const [message, setMessage] = useState(null);
  const { publicKey, signTransaction } = useWallet();
  const context = useContext(AppContext);

  const solana = useMemo(() => {
    if (
      !wallet ||
      !wallet.publicKey ||
      !wallet.signAllTransactions ||
      !wallet.signTransaction
    ) {
      return;
    }
    return {
      publicKey: wallet.publicKey,
      signAllTransactions: wallet.signAllTransactions,
      signTransaction: wallet.signTransaction,
    };
  }, [wallet]);

  useEffect(() => {
    getUsers();
    getAchievements();
  }, []);

  useEffect(() => {
    getWalletNFTData();
  }, [context.timestamp]);

  // Get Wallet NFT Data
  const getWalletNFTData = async () => {
    const metaplex = await Metaplex.make(connection).use(
      walletAdapterIdentity(solana)
    );
    setIsLoading(true);
    // const candyMachineObj = await metaplex.candyMachines();
    const data = await metaplex
      .nfts()
      .findAllByOwner({ owner: wallet.publicKey })
      .run();
    async function getMetaDataNFT() {
      let array = [];
      //This loop will wait for each next() to pass the next iteration
      for (var i = 0; i < data.length; i++) {
        array[i] = await metaplex
          .nfts()
          .findByMint({ mintAddress: data[i].mintAddress })
          .run();
      }
      setNfts(array);
      setIsLoading(false);
    }
    await getMetaDataNFT();
  };

  // Get List of Users
  const getUsers = async () => {
    // AppServices._getUsersData().then((res) => {
    const employees_from_same_department = allUsers.filter(
      (item) =>
        (item.department == user?.department) & (item.name != user?.name)
    );

    setUsers(employees_from_same_department);
    // });
  };

  // Get List of Achivements
  const getAchievements = async () => {
    AppServices._getAchievementsData().then((res) => {
      setAchievements(res);
    });
  };

  // Close Modal From Child
  const handleClose = async (payload) => {
    console.log("payload", payload);
    if (payload.obj) {
      setIsLoading(true);
      await transferTokenAndNFT(payload.user, payload.obj);
    }
    setTransferEmployee(null);
  };

  const transferToken = async (toPublicKey) => {
    const pvKey = CONSTANTS.PRIVATE_KEY_MANAGER;
    const fromWallet = Keypair.fromSecretKey(bs58.decode(pvKey));
    // const toPublicKey = wallet.publicKey;
    console.log("toPublicKey", toPublicKey);
    try {
      // Send Whitelist token with Minting
      const tokenAddress = CONSTANTS.MINT_ADDRESS;
      const whiteListTokenPublicKey = new solanaWeb3.PublicKey(tokenAddress);
      const fromTokenAccount = await getOrCreateAssociatedTokenAccount(
        connection,
        fromWallet,
        whiteListTokenPublicKey,
        fromWallet.publicKey
      );
      const associatedDestinationTokenAddr =
        await getOrCreateAssociatedTokenAccount(
          connection,
          fromWallet,
          whiteListTokenPublicKey,
          toPublicKey
        );

      const signature = await splToken.transfer(
        connection,
        fromWallet,
        fromTokenAccount.address,
        associatedDestinationTokenAddr.address,
        fromWallet.publicKey, // or pass fromPublicKey
        1 // tokens have 6 decimals of precision so your amount needs to have the same
      );

      console.log("signature", signature);
      console.log("Token Transfer Successfully");
      // Sent trigger to context update other info in app
      // context.sendUpdateAction(Date.now());
    } catch (error) {
      console.log("There is problem in RPC JSON API", "error");
      console.log("error>>", error);
    }
  };

  // Transfer Whitelist Token With NFT For Manager
  const transferTokenAndNFT = async (nft, obj) => {
    const pvKey = CONSTANTS.PRIVATE_KEY_MANAGER;
    const fromWallet = Keypair.fromSecretKey(bs58.decode(pvKey));
    console.log("nft.mint.address", nft);
    const nftPublicKey = nft.mint.address;
    const fromPublicKey = wallet.publicKey;
    const toPublicKey = new PublicKey(obj.selectedUser);
    try {
      const fromTokenAccount = await getOrCreateAssociatedTokenAccount(
        connection,
        fromPublicKey,
        nftPublicKey,
        fromPublicKey,
        signTransaction
      );
      await sleep(1000);
      console.log("fromTokenAccount", fromTokenAccount);
      const associatedDestinationTokenAddr =
        await getOrCreateAssociatedTokenAccount(
          connection,
          fromWallet,
          nftPublicKey,
          toPublicKey,
          signTransaction
        );
      console.log(
        "associatedDestinationTokenAddr",
        associatedDestinationTokenAddr
      );
      // // Send Whitelist token with Minting
      // const tokenAddress = CONSTANTS.MINT_ADDRESS;
      // const whiteListTokenPublicKey = new solanaWeb3.PublicKey(tokenAddress);
      // const fromTokenAccount2 = await getOrCreateAssociatedTokenAccount(
      //   connection,
      //   fromPublicKey,
      //   whiteListTokenPublicKey,
      //   fromPublicKey,
      //   signTransaction
      // );
      // console.log("fromTokenAccount2", fromTokenAccount2);
      // await sleep(1000);
      // const associatedDestinationTokenAddr2 =
      //   await getOrCreateAssociatedTokenAccount(
      //     connection,
      //     fromWallet,
      //     whiteListTokenPublicKey,
      //     toPublicKey,
      //     signTransaction
      //   );
      // console.log(
      //   "associatedDestinationTokenAddr2",
      //   associatedDestinationTokenAddr2
      // );

      const transaction = await new solanaWeb3.Transaction().add(
        // Sending NFT
        createTransferInstruction(
          // imported from '@solana/spl-token'
          fromTokenAccount.address,
          associatedDestinationTokenAddr.address,
          fromPublicKey,
          1, // tokens have 6 decimals of precision so your amount needs to have the same
          [],
          TOKEN_PROGRAM_ID // imported from '@solana/spl-token'
        )
        // // Sending Token
        // createTransferInstruction(
        //   // imported from '@solana/spl-token'
        //   fromTokenAccount2.address,
        //   associatedDestinationTokenAddr2.address,
        //   fromPublicKey,
        //   1, // tokens have 6 decimals of precision so your amount needs to have the same
        //   [],
        //   TOKEN_PROGRAM_ID // imported from '@solana/spl-token'
        // )
      );

      // set a recent block hash on the transaction to make it pass smoothly
      const latestBlockHash = await connection.getLatestBlockhash();
      transaction.recentBlockhash = await latestBlockHash.blockhash;
      // set who is the fee payer for that transaction
      transaction.feePayer = fromPublicKey;
      console.log("transaction", transaction);
      // sign the transaction using the signTransaction method that we got from the useWallet hook above
      const signed = await signTransaction(transaction);
      // send the signed transaction
      const signature = await connection.sendRawTransaction(signed.serialize());
      // wait for a confirmation to make sure it went to the blockchain (optional)
      await connection.confirmTransaction({
        signature,
        lastValidBlockHeight: latestBlockHash.lastValidBlockHeight,
        blockhash: latestBlockHash.blockhash,
      });
      await sendDataToDB(signature, nft?.name, obj);
    } catch (error) {
      setIsLoading(false);
      displayMessage("There is problem in RPC JSON API", "error");
      console.log("error>>", error);
    }
  };
  const sleep = (ms) => {
    return new Promise((resolve) => setTimeout(resolve, ms));
  };

  //  Send data to db
  const sendDataToDB = async (tx, nft, fields) => {
    console.log("fields", fields);
    transferToken(new solanaWeb3.PublicKey(fields.selectedUser));
    const result = await connection.getTransaction(tx);
    let payload = {
      mint: result?.meta?.postTokenBalances[0]?.mint,
      fromWalletId: wallet.publicKey.toString(),
      toWalletId: fields.selectedUser,
      achievement: fields.achievement,
      message: fields.message,
      name: nft,
    };
    console.log("Payload", payload);
    AppServices._postNFTData(payload).then((res) => {
      if (res) {
        setIsLoading(false);

        displayMessage("NFT Transfer Successfully");
        // Sent trigger to context update other info in app
        context.sendUpdateAction(Date.now());
        // Reload NFT Data
        // getWalletNFTData();
      }
    });
  };

  // Get Success/Error Message and Refresh Component
  const displayMessage = (msg, type) => {
    setMessage({ msg, type });
    setTimeout(() => {
      setMessage(null);
    }, 2000);
  };

  return (
    <div className="flex flex-col mx-8 p-2 mt-16 min-w-2xl">
      <div className="flex flex-row relative items-center justify-center left">
        {/* <h2 className="text-xxl pt-2 mb-5 font-bold">My NFT's</h2> */}
        {message && <Messages msg={message} />}
        {nfts?.length > 1 && (
          <button
            onClick={() => getWalletNFTData()}
            className="absolute left-0 text-white bg-ing-orange hover:bg-yellow-800  font-medium rounded p-1 text-center mb-5 mt-2"
          >
            Refresh
          </button>
        )}
        <div className="flex items-center justify-center text-2xl text-ing-blue font-bold mb-4">
          Minted NFTs
        </div>
      </div>

      <div>
        <div className="flex flex-col gap-8">
          {!nfts && (
            <div className="">
              <div
                colSpan={6}
                className="whitespace-nowrap font-medium text-zinc-900 dark:text-white text-center"
              >
                Loading...
              </div>
            </div>
          )}

          {nfts?.length > 0 &&
            nfts.map((item, ind) => {
              //Only Minted NFT From UI
              if (item.json == null && nfts?.length == 1) {
                return (
                  <div key={`nft-table-${ind}`} className="">
                    <div
                      colSpan={6}
                      className="whitespace-nowrap font-medium text-zinc-900 dark:text-white text-center"
                    >
                      No Data Available.
                    </div>
                  </div>
                );
              }
              if (item.json) {
                return (
                  <div
                    key={`nft-table-${ind}`}
                    className="flex flex-row items-center justify-center rounded-md shadow-md bg-white p-2"
                  >
                    <div className="flex flex-col font-medium text-zinc-900">
                      <div className="text-ing-orange text-lg font-semibold">
                        <a
                          target="_blank"
                          href={`https://solscan.io/token/${item.mint.address.toString()}?cluster=devnet#metadata`}
                        >
                          {item.name || "NA"}
                        </a>
                      </div>
                      <img
                        className="h-96 rounded-md"
                        src={
                          item.json
                            ? item.json?.image
                            : CONSTANTS.IMG_PLACEHOLDER
                        }
                        alt=""
                      />
                      <div
                        onClick={() => setTransferEmployee(item)}
                        className="flex text-white mt-4 text-center items-center justify-center font-bold p-1 bg-gradient-to-r from-[#3f83f8] to-[#7E3AF2] cursor-pointer w-36 rounded-md"
                      >
                        Transfer NFT
                      </div>
                    </div>
                    <div className="flex flex-col mt-4">
                      <div className="flex flex-col items-center justify-center  text-zinc-900 ">
                        <div className="text-center mb-2 font-semibold">
                          Layers
                        </div>

                        <div className="flex flex-col">
                          {item?.json?.attributes.map((attr, index) => {
                            return (
                              <div
                                className="grid grid-cols-2 text-start"
                                key={index}
                              >
                                <div className="text-end mr-2">
                                  {attr.trait_type}
                                  {"  :  "}
                                </div>
                                <div className="text-ing-orange">
                                  {attr.value}
                                </div>
                              </div>
                            );
                          })}
                        </div>
                      </div>

                      <div className="flex  flex-col items-center justify-center font-medium text-zinc-900 mt-4">
                        <div className="text-center my-2 font-semibold">
                          Benefits
                        </div>

                        <div className="flex flex-col">
                          {item?.json?.benefits.map((attr, index) => {
                            return (
                              <div className="grid grid-cols-4" key={index}>
                                <div className="  text-end mr-2">
                                  {index + 1} :
                                </div>
                                <div className="text-ing-orange col-span-3 ">
                                  {attr.description}
                                </div>
                              </div>
                            );
                          })}
                        </div>
                      </div>
                    </div>
                  </div>
                );
              }
            })}
        </div>
      </div>

      {achievements && transferEmployee && (
        <TokensTransferModal
          users={users}
          achievements={achievements}
          user={transferEmployee}
          onClose={handleClose}
        />
      )}
      {isLoading && <Loader />}
    </div>
  );
};

export default ManagerNFTListing;
