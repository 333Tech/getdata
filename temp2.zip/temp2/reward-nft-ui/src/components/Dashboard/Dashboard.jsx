import React, { useEffect, useState, useContext } from "react";
import * as anchor from "@project-serum/anchor";
import * as solanaWeb3 from "@solana/web3.js";

import CONSTANTS from "../../services/Constants";
import ManagerNFTListing from "./ManagerNFTListing";
import Home from "../MintNFT/Home.tsx";
import CongratsMessage from "./Congrats";
import { useWallet } from "@solana/wallet-adapter-react";
import { TOKEN_PROGRAM_ID } from "@solana/spl-token";
import UserNFTListing from "./UserNFTListing";
import {  Navigate } from "react-router-dom";
import AppServices from "../../services/Api";
import Header from "../Header/Header";
import AppContext from '../../context/AppContext';

const Dashboard = () => {
  const [userData, setUserData] = useState([]);
  const [users, setUsers] = useState(null);
  const [availableTokens, setAvailableTokens] = useState(0);
  const rpcHost =
    CONSTANTS.SOLANA_RPC_HOST ?? anchor.web3.clusterApiUrl("devnet");
  const connection = new solanaWeb3.Connection(rpcHost, "confirmed");
  const wallet = useWallet();
  const context = useContext(AppContext);

  // Get CandyMachine ID
  const getCandyMachineId = () => {
    try {
      return new anchor.web3.PublicKey(CONSTANTS.CANDY_MACHINE_ID);
    } catch (e) {
      console.log("Failed to construct CandyMachineId", e);
      return undefined;
    }
  };
  const candyMachineId = getCandyMachineId();
  // Get Whitelist Token Balance
  const getTokenCount = async () => {
    (async () => {
      const MY_WALLET_ADDRESS = wallet.publicKey.toString();
      const accounts = await connection.getParsedProgramAccounts(
        TOKEN_PROGRAM_ID, // new PublicKey("TokenkegQfeZyiNwAJbNbGKPFXCWuBvf9Ss623VQ5DA")
        {
          filters: [
            {
              dataSize: 165, // number of bytes
            },
            {
              memcmp: {
                offset: 32, // number of bytes
                bytes: MY_WALLET_ADDRESS, // base58 encoded string
              },
            },
          ],
        }
      );
      async function getWLTokenAccountBalance() {
        //This loop will wait for each next() to pass the next iteration
        for (var i = 0; i < accounts.length; i++) {
          let tokenAccountMintAddr = accounts[i].account.data.parsed.info.mint;
          if (tokenAccountMintAddr == CONSTANTS.MINT_ADDRESS) {
            let balance =
              accounts[i].account.data.parsed.info.tokenAmount.uiAmount;
            setAvailableTokens(balance);
          }
        }
      }
      await getWLTokenAccountBalance();
    })();
  };

  useEffect(() => {
    getUsers();
  }, [context.timestamp]);

  const getUsers = async () => {
    AppServices._getUsersData().then((res) => {
      console.log(res);
      setUsers(res);
      if (res.length > 0) {
        const userObj = res.filter(
          (item) => item.walletId == wallet?.publicKey.toString()
        );
        if (userObj && userObj.length > 0) {
          setUserData(userObj[0]);
        } else {
          setUserData(null);
        }
      }
      getTokenCount();
    });
  };

  return (
    <>
      <Header tokens={availableTokens} userData={userData} />
      <div className="flex flex-col items-center justify-center">
        {userData ? (
          <>
            {availableTokens != 0 && userData?.role == "Employee" && (
              <CongratsMessage tokens={availableTokens} />
            )}

            {/* MINTing NFT COMPONENT */}
            {userData?.role == "Manager" && candyMachineId && (
              <>
                {availableTokens > 0 ? (
                  <Home
                    tokens={availableTokens}
                    txTimeout={6000}
                    rpcHost={rpcHost}
                    candyMachineId={candyMachineId}
                  />
                ) : (
                  <div>No Tokens Available</div>
                )}
              </>
            )}

            {users && userData?.role == "Employee" && (
              <UserNFTListing
                user={userData}
                allUsers={users}
                availableTokens={availableTokens}
                selectedUser={userData}
                connection={connection}
              />
            )}
            {userData?.role == "Manager" && (
              <>
                <ManagerNFTListing  allUsers={users} user={userData} connection={connection} />
              </>
            )}
          </>
        ) : (
          <>
            <Navigate replace to="/mint" />
          </>
        )}
      </div>
    </>
  );
};

export default Dashboard;
