import React, { useEffect, useState, useMemo } from "react";
import Connect from "./Connect";
import Logo from "./Logo";
import Navigation from "./Navigation";
import Profile from "./Profile";
import { useWallet } from "@solana/wallet-adapter-react";
import * as solanaWeb3 from "@solana/web3.js";
import { LAMPORTS_PER_SOL } from "@solana/web3.js";
import CONSTANTS from "../../services/Constants";
import AppServices from "../../services/Api";

import { Metaplex, walletAdapterIdentity } from "@metaplex-foundation/js";



const Header = ({ tokens }) => {
  const [nfts, setNfts] = useState(null);
  const wallet = useWallet();
  const walletId = wallet.publicKey?.toString();
  const connection = new solanaWeb3.Connection(
    CONSTANTS.SOLANA_RPC,
    "confirmed"
  );

  const solana = useMemo(() => {
    if (
      !wallet ||
      !wallet.publicKey ||
      !wallet.signAllTransactions ||
      !wallet.signTransaction
    ) {
      return;
    }
    return {
      publicKey: wallet.publicKey,
      signAllTransactions: wallet.signAllTransactions,
      signTransaction: wallet.signTransaction,
    };
  }, [wallet]);

  const [user, setUser] = useState(null);
  useEffect(() => {
    walletId && GetUsersProfile();
  }, [walletId]);

  const GetUsersProfile = async () => {
    AppServices._getUsersData().then((res) => {
      sessionStorage.setItem("users", JSON.stringify(res));
      const userObj = res.filter((item) => item.walletId == walletId);
      sessionStorage.setItem("selectedUser", JSON.stringify(userObj[0]));
      setUser(userObj[0]);
    });
  };

  const [accountBalance, setAccountBalance] = useState(null);
  const [message, setMessage] = useState(null);
  useEffect(() => {
    getBalance();
    getWalletNFTData();
  }, [tokens]);

  // Get updated balance
  const getBalance = async () => {
    const lamports = await connection
      .getBalance(wallet.publicKey)
      .catch((err) => {
        console.error(`Error: ${err}`);
      });
    let balSol = lamports / LAMPORTS_PER_SOL;
    if (balSol == 0) {
      getAirdrop();
    }
    setAccountBalance((Math.round(balSol * 100) / 100).toFixed(2)); // In the Solana Network, a lamport is the smallest unit: 1 SOL = 1 billion lamports.
  };
  //Add sol in wallet
  const getAirdrop = async () => {
    try {
      var airdropSignature = await connection.requestAirdrop(
        wallet.publicKey,
        LAMPORTS_PER_SOL
      );
      await connection.confirmTransaction(airdropSignature);
      await getBalance();
      displayMessage("Sols added successfully");
    } catch (error) {
      displayMessage("There is problem with Airdrop Sol", "error");
    }
  };

  const getWalletNFTData = async () => {
    const metaplex = await Metaplex.make(connection).use(
      walletAdapterIdentity(solana)
    );
    // const candyMachineObj = await metaplex.candyMachines();
    const data = await metaplex
      .nfts()
      .findAllByOwner({ owner: wallet.publicKey })
      .run();
    async function getMetaDataNFT() {
      let array = [];
      //This loop will wait for each next() to pass the next iteration
      for (var i = 0; i < data.length; i++) {
        array[i] = await metaplex
          .nfts()
          .findByMint({ mintAddress: data[i].mintAddress })
          .run();
      }
      setNfts(array);
    }
    await getMetaDataNFT();
  };

  // Get Success/Error Message and Refresh Component
  const displayMessage = (msg, type) => {
    setMessage({ msg, type });
    setTimeout(() => {
      setMessage(null);
    }, 2000);
  };

  return (
    <header className="flex flex-row items-center justify-between mt-2">
      <Logo />
      <Navigation />
      <div className="flex flex-row space-x-4">
        {wallet?.connected && <Profile user={user} />}
        <div className="flex items-start justify-center flex-col text-zinc-900 font-semibold">
          <div className="cursor-pointer" onClick={getAirdrop}>
            Account Balance :{" "}
            <span className="font-bold text-ing-orange">
              {accountBalance} SOL
            </span>
          </div>
          {user?.role == "Manager" ? (
            <div>
              Whitelist Tokens :{" "}
              <span className="font-bold text-ing-orange">{tokens}</span>
            </div>
          ) : (
            <div>
              NFT Rewards :{" "}
              <span className="font-bold text-ing-orange">{nfts?.length}</span>
            </div>
          )}
        </div>
        {/* <button
          onClick={getAirdrop}
          className="text-white bg-ing-orange hover:bg-yellow-800  font-medium rounded-full text-xs px-5 text-center mb-3"
        >
          Add Fund in Wallet
        </button> */}
        {wallet?.connected && <Connect />}
      </div>
    </header>
  );
};

export default Header;
