
const Navigation = () => {
    return <nav className="col-span-5">
        {/* Menu Navigation */}
    </nav>
  }
   
  export default Navigation;
  