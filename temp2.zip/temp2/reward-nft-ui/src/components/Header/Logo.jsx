const Logo = () => {
  return (
    <div className="flex">
      <img width={"250px"} height={"10px"} src="/assets/images/logo.png" alt="" />
    </div>
  );
};

export default Logo;
