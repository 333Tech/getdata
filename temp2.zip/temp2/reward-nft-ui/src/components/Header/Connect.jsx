import { WalletMultiButton } from "@solana/wallet-adapter-react-ui";
const Connect = () => {
  return (
    <div className="flex items-center">
      <WalletMultiButton />
    </div>
  );
};

export default Connect;
