const Profile = ({ user }) => {
  return (
    <div className="flex items-center justify-center space-x-2">
      {user && (
        <>
          <div className="w-16">
            <img
              className="rounded-full"
              // src={`/assets/images/profile_pics/${user.image}.jpg`}
              src={`/assets/images/profile_pics/defualt.png`}
            />
          </div>

          <div className="">
            <div className="text-zinc-900 font-bold">
              {user?.name}{" "}
              {user?.role == "Manager" && <span>({user?.role})</span>}
            </div>
            <div className="text-zinc-700 font-semibold text-sm">
              {user?.department}
            </div>
          </div>
        </>
      )}
    </div>
  );
};

export default Profile;
