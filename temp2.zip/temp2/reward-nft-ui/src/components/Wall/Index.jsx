import React, {useEffect, useState} from 'react'
import * as anchor from "@project-serum/anchor";
import * as solanaWeb3 from '@solana/web3.js';
import UserNFTListing from '../Dashboard/UserNFTListing';
import CONSTANTS from '../../services/Constants';
import AppServices from '../../services/Api';

const WallPage = () => {
  const rpcHost = CONSTANTS.SOLANA_RPC_HOST ?? anchor.web3.clusterApiUrl("devnet");
  const connection = new solanaWeb3.Connection(rpcHost, "confirmed");
  const [users, setUsers] = useState(null)
  const getAllUsers = async () => {
    AppServices._getUsersData().then((res) => {
      setUsers(res);
    });
};
useEffect(() => {
  getAllUsers()
}, [])

  return (
    <div>
      {connection && <UserNFTListing allUsers={users} connection={connection} type='wall' />}
    </div>
  )
}
export default WallPage;