import React, { useEffect, useState } from "react";
import { useWallet } from "@solana/wallet-adapter-react";
import * as solanaWeb3 from "@solana/web3.js";
import { LAMPORTS_PER_SOL } from "@solana/web3.js";
import { Badge } from "flowbite-react";
import Messages from "./Messages";
import CONSTANTS from "../../services/Constants";

const Stats = ({ userData, tokens }) => {
  const connection = new solanaWeb3.Connection(
    CONSTANTS.SOLANA_RPC,
    "confirmed"
  );
  const wallet = useWallet();
  const [accountBalance, setAccountBalance] = useState(null);
  const [message, setMessage] = useState(null);
  useEffect(() => {
    getBalance();
  }, []);

  // Get updated balance
  const getBalance = async () => {
    const lamports = await connection
      .getBalance(wallet.publicKey)
      .catch((err) => {
        console.error(`Error: ${err}`);
      });
    let balSol = lamports / LAMPORTS_PER_SOL;
    if (balSol == 0) {
      getAirdrop();
    }
    setAccountBalance(balSol); // In the Solana Network, a lamport is the smallest unit: 1 SOL = 1 billion lamports.
  };
  //Add sol in wallet
  const getAirdrop = async () => {
    try {
      var airdropSignature = await connection.requestAirdrop(
        wallet.publicKey,
        LAMPORTS_PER_SOL
      );
      await connection.confirmTransaction(airdropSignature);
      await getBalance();
      displayMessage("Sols added successfully");
    } catch (error) {
      displayMessage("There is problem with Airdrop Sol", "error");
    }
  };

  // Get Success/Error Message and Refresh Component
  const displayMessage = (msg, type) => {
    setMessage({ msg, type });
    setTimeout(() => {
      setMessage(null);
    }, 2000);
  };

  return (
    <div className="my-5">
      {message && <Messages msg={message} />}
      <div className="flex justify-between">
        <h2 className="text-xxl pt-2 mb-5 font-bold">Statistics</h2>
        <button
          onClick={getAirdrop}
          className="text-white bg-ing-orange hover:bg-yellow-800  font-medium rounded-full text-xs px-5 text-center mb-3"
        >
          Add Fund in Wallet
        </button>
      </div>
      <div className="grid grid-cols-4 gap-4">
        <div className="bg-blue-900 p-5">
          <span className="block">Welcome {userData?.name || "to"},</span>
          <p className="truncate">
            {userData?.email || "S"}{" "}
          </p>
        </div>
        <div className="bg-blue-700 p-5">
          <span className="block">Wallet Details</span>
          <div className="flex flex-wrap gap-2 mt-2">
            <Badge color="success" size="sm">
              Balance {accountBalance} SOL
            </Badge>
            <Badge color="warning" size="sm">
              {" "}
              {tokens} Tokens
            </Badge>
          </div>
        </div>
        <div className="bg-blue-900 p-5">
          <span className="block">Wallet ID</span>
          <p className="truncate ..." title={wallet?.publicKey.toString()}>
            {wallet?.publicKey.toString()}
          </p>
        </div>
        {/* If Authenticated User > Display Information of department */}
        {userData && (
          <div className="bg-blue-700 p-5">
            <span className="block">Department</span>
            <p>
              {userData?.department} -{" "}
              <span className="text-sm">{userData?.role}</span>{" "}
            </p>
          </div>
        )}
      </div>
    </div>
  );
};

export default Stats;
