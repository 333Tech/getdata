import React from "react";

const Messages = ({ msg }) => {
  console.log("type", msg?.type);
  return (
    <div className="fixed z-50	left-[50%] ml-[-200px] bottom-8">
      <div
        className={`${
          msg?.type == "error" ? "bg-red-500" : "bg-green-500"
        } shadow-lg mx-auto w-96 max-w-full text-sm pointer-events-auto bg-clip-padding rounded-lg block mb-3`}
      >
        <div
          className={`${
            msg?.type == "error" ? "bg-red-500" : "bg-green-500"
          } flex justify-between items-center py-2 px-3 bg-clip-padding border-b border-slate-400 rounded-t-lg`}
        >
          <p className="font-semibold text-white flex items-center">
            <svg
              aria-hidden="true"
              focusable="false"
              data-prefix="fas"
              data-icon="check-circle"
              className="w-4 h-4 mr-2 fill-current"
              role="img"
              xmlns="http://www.w3.org/2000/svg"
              viewBox="0 0 512 512"
            >
              <path
                fill="currentColor"
                d="M504 256c0 136.967-111.033 248-248 248S8 392.967 8 256 119.033 8 256 8s248 111.033 248 248zM227.314 387.314l184-184c6.248-6.248 6.248-16.379 0-22.627l-22.627-22.627c-6.248-6.249-16.379-6.249-22.628 0L216 308.118l-70.059-70.059c-6.248-6.248-16.379-6.248-22.628 0l-22.627 22.627c-6.248 6.248-6.248 16.379 0 22.627l104 104c6.249 6.249 16.379 6.249 22.628.001z"
              ></path>
            </svg>
            Message
          </p>
          <div className="flex items-center">
            <button
              type="button"
              className="btn-close btn-close-white box-content w-4 h-4 ml-2 text-white border-none rounded-none  "
              data-mdb-dismiss="toast"
              aria-label="Close"
            >
              X
            </button>
          </div>
        </div>
        <div
          className={`${
            msg?.type == "error" ? "bg-red-500" : "bg-green-500"
          } p-3  rounded-b-lg break-words text-white`}
        >
          {msg.msg}
        </div>
      </div>
    </div>
  );
};
export default Messages;
