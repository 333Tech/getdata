import React, { useState, useEffect, useMemo, useContext } from "react";
import Logo from "../Header/Logo";
import TeamMember from "../Mint/TeamMember";
import AppServices from "../../services/Api";
import YoutubeEmbed from "./YoutubeEmbed";

function PresentationPage() {
  const [teams, setTeams] = useState(null);
  const getTeamsData = () => {
    AppServices._getTeamsData().then((res) => {
      setTeams(res);
    });
  };
  useEffect(() => {
    getTeamsData();
  }, []);

  return (
    <div className="flex flex-col items-center justify-center ">
      <div className="flex flex-col items-center mt-8 ">
        <Logo />
      </div>
      <div className="flex mt-4 text-ing-orange text-2xl font-bold p-2 ">
        The Team
      </div>
      <div className="grid grid-cols-3 lg:grid-cols-none lg:grid-flow-col justify-center items-center mt-2">
        {teams &&
          teams.length > 0 &&
          teams.map((item, ind) => {
            return <TeamMember item={item} key={ind} />;
          })}
      </div>
      <div className="my-8">
        <img src="/assets/images/Infographic3.png" />
      </div>
      <YoutubeEmbed embedId="02dXPqsRzEw" />
    </div>
  );
}

export default PresentationPage;
