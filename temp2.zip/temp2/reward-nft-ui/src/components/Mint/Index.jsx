import React, { useState, useEffect, useMemo, useContext } from "react";
import Logo from "../Header/Logo";
import Mint from "./Mint";
import { useWallet } from "@solana/wallet-adapter-react";
import { WalletMultiButton } from "@solana/wallet-adapter-react-ui";
import * as anchor from "@project-serum/anchor";
import * as solanaWeb3 from "@solana/web3.js";
import CONSTANTS from "../../services/Constants";
import TeamMember from "./TeamMember";
import Loader from "../Common/Loader";
import AppContext from "../../context/AppContext";
import { LAMPORTS_PER_SOL, PublicKey } from "@solana/web3.js";

import { Metaplex, walletAdapterIdentity } from "@metaplex-foundation/js";
import AppServices from "../../services/Api";

const Welcome = () => {
  const wallet = useWallet();
  const rpcHost =
    CONSTANTS.SOLANA_RPC_HOST ?? anchor.web3.clusterApiUrl("devnet");
  const connection = new solanaWeb3.Connection(rpcHost, "confirmed");
  const context = useContext(AppContext);
  const [meetFounders, setMeetFounders] = useState(false);
  const [ourIdea, setOurIdea] = useState(false);
  const [accountBalance, setAccountBalance] = useState(null);
  const [availableTokens, setAvailableTokens] = useState(null);
  const [moreInfo1, setMoreInfo1] = useState(false);
  const [teams, setTeams] = useState(null);
  const [mobileInstructions, setMobileInstructions] = useState(true);
  const [webInstructions, setWebInstructions] = useState(false);

  const [nfts, setNfts] = useState(null);
  const [isLoading, setIsLoading] = useState(false);

  const solana = useMemo(() => {
    if (
      !wallet ||
      !wallet.publicKey ||
      !wallet.signAllTransactions ||
      !wallet.signTransaction
    ) {
      return;
    }
    return {
      publicKey: wallet.publicKey,
      signAllTransactions: wallet.signAllTransactions,
      signTransaction: wallet.signTransaction,
    };
  }, [wallet]);

  useEffect(() => {
    if (wallet.publicKey) {
      getBalance();
      getTokenCount();
    }
    getTeamsData();
  }, [wallet.publicKey, context.timestamp]);

  const getTeamsData = () => {
    AppServices._getTeamsData().then((res) => {
      setTeams(res);
    });
  };

  const getWalletNFTData = () => {
    setNfts(null);
    if (wallet.publicKey) {
      setIsLoading(true);
      setTimeout(async () => {
        const metaplex = await Metaplex.make(connection).use(
          walletAdapterIdentity(solana)
        );
        // const candyMachineObj = await metaplex.candyMachines();
        const data = await metaplex
          .nfts()
          .findAllByOwner({ owner: wallet.publicKey })
          .run();
        console.log("data", data);
        async function getMetaDataNFT() {
          let array = [];
          //This loop will wait for each next() to pass the next iteration
          for (var i = 0; i < data.length; i++) {
            // Checking only encourage mint nft
            if (data[i].name.indexOf("synechron Mint") > -1) {
              array[i] = await metaplex
                .nfts()
                .findByMint({ mintAddress: data[i].mintAddress })
                .run();
            }
          }
          console.log("array[i]", array);
          setNfts(array);
          setIsLoading(false);
        }
        await getMetaDataNFT();
      }, 1000);
    }
  };

  // Get updated balance
  const getBalance = async () => {
    const lamports = await connection
      .getBalance(wallet.publicKey)
      .catch((err) => {
        console.error(`Error: ${err}`);
      });
    let balSol = lamports / LAMPORTS_PER_SOL;
    if (balSol == 0) {
      getAirdrop();
    }
    getWalletNFTData();
    setAccountBalance((Math.round(balSol * 100) / 100).toFixed(2)); // In the Solana Network, a lamport is the smallest unit: 1 SOL = 1 billion lamports.
  };

  //Add sol in wallet
  const getAirdrop = async () => {
    const connection2 = new solanaWeb3.Connection(
      CONSTANTS.SOLANA_RPC,
      "confirmed"
    );
    try {
      var airdropSignature = await connection2.requestAirdrop(
        wallet.publicKey,
        LAMPORTS_PER_SOL
      );
      await connection2.confirmTransaction(airdropSignature);
      await getBalance();
    } catch (error) {
      console.log("There is problem with Airdrop Sol");
    }
  };

  // Get Whitelist Token Balance
  const getTokenCount = async () => {
    // (async () => {
    const balance = await connection.getParsedTokenAccountsByOwner(
      wallet.publicKey,
      { mint: new PublicKey(CONSTANTS.MINT_ADDRESS) }
    );
    const tokenBalance =
      balance?.value && balance.value.length > 0
        ? balance.value[0]?.account.data.parsed.info.tokenAmount.uiAmount
        : 0;
    console.log("balance", balance);
    console.log("tokenBalance", tokenBalance);
    setAvailableTokens(tokenBalance);
    // })();
  };

  console.log(meetFounders);

  return (
    <div className="flex flex-col items-center justify-center ">
      {isLoading && <Loader />}
      <div className="flex flex-col items-center mt-8 ">
        
        <Logo />
      </div>
      <div className="flex flex-col">
        <div
          onClick={() => {
            setMeetFounders(!meetFounders);
            setOurIdea(false);
          }}
          className={`${
            !meetFounders ? "opacity-50" : ""
          } flex mt-4 text-ing-orange text-2xl font-bold p-2 cursor-pointer hover:text-ing-blue`}
        >
          Meet the team
        </div>
        <div
          onClick={() => {
            setOurIdea(!ourIdea);
            setMeetFounders(false);
          }}
          className={`${
            !ourIdea ? "opacity-50" : ""
          } flex mt-4 text-ing-orange text-2xl font-bold p-2 cursor-pointer hover:text-ing-blue`}
        >
          What is our idea?
        </div>
      </div>

      {meetFounders && (
        <div className="grid grid-cols-3 lg:grid-cols-none lg:grid-flow-col justify-center items-center mt-2">
          {teams &&
            teams.length > 0 &&
            teams.map((item, ind) => {
              return <TeamMember item={item} key={ind} />;
            })}
        </div>
      )}

      {ourIdea && (
        <div className="flex mx-2 flex-col justify-center items-center mt-2 max-w-lg text-lg font-semibold text-zinc-900">
          synechron Mint! <br />
          <br /> Your colleagues are participating in the 2022 . We aim to improve  synechron's rewards and recognition system by
          creating an innovative platform to: <br />
          <br />
          <div>
            <span className="text-ing-orange font-bold">Motivate</span> ing
            employees through non-financial rewards and recognition
          </div>
          <div>
            <span className="text-ing-orange font-bold">Innovate</span> by
            molding into one of  synechron's global innovation hubs{" "}
          </div>{" "}
          <div>
            <span className="text-ing-orange font-bold">Navigate</span> a
            rapidly evolving business and technological environment
          </div>{" "}
          <div>
            <span className="text-ing-orange font-bold">Teach</span> employees
            about blockchain technology in a fun and digestible manner
          </div>
          <br />
          We need your help: Come to the Big Apple Cafe to support our team in
          the final round from 1-2pm. Thank you! synechron Mint team (Alex,
          Chris, Carly, Kaz and Kiran)
        </div>
      )}

      <div className="flex mt-8 text-ing-orange text-3xl text-center lg:text-4xl font-bold p-2 uppercase ">
        Mint your first NFT in 3 easy steps
      </div>

      <div className="flex flex-col items-center justify-center mx-2">
        <div className="flex flex-col items-center mt-8">
          <div className="flex items-center justify-center text-white text-4xl rounded-full bg-zinc-700 w-16 h-16 text-center p-2 z-20">
            1
          </div>
          <div className="p-6 max-w-lg text-white bg-zinc-700 rounded-lg border border-gray-200 shadow-md z-10">
            <div className="flex flex-row justify-between">
              <h5 className="mb-2 text-2xl font-semibold tracking-tight">
                Install Phantom wallet
              </h5>
              <img
                className="w-10 h-10 rounded-full"
                src="/assets/images/phantom.jpg"
              />
            </div>
            <p className="my-4 font-normal ">
              Phantom is a secure Solana-based wallet that allows you to
              interact with Solana dapps, smart contracts and tokens. No
              personal information is required to create a wallet.
            </p>
            <a
              onClick={() => setMoreInfo1(!moreInfo1)}
              className="cursor-pointer inline-flex items-center text-ing-blue-light hover:underline"
            >
              See the installation instructions
            </a>
            {moreInfo1 && (
              <div className="mt-4">
                <div className="flex justify-around">
                  <span
                    onClick={() => (
                      setWebInstructions(false), setMobileInstructions(true)
                    )}
                    className={`${
                      mobileInstructions
                        ? "font-bold"
                        : "font-semibold text-white/50"
                    } mb-4 cursor-pointer`}
                  >
                    Mobile version
                  </span>
                  <span
                    onClick={() => (
                      setWebInstructions(true), setMobileInstructions(false)
                    )}
                    className={`${
                      webInstructions
                        ? "font-bold"
                        : "font-semibold text-white/50"
                    } mb-4 cursor-pointer`}
                  >
                    Web version
                  </span>
                </div>

                <hr className="my-2" />
                {mobileInstructions && (
                  <div className="flex flex-col space-y-4">
                    <span>
                      1) Download Phantom by Phantom Technologies, Inc.
                    </span>
                    <div className="flex flex-row justify-around">
                      <a
                        className="flex"
                        href="https://apps.apple.com/app/phantom-solana-wallet/1598432977"
                      >
                        <img className="h-12" src="/assets/images/ios.svg" />
                      </a>
                      <a
                        className="flex"
                        href="https://play.google.com/store/apps/details?id=app.phantom"
                      >
                        <img className="" src="/assets/images/googleplay.svg" />
                      </a>
                    </div>

                    <span className="flex">
                      2) Set up authentication (faceID, fingerprint or password)
                      and create a wallet{" "}
                    </span>

                    <span className="flex">
                      3) In Settings switch to Devnet
                    </span>
                    <div className="flex items-center justify-center">
                      <img
                        className="flex w-48 items-center justify-center"
                        src="/assets/images/screenshot-network.jpg"
                      />
                    </div>

                    <p>
                      4) Open the Phantom browser, go to{" "}
                      <span className="text-ing-orange">
                        Synechron Awards/mint
                      </span>{" "}
                      and follow all next steps using that browser
                    </p>
                    <div className="flex items-center justify-center">
                      <img
                        className="flex w-48 items-center justify-center"
                        src="/assets/images/screenshot-browser.jpg"
                      />
                    </div>
                  </div>
                )}

                {webInstructions && (
                  <div className="flex flex-col space-y-4">
                    <span>1) Download the Phantom extension for Chrome</span>
                    <div className="flex flex-row justify-around">
                      <a
                        className="flex"
                        href="https://chrome.google.com/webstore/detail/phantom/bfnaelmomeimhlpmgjnjophhpkkoljpa"
                      >
                        <img className="h-12" src="/assets/images/chrome.svg" />
                      </a>
                    </div>
                    <span className="flex">
                      2) If installation is successful the Phantom icon should
                      appear in the upper-right corner of your browser
                    </span>
                    <div className="flex items-center justify-center">
                      <img
                        className="flex w-48 items-center justify-center"
                        src="/assets/images/extension.PNG"
                      />
                    </div>

                    <span className="flex">
                      3) Set up a password and create a wallet{" "}
                    </span>

                    <span className="flex">
                      4) Go to Settings / Developer Settings and switch to
                      Devnet{" "}
                    </span>
                    <div className="flex items-center justify-center">
                      <img
                        className="flex w-48 items-center justify-center"
                        src="/assets/images/extension-devnet.PNG"
                      />
                    </div>
                  </div>
                )}
              </div>
            )}
          </div>
        </div>
        <div className="flex flex-col items-center mt-8">
          <div className="flex items-center justify-center text-white text-4xl rounded-full bg-zinc-700 w-16 h-16 text-center p-2 z-20">
            2
          </div>
          <div className="p-6 max-w-lg text-white bg-zinc-700 rounded-lg border border-gray-200 shadow-md z-10">
            <div className="flex flex-row justify-between">
              <div className="flex flex-col">
                <h6 className="mb-2 text-rose-500 text-lg font-semibold tracking-tight">
                  For this step make sure that you've opened this webpage in the
                  Phantom app
                </h6>
                <h5 className="mb-2 text-2xl font-semibold tracking-tight">
                  Connect your wallet in the Phantom app browser
                </h5>
              </div>

              <img
                className="h-10 w-10 "
                src="/assets/images/solana-sol-logo.svg"
              />
            </div>
            <div className="flex items-center justify-center">
              <img
                className="flex items-center h-full w-48 items-center justify-center"
                src="/assets/images/screenshot-browser.jpg"
              />
            </div>

            <p className="my-4 font-normal ">
              By connecting your Phantom wallet you will automatically receive 1
              SOL - the Solana native cryptocurrency - and 1 Whitelist token
              from us. The Whitelist token will give you the right to mint 1{" "}
              <span className="text-ing-orange">synechron Mint</span> NFT. The
              SOL in your wallet will be used to pay for the transaction fee.
            </p>
            <p className="my-4 font-normal text-white/50">
              Please note that that all transactions are done on the Solana
              Devnet which is an environment that replicates the actual Solana
              network (Mainnet). The Devnet is for testing purposes and uses
              test SOL tokens, so we're not spending actual money here.
            </p>
            <div className="flex flex-col justify-center items-center z-30">
              {wallet?.connected && (
                <div className="flex items-center text-center font-semibold text-emerald-500">
                  You are connected! <br />
                  Balance: {accountBalance} SOL | Whitelist Tokens:{" "}
                  {availableTokens}
                </div>
              )}
              <WalletMultiButton />
            </div>
          </div>
        </div>
        <div className="flex flex-col items-center mt-8">
          <div className="flex items-center justify-center text-white text-4xl rounded-full bg-zinc-700 w-16 h-16 text-center p-2">
            3
          </div>
          <div className="p-6 max-w-lg text-white bg-zinc-700 rounded-lg border border-gray-200 shadow-md">
            <div className="flex flex-row justify-between">
              <h5 className="mb-2 text-2xl font-semibold tracking-tight">
                Mint your first NFT
              </h5>
              <img
                className="h-8 lg:h-10 bg-white p-1 rounded-md"
                src="/assets/images/logo.png"
              />
            </div>
            <p className="my-4 font-normal ">
              Minting an NFT refers to converting a digital file into a digital
              asset stored on the blockchain. When you click on the Mint button
              below you will be prompted to authorize the transaction using your
              Phantom wallet. The transaction entails exchanging the 1 Whitelist
              token and some SOL you received in the previous step for 1{" "}
              <span className="text-ing-orange">synechron Mint</span> NFT from
              our collection. Once successfully minted, the NFT will be stored
              on the blockchain and you will be recorded as the current owner of
              that particular digital asset.
            </p>
         
            <div className="flex flex-col justify-center items-center">
              {!wallet?.connected && (
                <div className="flex font-semibold text-rose-500">
                  You need to connect your wallet first to be able to mint
                </div>
              )}
              {wallet?.connected && nfts && <Mint nfts={nfts} />}
            </div>
          </div>
        </div>
        {nfts?.length > 0 && wallet?.connected && (
          <div className="flex flex-col items-center mt-8">
            <div className="flex items-center text-center justify-center text-zinc-700 text-xl font-bold">
              And here's your freshly minted NFT! <br /> Welcome to the club!
            </div>
            <div className="p-6 max-w-lg text-white bg-zinc-700 rounded-lg border border-gray-200 shadow-md z-10">
              <div className="flex flex-col">
                {nfts?.length > 0 &&
                  nfts.map((item, ind) => {
                    return (
                      <div
                        key={`nft-table-${ind}`}
                        className="flex flex-col mb-20 "
                      >
                        <div className="flex flex-row justify-between">
                          <div className="mb-2 text-2xl font-semibold tracking-tight">
                            {item?.name}
                          </div>
                          <img
                            className="h-8 lg:h-10 bg-white p-1 rounded-md z-50"
                            src="/assets/images/logo.png"
                          />
                        </div>
                        <div className="mt-4 whitespace-nowrap font-medium text-gray-900 dark:text-white">
                          <img
                            src={
                              item.json
                                ? item.json?.image
                                : CONSTANTS.IMG_PLACEHOLDER
                            }
                            alt=""
                          />
                        </div>
                        <div className="flex flex-col mt-4 font-medium text-white">
                          <div className="text-center mb-2 font-semibold">
                            Layers
                          </div>
                          {item?.json?.attributes.map((attr, index) => {
                            return (
                              <div
                                className="grid grid-cols-2 space-x-4 "
                                key={index}
                              >
                                <div className="text-end">
                                  {attr.trait_type} :
                                </div>
                                <div className="text-ing-orange">
                                  {attr.value}
                                </div>
                              </div>
                            );
                          })}
                        </div>
                      </div>
                    );
                  })}
              </div>
              <span className="flex mt-8">
                You can also see this NFT in the collectibles tab of your
                Phantom wallet{" "}
              </span>
              <div className="flex items-center justify-center">
                <img
                  className="flex w-48 items-center justify-center"
                  src="/assets/images/screenshot-collectibles.jpg"
                />
              </div>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};
export default Welcome;
