import React from 'react'
const TeamMember = ({item}) => {
  return (
    <div className="flex flex-col items-center justify-center text-center mx-2 mb-2">
          <div className="w-20 h-20 rounded-full">
            <img
              className="rounded-full"
              alt={item.name}
              src={`/assets/images/profile_pics/${item.photo}.jpg`}
            />
          </div>
          <div className="flex flex-col  mt-2">
            <span className="text-zinc-900 text-lg font-bold">{item.name}</span>
            <span className="text-zinc-700 text-md font-semibold">{item.department}</span>
          </div>
        </div>
  )
}
export default TeamMember;