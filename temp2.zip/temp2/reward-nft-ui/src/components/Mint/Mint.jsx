import React, { useEffect, useState, useContext } from "react";
import * as anchor from "@project-serum/anchor";
import * as solanaWeb3 from "@solana/web3.js";
import * as bs58 from "bs58";
import * as splToken from "@solana/spl-token";
import CONSTANTS from "../../services/Constants";
import HomeNew from "../MintNFT/HomeNew.tsx";
import { useWallet } from "@solana/wallet-adapter-react";
import { Keypair, PublicKey } from "@solana/web3.js";
import AppContext from "../../context/AppContext";

import {
  getOrCreateAssociatedTokenAccount,
  TOKEN_PROGRAM_ID,
} from "@solana/spl-token";

const Mint = ({ nfts }) => {
  const [availableTokens, setAvailableTokens] = useState(null);
  const rpcHost =
    CONSTANTS.SOLANA_RPC_HOST ?? anchor.web3.clusterApiUrl("devnet");
  const connection = new solanaWeb3.Connection(rpcHost, "confirmed");
  const wallet = useWallet();
  const context = useContext(AppContext);
  // Get CandyMachine ID
  const getCandyMachineId = () => {
    try {
      return new anchor.web3.PublicKey(CONSTANTS.CANDY_MACHINE_ID);
    } catch (e) {
      console.log("Failed to construct CandyMachineId", e);
      return undefined;
    }
  };
  const candyMachineId = getCandyMachineId();

  // Get Whitelist Token Balance
  const getTokenCount = async (transfer) => {
    // (async () => {
    const balance = await connection.getParsedTokenAccountsByOwner(
      wallet.publicKey,
      { mint: new PublicKey(CONSTANTS.MINT_ADDRESS) }
    );
    console.log("balance", balance);
    const tokenBalance =
      balance?.value && balance.value.length > 0
        ? balance.value[0]?.account.data.parsed.info.tokenAmount.uiAmount
        : 0;
    console.log("tokenBalance", tokenBalance);
    setAvailableTokens(tokenBalance);
    if (tokenBalance == 0 && nfts?.length == 0 && !transfer) {
      await transferTokenAndNFT();
    }
    // if (accounts.length > 0) {
    //   console.log("accounts", accounts);
    //   async function getWLTokenAccountBalance() {
    //     //This loop will wait for each next() to pass the next iteration
    //     for (var i = 0; i < accounts.length; i++) {
    //       let tokenAccountMintAddr =
    //         accounts[i].account.data.parsed.info.mint;
    //       if (tokenAccountMintAddr == CONSTANTS.MINT_ADDRESS) {
    //         let balance =
    //           accounts[i].account.data.parsed.info.tokenAmount.uiAmount;
    //         console.log("token balance",accounts[i].account.data.parsed.info.tokenAmount);
    //         setAvailableTokens(balance);
    //       }
    //     }
    //   }
    //   await getWLTokenAccountBalance();
    // } else {
    //   await transferTokenAndNFT();
    // }
    // })();
  };

  // useEffect(() => {
  //   if(availableTokens == 0 && (nfts?.length == 0 )){
  //       transferTokenAndNFT();
  //   }
  // }, [availableTokens])

  // Auto transfer whitelist token after connect to wallet
  const transferTokenAndNFT = async () => {
    const pvKey = CONSTANTS.PRIVATE_KEY_MANAGER;
    const fromWallet = Keypair.fromSecretKey(bs58.decode(pvKey));
    const toPublicKey = wallet.publicKey;
    console.log("toPublicKey", toPublicKey);
    try {
      // Send Whitelist token with Minting
      const tokenAddress = CONSTANTS.MINT_ADDRESS;
      const whiteListTokenPublicKey = new solanaWeb3.PublicKey(tokenAddress);
      const fromTokenAccount = await getOrCreateAssociatedTokenAccount(
        connection,
        fromWallet,
        whiteListTokenPublicKey,
        fromWallet.publicKey
      );
      const associatedDestinationTokenAddr =
        await getOrCreateAssociatedTokenAccount(
          connection,
          fromWallet,
          whiteListTokenPublicKey,
          toPublicKey
        );

      const signature = await splToken.transfer(
        connection,
        fromWallet,
        fromTokenAccount.address,
        associatedDestinationTokenAddr.address,
        fromWallet.publicKey, // or pass fromPublicKey
        1 // tokens have 6 decimals of precision so your amount needs to have the same
      );

      console.log("signature", signature);
      console.log("Token Transfer Successfully");
      // Sent trigger to context update other info in app
      context.sendUpdateAction(Date.now());
      getTokenCount("transfer");
    } catch (error) {
      console.log("There is problem in RPC JSON API", "error");
      console.log("error>>", error);
    }
  };

  useEffect(() => {
    getTokenCount();
  }, [wallet?.connected]);

  return (
    <div>
      {candyMachineId && (
        <>
          {availableTokens > 0 && nfts?.length == 0 && (
            <HomeNew rpcHost={rpcHost} candyMachineId={candyMachineId} />
          )}
          {availableTokens == 0 && (nfts?.length == 0 || nfts == null) && (
            <div className="font-semibold text-rose-500">
              Don't see a Mint button yet? Manually request 1 Whitelist token
              and 1 SOL by clicking{" "}
              <span
                onClick={() => transferTokenAndNFT()}
                className="cursor-pointer font-bold text-emerald-600"
              >
                here
              </span>
            </div>
          )}
        </>
      )}
    </div>
  );
};
export default Mint;
