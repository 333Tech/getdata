import Countdown from "react-countdown";
import React from "react";

interface MintCountdownProps {
  date: Date | undefined;
  style?: React.CSSProperties;
  status?: string;
  onComplete?: () => void;
}

interface MintCountdownRender {
  days: number;
  hours: number;
  minutes: number;
  seconds: number;
  completed: boolean;
}

export const MintCountdown: React.FC<MintCountdownProps> = ({
  date,
  status,
  style,
  onComplete,
}) => {
  const renderCountdown = ({
    days,
    hours,
    minutes,
    seconds,
    completed,
  }: MintCountdownRender) => {
    // hours += days * 24;
    if (completed) {
      return status ? <span className=''>{status}</span> : null;
    } else {
      return (
        <div className='col-span-6'>
          <div className='grid grid-cols-4 gap-4 text-center uppercase'>
            <div className='bg-orange-700 rounded py-3 font-bold'>
              <span className='block text-xl'>{days < 10 ? `0${days}` : days}</span>
              <span className="text-xs">days</span>
            </div>
            <div className='bg-orange-700 rounded py-3 font-bold'>
              <span className='block text-xl'> {hours < 10 ? `0${hours}` : hours} </span>
              <span className="text-xs">hrs</span>
            </div>
            <div className='bg-orange-700 rounded py-3 font-bold'>
              <span className='block text-xl'> {minutes < 10 ? `0${minutes}` : minutes} </span>
              <span className="text-xs">mins</span>
            </div>
            <div className='bg-orange-700 rounded py-3 font-bold'>
              <span className='block text-xl'>{seconds < 10 ? `0${seconds}` : seconds} </span>
              <span className="text-xs">secs</span>
            </div>
          </div>
        </div>
      );
    }
  };

  if (date) {
    return (
      <Countdown
        date={date}
        onComplete={onComplete}
        renderer={renderCountdown}
      />
    );
  } else {
    return null;
  }
};
