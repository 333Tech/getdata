import { Spinner } from "flowbite-react";
import React, { Suspense, Fragment, useState, lazy } from "react";
import { BrowserRouter, Route, Routes } from "react-router-dom";
import Loader from "./components/Common/Loader";
const Welcome = lazy(() => import("./components/Welcome/Welcome"));
const WallPage = lazy(() => import("./components/Wall/Index"));
const MintPage = lazy(() => import("./components/Mint/Index"));
const PresentationPage = lazy(() => import("./components/Presentation/Index"));

const Routers = (props) => {
  return (
    <Fragment>
      <BrowserRouter>
        <Suspense fallback={<Loader size="xl" />}>
          <Routes>
            <Route path="/" exact element={<Welcome />} />
            <Route path="/mint" exact element={<MintPage />} />
            <Route path="/benefits" exact element={<Welcome />} />
            <Route path="/wall" exact element={<WallPage />} />
            <Route path="/presentation" element={<PresentationPage />} />
            <Route path="*" element={<p>There's nothing here: 404!</p>} />
          </Routes>
        </Suspense>
      </BrowserRouter>
    </Fragment>
  );
};

export default Routers;
