import { ContextAppStore } from './context/AppContext';
import Routes from "./Routes";
import {
  ConnectionProvider,
  WalletProvider,
} from "@solana/wallet-adapter-react";
import {
  WalletModalProvider,
} from "@solana/wallet-adapter-react-ui";
import React, { useMemo } from "react";
import { PhantomWalletAdapter } from "@solana/wallet-adapter-wallets";
import CONSTANTS from "./services/Constants";

export const App = () => {
  return (
    <Context>
      <Content />
    </Context>
  );
};

const Context = ({ children }) => {
  // The network can be set to 'devnet', 'testnet', or 'mainnet-beta'.
  const rpcHost = CONSTANTS.SOLANA_RPC_HOST;
  // You can also provide a custom RPC endpoint.
  const endpoint = useMemo(() => rpcHost, [CONSTANTS.SOLANA_NETWORK]);

  const wallets = useMemo(() => [new PhantomWalletAdapter()], []);

  return (
    <ConnectionProvider endpoint={endpoint}>
      <WalletProvider wallets={wallets} autoConnect>
        <WalletModalProvider>{children}</WalletModalProvider>
      </WalletProvider>
    </ConnectionProvider>
  );
};

const Content = () => {
  return (
    <div className="flex flex-col h-screen bg-ing-grey-light">
      <ContextAppStore>
      <article className="flex-grow bg-ing-grey-light">
        <Routes />
      </article>
      <footer className="bg-ing-grey-light">
        <div className="flex items-center justify-center mt-8">
          <img className="h-12" src="/assets/images/breakinghabits-new.png" />
          {/* Copyright © {new Date().getFullYear()} */}
        </div>
      </footer>
      </ContextAppStore>
    </div>
  );
};

export default App;
