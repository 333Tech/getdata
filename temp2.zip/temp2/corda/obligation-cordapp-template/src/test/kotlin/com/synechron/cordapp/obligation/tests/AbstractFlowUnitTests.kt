package com.synechron.cordapp.obligation.tests

import com.synechron.cordapp.obligation.borrower.flows.IssueObligationInitiatorFlow
import com.synechron.cordapp.obligation.borrower.flows.SettleObligationInitiatorFlow
import com.synechron.cordapp.obligation.commons.flows.ResetNetworkTimeInitiatorFlow
import com.synechron.cordapp.obligation.commons.flows.ResetNetworkTimeHandlerFlow
import com.synechron.cordapp.obligation.commons.flows.SetNetworkTimeInitiatorFlow
import com.synechron.cordapp.obligation.commons.flows.SetNetworkTimeHandlerFlow
import com.synechron.cordapp.obligation.lender.flows.IssueObligationHandlerFlow
import com.synechron.cordapp.obligation.lender.flows.SettleObligationHandlerFlow
import net.corda.core.contracts.Amount
import net.corda.core.contracts.UniqueIdentifier
import net.corda.core.identity.Party
import net.corda.core.utilities.OpaqueBytes
import net.corda.core.utilities.getOrThrow
import net.corda.finance.flows.CashIssueFlow
import net.corda.testing.internal.chooseIdentity
import net.corda.testing.node.MockNetwork
import net.corda.testing.node.StartedMockNode
import org.junit.After
import org.junit.Before
import java.util.*

/**
 * A base class to reduce the boilerplate when writing obligation flow tests.
 */
abstract class AbstractFlowUnitTests {
    lateinit var network: MockNetwork
    lateinit var borrower: StartedMockNode
    lateinit var lender: StartedMockNode

    @Before
    fun setup() {
        network = MockNetwork(listOf("com.synechron.cordapp.obligation", "net.corda.finance"),
                threadPerNode = true)
        borrower = network.createNode()
        lender = network.createNode()

        lender.registerInitiatedFlow(IssueObligationHandlerFlow::class.java)
        lender.registerInitiatedFlow(SettleObligationHandlerFlow::class.java)
        lender.registerInitiatedFlow(SetNetworkTimeHandlerFlow::class.java)
        lender.registerInitiatedFlow(ResetNetworkTimeHandlerFlow::class.java)
    }

    @After
    open fun tearDown() {
        network.stopNodes()
    }

    protected fun getNotary(party: StartedMockNode): Party {
        return party.services.networkMapCache.notaryIdentities.firstOrNull()
                ?: throw IllegalStateException("Could not find a notary.")
    }

    protected fun issueObligation(borrower: StartedMockNode,
                                  lender: StartedMockNode,
                                  amount: Amount<Currency>
    ): net.corda.core.transactions.SignedTransaction {
        val lenderIdentity = lender.info.chooseIdentity()
        val flow = IssueObligationInitiatorFlow(amount, lenderIdentity)
        return borrower.startFlow(flow).getOrThrow()
    }

    protected fun settleObligation(linearId: UniqueIdentifier,
                                   borrower: StartedMockNode,
                                   amount: Amount<Currency>,
                                   anonymous: Boolean = true
    ): net.corda.core.transactions.SignedTransaction {
        val flow = SettleObligationInitiatorFlow(linearId, amount, anonymous)
        return borrower.startFlow(flow).getOrThrow()
    }

    protected fun selfIssueCash(party: StartedMockNode,
                                amount: Amount<Currency>): net.corda.core.transactions.SignedTransaction {
        val notary = getNotary(party)
        val issueRef = OpaqueBytes.of(0)
        val issueRequest = CashIssueFlow.IssueRequest(amount, issueRef, notary)
        val flow = CashIssueFlow(issueRequest)
        return party.startFlow(flow).getOrThrow().stx
    }

    protected fun setNetworkOffset(millis: Long, party: StartedMockNode) {
        val flow = SetNetworkTimeInitiatorFlow(millis)
        party.startFlow(flow).getOrThrow()
    }

    protected fun resetNetworkOffset(party: StartedMockNode) {
        val flow = ResetNetworkTimeInitiatorFlow()
        party.startFlow(flow).getOrThrow()
    }
}
