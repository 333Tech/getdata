package com.synechron.cordapp.obligation.tests.commons.flows

import co.paralleluniverse.fibers.Suspendable
import com.synechron.cordapp.obligation.tests.AbstractFlowUnitTests
import com.synechron.cordapp.obligation.commons.flows.TxNoteFlow
import com.synechron.cordapp.obligation.contract.NetworkTimeContract
import com.synechron.cordapp.obligation.state.NetworkTime
import net.bytebuddy.utility.RandomString
import net.corda.core.contracts.Command
import net.corda.core.crypto.SecureHash
import net.corda.core.flows.FinalityFlow
import net.corda.core.flows.FlowLogic
import net.corda.core.flows.InitiatingFlow
import net.corda.core.transactions.TransactionBuilder
import net.corda.core.utilities.getOrThrow
import org.junit.Test
import java.time.Duration


class TxNoteFlowTests : AbstractFlowUnitTests() {
    @Test
    fun addTxNotes() {
        val str = RandomString.make(255)!!
        val txId = borrower.startFlow(DummyTxNote(listOf(str))).getOrThrow()
        network.waitQuiescent()
        borrower.transaction {
            assert(borrower.services.vaultService.getTransactionNotes(txId).first() == str)
        }
    }

    @Test
    fun addTxNoteWithStringSizeMoreThan255() {
        val str = RandomString.make(260)!!
        val txId = borrower.startFlow(DummyTxNote(listOf(str))).getOrThrow()
        network.waitQuiescent()
        borrower.transaction {
            val itr = borrower.services.vaultService.getTransactionNotes(txId).iterator()
            assert(itr.next().length == 255)
            assert(itr.next().length == 5)
        }
    }
}

//Create dummy flow to test the [TxNoteFlow].
@InitiatingFlow
class DummyTxNote(val txNotes: List<String>) : FlowLogic<SecureHash>() {
    @Suspendable
    override fun call(): SecureHash {
        val notary = serviceHub.networkMapCache.notaryIdentities.first()
        val state = NetworkTime(millis = 100, participants = listOf(ourIdentity))

        val txb = TransactionBuilder(notary)
                .addOutputState(state, NetworkTimeContract.NETWORK_TIME_CONTRACT_ID)
                .addCommand(Command(NetworkTimeContract.Commands.CreateNetworkOffset(), ourIdentity.owningKey))
                .setTimeWindow(serviceHub.clock.instant(), Duration.ofSeconds(60))
        val stx = serviceHub.signInitialTransaction(txb)
        val ftx = subFlow(FinalityFlow(stx, listOf()))
        subFlow(TxNoteFlow(ftx.id, txNotes))
        return ftx.id
    }
}