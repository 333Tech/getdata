package com.synechron.cordapp.obligation.tests.commons.contract

import com.synechron.cordapp.obligation.tests.AbstractContractUnitTests
import com.synechron.cordapp.obligation.contract.NetworkTimeContract
import com.synechron.cordapp.obligation.contract.NetworkTimeContract.Companion.NETWORK_TIME_CONTRACT_ID
import com.synechron.cordapp.obligation.state.NetworkTime
import net.corda.testing.node.ledger
import org.junit.Test
import java.time.Duration
import java.time.Instant


class CreateNetworkOffsetTests : AbstractContractUnitTests() {
    //Create dummy network state.
    private val state = NetworkTime(1527234215020, participants = listOf(alice.party, bob.party))

    @Test
    fun `transaction must have single output state`() {
        ledgerServices.ledger {
            transaction {
                input(NETWORK_TIME_CONTRACT_ID, state)
                command(alice.party.owningKey, NetworkTimeContract.Commands.CreateNetworkOffset())
                timeWindow(Instant.now(), tolerance = Duration.ofSeconds(60))
                this `fails with` "Output state should be single."
            }
            transaction {
                command(alice.party.owningKey, NetworkTimeContract.Commands.CreateNetworkOffset())
                output(NETWORK_TIME_CONTRACT_ID, state)
                output(NETWORK_TIME_CONTRACT_ID, state)
                timeWindow(Instant.now(), tolerance = Duration.ofSeconds(60))
                this `fails with` "Output state should be single."
            }
            transaction {
                command(alice.party.owningKey, NetworkTimeContract.Commands.CreateNetworkOffset())
                output(NETWORK_TIME_CONTRACT_ID, state)
                timeWindow(Instant.now(), tolerance = Duration.ofSeconds(60))
                this.verifies()
            }
        }
    }


    @Test
    fun `transaction must have zero or single input state`() {
        ledgerServices.ledger {
            transaction {
                input(NETWORK_TIME_CONTRACT_ID, state)
                input(NETWORK_TIME_CONTRACT_ID, state)
                command(alice.party.owningKey, NetworkTimeContract.Commands.CreateNetworkOffset())
                timeWindow(Instant.now(), tolerance = Duration.ofSeconds(60))
                this `fails with` "Input state should be zero or one."
            }
            transaction {
                input(NETWORK_TIME_CONTRACT_ID, state)
                command(alice.party.owningKey, NetworkTimeContract.Commands.CreateNetworkOffset())
                output(NETWORK_TIME_CONTRACT_ID, state.copy(millis = 1527234215020))
                timeWindow(Instant.now(), tolerance = Duration.ofSeconds(60))
                this.verifies()
            }
        }
    }

    @Test
    fun `milliseconds value should be greater than zero`() {
        ledgerServices.ledger {
            transaction {
                command(alice.party.owningKey, NetworkTimeContract.Commands.CreateNetworkOffset())
                output(NETWORK_TIME_CONTRACT_ID, state.copy(millis = 0))
                timeWindow(Instant.now(), tolerance = Duration.ofSeconds(60))
                this `fails with` "Time offset value (i.e. millis) must be greater than zero."
            }
            transaction {
                command(alice.party.owningKey, NetworkTimeContract.Commands.CreateNetworkOffset())
                output(NETWORK_TIME_CONTRACT_ID, state.copy(millis = 1777774215020))
                timeWindow(Instant.now(), tolerance = Duration.ofSeconds(60))
                this.verifies()
            }
        }
    }
}