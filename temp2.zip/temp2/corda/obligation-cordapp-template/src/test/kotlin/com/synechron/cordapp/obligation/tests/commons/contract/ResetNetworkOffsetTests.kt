package com.synechron.cordapp.obligation.tests.commons.contract

import com.synechron.cordapp.obligation.tests.AbstractContractUnitTests
import com.synechron.cordapp.obligation.contract.NetworkTimeContract
import com.synechron.cordapp.obligation.state.NetworkTime
import net.corda.testing.node.ledger
import org.junit.Test
import java.time.Duration
import java.time.Instant

class ResetNetworkOffsetTests : AbstractContractUnitTests() {
    //Create dummy network inState.
    private val inState = NetworkTime(1527234215020, participants = listOf(alice.party, bob.party))
    private val outState = NetworkTime(0, participants = listOf(alice.party, bob.party))

    @Test
    fun `transaction must have single output state`() {
        ledgerServices.ledger {
            transaction {
                input(NetworkTimeContract.NETWORK_TIME_CONTRACT_ID, inState)
                command(alice.party.owningKey, NetworkTimeContract.Commands.ResetNetworkOffset())
                timeWindow(Instant.now(), tolerance = Duration.ofSeconds(60))
                this `fails with` "Output state should be single."
            }
            transaction {
                input(NetworkTimeContract.NETWORK_TIME_CONTRACT_ID, inState)
                command(alice.party.owningKey, NetworkTimeContract.Commands.ResetNetworkOffset())
                output(NetworkTimeContract.NETWORK_TIME_CONTRACT_ID, outState)
                output(NetworkTimeContract.NETWORK_TIME_CONTRACT_ID, outState)
                timeWindow(Instant.now(), tolerance = Duration.ofSeconds(60))
                this `fails with` "Output state should be single."
            }
            transaction {
                input(NetworkTimeContract.NETWORK_TIME_CONTRACT_ID, inState)
                command(alice.party.owningKey, NetworkTimeContract.Commands.ResetNetworkOffset())
                output(NetworkTimeContract.NETWORK_TIME_CONTRACT_ID, outState)
                timeWindow(Instant.now(), tolerance = Duration.ofSeconds(60))
                this.verifies()
            }
        }
    }


    @Test
    fun `transaction must have single input state`() {
        ledgerServices.ledger {
            transaction {
                output(NetworkTimeContract.NETWORK_TIME_CONTRACT_ID, inState)
                command(alice.party.owningKey, NetworkTimeContract.Commands.ResetNetworkOffset())
                timeWindow(Instant.now(), tolerance = Duration.ofSeconds(60))
                this `fails with` "Input state must be single."
            }
            transaction {
                input(NetworkTimeContract.NETWORK_TIME_CONTRACT_ID, inState)
                input(NetworkTimeContract.NETWORK_TIME_CONTRACT_ID, inState)
                command(alice.party.owningKey, NetworkTimeContract.Commands.ResetNetworkOffset())
                output(NetworkTimeContract.NETWORK_TIME_CONTRACT_ID, outState)
                timeWindow(Instant.now(), tolerance = Duration.ofSeconds(60))
                this `fails with` "Input state must be single."
            }
            transaction {
                input(NetworkTimeContract.NETWORK_TIME_CONTRACT_ID, inState)
                command(alice.party.owningKey, NetworkTimeContract.Commands.ResetNetworkOffset())
                output(NetworkTimeContract.NETWORK_TIME_CONTRACT_ID, outState)
                timeWindow(Instant.now(), tolerance = Duration.ofSeconds(60))
                this.verifies()
            }
        }
    }

    @Test
    fun `milliseconds value should be zero`() {
        ledgerServices.ledger {
            transaction {
                input(NetworkTimeContract.NETWORK_TIME_CONTRACT_ID, inState)
                command(alice.party.owningKey, NetworkTimeContract.Commands.ResetNetworkOffset())
                output(NetworkTimeContract.NETWORK_TIME_CONTRACT_ID, inState)
                timeWindow(Instant.now(), tolerance = Duration.ofSeconds(60))
                this `fails with` "Time offset value must be zero."
            }
            transaction {
                input(NetworkTimeContract.NETWORK_TIME_CONTRACT_ID, inState)
                command(alice.party.owningKey, NetworkTimeContract.Commands.ResetNetworkOffset())
                output(NetworkTimeContract.NETWORK_TIME_CONTRACT_ID, outState.copy(millis = -10L))
                timeWindow(Instant.now(), tolerance = Duration.ofSeconds(60))
                this `fails with` "Time offset value must be zero."
            }
            transaction {
                input(NetworkTimeContract.NETWORK_TIME_CONTRACT_ID, inState)
                command(alice.party.owningKey, NetworkTimeContract.Commands.ResetNetworkOffset())
                output(NetworkTimeContract.NETWORK_TIME_CONTRACT_ID, outState)
                timeWindow(Instant.now(), tolerance = Duration.ofSeconds(60))
                this.verifies()
            }
        }
    }
}