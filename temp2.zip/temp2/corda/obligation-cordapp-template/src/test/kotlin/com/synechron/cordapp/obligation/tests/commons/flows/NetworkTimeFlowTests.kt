package com.synechron.cordapp.obligation.tests.commons.flows

import com.synechron.cordapp.obligation.tests.AbstractFlowUnitTests
import com.synechron.cordapp.obligation.state.NetworkTime
import net.corda.core.contracts.TransactionVerificationException
import org.junit.Test

class NetworkTimeFlowTests : AbstractFlowUnitTests() {
    val futureMillis = System.currentTimeMillis() + 1000000000L

    @Test
    fun `set network time successfully`() {
        setNetworkOffset(futureMillis, borrower)
        network.waitQuiescent()

        listOf(borrower, lender).forEach {
            it.transaction {
                assert(it.services.vaultService.queryBy(NetworkTime::class.java).states.size == 1)
            }
        }
    }

    @Test(expected = TransactionVerificationException.ContractRejection::class)
    fun `network time millis should be greater than zero`() {
        setNetworkOffset(0, borrower)
    }

    @Test(expected = TransactionVerificationException.ContractRejection::class)
    fun `invalid millis value`() {
        setNetworkOffset(System.currentTimeMillis(), borrower)
    }

    @Test
    fun `reset network time`() {
        setNetworkOffset(futureMillis, borrower)
        network.waitQuiescent()
        resetNetworkOffset(borrower)
        network.waitQuiescent()
        listOf(borrower, lender).forEach {
            it.transaction {
                assert(it.services.vaultService.queryBy(NetworkTime::class.java).states.single().state.data.millis == 0L)
            }
        }
    }
}