package com.synechron.cordapp.obligation.tests.borrower.flows

import com.synechron.cordapp.obligation.tests.AbstractFlowUnitTests
import com.synechron.cordapp.obligation.state.Obligation
import net.corda.finance.POUNDS
import net.corda.testing.internal.chooseIdentity
import org.junit.Test
import kotlin.test.assertEquals

class IssueFlowUnitTests : AbstractFlowUnitTests() {
    @Test
    fun `issue anonymous obligation successfully`() {
        val stx = issueObligation(borrower, lender, 1000.POUNDS)

        val aIdentity = borrower.services.myInfo.chooseIdentity()
        val bIdentity = lender.services.myInfo.chooseIdentity()

        network.waitQuiescent()

        val aObligation = borrower.services.loadState(stx.tx.outRef<Obligation>(0).ref).data as Obligation
        val bObligation = lender.services.loadState(stx.tx.outRef<Obligation>(0).ref).data as Obligation

        assertEquals(aObligation, bObligation)

        val maybePartyALookedUpByA = borrower.services.identityService.requireWellKnownPartyFromAnonymous(aObligation.borrower)
        val maybePartyALookedUpByB = lender.services.identityService.requireWellKnownPartyFromAnonymous(aObligation.borrower)

        assertEquals(aIdentity, maybePartyALookedUpByA)
        assertEquals(aIdentity, maybePartyALookedUpByB)

        val maybePartyCLookedUpByA = borrower.services.identityService.requireWellKnownPartyFromAnonymous(aObligation.lender)
        val maybePartyCLookedUpByB = lender.services.identityService.requireWellKnownPartyFromAnonymous(aObligation.lender)

        assertEquals(bIdentity, maybePartyCLookedUpByA)
        assertEquals(bIdentity, maybePartyCLookedUpByB)
    }
}
