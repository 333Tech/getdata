package com.synechron.cordapp.obligation.tests.borrower.contract

import com.synechron.cordapp.obligation.tests.AbstractContractUnitTests
import com.synechron.cordapp.obligation.contract.ObligationContract
import com.synechron.cordapp.obligation.contract.ObligationContract.Companion.OBLIGATION_CONTRACT_ID
import com.synechron.cordapp.obligation.state.Obligation
import net.corda.core.identity.CordaX500Name
import net.corda.core.utilities.seconds
import net.corda.finance.DOLLARS
import net.corda.finance.POUNDS
import net.corda.finance.SWISS_FRANCS
import net.corda.testing.core.TestIdentity
import net.corda.testing.node.ledger
import org.junit.Test
import java.time.Instant

class ContractIssueTests : AbstractContractUnitTests() {

    @Test
    fun `issue obligation transaction must have no inputs`() {
        print(OBLIGATION_CONTRACT_ID)

        ledgerServices.ledger {
            transaction {
                input(OBLIGATION_CONTRACT_ID, DummyState())
                command(listOf(alice.publicKey, bob.publicKey), ObligationContract.Commands.Issue())
                output(OBLIGATION_CONTRACT_ID, oneDollarObligation)
                timeWindow(Instant.now(), 60.seconds)
                this `fails with` "No inputs should be consumed when issuing an obligation."
            }
            transaction {
                output(OBLIGATION_CONTRACT_ID, oneDollarObligation)
                command(listOf(alice.publicKey, bob.publicKey), ObligationContract.Commands.Issue())
                timeWindow(Instant.now(), 60.seconds)
                verifies() // As there are no input states.
            }
        }
    }

    @Test
    fun `Issue transaction must have only one output obligation`() {
        ledgerServices.ledger {
            transaction {
                command(listOf(alice.publicKey, bob.publicKey), ObligationContract.Commands.Issue())
                output(OBLIGATION_CONTRACT_ID, oneDollarObligation) // Two outputs fails.
                output(OBLIGATION_CONTRACT_ID, oneDollarObligation)
                timeWindow(Instant.now(), 60.seconds)
                this `fails with` "Only one obligation state should be created when issuing an obligation."
            }
            transaction {
                command(listOf(alice.publicKey, bob.publicKey), ObligationContract.Commands.Issue())
                output(OBLIGATION_CONTRACT_ID, oneDollarObligation) // One output passes.
                timeWindow(Instant.now(), 60.seconds)
                verifies()
            }
        }
    }

    @Test
    fun `cannot issue zero value obligations`() {
        ledgerServices.ledger {
            transaction {
                command(listOf(alice.publicKey, bob.publicKey), ObligationContract.Commands.Issue())
                output(OBLIGATION_CONTRACT_ID, Obligation(0.POUNDS, alice.party, bob.party)) // Zero amount fails.
                timeWindow(Instant.now(), 60.seconds)
                this `fails with` "A newly issued obligation must have a positive amount."
            }
            transaction {
                command(listOf(alice.publicKey, bob.publicKey), ObligationContract.Commands.Issue())
                output(OBLIGATION_CONTRACT_ID, Obligation(100.SWISS_FRANCS, alice.party, bob.party))
                timeWindow(Instant.now(), 60.seconds)
                verifies()
            }
            transaction {
                command(listOf(alice.publicKey, bob.publicKey), ObligationContract.Commands.Issue())
                output(OBLIGATION_CONTRACT_ID, Obligation(1.POUNDS, alice.party, bob.party))
                timeWindow(Instant.now(), 60.seconds)
                verifies()
            }
            transaction {
                command(listOf(alice.publicKey, bob.publicKey), ObligationContract.Commands.Issue())
                output(OBLIGATION_CONTRACT_ID, Obligation(10.DOLLARS, alice.party, bob.party))
                timeWindow(Instant.now(), 60.seconds)
                verifies()
            }
        }
    }

    @Test
    fun `lender and borrower must sign issue obligation transaction`() {
        val dummyIdentity = TestIdentity(CordaX500Name("Dummy", "", "GB"))

        ledgerServices.ledger {
            transaction {
                command(dummyIdentity.publicKey, ObligationContract.Commands.Issue())
                output(OBLIGATION_CONTRACT_ID, oneDollarObligation)
                timeWindow(Instant.now(), 60.seconds)
                this `fails with` "Both lender and borrower together only may sign obligation issue transaction."
            }
            transaction {
                command(alice.publicKey, ObligationContract.Commands.Issue())
                output(OBLIGATION_CONTRACT_ID, oneDollarObligation)
                timeWindow(Instant.now(), 60.seconds)
                this `fails with` "Both lender and borrower together only may sign obligation issue transaction."
            }
            transaction {
                command(bob.publicKey, ObligationContract.Commands.Issue())
                output(OBLIGATION_CONTRACT_ID, oneDollarObligation)
                timeWindow(Instant.now(), 60.seconds)
                this `fails with` "Both lender and borrower together only may sign obligation issue transaction."
            }
            transaction {
                command(listOf(bob.publicKey, bob.publicKey, bob.publicKey), ObligationContract.Commands.Issue())
                output(OBLIGATION_CONTRACT_ID, oneDollarObligation)
                timeWindow(Instant.now(), 60.seconds)
                this `fails with` "Both lender and borrower together only may sign obligation issue transaction."
            }
            transaction {
                command(listOf(bob.publicKey, bob.publicKey, dummyIdentity.publicKey, alice.publicKey), ObligationContract.Commands.Issue())
                output(OBLIGATION_CONTRACT_ID, oneDollarObligation)
                timeWindow(Instant.now(), 60.seconds)
                this `fails with` "Both lender and borrower together only may sign obligation issue transaction."
            }
            transaction {
                command(listOf(bob.publicKey, bob.publicKey, bob.publicKey, alice.publicKey), ObligationContract.Commands.Issue())
                output(OBLIGATION_CONTRACT_ID, oneDollarObligation)
                timeWindow(Instant.now(), 60.seconds)
                verifies()
            }
            transaction {
                command(listOf(alice.publicKey, bob.publicKey), ObligationContract.Commands.Issue())
                output(OBLIGATION_CONTRACT_ID, oneDollarObligation)
                timeWindow(Instant.now(), 60.seconds)
                verifies()
            }
        }
    }

    @Test
    fun `lender and borrower cannot be the same`() {
        val borrowerIsLenderObligation = Obligation(10.POUNDS, alice.party, alice.party)
        ledgerServices.ledger {
            transaction {
                command(listOf(alice.publicKey, bob.publicKey), ObligationContract.Commands.Issue())
                output(OBLIGATION_CONTRACT_ID, borrowerIsLenderObligation)
                timeWindow(Instant.now(), 60.seconds)
                this `fails with` "The lender and borrower cannot be the same identity."
            }
            transaction {
                command(listOf(alice.publicKey, bob.publicKey), ObligationContract.Commands.Issue())
                output(OBLIGATION_CONTRACT_ID, oneDollarObligation)
                timeWindow(Instant.now(), 60.seconds)
                verifies()
            }
        }
    }
}