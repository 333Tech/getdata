package com.synechron.cordapp.obligation.tests

import com.synechron.cordapp.obligation.state.Obligation
import net.corda.core.contracts.CommandData
import net.corda.core.contracts.ContractState
import net.corda.core.identity.AbstractParty
import net.corda.core.identity.CordaX500Name
import net.corda.core.internal.packageName
import net.corda.finance.DOLLARS
import net.corda.finance.POUNDS
import net.corda.finance.schemas.CashSchemaV1
import net.corda.testing.core.TestIdentity
import net.corda.testing.node.MockServices
import net.corda.testing.node.makeTestIdentityService

/**
 * A base class to reduce the boilerplate when writing obligation contract tests.
 */
abstract class AbstractContractUnitTests {
    protected val ledgerServices = MockServices(
            listOf("com.synechron.cordapp.obligation.contract", "net.corda.testing.contracts",
                    "net.corda.finance.contracts.asset", CashSchemaV1::class.packageName),
            identityService = makeTestIdentityService(),
            initialIdentity = TestIdentity(CordaX500Name("TestIdentity", "", "GB")))

    protected val alice = TestIdentity(CordaX500Name("Alice", "", "GB"))
    protected val bob = TestIdentity(CordaX500Name("Bob", "", "GB"))
    protected val charlie = TestIdentity(CordaX500Name("Bob", "", "GB"))

    protected class DummyState : ContractState {
        override val participants: List<AbstractParty> get() = listOf()
    }

    protected class DummyCommand : CommandData

    protected val oneDollarObligation = Obligation(1.POUNDS, alice.party, bob.party)
    protected val tenDollarObligation = Obligation(10.DOLLARS, alice.party, bob.party)
}
