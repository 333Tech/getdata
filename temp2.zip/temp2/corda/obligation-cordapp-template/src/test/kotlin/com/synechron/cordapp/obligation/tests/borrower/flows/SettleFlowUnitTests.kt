package com.synechron.cordapp.obligation.tests.borrower.flows

import com.synechron.cordapp.obligation.tests.AbstractFlowUnitTests
import com.synechron.cordapp.obligation.commons.exception.InvalidFlowInitiatorException
import com.synechron.cordapp.obligation.state.Obligation
import net.corda.core.contracts.withoutIssuer
import net.corda.core.flows.FlowException
import net.corda.finance.POUNDS
import net.corda.finance.contracts.asset.Cash
import net.corda.testing.internal.chooseIdentity
import net.corda.testing.node.StartedMockNode
import org.junit.Assert.assertEquals
import org.junit.Test

class SettleFlowUnitTests : AbstractFlowUnitTests() {

    // Helper for extracting the cash output owned by a the node.
    private fun getCashOutputByOwner(
            cashStates: List<Cash.State>,
            node: StartedMockNode): Cash.State {
        return cashStates.single { cashState ->
            val cashOwner = node.services.identityService.requireWellKnownPartyFromAnonymous(cashState.owner)
            cashOwner == node.info.chooseIdentity()
        }
    }

    @Test
    fun `Settle flow can only be started by borrower`() {
        // Issue obligation.
        val issuanceTransaction = issueObligation(borrower, lender, 1000.POUNDS)
        network.waitQuiescent()
        val issuedObligation = issuanceTransaction.tx.outputStates.first() as Obligation

        // Attempt settlement.
        kotlin.test.assertFailsWith<InvalidFlowInitiatorException> {
            settleObligation(issuedObligation.linearId, lender, 1000.POUNDS)
        }
    }

    @Test
    fun `Settle flow fails when borrower has no cash`() {
        // Issue obligation.
        val issuanceTransaction = issueObligation(borrower, lender, 1000.POUNDS)
        network.waitQuiescent()
        val issuedObligation = issuanceTransaction.tx.outputStates.first() as Obligation

        // Attempt settlement.
        kotlin.test.assertFailsWith<FlowException> {
            settleObligation(issuedObligation.linearId, borrower, 1000.POUNDS)
        }
    }

    @Test
    fun `Settle flow fails when borrower pledges too much cash to settle`() {
        // Self issue cash.
        selfIssueCash(borrower, 1500.POUNDS)
        network.waitQuiescent()

        // Issue obligation.
        val issuanceTransaction = issueObligation(borrower, lender, 1000.POUNDS)
        network.waitQuiescent()
        val issuedObligation = issuanceTransaction.tx.outputStates.first() as Obligation

        // Attempt settlement.
        kotlin.test.assertFailsWith<FlowException> {
            settleObligation(issuedObligation.linearId, borrower, 1500.POUNDS)
        }
    }

    @Test
    fun `Fully settle non-anonymous obligation`() {
        // Self issue cash.
        selfIssueCash(borrower, 1500.POUNDS)
        network.waitQuiescent()

        // Issue obligation.
        val issuanceTransaction = issueObligation(borrower, lender, 1000.POUNDS)
        network.waitQuiescent()
        val issuedObligation = issuanceTransaction.tx.outputStates.first() as Obligation

        // Attempt settlement.
        val settleTransaction = settleObligation(issuedObligation.linearId, borrower, 1000.POUNDS)
        network.waitQuiescent()
        assert(settleTransaction.tx.outputsOfType<Obligation>().isEmpty())

        // Check both parties have the transaction.
        val aTx = borrower.services.validatedTransactions.getTransaction(settleTransaction.id)
        val bTx = lender.services.validatedTransactions.getTransaction(settleTransaction.id)
        assertEquals(aTx, bTx)
    }

    @Test
    fun `Fully settle anonymous obligation`() {
        // Self issue cash.
        selfIssueCash(borrower, 1500.POUNDS)

        // Issue obligation.
        val issuanceTransaction = issueObligation(borrower, lender, 1000.POUNDS)
        network.waitQuiescent()
        val issuedObligation = issuanceTransaction.tx.outputStates.first() as Obligation

        // Attempt settlement.
        val settleTransaction = settleObligation(issuedObligation.linearId, borrower, 1000.POUNDS)
        network.waitQuiescent()
        assert(settleTransaction.tx.outputsOfType<Obligation>().isEmpty())

        // Check both parties have the transaction.
        val aTx = borrower.services.validatedTransactions.getTransaction(settleTransaction.id)
        val bTx = lender.services.validatedTransactions.getTransaction(settleTransaction.id)
        assertEquals(aTx, bTx)
    }

    @Test
    fun `Partially settle non-anonymous obligation with non-anonymous cash payment`() {
        // Self issue cash.
        selfIssueCash(borrower, 1500.POUNDS)
        network.waitQuiescent()

        // Issue obligation.
        val issuanceTransaction = issueObligation(borrower, lender, 1000.POUNDS)
        network.waitQuiescent()
        val issuedObligation = issuanceTransaction.tx.outputStates.first() as Obligation

        // Attempt settlement.
        val amountToSettle = 500.POUNDS
        val settleTransaction = settleObligation(issuedObligation.linearId, borrower, amountToSettle)
        network.waitQuiescent()
        assertEquals(1, settleTransaction.tx.outputsOfType<Obligation>().size)

        // Check both parties have the transaction.
        val aTx = borrower.services.validatedTransactions.getTransaction(settleTransaction.id)
        val bTx = lender.services.validatedTransactions.getTransaction(settleTransaction.id)
        assertEquals(aTx, bTx)

        // Check the obligation paid amount is correctly updated.
        val partiallySettledObligation = settleTransaction.tx.outputsOfType<Obligation>().single()
        assertEquals(amountToSettle, partiallySettledObligation.paid)

        // Check cash has gone to the correct parties.
        val outputCash = settleTransaction.tx.outputsOfType<Cash.State>()
        assertEquals(2, outputCash.size)       // Cash to b and change to a.

        // Change addresses are always anonymous, I think.
        val change = getCashOutputByOwner(outputCash, borrower)
        assertEquals(1000.POUNDS, change.amount.withoutIssuer())

        val payment = getCashOutputByOwner(outputCash, lender)
        assertEquals(500.POUNDS, payment.amount.withoutIssuer())
    }

    @Test
    fun `Partially settle non-anonymous obligation with anonymous cash payment`() {
        // Self issue cash.
        selfIssueCash(borrower, 1500.POUNDS)
        network.waitQuiescent()

        // Issue obligation.
        val issuanceTransaction = issueObligation(borrower, lender, 1000.POUNDS)
        network.waitQuiescent()
        val issuedObligation = issuanceTransaction.tx.outputStates.first() as Obligation

        // Attempt settlement.
        val amountToSettle = 500.POUNDS
        val settleTransaction = settleObligation(issuedObligation.linearId, borrower, amountToSettle)
        network.waitQuiescent()
        assert(settleTransaction.tx.outputsOfType<Obligation>().size == 1)

        // Check both parties have the transaction.
        val aTx = borrower.services.validatedTransactions.getTransaction(settleTransaction.id)
        val bTx = lender.services.validatedTransactions.getTransaction(settleTransaction.id)
        assertEquals(aTx, bTx)

        // Check the obligation paid amount is correctly updated.
        val partiallySettledObligation = settleTransaction.tx.outputsOfType<Obligation>().single()
        assertEquals(amountToSettle, partiallySettledObligation.paid)

        // Check cash has gone to the correct parties.
        val outputCash = settleTransaction.tx.outputsOfType<Cash.State>()
        assertEquals(2, outputCash.size)       // Cash to b and change to borrower.

        val change = getCashOutputByOwner(outputCash, borrower)
        assertEquals(1000.POUNDS, change.amount.withoutIssuer())

        val payment = getCashOutputByOwner(outputCash, lender)
        assertEquals(500.POUNDS, payment.amount.withoutIssuer())
    }

    @Test
    fun `Partially settle anonymous obligation with anonymous cash payment`() {
        // Self issue cash.
        selfIssueCash(borrower, 1500.POUNDS)
        network.waitQuiescent()

        // Issue obligation.
        val issuanceTransaction = issueObligation(borrower, lender, 1000.POUNDS)
        network.waitQuiescent()
        val issuedObligation = issuanceTransaction.tx.outputStates.first() as Obligation

        // Attempt settlement.
        val amountToSettle = 500.POUNDS
        val settleTransaction = settleObligation(issuedObligation.linearId, borrower, amountToSettle)
        network.waitQuiescent()
        assertEquals(1, settleTransaction.tx.outputsOfType<Obligation>().size)

        // Check both parties have the transaction.
        val aTx = borrower.services.validatedTransactions.getTransaction(settleTransaction.id)
        val bTx = lender.services.validatedTransactions.getTransaction(settleTransaction.id)
        assertEquals(aTx, bTx)

        // Check the obligation paid amount is correctly updated.
        val partiallySettledObligation = settleTransaction.tx.outputsOfType<Obligation>().single()
        assertEquals(amountToSettle, partiallySettledObligation.paid)

        // Check cash has gone to the correct parties.
        val outputCash = settleTransaction.tx.outputsOfType<Cash.State>()
        assertEquals(2, outputCash.size)       // Cash to b and change to a.

        val change = getCashOutputByOwner(outputCash, borrower)
        assertEquals(1000.POUNDS, change.amount.withoutIssuer())

        val payment = getCashOutputByOwner(outputCash, lender)
        assertEquals(500.POUNDS, payment.amount.withoutIssuer())
    }

}
