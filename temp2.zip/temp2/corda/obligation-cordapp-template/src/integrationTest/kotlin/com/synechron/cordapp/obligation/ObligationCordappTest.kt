package com.synechron.cordapp.obligation

import com.synechron.cordapp.obligation.borrower.flows.IssueObligationInitiatorFlow
import com.synechron.cordapp.obligation.borrower.flows.SettleObligationInitiatorFlow
import com.synechron.cordapp.obligation.state.Obligation
import net.corda.client.rpc.CordaRPCClient
import net.corda.core.identity.CordaX500Name
import net.corda.core.utilities.OpaqueBytes
import net.corda.core.utilities.getOrThrow
import net.corda.finance.DOLLARS
import net.corda.finance.USD
import net.corda.finance.flows.CashIssueFlow
import net.corda.finance.workflows.getCashBalances
import net.corda.testing.driver.DriverParameters
import net.corda.testing.driver.driver
import net.corda.testing.node.NotarySpec
import net.corda.testing.node.User
import org.junit.Test
import kotlin.test.assertEquals

class ObligationCordappTest {
    @Test
    fun `obligation cordapp integration test`() {
        driver(DriverParameters(isDebug = true,
                startNodesInProcess = true,
                extraCordappPackagesToScan = listOf("net.corda.finance"),
                notarySpecs = listOf(NotarySpec(CordaX500Name("Notary", "London", "GB"))))
        ) {
            val testUser = User("usr1", "pass", setOf("ALL"))
            // This starts nodes simultaneously with startNode, which returns a future that completes when the node
            // has completed startup. Then these are all resolved with getOrThrow which returns the NodeHandle list.
            val (borrowerHandle, lenderHandle) = listOf(
                    startNode(providedName = CordaX500Name("BorrowerA", "London", "GB"), rpcUsers = listOf(testUser)),
                    startNode(providedName = CordaX500Name("LenderA", "New York", "US"), rpcUsers = listOf(testUser))
            ).map { it.getOrThrow() }

            val borrowerClient = CordaRPCClient(borrowerHandle.rpcAddress)
            val borrowerProxy = borrowerClient.start(testUser.username, testUser.password).proxy

            val lenderClient = CordaRPCClient(lenderHandle.rpcAddress)
            val lenderProxy = lenderClient.start(testUser.username, testUser.password).proxy

            val lenderParty = lenderProxy.nodeInfo().legalIdentities.first()
            val borrowerParty = borrowerProxy.nodeInfo().legalIdentities.first()
            val notaryParty = defaultNotaryHandle.identity

            //Issue obligation.
            borrowerProxy.startFlowDynamic(IssueObligationInitiatorFlow::class.java,
                    DOLLARS(1000),
                    lenderParty,
                    false).returnValue.getOrThrow()

            //Verify obligation issued.
            listOf(borrowerProxy, lenderProxy).forEach {
                val obligation = it.vaultQuery(Obligation::class.java).states.single().state.data
                assertEquals(obligation.amount, DOLLARS(1000))
                assertEquals(obligation.lender, lenderParty)
                assertEquals(obligation.borrower, borrowerParty)
            }

            //Self-issue and verify cash to Borrower.
            borrowerProxy.startFlowDynamic(CashIssueFlow::class.java,
                    DOLLARS(1200),
                    OpaqueBytes.of(0),
                    notaryParty).returnValue.getOrThrow()
            assertEquals(borrowerProxy.getCashBalances(), mapOf(Pair(USD, DOLLARS(1200))))

            //Verify cash balance of Lender.
            assertEquals(lenderProxy.getCashBalances(), mapOf())

            //Get obligation.
            val obligation = borrowerProxy.vaultQuery(Obligation::class.java).states.single().state.data
            //Settle obligation.
            borrowerProxy.startFlowDynamic(SettleObligationInitiatorFlow::class.java,
                    obligation.linearId,
                    DOLLARS(1000),
                    false).returnValue.getOrThrow()

            //Verify vault of lender and borrower after settlement.
            assertEquals(borrowerProxy.getCashBalances(), mapOf(Pair(USD, DOLLARS(200))))
            assertEquals(lenderProxy.getCashBalances(), mapOf(Pair(USD, DOLLARS(1000))))
            listOf(borrowerHandle, lenderHandle).forEach {
                assertEquals(it.rpc.vaultQuery(Obligation::class.java).states.size, 0)
            }
        }
    }
}