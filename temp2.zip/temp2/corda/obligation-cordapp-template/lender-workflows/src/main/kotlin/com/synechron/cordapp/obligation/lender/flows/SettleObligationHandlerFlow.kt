package com.synechron.cordapp.obligation.lender.flows

import co.paralleluniverse.fibers.Suspendable
import com.synechron.cordapp.obligation.commons.flows.SignTxFlowVerify
import com.synechron.cordapp.obligation.flows.AbstractSettleObligationFlow
import net.corda.confidential.IdentitySyncFlow
import net.corda.core.flows.FlowLogic
import net.corda.core.flows.FlowSession
import net.corda.core.flows.InitiatedBy
import net.corda.core.flows.ReceiveFinalityFlow
import net.corda.core.transactions.SignedTransaction

@InitiatedBy(AbstractSettleObligationFlow::class)
class SettleObligationHandlerFlow(private val otherSideSession: FlowSession) : FlowLogic<SignedTransaction>() {
    @Suspendable
    override fun call(): SignedTransaction {
        subFlow(IdentitySyncFlow.Receive(otherSideSession))
        val stx = subFlow(SignTxFlowVerify(otherSideSession))
        return subFlow(ReceiveFinalityFlow(otherSideSession, stx.id))
    }
}
