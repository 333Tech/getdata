package com.synechron.cordapp.obligation.state

import com.synechron.cordapp.obligation.contract.NetworkTimeContract
import net.corda.core.contracts.BelongsToContract
import net.corda.core.contracts.LinearState
import net.corda.core.contracts.UniqueIdentifier
import net.corda.core.identity.AbstractParty

@BelongsToContract(NetworkTimeContract::class)
data class NetworkTime(val millis: Long,
                       override val linearId: UniqueIdentifier = UniqueIdentifier(),
                       override val participants: List<AbstractParty>
) : LinearState