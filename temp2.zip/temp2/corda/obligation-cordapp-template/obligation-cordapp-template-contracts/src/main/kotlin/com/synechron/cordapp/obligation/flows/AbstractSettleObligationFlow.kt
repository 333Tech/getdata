package com.synechron.cordapp.obligation.flows

import net.corda.core.flows.FlowLogic
import net.corda.core.flows.InitiatingFlow

/**
 * An abstract FlowLogic class that is used to implement Node specific Initiator and Handler classes.
 * It also provides helper methods.
 */
@InitiatingFlow
abstract class AbstractSettleObligationFlow<out T> : FlowLogic<T>(), FlowHelper