package com.synechron.cordapp.obligation.contract

import com.synechron.cordapp.obligation.state.NetworkTime
import net.corda.core.contracts.*
import net.corda.core.transactions.LedgerTransaction

class NetworkTimeContract : Contract {
    companion object {
        @JvmStatic
        val NETWORK_TIME_CONTRACT_ID = NetworkTimeContract::class.java.name!!
    }

    interface Commands : CommandData {
        class CreateNetworkOffset : TypeOnlyCommandData(), Commands
        class ResetNetworkOffset : TypeOnlyCommandData(), Commands
    }

    override fun verify(tx: LedgerTransaction) {
        require(tx.timeWindow?.midpoint != null) { "Transaction must be timestamped" }
        val command = tx.commands.requireSingleCommand<Commands>()
        when (command.value) {
            is Commands.CreateNetworkOffset -> verifyNetworkOffset(tx)
            is Commands.ResetNetworkOffset -> verifyResetNetworkOffset(tx)
            else -> throw IllegalArgumentException("Unrecognised command")
        }
    }

    private fun verifyNetworkOffset(tx: LedgerTransaction) = requireThat {
        "Input state should be zero or one." using (tx.inputStates.filterIsInstance<NetworkTime>().size <= 1)
        val outputStates = tx.outputStates.filterIsInstance<NetworkTime>()
        "Output state should be single." using (outputStates.size == 1)
        "Time offset value (i.e. millis) must be greater than zero." using (outputStates.first().millis > 0L)
    }

    private fun verifyResetNetworkOffset(tx: LedgerTransaction) = requireThat {
        "Input state must be single." using (tx.inputStates.filterIsInstance<NetworkTime>().size == 1)
        val outputStates = tx.outputStates.filterIsInstance<NetworkTime>()
        "Output state should be single." using (outputStates.size == 1)
        "Time offset value must be zero." using (outputStates.first().millis == 0L)
    }
}