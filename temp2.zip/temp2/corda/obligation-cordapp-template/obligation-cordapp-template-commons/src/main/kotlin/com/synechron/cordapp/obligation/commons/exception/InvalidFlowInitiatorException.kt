package com.synechron.cordapp.obligation.commons.exception

import net.corda.core.CordaRuntimeException

class InvalidFlowInitiatorException(override val message: String) : CordaRuntimeException(message)