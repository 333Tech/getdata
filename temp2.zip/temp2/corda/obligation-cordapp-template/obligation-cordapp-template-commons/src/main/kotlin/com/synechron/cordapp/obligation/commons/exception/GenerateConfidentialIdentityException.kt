package com.synechron.cordapp.obligation.commons.exception

import net.corda.core.CordaRuntimeException

class GenerateConfidentialIdentityException(override val message: String) : CordaRuntimeException(message)