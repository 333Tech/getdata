#!/bin/bash

BASE_DIR=$PWD
BASE_PROJECT_NAME=obligation-cordapp-template

RED=$'\e[1;31m'
GREEN=$'\e[1;32m'
YELLOW=$'\e[1;33m'
BLUE=$'\e[1;34m'
PINK=$'\e[1;35m'
CYAN=$'\e[1;96m'
WHITE=$'\e[1;39m'
COLOR_END=$'\e[0'
NC=$'\033[0m'


function print_banner() {
        printf $RED'    _____            _____       ______            ____           _____       ______         ______       ______________       \n'
        printf $RED'  /  ____ \         |      \    |   ___ \         /    \         |     \     /      \       /      \     |              |      \n'
        printf $RED' / /     \ \   ___  |  --   |   |  |   \ \       /  /\  \        |  __  |   /  ____  \     /  ____  \    |_____    _____|      \n'
        printf $RED' | |          /    \|  --  /    |  |    \ \     /  /__\  \       |     /   |          |   |          |         |  |            \n'
        printf $RED' | |         |      |     /     |  |    | |    /   ____   \      |    |    |          |   |          |         |  |            \n'
        printf $RED' | |          \____/|  |\ \     |  |    / /   /   /    \   \     |     \   |   ____   |   |   ____   |         |  |            \n'
        printf $RED' \ \ ____/ /        |  | \ \    |  |___/ /   /   /      \   \    |  __  |   \         /    \         /         |  |            \n'
        printf $RED'  \ ______/         |__|  \_\   |______ /   /___/        \___\   |_____/     \_______/      \_______/          |__|            \n'
        printf $NC
}



function rename_project_name(){
   cd "$BASE_DIR"
   cd ..
   echo $YELLOW"Enter your project name"$BLUE
   read PROJECT_NAME
   if [ -d "obligation-cordapp-template" ]
      then
      cp -a obligation-cordapp-template/. $PROJECT_NAME
      echo $YCAN"Renamed obligation-cordapp-template to "$PROJECT_NAME" "$NC
   else
      echo $RED"Directory not exist"$NC
   fi
   cd "$PROJECT_NAME"
   sed -i -e '/name=/s/=.*/='$PROJECT_NAME'/' gradle.properties
   sed -i -e '/rootProject.name =/ s/= .*/= '"'"$PROJECT_NAME"'"'/' settings.gradle

   BASE_PROJECT_NAME=$PROJECT_NAME
   BASE_DIR=$PWD
}


function rename_root_package_name(){
  cd "$BASE_DIR"
  mkdir "$BASE_DIR/temp"
  mv obligation-cordapp-template-contracts/* "$BASE_DIR/temp"
  cd "$BASE_DIR"
  rm -rf obligation-cordapp-template-contracts

  echo $YELLOW"Enter root package name"$BLUE
  read ROOT_PACKAGE_NAME
  ROOT_PACKAGE_DIR=$(echo $ROOT_PACKAGE_NAME | sed 's/\./\//g')

  #delete temp backup after creating new build.gradle,resource and package content as per new package
  CONTRACT_DIR=$BASE_PROJECT_NAME"-contracts/src/main/kotlin/"$ROOT_PACKAGE_DIR
  mkdir -p "$CONTRACT_DIR"
  cd "$BASE_DIR"
  mv temp/src/main/kotlin/com/synechron/cordapp/obligation/* "$CONTRACT_DIR"
  mv "temp/build.gradle" $BASE_PROJECT_NAME"-contracts"
  mkdir $BASE_PROJECT_NAME"-contracts/src/main/resources"
  cd "$BASE_DIR"
  mv temp/src/main/resources/* $BASE_PROJECT_NAME"-contracts/src/main/resources"
  rm -rf "$BASE_DIR/temp"

  #replace new project name and package in Whitelist
  cd "$BASE_DIR/"$BASE_PROJECT_NAME"-contracts/src/main/resources/META-INF/services"
  sed -i 's/'com.synechron.cordapp.obligation'/'$ROOT_PACKAGE_NAME'/g' net.corda.core.serialization.SerializationWhitelist

  #replace new project name and package in gradle.properties
  cd "$BASE_DIR"
  sed -i 's/'name=obligation-cordapp-template'/'name=$BASE_PROJECT_NAME'/g' gradle.properties
  sed -i 's/'group=com.synechron.cordapp.obligation'/'group=$ROOT_PACKAGE_NAME'/g' gradle.properties

  #replace new project name and package in settings.gradle
  cd "$BASE_DIR"
  sed -i 's/"rootProject.name = 'obligation-cordapp-template'"/"rootProject.name ='$BASE_PROJECT_NAME'"/g' settings.gradle
  sed -i 's/'obligation-cordapp-template'/'$BASE_PROJECT_NAME'/g' settings.gradle

  #replace new package in constants.properties
  cd "$BASE_DIR"
  sed -i 's/'obligation-cordapp-template'/'$BASE_PROJECT_NAME'/g' constants.properties

  #echo $PWD
  cd "$BASE_DIR"
  cd "$CONTRACT_DIR"
  #PACKAGE=$( echo $ROOT_PACKAGE_NAME | sed 's/\//./g')
  #echo $PACKAGE
  find ./ -type f -name '*.kt' -exec sed -i 's/com.synechron.cordapp.obligation/'$ROOT_PACKAGE_NAME'/g' {} \;
  echo $CYAN"Root package name has been changed to "$ROOT_PACKAGE_NAME""
  cd "$BASE_DIR"
  sed -i -e '/group=/s/=.*/='$ROOT_PACKAGE_NAME'/' gradle.properties
  cd "$BASE_DIR"

  if [ -d "obligation-cordapp-template-commons" ]
    then
#       cd obligation-cordapp-template-commons/src/main/kotlin
       mkdir "$BASE_DIR/temp"
#       mv com/synechron/cordapp/obligation/* "$BASE_DIR/temp"
       mv obligation-cordapp-template-commons/* "$BASE_DIR/temp"
       cd "$BASE_DIR"
       rm -rf obligation-cordapp-template-commons

       #delete temp backup after creating new build.gradle,resource and package content as per new package
       COMMONS_DIR=$BASE_PROJECT_NAME"-commons/src/main/kotlin/"$ROOT_PACKAGE_DIR"/commons"
       mkdir -p "$COMMONS_DIR"
       cd "$BASE_DIR"
       mv temp/src/main/kotlin/com/synechron/cordapp/obligation/commons/* "$COMMONS_DIR"
       mv "temp/build.gradle" $BASE_PROJECT_NAME"-commons"
       mkdir $BASE_PROJECT_NAME"-commons/src/main/resources"
       cd "$BASE_DIR"
       mv temp/src/main/resources/* $BASE_PROJECT_NAME"-commons/src/main/resources"
       rm -rf "$BASE_DIR/temp"

#       mv temp/* "$COMMONS_DIR"
#       rm -rf "$BASE_DIR/temp"
       cd "$COMMONS_DIR"
       #PACKAGE=$(echo $ROOT_PACKAGE_NAME | sed 's/\//./g')
       #echo $PACKAGE
       #echo $PWD
       find ./ -type f -name '*.kt' -exec sed -i -e 's/com.synechron.cordapp.obligation/'$ROOT_PACKAGE_NAME'/g' {} \;
    else
       echo "obligation-cordapp-template-commons: no such directory."
  fi
 cd "$BASE_DIR"
 }

function add_new_module(){
  cd "$BASE_DIR"
  echo $YELLOW"How many module you want to create: "$BLUE
  read  MODULE_COUNT
  for ((i=1;i<=$MODULE_COUNT;i++));do
     #echo $i
     if [ $i == 1 ];then
       echo $YELLOW"Enter "$i" module name: "$BLUE
       read  MODULE_NAME
       mkdir "$MODULE_NAME"
       cp -a borrower-workflows/. "$MODULE_NAME"
       cd "$MODULE_NAME/src/main/kotlin"
       mkdir -p temp
       mv com/synechron/cordapp/obligation/borrower/flows temp
       rm -rf com
       echo $YELLOW"Enter package name for "$MODULE_NAME": "$BLUE
       read  MODULE_1_PACKAGE_NAME
       MODULE_PKG_DIR=$(echo $MODULE_1_PACKAGE_NAME | sed 's/\./\//g')
       #echo $DIR
       mkdir -p $MODULE_PKG_DIR
       mv temp/flows $MODULE_PKG_DIR
       rm -rf temp
       cd $MODULE_PKG_DIR
       #PACKAGE=$( echo $MODULE_1_PACKAGE_NAME | sed 's/\//./g')
       #echo $PACKAGE
       find ./ -type f -name '*.kt' -exec sed -i -e 's/com.synechron.cordapp.obligation.borrower/'$MODULE_1_PACKAGE_NAME'/' {} \;
       find ./ -type f -name '*.kt' -exec sed -i 's/com.synechron.cordapp.obligation/'$ROOT_PACKAGE_NAME'/g' {} \;
       echo $CYAN$MODULE_NAME "module created."$NC
       cd "$BASE_DIR"
       sed -i -e 's/borrower-workflows/'$MODULE_NAME'/g' settings.gradle

       #replace new module name in constants.properties
       cd "$BASE_DIR"
       sed -i 's/'borrower-workflows'/'$MODULE_NAME'/g' constants.properties

       echo $CYAN"..........................................................................."$NC
       cd "$BASE_DIR"
     fi
     if [ $i == 2 ];then
         echo $YELLOW"Enter "$i" module name: "$BLUE
         read  MODULE_NAME
         mkdir "$MODULE_NAME"
         cp -a lender-workflows/. "$MODULE_NAME"
         cd "$MODULE_NAME/src/main/kotlin"
         mkdir -p temp
         mv com/synechron/cordapp/obligation/lender/flows temp
         rm -rf com
         echo $YELLOW"Enter package name for "$MODULE_NAME": "$BLUE
         read  MODULE_2_PACKAGE_NAME
         MODULE_2_PKG_DIR=$(echo $MODULE_2_PACKAGE_NAME | sed 's/\./\//g')
         #echo $DIR
         mkdir -p $MODULE_2_PKG_DIR
         mv temp/flows $MODULE_2_PKG_DIR
         rm -rf temp
         cd $MODULE_2_PKG_DIR
         #PACKAGE=$( echo $MODULE_2_PACKAGE_NAME | sed 's/\//./g')
         #echo $PWD
         find ./ -type f -name '*.kt' -exec sed -i -e 's/com.synechron.cordapp.obligation.lender/'$MODULE_2_PACKAGE_NAME'/' {} \;
         find ./ -type f -name '*.kt' -exec sed -i 's/com.synechron.cordapp.obligation/'$ROOT_PACKAGE_NAME'/g' {} \;
         echo $CYAN$MODULE_NAME "module created."$NC
         cd "$BASE_DIR"
         sed -i -e 's/lender-workflows/'$MODULE_NAME'/g' settings.gradle
         printf "\n" >> settings.gradle

         #replace new module name in constants.properties
         cd "$BASE_DIR"
         sed -i 's/'lender-workflows'/'$MODULE_NAME'/g' constants.properties

         echo $CYAN"..........................................................................."$NC
         cd "$BASE_DIR"
      fi
     if [ $i -gt 2 ];then
     echo $YELLOW"Enter "$i" module name: "$BLUE
     read  MODULE_NAME
     mkdir $MODULE_NAME
     cp -a borrower-workflows/. $MODULE_NAME
     cd $MODULE_NAME/src/main/kotlin
     #mkdir -p temp
     #mv com/synechron/cordapp/obligation/borrower/flows temp
     rm -rf com
     echo $YELLOW"Enter package name for "$MODULE_NAME": "$BLUE
     read  PACKAGE_NAME
     MODULE_N_PKG_DIR=$(echo $PACKAGE_NAME | sed 's/\./\//g')
     #echo $DIR
     mkdir -p $MODULE_N_PKG_DIR
     #mv temp/flows $PACKAGE_NAME
     #rm -rf temp
     cd $MODULE_N_PKG_DIR
     #PACKAGE=$( echo $PACKAGE_NAME | sed 's/\//./g')
     #echo $PACKAGE
     find ./ -type f -name '*.kt' -exec sed -i -e 's/com.synechron.cordapp.obligation.borrower/'$PACKAGE_NAME'/' {} \;
     echo $CYAN$MODULE_NAME "module created"$NC
     cd "$BASE_DIR"
     printf "include '$MODULE_NAME'\n" >> settings.gradle
     echo $CYAN"..........................................................................."$NC
    fi
   done

  #delete temp backup after creating new test package content
   cd "$BASE_DIR"
   mkdir "$BASE_DIR/temp"
   mv src/* "$BASE_DIR/temp"
   cd "$BASE_DIR"
   rm -rf src

   cd "$BASE_DIR"
   TEST_DIR=$BASE_DIR"/src/test/kotlin/"$ROOT_PACKAGE_DIR"/tests"
   mkdir -p "$TEST_DIR"
   cd "$BASE_DIR"
   mv $BASE_DIR/temp/test/kotlin/com/synechron/cordapp/obligation/tests/* $TEST_DIR

   # get last element after "." Ex. com.net.spv ---> spv
   SPLIT_MODULENAME=$(echo $MODULE_PKG_DIR | grep -oE "[^/]+$")
   # remove last element after "." and append tests Ex. com.net.spv ---> com.net.tests
   TEST_ROOT_DIR=$(echo ${MODULE_1_PACKAGE_NAME%.*})".tests"
   cd "$BASE_DIR"
   mkdir -p $TEST_DIR/$SPLIT_MODULENAME
   cd "$BASE_DIR"
   mv $TEST_DIR/borrower/* $TEST_DIR/$SPLIT_MODULENAME
   rm -rf $TEST_DIR"/borrower"

  #replace package and import with new package of test folder
   PCK_ONE=$TEST_ROOT_DIR"."$SPLIT_MODULENAME
   cd "$BASE_DIR"
   cd $TEST_DIR/$SPLIT_MODULENAME"/contract"
   sed -i 's/'com.synechron.cordapp.obligation.state'/'$ROOT_PACKAGE_NAME'.state/g' *.kt
   sed -i 's/'com.synechron.cordapp.obligation.contract'/'$ROOT_PACKAGE_NAME'.contract/g' *.kt
   sed -i 's/'com.synechron.cordapp.obligation.tests.borrower.contract'/'$PCK_ONE'.contract/g' *.kt
   sed -i 's/'com.synechron.cordapp.obligation.tests'/'$TEST_ROOT_DIR'/g' *.kt
   cd $TEST_DIR/$SPLIT_MODULENAME"/flows"
   sed -i 's/'com.synechron.cordapp.obligation.state'/'$ROOT_PACKAGE_NAME'.state/g' *.kt
   sed -i 's/'com.synechron.cordapp.obligation.commons'/'$ROOT_PACKAGE_NAME'.commons/g' *.kt
   sed -i 's/'com.synechron.cordapp.obligation.tests.borrower.flows'/'$PCK_ONE'.flows/g' *.kt
   sed -i 's/'com.synechron.cordapp.obligation.tests'/'$TEST_ROOT_DIR'/g' *.kt
   cd $TEST_DIR"/commons/contract"
   sed -i 's/'com.synechron.cordapp.obligation.state'/'$ROOT_PACKAGE_NAME'.state/g' *.kt
   sed -i 's/'com.synechron.cordapp.obligation.contract'/'$ROOT_PACKAGE_NAME'.contract/g' *.kt
   sed -i 's/'com.synechron.cordapp.obligation.tests.commons.contract'/'$TEST_ROOT_DIR'.commons.contract/g' *.kt
   sed -i 's/'com.synechron.cordapp.obligation.tests'/'$TEST_ROOT_DIR'/g' *.kt
   cd $TEST_DIR"/commons/flows"
   sed -i 's/'com.synechron.cordapp.obligation.state'/'$ROOT_PACKAGE_NAME'.state/g' *.kt
   sed -i 's/'com.synechron.cordapp.obligation.contract'/'$ROOT_PACKAGE_NAME'.contract/g' *.kt
   sed -i 's/'com.synechron.cordapp.obligation.commons.flows'/'$ROOT_PACKAGE_NAME'.commons.flows/g' *.kt
   sed -i 's/'com.synechron.cordapp.obligation.tests.commons.flows'/'$TEST_ROOT_DIR'.commons.flows/g' *.kt
   sed -i 's/'com.synechron.cordapp.obligation.tests'/'$TEST_ROOT_DIR'/g' *.kt
   cd $TEST_DIR
   #replace MockNetwork package
   MOCK_SERVICE_OLD='"'com.synechron.cordapp.obligation.contract'"'
   MOCK_SERVICE_NEW='"'$ROOT_PACKAGE_NAME'.contract"'
   sed -i 's/'$MOCK_SERVICE_OLD'/'$MOCK_SERVICE_NEW'/g' AbstractContractUnitTests.kt
   MOCK_SERVICE_OLD='"'com.synechron.cordapp.obligation'"'
   MOCK_SERVICE_NEW='"'$ROOT_PACKAGE_NAME'"'
   sed -i 's/'$MOCK_SERVICE_OLD'/'$MOCK_SERVICE_NEW'/g' AbstractFlowUnitTests.kt

   sed -i 's/'com.synechron.cordapp.obligation.commons'/'$ROOT_PACKAGE_NAME'.commons/g' *.kt
   sed -i 's/'com.synechron.cordapp.obligation.state'/'$ROOT_PACKAGE_NAME'.state/g' *.kt
   sed -i 's/'com.synechron.cordapp.obligation.borrower'/'$MODULE_1_PACKAGE_NAME'/g' *.kt
   sed -i 's/'com.synechron.cordapp.obligation.lender'/'$MODULE_2_PACKAGE_NAME'/g' *.kt
   sed -i 's/'com.synechron.cordapp.obligation.tests'/'$TEST_ROOT_DIR'/g' *.kt

   #replace new package name in integration test folder.
   cd "$BASE_DIR"
   INTER_DIR=$BASE_DIR"/src/integrationTest/kotlin/"$MODULE_PKG_DIR
   mkdir -p "$INTER_DIR"
   cd "$BASE_DIR"
   mv $BASE_DIR/temp/integrationTest/kotlin/com/synechron/cordapp/obligation/* $INTER_DIR

   cd $INTER_DIR
   sed -i 's/'com.synechron.cordapp.obligation.state'/'$ROOT_PACKAGE_NAME'.state/g' *.kt
   sed -i 's/'com.synechron.cordapp.obligation.borrower'/'$MODULE_1_PACKAGE_NAME'/g' *.kt
   sed -i 's/'com.synechron.cordapp.obligation'/'$MODULE_1_PACKAGE_NAME'/g' *.kt

   rm -rf "$BASE_DIR/temp"

	#echo $PWD

#	if [ -d "borrower-workflows" ]
#      then
#      rm -r borrower-workflows
#    else
#      echo $RED"Directory not exist"$NC
#    fi
#
#    if [ -d "lender-workflows" ]
#      then
#      rm -r lender-workflows
#    else
#      echo $RED"Directory not exist"$NC
#    fi
#	cd ""

    cd "$BASE_DIR"
}


function change_build_config(){
	cd $BASE_DIR

	echo $YELLOW"Enter corda release version"$NC
	read CORDA_RELEASE_VERSION
	sed -i -e '/ext.corda_release_version =/ s/= .*/= '"'"$CORDA_RELEASE_VERSION"'"'/' build.gradle

	echo $YELLOW"Enter corda gradle plugins version"$NC
	read CORDA_GRADLE_PLUGIN_VERSION
	sed -i -e '/ext.corda_gradle_plugins_version =/ s/= .*/= '"'"$CORDA_GRADLE_PLUGIN_VERSION"'"'/' build.gradle

	echo $YELLOW"Enter kotlin version"$NC
	read KOTLIN_VERSION
	sed -i -e '/ext.kotlin_version =/ s/= .*/= '"'"$KOTLIN_VERSION"'"'/' build.gradle

	echo $YELLOW"Enter junit version"$NC
	read JUNIT_VERSION
	sed -i -e '/ext.junit_version =/ s/= .*/= '"'"$JUNIT_VERSION"'"'/' build.gradle

	echo $YELLOW"Enter quasar version"$NC
	read QUASAR_VERSION
	sed -i -e '/ext.quasar_version =/ s/= .*/= '"'"$QUASAR_VERSION"'"'/' build.gradle

	cd $BASE_DIR
}

function to_check(){

     PROJECT_NAME="Test.Cordapp-Template1"
     PACKAGE="com.testing.cordapp"
     #sed -i -e '/name=/s/=.*/='$PROJECT_NAME'/' gradle.properties
     #sed -i -e '/group=/s/=.*/='$PACKAGE'/' gradle.properties



     #sed -i -e '/rootProject.name =/ s/= .*/= '"'"$PROJECT_NAME"'"'/' settings.gradle
     var=$(echo $PACKAGE | sed 's/\./\//g')
     echo $var
     new_var=$(echo $var | sed -e 's/-//g')
     echo $new_var
     #echo "include 'MY_MODULE'" >> settings.gradle

}

print_banner
#to_check
rename_project_name
rename_root_package_name
add_new_module
change_build_config