package com.synechron.cordapp.obligation.client.lender.controller;

import java.util.HashMap;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Profile;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import com.synechron.cordapp.obligation.client.base.service.BaseService;
import com.synechron.cordapp.obligation.client.lender.service.ObligationService;

import io.swagger.annotations.ApiOperation;

@Profile("!mock")
@CrossOrigin
@RestController
@RequestMapping(value = "/lender/obligation")
public class LenderApiController implements LenderApi {

    @Autowired
    private ObligationService obligationService;
    @Autowired
    private BaseService baseService;

    /**
     * {@inheritDoc}
     */
    // @PreAuthorize("hasAnyRole('ROLE_USER', 'ROLE_ADMIN')")
    @ApiOperation(value = "Name of the Node", produces = MediaType.APPLICATION_JSON_VALUE)
    @RequestMapping(value = "/name", method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity getNodeName() {
        String nodeName = baseService.getNodeName();
        Map<String, String> map = new HashMap<>();
        map.put("name", nodeName);
        return new ResponseEntity<>(map, HttpStatus.OK);
    }

    /**
     * {@inheritDoc}
     */
    // @PreAuthorize("hasAnyRole('ROLE_USER', 'ROLE_ADMIN')")
    @ApiOperation(value = "Obligation list", produces = MediaType.APPLICATION_JSON_VALUE)
    @RequestMapping(value = "/obligations", method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity getObligations(@RequestParam(value = "page", defaultValue = "1") Integer page) {
        Map<String, Object> obligations = obligationService.getObligations(page);
        return new ResponseEntity<>(obligations, HttpStatus.OK);
    }
}
