package com.synechron.cordapp.obligation.client.lender.dao;

import java.util.List;

import org.springframework.data.util.Pair;

import com.synechron.cordapp.obligation.state.Obligation;

public interface ObligationDao {
    /**
     * Get all Obligation states on the ledger.
     *
     * @return list of Obligation states.
     */
    Pair<List<Obligation>, Long> getObligations(Integer page);
}
