package com.synechron.cordapp.obligation.client.lender.controller;

import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.RequestParam;

public interface LenderApi {
    /**
     * Get node information.
     *
     * @return name of the node.
     */
    ResponseEntity getNodeName();

    /**
     * Get all Obligation states on the ledger.
     *
     * @return list of obligation states.
     */
    ResponseEntity getObligations(@RequestParam(value = "page", defaultValue = "1") Integer page);

}
