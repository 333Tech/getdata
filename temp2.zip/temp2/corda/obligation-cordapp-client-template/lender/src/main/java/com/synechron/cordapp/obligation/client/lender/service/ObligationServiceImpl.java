package com.synechron.cordapp.obligation.client.lender.service;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.util.Pair;
import org.springframework.stereotype.Service;

import com.synechron.cordapp.obligation.client.base.model.response.Obligation;
import com.synechron.cordapp.obligation.client.base.service.BaseService;
import com.synechron.cordapp.obligation.client.lender.dao.ObligationDao;

@Service("obligationServiceLender")
public class ObligationServiceImpl implements ObligationService {

    @Autowired
    private ObligationDao obligationDao;
    @Autowired
    private BaseService baseService;

    /**
     * {@inheritDoc}
     */
    @Override
    public Map<String, Object> getObligations(Integer page) {
        Pair<List<com.synechron.cordapp.obligation.state.Obligation>, Long> dataAndPageCount = obligationDao.getObligations(page);
        List<Obligation> obligationModels = Obligation.getObligations(dataAndPageCount.getFirst(), baseService);
        Map<String, Object> obligationsAndPageCount = new HashMap<>();
        obligationsAndPageCount.put("Obligations", obligationModels);
        obligationsAndPageCount.put("totalPages", dataAndPageCount.getSecond());
        return obligationsAndPageCount;
    }

}
