package com.synechron.cordapp.obligation.client.lender.dao;

import java.util.List;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.PropertySource;
import org.springframework.data.util.Pair;
import org.springframework.stereotype.Repository;

import com.synechron.cordapp.obligation.client.base.rpc.NodeRPCConnection;
import com.synechron.cordapp.obligation.state.Obligation;

import net.corda.core.node.services.Vault;
import net.corda.core.node.services.vault.PageSpecification;
import net.corda.core.node.services.vault.QueryCriteria;

@Repository("obligationDaoLender")
@PropertySource("classpath:sql_query.properties")
public class ObligationDaoImpl implements ObligationDao {

    @Autowired
    private NodeRPCConnection rpcConnection;
    @Value("${corda.vault.pageSize}")
    private int pageSize;

    /**
     * {@inheritDoc}
     */
    @Override
    public Pair<List<Obligation>, Long> getObligations(Integer page) {
        Pair<List<Obligation>, Long> dataAndPageCount;
        QueryCriteria criteria = new QueryCriteria.VaultQueryCriteria(Vault.StateStatus.UNCONSUMED);
        Vault.Page<Obligation> obligationPage = rpcConnection.getProxy().vaultQueryByWithPagingSpec(Obligation.class, criteria,
                new PageSpecification(page, pageSize));
        List<Obligation> obligations = obligationPage.getStates().stream().map(it -> it.getState().getData()).collect(Collectors.toList());
        long totalStatesAvailable = obligationPage.getTotalStatesAvailable();
        totalStatesAvailable = totalStatesAvailable < pageSize ? 1 : ((long) Math.ceil(totalStatesAvailable / ((double) pageSize)));
        dataAndPageCount = Pair.of(obligations, totalStatesAvailable);
        return dataAndPageCount;
    }
}
