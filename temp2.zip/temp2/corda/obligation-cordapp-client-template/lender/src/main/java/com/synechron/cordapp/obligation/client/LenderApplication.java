package com.synechron.cordapp.obligation.client;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class LenderApplication {

    /**
     * This is Main method to which will start Spring Boot Application.
     *
     * @param args
     */
    public static void main(String[] args) {
        SpringApplication.run(LenderApplication.class, args);
    }
}
