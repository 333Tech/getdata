package com.synechron.cordapp.obligation.client.lender.service;

import java.util.Map;

public interface ObligationService {
    /**
     * Get all Obligation states on the ledger.
     * 
     * @return list of obligation states.
     */
    Map<String, Object> getObligations(Integer page);
}
