package com.synechron.cordapp.obligation.client.lender.controller.mock;

import org.springframework.context.annotation.Profile;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import com.synechron.cordapp.obligation.client.lender.controller.LenderApi;

import io.swagger.annotations.ApiOperation;

@Profile("mock")
@CrossOrigin
@RestController
@RequestMapping(value = "/obligation")
public class LenderApiController implements LenderApi {
    /**
     * {@inheritDoc}
     */
    @ApiOperation(value = "Name of the Node", produces = MediaType.APPLICATION_JSON_VALUE)
    @RequestMapping(value = "/name", method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity getNodeName() {
        return null;
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public ResponseEntity getObligations(@RequestParam(value = "page", defaultValue = "1") Integer page) {
        return null;
    }
}
