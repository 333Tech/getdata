package com.synechron.cordapp.obligation.client.lender.controller;

import static org.mockito.Mockito.when;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

import java.util.HashMap;
import java.util.Map;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.MediaType;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.request.MockMvcRequestBuilders;

import com.synechron.cordapp.obligation.client.base.service.BaseService;
import com.synechron.cordapp.obligation.client.lender.service.ObligationService;

@RunWith(SpringRunner.class)
@WebMvcTest(value = LenderApiController.class, secure = false)
public class LenderApiControllerTest {

    @InjectMocks
    private LenderApiController lenderApiController;
    @MockBean
    private BaseService baseService;
    @Autowired
    private MockMvc mvc;

    @MockBean
    private ObligationService obligationService;

    @Test
    public void testGetNodeName() throws Exception {
        String partyName = "PartyA";
        when(baseService.getNodeName()).thenReturn(partyName);

        mvc.perform(MockMvcRequestBuilders.get("/lender/obligation/name").contentType(MediaType.APPLICATION_JSON))
                .andExpect(status().isOk());
    }

    @Test
    public void testGetObligations() throws Exception {
        Map<String, Object> obligationMap = new HashMap<>();
        when(obligationService.getObligations(1)).thenReturn(obligationMap);

        mvc.perform(MockMvcRequestBuilders.get("/lender/obligation/obligations").contentType(MediaType.APPLICATION_JSON))
                .andExpect(status().isOk());

    }
}
