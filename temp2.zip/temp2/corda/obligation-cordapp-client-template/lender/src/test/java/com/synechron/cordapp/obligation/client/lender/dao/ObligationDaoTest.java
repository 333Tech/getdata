package com.synechron.cordapp.obligation.client.lender.dao;

import static org.junit.Assert.assertEquals;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.doReturn;

import java.math.BigDecimal;
import java.security.PublicKey;
import java.util.Collections;
import java.util.Currency;
import java.util.List;
import java.util.UUID;

import org.junit.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.springframework.data.util.Pair;

import com.synechron.cordapp.obligation.client.lender.AbstractDaoUnitTests;
import com.synechron.cordapp.obligation.contract.ObligationContract;
import com.synechron.cordapp.obligation.state.Obligation;

import net.corda.core.contracts.*;
import net.corda.core.identity.CordaX500Name;
import net.corda.core.identity.Party;

public class ObligationDaoTest extends AbstractDaoUnitTests {

    @InjectMocks
    private ObligationDaoImpl obligationDao;

    @Mock
    private StateAndRef<Obligation> obligation;

    @Test
    public void testGetObligation() {

        PublicKey publicKey = Mockito.mock(PublicKey.class);
        Party borrowerParty = new Party(new CordaX500Name("PartyA", "London", "GB"), publicKey);
        Party lenderParty = new Party(new CordaX500Name("PartyB", "New York", "US"), publicKey);

        com.synechron.cordapp.obligation.state.Obligation obligationState = new com.synechron.cordapp.obligation.state.Obligation(
                Amount.fromDecimal(BigDecimal.valueOf(2000), Currency.getInstance("USD")), lenderParty, borrowerParty,
                Amount.fromDecimal(BigDecimal.valueOf(2000), Currency.getInstance("USD")), new UniqueIdentifier("1", UUID.randomUUID()));

        StateAndRef<Obligation> obligationStateAndRef = new StateAndRef<>(
                new TransactionState<>(obligationState, ObligationContract.getOBLIGATION_CONTRACT_ID(), notary),
                new StateRef(secureHash, 0));
        doReturn(Collections.singletonList(obligationStateAndRef)).when(vaultPage).getStates();
        doReturn(vaultPage).when(rpcOps).vaultQueryByWithPagingSpec(any(), any(), any());
        Pair<List<Obligation>, Long> obligationList = obligationDao.getObligations(1);
        assertEquals(1, obligationList.getFirst().size());
        assertEquals(obligationList.getFirst().get(0), obligationState);
    }

}
