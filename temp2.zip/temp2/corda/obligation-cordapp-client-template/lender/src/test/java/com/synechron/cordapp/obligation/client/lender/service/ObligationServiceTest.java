package com.synechron.cordapp.obligation.client.lender.service;

import java.math.BigDecimal;
import java.security.PublicKey;
import java.util.*;

import org.junit.Assert;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mockito;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.TestConfiguration;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.context.annotation.Bean;
import org.springframework.data.util.Pair;
import org.springframework.test.context.junit4.SpringRunner;

import com.synechron.cordapp.obligation.client.base.dao.BaseDao;
import com.synechron.cordapp.obligation.client.base.service.BaseService;
import com.synechron.cordapp.obligation.client.base.service.BaseServiceImpl;
import com.synechron.cordapp.obligation.client.lender.dao.ObligationDao;
import com.synechron.cordapp.obligation.state.Obligation;

import net.corda.core.contracts.Amount;
import net.corda.core.contracts.UniqueIdentifier;
import net.corda.core.identity.CordaX500Name;
import net.corda.core.identity.Party;

@RunWith(SpringRunner.class)
public class ObligationServiceTest {

    @TestConfiguration
    static class ObligationServiceImplTestContextConfig {
        @Bean
        public ObligationService obligationService() {
            return new ObligationServiceImpl();
        }

        @Bean
        public BaseService baseService() {
            return new BaseServiceImpl();
        }
    }

    @MockBean
    private ObligationDao obligationDao;
    @MockBean
    private BaseDao baseDao;
    @Autowired
    private ObligationService obligationService;
    @Autowired
    BaseService baseService;

    @Test
    public void testGetObligations() {

        PublicKey publicKey = Mockito.mock(PublicKey.class);
        Party borrowerParty = new Party(new CordaX500Name("PartyA", "London", "GB"), publicKey);
        Party lenderParty = new Party(new CordaX500Name("PartyB", "New York", "US"), publicKey);

        List<Obligation> obligationsStateList = new ArrayList<>();
        com.synechron.cordapp.obligation.state.Obligation obligationState = new com.synechron.cordapp.obligation.state.Obligation(
                Amount.fromDecimal(BigDecimal.valueOf(2000), Currency.getInstance("USD")), lenderParty, borrowerParty,
                Amount.fromDecimal(BigDecimal.valueOf(2000), Currency.getInstance("USD")), new UniqueIdentifier("1", UUID.randomUUID()));
        Mockito.when(baseService.resolveIdentity(obligationState.getBorrower())).thenReturn(borrowerParty);
        Mockito.when(baseService.resolveIdentity(obligationState.getLender())).thenReturn(lenderParty);
        obligationsStateList.add(obligationState);

        Pair<List<Obligation>, Long> obligationsStates = Pair.of(obligationsStateList, 1L);
        Mockito.when(obligationDao.getObligations(1)).thenReturn(obligationsStates);
        Map<String, Object> obligations = obligationService.getObligations(1);
        Assert.assertEquals(2, obligations.size());
    }

}
