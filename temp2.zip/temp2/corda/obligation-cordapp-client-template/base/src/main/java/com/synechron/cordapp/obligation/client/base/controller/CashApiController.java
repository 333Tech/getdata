package com.synechron.cordapp.obligation.client.base.controller;

import java.math.BigDecimal;
import java.util.Currency;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ExecutionException;

import javax.ws.rs.Consumes;
import javax.ws.rs.Produces;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Profile;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import com.synechron.cordapp.obligation.client.base.model.request.SelfIssueCash;
import com.synechron.cordapp.obligation.client.base.service.CashService;

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import net.corda.core.contracts.StateAndRef;
import net.corda.finance.contracts.asset.Cash;

@Profile("!mock")
@CrossOrigin
@RestController
@RequestMapping(value = "/cash")
@Produces(MediaType.APPLICATION_JSON_VALUE)
@Consumes(MediaType.APPLICATION_JSON_VALUE)
@Api(value = "Cash Api")
public class CashApiController implements CashApi {

    @Autowired
    private CashService cashService;

    /**
     * {@inheritDoc}
     */

    @Override
    // @PreAuthorize("hasAnyRole('ROLE_USER', 'ROLE_ADMIN')")
    @ApiOperation(value = "List available cash tokens on ledger", produces = MediaType.APPLICATION_JSON_VALUE)
    @RequestMapping(method = RequestMethod.GET)
    public ResponseEntity<List<StateAndRef<Cash.State>>> cash() {

        List<StateAndRef<Cash.State>> stateAndRefs = cashService.cash();

        return new ResponseEntity<>(stateAndRefs, HttpStatus.OK);
    }

    /**
     * {@inheritDoc}
     */
    @Override
    // @PreAuthorize("hasAnyRole('ROLE_USER', 'ROLE_ADMIN')")
    @ApiOperation(value = "Total cash balances per Currency.", produces = MediaType.APPLICATION_JSON_VALUE)
    @RequestMapping(value = "/cash-balances", method = RequestMethod.GET)
    public ResponseEntity<Map<Currency, BigDecimal>> cashBalances() {

        Map<Currency, BigDecimal> currencyAmountMap = cashService.cashBalances();

        return new ResponseEntity<>(currencyAmountMap, HttpStatus.OK);
    }

    /**
     * {@inheritDoc}
     */
    @Override
    // @PreAuthorize("hasRole('ROLE_ADMIN')")
    @ApiOperation(value = "Self-Issue the cash tokens on a ledger.", produces = MediaType.APPLICATION_JSON_VALUE,
            consumes = MediaType.APPLICATION_JSON_VALUE)
    @RequestMapping(value = "/self-issue-cash", method = RequestMethod.POST)
    public ResponseEntity selfIssueCash(@RequestBody SelfIssueCash issueCash) throws InterruptedException, ExecutionException {

        cashService.selfIssueCash(issueCash.getAmount(), issueCash.getCurrency());

        return ResponseEntity.status(HttpStatus.CREATED).build();
    }
}
