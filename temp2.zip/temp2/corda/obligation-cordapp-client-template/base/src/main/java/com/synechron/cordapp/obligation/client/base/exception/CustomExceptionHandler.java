package com.synechron.cordapp.obligation.client.base.exception;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.servlet.mvc.method.annotation.ResponseEntityExceptionHandler;

@ControllerAdvice
public class CustomExceptionHandler extends ResponseEntityExceptionHandler {

    @ExceptionHandler(value = Exception.class)
    public ResponseEntity<ErrorResponse> genericExceptionHandler(Exception exception) {
        ErrorResponse errorResponse = getErrorResponse(ErrorCode.EXCEPTION, exception, HttpStatus.INTERNAL_SERVER_ERROR);
        return new ResponseEntity<>(errorResponse, errorResponse.getStatus());
    }

    @ExceptionHandler(value = PartyNotFoundException.class)
    public ResponseEntity<ErrorResponse> partyNotFoundExceptionHandler(PartyNotFoundException exception) {
        ErrorResponse errorResponse = getErrorResponse(ErrorCode.PARTY_NOT_FOUND, exception, HttpStatus.NOT_FOUND);
        return new ResponseEntity<>(errorResponse, errorResponse.getStatus());
    }

    @ExceptionHandler(value = InvalidCordaX500NameException.class)
    public ResponseEntity<ErrorResponse> invalidCordaX500NameExceptionHandler(InvalidCordaX500NameException exception) {
        ErrorResponse errorResponse = getErrorResponse(ErrorCode.INVALID_X500_NAME, exception, HttpStatus.NOT_FOUND);
        return new ResponseEntity<>(errorResponse, errorResponse.getStatus());
    }

    @ExceptionHandler(value = IssueObligationException.class)
    public ResponseEntity<ErrorResponse> issueObligationExceptionHandler(IssueObligationException exception) {
        ErrorResponse errorResponse = getErrorResponse(ErrorCode.SETTLE_OBLIGATION_EXCEPTION, exception, HttpStatus.BAD_REQUEST);
        return new ResponseEntity<>(errorResponse, errorResponse.getStatus());
    }

    @ExceptionHandler(value = SettleObligationException.class)
    public ResponseEntity<ErrorResponse> settleObligationExceptionHandler(SettleObligationException exception) {
        ErrorResponse errorResponse = getErrorResponse(ErrorCode.SETTLE_OBLIGATION_EXCEPTION, exception, HttpStatus.BAD_REQUEST);
        return new ResponseEntity<>(errorResponse, errorResponse.getStatus());
    }

    private ErrorResponse getErrorResponse(ErrorCode errorCode, Exception exception, HttpStatus httpStatus) {
        String code = errorCode.getCode();
        String msg = errorCode.getDescription() + exception.getMessage();
        ErrorResponse errorResponse = new ErrorResponse(code, msg, httpStatus);
        return errorResponse;
    }
}
