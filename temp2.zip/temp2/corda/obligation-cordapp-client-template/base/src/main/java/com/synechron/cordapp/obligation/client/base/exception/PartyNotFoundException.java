package com.synechron.cordapp.obligation.client.base.exception;

public class PartyNotFoundException extends CorDappClientBaseException {

    public PartyNotFoundException() {
    }

    public PartyNotFoundException(String message) {
        super(message);
    }

    public PartyNotFoundException(Exception exception) {
        super(exception);
    }

    public PartyNotFoundException(String message, Exception exception) {
        super(message, exception);
    }

}
