package com.synechron.cordapp.obligation.client.base.util;

import static org.springframework.http.HttpStatus.NOT_FOUND;

import java.util.List;
import java.util.UUID;

import com.synechron.cordapp.obligation.client.base.exception.ErrorCode;
import com.synechron.cordapp.obligation.client.base.exception.PartyNotFoundException;

import net.corda.core.contracts.UniqueIdentifier;
import net.corda.core.identity.Party;
import net.corda.core.messaging.CordaRPCOps;

public class CommonUtils {

    private CommonUtils() {

    }

    public static UniqueIdentifier toUniqueIdentifier(String str) {
        if (str == null) {
            throw new IllegalArgumentException("Invalid UniqueIdentifier string: " + str);
        }
        try {
            // Check if externalId and UUID may be separated by underscore.
            if (str.contains("_")) {
                String[] ids = str.split("_");
                // Create UUID object from string.
                UUID uuid = UUID.fromString(ids[1]);
                // Create UniqueIdentifier object using externalId and UUID.
                return new UniqueIdentifier(ids[0], uuid);
            }

            // Any other string used as id (i.e. UUID).
            return new UniqueIdentifier(null, UUID.fromString(str));
        } catch (IllegalArgumentException exception) {
            throw new IllegalArgumentException("Invalid UniqueIdentifier string: " + exception);
        }
    }

    public static String getOrganisation(Party party) {
        return party != null ? party.getName().getOrganisation() : "";
    }

    public static Party getNotary(CordaRPCOps proxy) {
        final List<Party> notaries = proxy.notaryIdentities();
        if (notaries.isEmpty()) {
            throw new PartyNotFoundException("Could not find a notary on the network.");
        }
        final Party notary = notaries.get(0);
        return notary;
    }
}
