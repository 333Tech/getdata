package com.synechron.cordapp.obligation.client.base.rpc;

import net.corda.client.rpc.CordaRPCConnection;
import net.corda.core.messaging.CordaRPCOps;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.web.context.annotation.RequestScope;

import javax.annotation.PostConstruct;
import javax.annotation.PreDestroy;

@RequestScope
@Component
public class NodeRPCConnection {

    @Autowired
    private RPCConnectionManager rpcConnectionManager;
    private CordaRPCOps cordaRPCOps = null;
    private final Log logger = LogFactory.getLog(this.getClass());
    CordaRPCConnection rpcConnection = null;

    @PostConstruct
    void getRPCConnection() throws Exception {
        rpcConnection = rpcConnectionManager.getConnection();
    }

    /**
     * This method returns rpc connection object for currently logged-in user.
     *
     * @return an instance that can be served from the pool of type {@link CordaRPCOps}
     */
    public CordaRPCOps getProxy() {
        return rpcConnection.getProxy();
    }

    @PreDestroy
    void destroy() throws Exception {
        if (rpcConnection != null) {
            rpcConnectionManager.returnConnection(rpcConnection);
        }
    }
}