package com.synechron.cordapp.obligation.client.base.config;

import java.util.Collections;
import java.util.List;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import springfox.documentation.builders.PathSelectors;
import springfox.documentation.builders.RequestHandlerSelectors;
import springfox.documentation.service.ApiKey;
import springfox.documentation.spi.DocumentationType;
import springfox.documentation.spring.web.plugins.Docket;
import springfox.documentation.swagger2.annotations.EnableSwagger2;

/**
 * SwaggerConfig Class, This class can be modified to add new Regex.
 *
 * @author Balaji.More
 */
@Configuration
@EnableSwagger2
public class SwaggerConfig {
    @Value("${swagger.basePackage}")
    String basePackage;

    /**
     * This method can be modified to add new Regex
     *
     * @return Docket
     */
    @Bean
    public Docket api() {
        return new Docket(DocumentationType.SWAGGER_2).select().apis(RequestHandlerSelectors.basePackage(basePackage))
                .paths(PathSelectors.any()).build().securitySchemes(apiKey());
    }

    private List<ApiKey> apiKey() {
        ApiKey apiKey = new ApiKey("Authorization", "Authorization", "header");
        return Collections.singletonList(apiKey);
    }
}
