package com.synechron.cordapp.obligation.client.base.jwt;

import java.util.ArrayList;
import java.util.List;

import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.stereotype.Component;

@Component
@ConfigurationProperties("security")
public class AuthenticationProperties {
    private final List<String> permit = new ArrayList<>();

    public List<String> getPermit() {
        return this.permit;
    }
}
