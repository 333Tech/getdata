package com.synechron.cordapp.obligation.client.base.dao;

import com.synechron.cordapp.obligation.client.base.rpc.NodeRPCConnection;
import com.synechron.cordapp.obligation.client.base.util.CommonUtils;
import net.corda.core.contracts.Amount;
import net.corda.core.contracts.StateAndRef;
import net.corda.core.identity.Party;
import net.corda.core.messaging.FlowHandle;
import net.corda.core.utilities.OpaqueBytes;
import net.corda.finance.contracts.asset.Cash;
import net.corda.finance.flows.AbstractCashFlow;
import net.corda.finance.flows.CashIssueFlow;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import java.math.BigDecimal;
import java.util.Currency;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ExecutionException;

import static net.corda.finance.workflows.GetBalances.getCashBalances;


@Repository
public class CashDaoImpl implements CashDao {

    @Autowired
    private NodeRPCConnection rpcConnection;

    /**
     * {@inheritDoc}
     */
    @Override
    public List<StateAndRef<Cash.State>> cash() {
        List<StateAndRef<Cash.State>> states = rpcConnection.getProxy().vaultQuery(Cash.State.class).getStates();
        return states;
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public Map<Currency, Amount<Currency>> cashBalances() {
        Map<Currency, Amount<Currency>> cashBalances = getCashBalances(rpcConnection.getProxy());
        return cashBalances;
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public void selfIssueCash(long amount, String currency) throws InterruptedException, ExecutionException {
        // Get currency object from string.
        Currency token = Currency.getInstance(currency);
        final Amount<Currency> issueAmount = Amount.fromDecimal(new BigDecimal(amount), token);
        final Party notary = CommonUtils.getNotary(rpcConnection.getProxy());
        // issueRef - a reference to put on the issued currency.
        // java byte arrays are default initialized to all zeros, so value at index 0 will be `zero`.
        final OpaqueBytes issueRef = OpaqueBytes.of(new byte[1]);
        final CashIssueFlow.IssueRequest issueRequest = new CashIssueFlow.IssueRequest(issueAmount, issueRef, notary);
        // Start the flow and wait for response.
        final FlowHandle<AbstractCashFlow.Result> flowHandle = rpcConnection.getProxy().startFlowDynamic(CashIssueFlow.class, issueRequest);
        flowHandle.getReturnValue().get();
    }
}

