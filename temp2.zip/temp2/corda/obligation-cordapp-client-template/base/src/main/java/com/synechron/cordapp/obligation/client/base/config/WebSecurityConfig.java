package com.synechron.cordapp.obligation.client.base.config;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.http.HttpMethod;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.config.annotation.authentication.builders.AuthenticationManagerBuilder;
import org.springframework.security.config.annotation.method.configuration.EnableGlobalMethodSecurity;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.configuration.EnableWebSecurity;
import org.springframework.security.config.annotation.web.configuration.WebSecurityConfigurerAdapter;
import org.springframework.security.config.annotation.web.configurers.ExpressionUrlAuthorizationConfigurer;
import org.springframework.security.config.http.SessionCreationPolicy;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.security.web.authentication.UsernamePasswordAuthenticationFilter;

import com.synechron.cordapp.obligation.client.base.jwt.AuthenticationProperties;
import com.synechron.cordapp.obligation.client.base.jwt.JwtAuthenticationEntryPoint;
import com.synechron.cordapp.obligation.client.base.jwt.JwtAuthenticationTokenFilter;

@SuppressWarnings("SpringJavaAutowiringInspection")
@Configuration
@EnableWebSecurity
@EnableGlobalMethodSecurity(prePostEnabled = true)
public class WebSecurityConfig extends WebSecurityConfigurerAdapter {
    private final Log logger = LogFactory.getLog(this.getClass());

    @Autowired
    private JwtAuthenticationEntryPoint unauthorizedHandler;

    @Autowired
    private UserDetailsService userDetailsService;

    @Autowired
    private AuthenticationProperties authenticationProperties;

    @Value("${security.enableAccessRole}")
    private boolean enableAccessRole;

    @Autowired
    public void configureAuthentication(AuthenticationManagerBuilder authenticationManagerBuilder) throws Exception {
        authenticationManagerBuilder.userDetailsService(this.userDetailsService).passwordEncoder(passwordEncoder());
    }

    @Bean
    public PasswordEncoder passwordEncoder() {
        return new BCryptPasswordEncoder();
    }

    @Bean
    public JwtAuthenticationTokenFilter authenticationTokenFilterBean() {
        return new JwtAuthenticationTokenFilter();
    }

    @Bean
    @Override
    public AuthenticationManager authenticationManagerBean() throws Exception {
        return super.authenticationManagerBean();
    }

    @Override
    protected void configure(HttpSecurity httpSecurity) throws Exception {
        logger.debug("configure Start");

        httpSecurity
                // we don't need CSRF because our token is invulnerable
                .csrf().disable().exceptionHandling().authenticationEntryPoint(unauthorizedHandler).and()
                // don't create session
                .sessionManagement().sessionCreationPolicy(SessionCreationPolicy.STATELESS);

        if (enableAccessRole) {
            addAccessRoles(httpSecurity);
        }
        addPermitAll(httpSecurity);
        // Custom JWT based security filter
        httpSecurity.addFilterBefore(authenticationTokenFilterBean(), UsernamePasswordAuthenticationFilter.class);
        // disable page caching
        httpSecurity.headers().cacheControl();

        logger.debug("configure End");
    }

    private void addPermitAll(HttpSecurity httpSecurity) throws Exception {
        logger.debug("addPermitAll Start");

        ExpressionUrlAuthorizationConfigurer<HttpSecurity>.ExpressionInterceptUrlRegistry urlRegistry = httpSecurity.authorizeRequests();

        for (String path : authenticationProperties.getPermit()) {
            urlRegistry.antMatchers(path).permitAll();
        }

        urlRegistry.antMatchers(HttpMethod.OPTIONS, "/**").permitAll();

        urlRegistry.anyRequest().authenticated();

        logger.debug("addPermitAll End");
    }

    private void addAccessRoles(HttpSecurity httpSecurity) throws Exception {
        logger.debug("addRoles start");
        httpSecurity.authorizeRequests()
                // TODO HttPMethod, URL, AccessRoles - data should be stored outside of this code. Could be in property file or
                // database?
                .antMatchers(HttpMethod.GET, "/base/user/loginAsHeaderInfo").access("hasAnyRole('ROLE_USER', 'ROLE_ADMIN')")
                .antMatchers(HttpMethod.GET, "/base/user/transactions").access("hasAnyRole('ROLE_USER', 'ROLE_ADMIN')")
                .antMatchers(HttpMethod.GET, "/cash").access("hasAnyRole('ROLE_USER', 'ROLE_ADMIN')")
                .antMatchers(HttpMethod.GET, "/cash/cash-balances").access("hasAnyRole('ROLE_USER', 'ROLE_ADMIN')")
                .antMatchers(HttpMethod.POST, "/cash/self-issue-cash").access("hasRole('ROLE_ADMIN')")
                .antMatchers(HttpMethod.GET, "/borrower/obligation/name").access("hasAnyRole('ROLE_USER', 'ROLE_ADMIN')")
                .antMatchers(HttpMethod.POST, "/borrower/obligation/issue-obligation").access("hasRole('ROLE_ADMIN')")
                .antMatchers(HttpMethod.GET, "/borrower/obligation/obligations").access("hasAnyRole('ROLE_USER', 'ROLE_ADMIN')")
                .antMatchers(HttpMethod.POST, "/borrower/obligation/settle-obligation").access("hasAnyRole('ROLE_ADMIN')")
                .antMatchers(HttpMethod.GET, "/borrower/obligation/lender-parties").access("hasAnyRole('ROLE_USER', 'ROLE_ADMIN')")
                .antMatchers(HttpMethod.POST, "/borrower/obligation/set-network-time").access("hasAnyRole('ROLE_ADMIN')")
                .antMatchers(HttpMethod.POST, "/borrower/obligation/reset-network-time").access("hasAnyRole('ROLE_ADMIN')")
                .antMatchers(HttpMethod.GET, "/lender/obligation/name").access("hasAnyRole('ROLE_USER', 'ROLE_ADMIN')")
                .antMatchers(HttpMethod.GET, "/lender/obligation/obligations").access("hasAnyRole('ROLE_USER', 'ROLE_ADMIN')");
        logger.debug("addRoles End");
    }
}
