package com.synechron.cordapp.obligation.client.base.rpc;

/**
 * Model class for RPC User's meta data info
 */
public class RpcHostPort{
    private String hostName;

    private int port;

    public RpcHostPort(String hostName,int port){
        this.hostName = hostName;
        this.port = port;
    }

    public int getPort() {
        return port;
    }

    public void setPort(int port) {
        this.port = port;
    }

    public String getHostName() {
        return hostName;
    }

    public void setHostName(String hostName) {
        this.hostName = hostName;
    }
}


