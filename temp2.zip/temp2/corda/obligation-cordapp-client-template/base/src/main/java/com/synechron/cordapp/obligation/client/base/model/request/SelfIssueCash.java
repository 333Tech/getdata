package com.synechron.cordapp.obligation.client.base.model.request;

public class SelfIssueCash {
    String currency;
    Long amount;

    public SelfIssueCash() {
    }

    public SelfIssueCash(String currency, Long amount) {
        this.currency = currency;
        this.amount = amount;
    }

    public String getCurrency() {
        return currency;
    }

    public void setCurrency(String currency) {
        this.currency = currency;
    }

    public Long getAmount() {
        return amount;
    }

    public void setAmount(Long amount) {
        this.amount = amount;
    }
}
