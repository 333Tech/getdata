
package com.synechron.cordapp.obligation.client.base.model.response;

import java.util.ArrayList;
import java.util.List;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.synechron.cordapp.obligation.client.base.dao.entity.Party;

public class PartyResponseModel {
    @JsonProperty("id")
    private int id;
    @JsonProperty("name")
    private String name;
    @JsonProperty("uri")
    private String uri;
    @JsonProperty("type")
    private String type;
    @JsonProperty("commonName")
    private String commonName;

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public String getUri() {
        return uri;
    }

    public String getType() {
        return type;
    }

    public void setName(String name) {
        this.name = name;
    }

    public void setUri(String uri) {
        this.uri = uri;
    }

    public void setType(String type) {
        this.type = type;
    }

    public String getCommonName() {
        return commonName;
    }

    public void setCommonName(String commonName) {
        this.commonName = commonName;
    }

    @Override
    public String toString() {
        return "PartyResponseModel{" + "name='" + name + '\'' + ", uri='" + uri + '\'' + ", type='" + type + '\'' + '}';
    }

    public static List<PartyResponseModel> getPartyList(List<Party> parties) {
        List<PartyResponseModel> partyResponseModels = new ArrayList<>();
        for (Party party : parties) {
            PartyResponseModel partyResponseModel = new PartyResponseModel();
            partyResponseModel.setId(party.getId());
            partyResponseModel.setType(party.getType());
            partyResponseModel.setUri(party.getUri());
            partyResponseModel.setName(party.getName());
            partyResponseModel.setCommonName(party.getCommonName());
            partyResponseModels.add(partyResponseModel);
        }

        return partyResponseModels;
    }
}
