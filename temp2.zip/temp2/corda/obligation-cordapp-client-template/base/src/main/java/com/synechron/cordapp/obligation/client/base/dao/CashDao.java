package com.synechron.cordapp.obligation.client.base.dao;

import java.util.Currency;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ExecutionException;

import net.corda.core.contracts.Amount;
import net.corda.core.contracts.StateAndRef;
import net.corda.finance.contracts.asset.Cash;

/**
 * Used to self-issue the Cash on a ledger, get the available Cash tokens and total cash balance per currency.
 */
public interface CashDao {
    /**
     * Get available cash tokens on ledger.
     *
     * @return List of cash states.
     */
    List<StateAndRef<Cash.State>> cash();

    /**
     * Get the total cash balance per [Currency].
     *
     * @return map of currency and total amount.
     */
    Map<Currency, Amount<Currency>> cashBalances();

    /**
     * Self-Issue the cash tokens on a ledger.
     *
     * @param amount   the number of tokens as a long value.
     * @param currency the ISO 4217 currency codes.
     */
    void selfIssueCash(long amount, String currency) throws InterruptedException, ExecutionException;
}