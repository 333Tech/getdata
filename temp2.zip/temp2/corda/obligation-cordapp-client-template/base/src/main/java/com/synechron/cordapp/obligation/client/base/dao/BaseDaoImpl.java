package com.synechron.cordapp.obligation.client.base.dao;

import static org.springframework.http.HttpStatus.NOT_FOUND;

import java.sql.Timestamp;
import java.util.*;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.messaging.simp.SimpMessagingTemplate;
import org.springframework.stereotype.Repository;

import com.synechron.cordapp.obligation.client.base.exception.ErrorCode;
import com.synechron.cordapp.obligation.client.base.exception.InvalidCordaX500NameException;
import com.synechron.cordapp.obligation.client.base.exception.PartyNotFoundException;
import com.synechron.cordapp.obligation.client.base.model.response.TransactionInfo;
import com.synechron.cordapp.obligation.client.base.rpc.NodeRPCConnection;
import com.synechron.cordapp.obligation.client.base.util.CommonUtils;
import com.synechron.cordapp.obligation.client.base.util.TransactionInfoComparator;
//import com.synechron.cordapp.obligation.state.NetworkTime;

import net.corda.core.contracts.StateAndRef;
import net.corda.core.identity.AbstractParty;
import net.corda.core.identity.CordaX500Name;
import net.corda.core.identity.Party;
import net.corda.core.transactions.SignedTransaction;

@Repository
public class BaseDaoImpl implements BaseDao {

    @PersistenceContext
    @Autowired
    private EntityManager entityManager;
    @Autowired
    private NodeRPCConnection rpcConnection;
    @Autowired
    private SimpMessagingTemplate simpMessagingTemplate;

    @Value("${query.get.party.by.type}")
    private String queryByPartyType;
    @Value("${websocket.network_time_topic}")
    private String networkTimeTopic;

    /**
     * {@inheritDoc}
     */
    @Override
    public String getNodeName() {
        String orgName = CommonUtils.getOrganisation(getParty());
        return orgName;
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public String getNodeName(AbstractParty party) {
        String orgName = CommonUtils.getOrganisation(resolveIdentity(party));
        return orgName;
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public Party getParty() {
        List<Party> party = rpcConnection.getProxy().nodeInfo().getLegalIdentities();
        return party.get(0);
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public Party getParty(String partyName) {
        CordaX500Name x500Name;
        Party party = null;
        try {
            x500Name = CordaX500Name.parse(partyName);
        } catch (Exception exception) {
            throw new InvalidCordaX500NameException(partyName, exception);
        }


        party = rpcConnection.getProxy().wellKnownPartyFromX500Name(x500Name);
        if (party == null) {
            throw new PartyNotFoundException(partyName);

        }
        return party;
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public Party resolveIdentity(AbstractParty party) {
        if (party instanceof Party) {
            return (Party) party;
        }
        Party wellKnownParty = rpcConnection.getProxy().wellKnownPartyFromAnonymous(party);
        return wellKnownParty;
    }

    /**
     * {@inheritDoc}
     */
    @SuppressWarnings("unchecked")
    public List<com.synechron.cordapp.obligation.client.base.dao.entity.Party> getParties(String placeholderName, String queryParamValue) {
        Query query = entityManager.createQuery(queryByPartyType);
        query.setParameter(placeholderName, queryParamValue);
        return query.getResultList();
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public List<TransactionInfo> getTransactions() {
        List<TransactionInfo> transactionInfoList = new ArrayList<>();
        for (SignedTransaction tx : rpcConnection.getProxy().internalVerifiedTransactionsSnapshot()) {
            Iterator<String> iterator = rpcConnection.getProxy().getVaultTransactionNotes(tx.getId()).iterator();
            StringBuilder sb = new StringBuilder();
            while (iterator.hasNext()) {
                sb.append(iterator.next()).append("\n");
            }
            if (sb.length() > 0) {
                sb.deleteCharAt(sb.length() - 1);
                Timestamp timestamp = Timestamp.from(tx.getTx().getTimeWindow().getMidpoint());
                TransactionInfo transactionInfo = new TransactionInfo();
                transactionInfo.setDatetime(String.valueOf(timestamp.getTime()));
                transactionInfo.setNotary(tx.getTx().getNotary().getOwningKey().toString());
                transactionInfo.setTxHash(tx.getId().toString());
                transactionInfo.setTxNote(sb.toString());
                transactionInfoList.add(transactionInfo);
            }
        }
        Comparator<TransactionInfo> comparator = Collections.reverseOrder(new TransactionInfoComparator());
        transactionInfoList.sort(comparator);
        return transactionInfoList;
    }

    /**
     * {@inheritDoc}
     */
//    @Override
//    public void subscribeToNetworkTimeEvent() {
//        rpcConnection.getProxy().vaultTrack(NetworkTime.class).getUpdates().subscribe(t -> pushNetworkTimeNotification(t.getProduced()));
//    }

    /**
     * This method will get updated network time and publish it on the topic of websocket.
     *
     * @param stateAndRefs
     */
//    private void pushNetworkTimeNotification(Set<StateAndRef<NetworkTime>> stateAndRefs) {
//        if (!stateAndRefs.isEmpty()) {
//            StateAndRef<NetworkTime> networkTimeStateAndRef = stateAndRefs.stream().findFirst().get();
//            long timeInMillis = networkTimeStateAndRef.getState().getData().getMillis();
//            simpMessagingTemplate.convertAndSend(networkTimeTopic, timeInMillis);
//        }
//    }
}
