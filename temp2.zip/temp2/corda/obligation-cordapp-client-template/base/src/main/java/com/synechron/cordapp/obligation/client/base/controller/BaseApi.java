package com.synechron.cordapp.obligation.client.base.controller;

import java.util.List;
import java.util.Map;

import org.springframework.http.ResponseEntity;

import com.synechron.cordapp.obligation.client.base.model.response.PartyResponseModel;

public interface BaseApi {

    /**
     * This method will return map of parties information.
     *
     * @return map of parties information.
     */
    ResponseEntity<Map<String, List<PartyResponseModel>>> getloginAsHeaderInfo();

    /**
     * This method will return the Transactions in vault
     *
     * @return ResponseEntity
     */
    ResponseEntity getTransactions();

}
