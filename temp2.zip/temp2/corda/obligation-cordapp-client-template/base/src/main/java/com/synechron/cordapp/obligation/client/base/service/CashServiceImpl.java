package com.synechron.cordapp.obligation.client.base.service;

import java.math.BigDecimal;
import java.util.Currency;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ExecutionException;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.synechron.cordapp.obligation.client.base.dao.CashDao;

import net.corda.core.contracts.Amount;
import net.corda.core.contracts.StateAndRef;
import net.corda.finance.contracts.asset.Cash;

@Service
public class CashServiceImpl implements CashService {

    @Autowired
    private CashDao cashDao;

    /**
     * {@inheritDoc}
     */
    @Override
    public List<StateAndRef<Cash.State>> cash() {
        List<StateAndRef<Cash.State>> stateAndRefs = cashDao.cash();
        return stateAndRefs;
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public Map<Currency, BigDecimal> cashBalances() {
        Map<Currency, Amount<Currency>> cashBalances = cashDao.cashBalances();
        Map<Currency, BigDecimal> currencyBigDecimalMap = cashBalances.entrySet().stream()
                .collect(Collectors.toMap(Map.Entry::getKey, entry -> entry.getValue().toDecimal()));
        return currencyBigDecimalMap;
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public void selfIssueCash(long amount, String currency) throws InterruptedException, ExecutionException {
        cashDao.selfIssueCash(amount, currency);
    }
}
