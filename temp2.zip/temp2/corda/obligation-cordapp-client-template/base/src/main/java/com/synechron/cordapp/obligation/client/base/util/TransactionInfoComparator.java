package com.synechron.cordapp.obligation.client.base.util;

import com.synechron.cordapp.obligation.client.base.model.response.TransactionInfo;

import java.util.Comparator;

public class TransactionInfoComparator implements Comparator<TransactionInfo> {
    @Override
    public int compare(TransactionInfo o1, TransactionInfo o2) {
        return o1.getDatetime().compareTo(o2.getDatetime());
    }
}
