package com.synechron.cordapp.obligation.client.base.rpc;

public class RPCConnectionFactoryCreator {
    public static RPCConnectionFactory getInstance(RpcHostPort rpcHostPort, String userName, String password) {
        return new RPCConnectionFactory(rpcHostPort, userName, password);
    }
}