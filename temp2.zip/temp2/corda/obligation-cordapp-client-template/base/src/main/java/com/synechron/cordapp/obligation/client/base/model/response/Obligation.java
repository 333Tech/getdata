package com.synechron.cordapp.obligation.client.base.model.response;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;

import com.synechron.cordapp.obligation.client.base.service.BaseService;
import com.synechron.cordapp.obligation.client.base.util.CommonUtils;

public class Obligation {

    private BigDecimal amount;
    private String currency;
    private String lender;
    private String borrower;
    private BigDecimal paid;
    private String linearId;

    public String getCurrency() {
        return currency;
    }

    public void setCurrency(String currency) {
        this.currency = currency;
    }

    public BigDecimal getAmount() {
        return amount;
    }

    public void setAmount(BigDecimal amount) {
        this.amount = amount;
    }

    public String getLender() {
        return lender;
    }

    public void setLender(String lender) {
        this.lender = lender;
    }

    public String getBorrower() {
        return borrower;
    }

    public void setBorrower(String borrower) {
        this.borrower = borrower;
    }

    public BigDecimal getPaid() {
        return paid;
    }

    public void setPaid(BigDecimal paid) {
        this.paid = paid;
    }

    public String getLinearId() {
        return linearId;
    }

    public void setLinearId(String linearId) {
        this.linearId = linearId;
    }

//    public static List<Obligation> getObligations(List<com.synechron.cordapp.obligation.state.Obligation> obligationStates,
//            BaseService baseService) {
//        List<Obligation> obligations = new ArrayList<>();
//        if (obligationStates != null) {
//            for (com.synechron.cordapp.obligation.state.Obligation state : obligationStates) {
//                Obligation model = new Obligation();
//                model.setAmount(state.getAmount().toDecimal());
//                model.setCurrency(state.getAmount().getToken().getCurrencyCode());
//                model.setBorrower(CommonUtils.getOrganisation(baseService.resolveIdentity(state.getBorrower())));
//                model.setLender(CommonUtils.getOrganisation(baseService.resolveIdentity(state.getLender())));
//                model.setPaid(state.getPaid().toDecimal());
//                model.setLinearId(state.getLinearId().toString());
//                obligations.add(model);
//            }
//        }
//        return obligations;
//    }
}
