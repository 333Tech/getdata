package com.synechron.cordapp.obligation.client.base.config;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Configuration;
import org.springframework.messaging.simp.config.MessageBrokerRegistry;
import org.springframework.web.socket.config.annotation.EnableWebSocketMessageBroker;
import org.springframework.web.socket.config.annotation.StompEndpointRegistry;
import org.springframework.web.socket.config.annotation.WebSocketMessageBrokerConfigurer;

@Configuration
@EnableWebSocketMessageBroker
public class WebSocketConfig implements WebSocketMessageBrokerConfigurer {

    private final Log logger = LogFactory.getLog(this.getClass());

    @Value("${websocket.destination_prefix}")
    private String destinationPrefix;
    @Value("${websocket.app_destination_prefix}")
    private String appDestinationPrefix;
    @Value("${websocket.stomp_websocket_endpoint}")
    private String stompWebsocketEndpoint;

    @Override
    public void configureMessageBroker(MessageBrokerRegistry messageBrokerRegistry) {
        logger.info("configureMessageBroker start");

        messageBrokerRegistry.enableSimpleBroker(destinationPrefix);
        messageBrokerRegistry.setApplicationDestinationPrefixes(appDestinationPrefix);

        logger.info("configureMessageBroker finish");
    }

    @Override
    public void registerStompEndpoints(StompEndpointRegistry stompEndpointRegistry) {
        logger.info("registerStompEndpoints start");

        stompEndpointRegistry.addEndpoint(stompWebsocketEndpoint).setAllowedOrigins("*").withSockJS();

        logger.info("registerStompEndpoints finish");
    }
}
