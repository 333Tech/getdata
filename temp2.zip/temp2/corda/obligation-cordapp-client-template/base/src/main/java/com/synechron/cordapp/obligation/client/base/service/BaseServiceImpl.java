package com.synechron.cordapp.obligation.client.base.service;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import com.synechron.cordapp.obligation.client.base.dao.BaseDao;
import com.synechron.cordapp.obligation.client.base.model.response.PartyResponseModel;
import com.synechron.cordapp.obligation.client.base.model.response.TransactionInfo;

import net.corda.core.identity.AbstractParty;
import net.corda.core.identity.Party;

@Service
public class BaseServiceImpl implements BaseService {

    @Autowired
    BaseDao baseDao;

    @Value("${party.type.borrower}")
    private String borrower;
    @Value("${party.type.lender}")
    private String lender;
    @Value("${party.type.placeholderName}")
    private String placeholderName;

    /**
     * {@inheritDoc}
     */
    @Override
    public String getNodeName() {
        String nodeName = baseDao.getNodeName();
        return nodeName;
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public String getNodeName(AbstractParty party) {
        String nodeName = baseDao.getNodeName(party);
        return nodeName;
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public Party getParty() {
        Party party = baseDao.getParty();
        return party;
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public Party getParty(String partyName) {
        Party party = baseDao.getParty(partyName);
        return party;
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public Party resolveIdentity(AbstractParty party) {
        Party party1 = baseDao.resolveIdentity(party);
        return party1;
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public Map<String, List<PartyResponseModel>> getloginAsHeaderInfo() {
        HashMap<String, List<PartyResponseModel>> partyResponseMap = new HashMap<>();
        partyResponseMap.put("Borrower", PartyResponseModel.getPartyList(baseDao.getParties(placeholderName, borrower)));
        partyResponseMap.put("Lender", PartyResponseModel.getPartyList(baseDao.getParties(placeholderName, lender)));
        return partyResponseMap;
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public List<TransactionInfo> getTransactions() {
        return baseDao.getTransactions();
    }
}
