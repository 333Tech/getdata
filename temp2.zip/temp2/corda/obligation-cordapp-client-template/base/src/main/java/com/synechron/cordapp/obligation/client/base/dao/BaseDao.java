package com.synechron.cordapp.obligation.client.base.dao;

import java.util.List;

import com.synechron.cordapp.obligation.client.base.exception.PartyNotFoundException;
import com.synechron.cordapp.obligation.client.base.model.response.TransactionInfo;

import net.corda.core.identity.AbstractParty;
import net.corda.core.identity.Party;

/**
 * Exposes common functionality to get information about node name, node identity,
 * well-known-identity from anonymous party.
 */
public interface BaseDao {
    /**
     * This method returns node's organisation name.
     *
     * @return String identity organisation name.
     */
    String getNodeName();

    /**
     * This method returns node's organisation name for given abstract or anonymous party.
     *
     * @return String identity organisation name.
     */
    String getNodeName(AbstractParty party);

    /**
     * This returns node's first identity.
     *
     * @return Party - well known party.
     */
    Party getParty();

    /***
     * Find the party on corda network-map with given party name.
     * 
     * @param partyName the party name.
     * @return return party object.
     * @throws PartyNotFoundException - when party not found on network.
     */
    Party getParty(String partyName);

    /**
     * Resolve the well known identity for given abstract or anonymous party.
     *
     * @return Party - well known party object.
     */
    Party resolveIdentity(AbstractParty party);

    /**
     * Get list of parties information.
     *
     * @return list of parties information.
     */
    List<com.synechron.cordapp.obligation.client.base.dao.entity.Party> getParties(String placeholderName, String queryParamValue);

    /**
     * This method will return list of transaction information
     *
     * @return List<TransactionInfo>
     */
    List<TransactionInfo> getTransactions();

    /**
     * This method will subscribe to network time state change event
     */
    //void subscribeToNetworkTimeEvent();

}
