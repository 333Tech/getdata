package com.synechron.cordapp.obligation.client.base.exception;

public class IssueObligationException extends CorDappClientBaseException {

    public IssueObligationException() {
    }

    public IssueObligationException(String message) {
        super(message);
    }

    public IssueObligationException(Exception exception) {
        super(exception);
    }
}
