package com.synechron.cordapp.obligation.client.base.rpc;

import com.synechron.cordapp.obligation.client.base.jwt.JwtUser;
import net.corda.core.messaging.CordaRPCOps;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Component;
import org.springframework.web.context.annotation.RequestScope;
import javax.annotation.PreDestroy;

/**
 *Class to initiate RPCConnection on request
 *
 */
@RequestScope
@Component
public class RPCConnection {

    @Autowired
    private RPCConnectionManager RPCConnectionManager;

    private final Log logger = LogFactory.getLog(this.getClass());

    private CordaRPCOps cordaRPCOps = null;

    //private RpcUser rpcUser;


    /**
     *
     * This method rpc connection object if it exists for the request.Otherwise it creates new RPCConnection
     * object by getting username and password from security context.
     *
     * @return an instance that can be served by the pool of type {@link CordaRPCOps}
     *
     * @throws Exception if there is a problem creating a new instance,
     *    this will be propagated to the code requesting an object.
     */
    public CordaRPCOps getCordaRPCOps() throws Exception {
        logger.info("Gettting RPC connection for the request");
        if(cordaRPCOps == null){
            synchronized (this) {
                if (cordaRPCOps == null) {
                    JwtUser user = (JwtUser) SecurityContextHolder.getContext().getAuthentication()
                            .getPrincipal();
                    //rpcUser = new RpcUser(user.getUsername(),user.getUsername());
                    //cordaRPCOps = RPCConnectionManager.getConnection(rpcUser);
                    //cordaRPCOps = RPCConnectionManager.getConnection();
                }
            }
        }
        return cordaRPCOps;
    }

    /**
     *This methods returns RPC connection object back to the pool using its key.
     * Once the request is processed the method is invoked before beans gets destroyed.
     * It uses key to put object back to the pool.
     * The object is validated before it is added back to pool.
     * If validatiion fails the returning object is destroyed.
     *
     */
    @PreDestroy
    void destroy(){
        logger.info("Calling destroy method of RPCConnection");
        if(cordaRPCOps != null){
            logger.info("Returning CordaRPCOPs object");
            //RPCConnectionManager.returnConnection(rpcUser,cordaRPCOps);
            //RPCConnectionManager.returnConnection(cordaRPCOps);
        }
    }
}
