package com.synechron.cordapp.obligation.client.base.exception;

public enum ErrorCode {
    EXCEPTION("1000", "Internal server error. ", ""),
    PARTY_NOT_FOUND("1001", "Party not found on the network. ", ""),
    AUTHENTICATION_INVALID_REQUEST("1002", "Invalid authentication request. ", ""),
    AUTHENTICATION_ERROR("1003", "Error in authentication. ", ""),
    UNAUTHORIZED("1004", "Unauthorized to access resources. ", ""),
    ISSUE_OBLIGATION_EXCEPTION("1005", "Error in Issuing Obligation. ", ""),
    SETTLE_OBLIGATION_EXCEPTION("1006", "Error in Settling Obligation.", ""),
    INVALID_X500_NAME("1007", "Invalid X500 name of corda party. ", "");


    private final String code;
    private final String description;
    private String placeHolder;

    ErrorCode(String code, String description, String placeHolder) {
        this.code = code;
        this.description = description;
        this.placeHolder = placeHolder;
    }

    public String getDescription() {
        return description;
    }

    public String getCode() {
        return code;
    }

    public String getPlaceHolder() {
        return placeHolder;
    }

    @Override
    public String toString() {
        return code + ": " + description;
    }
}
