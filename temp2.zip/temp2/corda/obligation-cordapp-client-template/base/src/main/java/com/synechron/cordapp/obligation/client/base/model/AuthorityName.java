package com.synechron.cordapp.obligation.client.base.model;

public enum AuthorityName {
    ROLE_USER, ROLE_ADMIN
}
