package com.synechron.cordapp.obligation.client.base.controller;

import com.synechron.cordapp.obligation.client.base.model.request.SelfIssueCash;
import net.corda.core.contracts.StateAndRef;
import net.corda.finance.contracts.asset.Cash;
import org.springframework.http.ResponseEntity;

import java.math.BigDecimal;
import java.util.Currency;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ExecutionException;

public interface CashApi {
    /**
     * Get available cash tokens on ledger.
     *
     * @return the list of cash states.
     */
    ResponseEntity<List<StateAndRef<Cash.State>>> cash();

    /**
     * Get the total cash balance per [Currency].
     *
     * @return map of currency and total amount.
     */
    ResponseEntity<Map<Currency, BigDecimal>> cashBalances();

    /**
     * Self-Issue the cash tokens on a ledger.
     *
     * @param issueCash - holds currency type and amount.
     * @return HttpStatus.CREATED on success.
     * @throws InterruptedException
     * @throws ExecutionException
     */
    ResponseEntity selfIssueCash(SelfIssueCash issueCash) throws InterruptedException, ExecutionException;
}
