package com.synechron.cordapp.obligation.client.base.rpc;

import net.corda.client.rpc.CordaRPCClient;
import net.corda.client.rpc.CordaRPCConnection;
import net.corda.core.utilities.NetworkHostAndPort;
import org.apache.commons.pool2.BasePooledObjectFactory;
import org.apache.commons.pool2.PooledObject;
import org.apache.commons.pool2.impl.DefaultPooledObject;

/**
 * Factory class for RPC connection objects pooling
 */
public class RPCConnectionFactory extends BasePooledObjectFactory<CordaRPCConnection> {

    private String hostName;
    private int port;
    private String userName;
    private String password;

    public RPCConnectionFactory(RpcHostPort rpcHostPort, String userName, String password) {
        this.hostName = rpcHostPort.getHostName();
        this.port = rpcHostPort.getPort();
        this.userName = userName;
        this.password = password;
    }

    /**
     * Create an instance that can be served by the pool.
     *
     * @return an instance that can be served by the pool of type {@link CordaRPCConnection}.
     */
    @Override
    public CordaRPCConnection create() {
        NetworkHostAndPort rpcAddress = new NetworkHostAndPort(hostName, port);
        CordaRPCClient rpcClient = new CordaRPCClient(rpcAddress);
        CordaRPCConnection rpcConnection = rpcClient.start(userName, password);
        return rpcConnection;
    }

    /**
     * Wrap the provided instance with an implementation of{@link PooledObject}.
     *
     * @param rpcConnection the instance to wrap.
     * @return The provided instance, wrapped by a {@link PooledObject}.
     */
    @Override
    public PooledObject<CordaRPCConnection> wrap(CordaRPCConnection rpcConnection) {
        return new DefaultPooledObject<>(rpcConnection);
    }

    /**
     * Destroys an instance no longer needed by the pool..
     *
     * @param pooledObject the instance to be destroyed.
     */
    @Override
    public void destroyObject(final PooledObject<CordaRPCConnection> pooledObject)
            throws Exception {
        super.destroyObject(pooledObject);
        pooledObject.getObject().close();
    }

}