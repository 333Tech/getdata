package com.synechron.cordapp.obligation.client.base.rpc;

import java.util.Objects;

/**
 * Model class for RPC User
 */
public class RpcUser {
    private String userName;
    private String password;
    public RpcUser(){}
    public RpcUser(String userName,String password){
        this.userName = userName;
        this.password = password;
    }

    public String getUserName() {
        return userName;
    }

    public void setUserName(String userName) {
        this.userName = userName;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }


    /**
     * Overriden equals method to identify connections with same credentials
     */
    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        RpcUser rpcUser = (RpcUser) o;
        return Objects.equals(userName, rpcUser.userName) &&
                Objects.equals(password, rpcUser.password);
    }

    /**
     * Overriden hashCode method to keep connections with same credentials with same hashcode
     */
    @Override
    public int hashCode() {
        return Objects.hash(userName, password);
    }
}