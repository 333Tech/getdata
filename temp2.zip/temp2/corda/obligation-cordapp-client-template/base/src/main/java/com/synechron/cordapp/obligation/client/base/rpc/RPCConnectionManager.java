package com.synechron.cordapp.obligation.client.base.rpc;

import net.corda.client.rpc.CordaRPCConnection;
import org.apache.commons.pool2.impl.GenericObjectPool;
import org.apache.commons.pool2.impl.GenericObjectPoolConfig;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

import javax.annotation.PostConstruct;

/**
 * Class to Manage RPC connection pool
 */
@Component
public class RPCConnectionManager {

    @Value("${corda.node.rpc.host}")
    private String host;
    @Value("${corda.node.rpc.port}")
    private int port;
    @Value("${corda.node.rpc.username}")
    private String userName;
    @Value("${corda.node.rpc.password}")
    private String password;
    @Value("${corda.node.rpc.pool.minIdle}")
    private int minIdle = 5;
    @Value("${corda.node.rpc.pool.maxIdle}")
    private int maxIdle = 10;
    @Value("${corda.node.rpc.pool.maxTotal}")
    private int maxTotal = 20;
    @Value("${corda.node.rpc.pool.testOnBorrow}")
    private boolean testOnBorrow = true;
    @Value("${corda.node.rpc.pool.testOnReturn}")
    private boolean testOnReturn = true;
    @Value("${corda.node.rpc.pool.timeBetweenEvictionRunsMillis}")
    private long timeBetweenEvictionRunsMillis = 60000;
    @Value("${corda.node.rpc.pool.minEvictableIdleTimeMillis}")
    private long minEvictableIdleTimeMillis = 300000;
    @Value("${corda.node.rpc.pool.softMinEvictableIdleTimeMillis}")
    private long softMinEvictableIdleTimeMillis = 400000;
    public GenericObjectPool<CordaRPCConnection> genericObjectPool;
    private GenericObjectPoolConfig config;

    /**
     * This method instantiates the GenericObjectPool for RPC connection objects.
     */
    @PostConstruct
    void init() throws Exception {
        //RPC connection pool
        config = new GenericObjectPoolConfig();
        config.setMinIdle(minIdle);
        config.setMaxIdle(maxIdle);
        config.setMaxTotal(maxTotal);
        config.setTestOnBorrow(testOnBorrow);
        config.setTestOnReturn(testOnReturn);
        config.setTimeBetweenEvictionRunsMillis(timeBetweenEvictionRunsMillis);
        config.setMinEvictableIdleTimeMillis(minEvictableIdleTimeMillis);
        config.setSoftMinEvictableIdleTimeMillis(softMinEvictableIdleTimeMillis);

        genericObjectPool = new GenericObjectPool<CordaRPCConnection>(
                RPCConnectionFactoryCreator.getInstance(new RpcHostPort(host, port), userName, password)
                , config);
    }

    /**
     * @return CordaRPCConnection instance that can be served by the pool of type {@link CordaRPCConnection}.
     * @throws Exception if there is a problem creating a new instance,
     *                   this will be propagated to the code requesting an object.
     */
    public CordaRPCConnection getConnection() throws Exception {
        CordaRPCConnection rpcConnection = this.genericObjectPool.borrowObject();
        return rpcConnection;
    }

    /**
     * Returns an object to a base object pool. It validates the object before adding the pool.
     * If validations fail then the returning object is destroyed.
     *
     * @param rpcConnection the connection object that is to be returned.
     */
    public void returnConnection(CordaRPCConnection rpcConnection) throws Exception {
        this.genericObjectPool.returnObject(rpcConnection);
    }
}
