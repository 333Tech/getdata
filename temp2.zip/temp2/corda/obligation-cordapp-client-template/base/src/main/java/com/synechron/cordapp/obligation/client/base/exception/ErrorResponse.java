package com.synechron.cordapp.obligation.client.base.exception;

import org.springframework.http.HttpStatus;

import com.fasterxml.jackson.annotation.JsonProperty;

public class ErrorResponse {
    @JsonProperty("result_code")
    private String resultCode;

    @JsonProperty("status")
    private HttpStatus status;

    @JsonProperty("message")
    private String message;

    public ErrorResponse() {
    }

    public ErrorResponse(String message, String resultCode, HttpStatus status) {
        this.message = message;
        this.resultCode = resultCode;
        this.status = status;
    }

    /**
     * @return the Result Code
     */
    public String getResultCode() {
        return resultCode;
    }

    /**
     * @param resultCode
     */
    public void setResultCode(String resultCode) {
        this.resultCode = resultCode;
    }

    /**
     * @return the Status
     */
    public HttpStatus getStatus() {
        return status;
    }

    /**
     * @param status
     */
    public void setStatus(HttpStatus status) {
        this.status = status;
    }

    /**
     * @return the Error Message
     */
    public String getMessage() {
        return message;
    }

    /**
     * @param message
     */
    public void setMessage(String message) {
        this.message = message;
    }

    @Override
    public String toString() {
        return "ErrorResponse [resultCode=" + resultCode + ", status=" + status + ", message=" + message + "]";
    }

   /* public static ErrorResponse getInstance(CorDappClientBaseException ex) {
        ErrorResponse errorResponse = new ErrorResponse();
        errorResponse.setResultCode(ex.getErrorCode());
        errorResponse.setMessage(ex.getMessage());
        errorResponse.setStatus(ex.getStatus());
        return errorResponse;
    }*/
}
