package com.synechron.cordapp.obligation.client.base.controller;

import java.util.List;
import java.util.Map;

import javax.ws.rs.Consumes;
import javax.ws.rs.Produces;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Profile;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.synechron.cordapp.obligation.client.base.model.response.PartyResponseModel;
import com.synechron.cordapp.obligation.client.base.model.response.TransactionInfo;
import com.synechron.cordapp.obligation.client.base.service.BaseService;

import io.swagger.annotations.ApiOperation;

@Profile("!mock")
@CrossOrigin
@RestController
@RequestMapping(value = "/base")
@Produces(MediaType.APPLICATION_JSON_VALUE)
@Consumes(MediaType.APPLICATION_JSON_VALUE)
public class BaseApiController implements BaseApi {

    @Autowired
    BaseService baseService;

    /**
     * {@inheritDoc}
     */
    @ApiOperation(value = "Header Information")
    @RequestMapping(value = "/user/loginAsHeaderInfo", method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<Map<String, List<PartyResponseModel>>> getloginAsHeaderInfo() {

        Map<String, List<PartyResponseModel>> headerInfo = baseService.getloginAsHeaderInfo();

        return new ResponseEntity<>(headerInfo, HttpStatus.OK);
    }

    /**
     * This method will return the Transactions in vault
     *
     * @return ResponseEntity
     */
    @ApiOperation("transactions info")
    @RequestMapping(value = "/transactions", method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity getTransactions() {

        List<TransactionInfo> transactionInfos = baseService.getTransactions();

        return new ResponseEntity<>(transactionInfos, HttpStatus.OK);

    }
}
