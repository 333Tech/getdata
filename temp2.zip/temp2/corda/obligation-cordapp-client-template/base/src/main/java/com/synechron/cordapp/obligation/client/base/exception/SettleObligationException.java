package com.synechron.cordapp.obligation.client.base.exception;

public class SettleObligationException extends CorDappClientBaseException {

    public SettleObligationException() {
    }

    public SettleObligationException(String message) {
        super(message);
    }

    public SettleObligationException(Exception exception) {
        super(exception);
    }
}
