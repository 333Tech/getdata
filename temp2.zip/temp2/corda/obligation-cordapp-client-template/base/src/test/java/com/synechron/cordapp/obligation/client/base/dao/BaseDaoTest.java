package com.synechron.cordapp.obligation.client.base.dao;

import static org.mockito.Mockito.doReturn;

import java.util.ArrayList;
import java.util.List;

import org.junit.Assert;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.powermock.api.mockito.PowerMockito;
import org.powermock.core.classloader.annotations.PrepareForTest;
import org.powermock.modules.junit4.PowerMockRunner;

import com.synechron.cordapp.obligation.client.base.AbstractDaoUnitTests;
import com.synechron.cordapp.obligation.client.base.util.CommonUtils;

import net.corda.core.identity.Party;
import net.corda.core.node.NodeInfo;

@RunWith(PowerMockRunner.class)
@PrepareForTest({ CommonUtils.class })
public class BaseDaoTest extends AbstractDaoUnitTests {

    @InjectMocks
    BaseDaoImpl baseDao;

    @Mock
    protected NodeInfo nodeInfo;

    @Test
    public void testGetParty() {
        List<Party> parties = new ArrayList<>();
        parties.add(partyA);
        doReturn(nodeInfo).when(rpcOps).nodeInfo();
        doReturn(parties).when(nodeInfo).getLegalIdentities();
        Party party = baseDao.getParty();
        Assert.assertEquals(partyA, party);
    }

    @Test
    public void getNodeName() {
        PowerMockito.mockStatic(CommonUtils.class);
        PowerMockito.when(CommonUtils.getOrganisation(partyA)).thenReturn("PartyA");
        List<Party> parties = new ArrayList<>();
        parties.add(partyA);
        doReturn(nodeInfo).when(rpcOps).nodeInfo();
        doReturn(parties).when(nodeInfo).getLegalIdentities();
        String party = baseDao.getNodeName();
        Assert.assertEquals("PartyA", party);
    }

}
