package com.synechron.cordapp.obligation.client.base.service;

import java.math.BigDecimal;
import java.util.Currency;
import java.util.Map;
import java.util.concurrent.ExecutionException;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mockito;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.TestConfiguration;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.context.annotation.Bean;
import org.springframework.test.context.junit4.SpringRunner;

import com.synechron.cordapp.obligation.client.base.AbstractCashTests;
import com.synechron.cordapp.obligation.client.base.dao.CashDao;

@RunWith(SpringRunner.class)
public class CashServiceTests extends AbstractCashTests {

    @TestConfiguration
    static class CashServiceImplTestContextConfig {
        @Bean
        public CashService cashService() {
            return new CashServiceImpl();
        }
    }

    @MockBean
    private CashDao cashDao;
    @Autowired
    private CashService cashService;

    @Test
    public void testGetAllCashStates() {
        Mockito.when(cashDao.cash()).thenReturn(cashStateAndRefs);
        assert (cashService.cash() == cashStateAndRefs);
    }

    @Test
    public void testGetCashBalances() {
        Mockito.when(cashDao.cashBalances()).thenReturn(currencyAmountMap);

        Map<Currency, BigDecimal> resultMap = cashService.cashBalances();
        assert (resultMap.size() == 1);
        assert (resultMap.keySet().contains(usd));
        assert (resultMap.values().iterator().next().longValue() == 1000);
    }

    @Test
    public void testSelfIssueCash() throws InterruptedException, ExecutionException {
        cashService.selfIssueCash(1000, "USD");
    }
}
