package com.synechron.cordapp.obligation.client.base.service;

import com.synechron.cordapp.obligation.client.base.AbstractDaoUnitTests;
import org.junit.Assert;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mockito;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.TestConfiguration;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.context.annotation.Bean;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.test.context.junit4.SpringRunner;

import com.synechron.cordapp.obligation.client.base.dao.BaseDao;

import net.corda.core.identity.Party;

@RunWith(SpringRunner.class)
public class BaseServiceTest extends AbstractDaoUnitTests {

    @TestConfiguration
    static class BaseServiceImplTestContextConfig {
        @Bean
        public BaseService cashService() {
            return new BaseServiceImpl();
        }
    }

    @Autowired
    BaseService baseService;
    @MockBean
    BaseDao baseDao;

    @Test
    public void testGetNodeName() {
        String party = "PartyA";
        Mockito.when(baseDao.getNodeName()).thenReturn(party);
        String partyName = baseService.getNodeName();
        Assert.assertEquals(party, partyName);
    }

    @Test
    public void testGetNodeName1() {
        String party = "PartyA";
        Mockito.when(baseDao.getNodeName(partyA)).thenReturn(party);
        String partyName = baseService.getNodeName(partyA);
        Assert.assertEquals(party, partyName);
    }

    @Test
    public void testGetParty() {
        Mockito.when(baseDao.getParty()).thenReturn(partyA);
        Party party = baseService.getParty();
        Assert.assertEquals(party, partyA);
    }

    @Test
    public void testGetParty1() {
        String party = "PartyA";
        Mockito.when(baseDao.getParty(party)).thenReturn(partyA);
        Party party1 = baseService.getParty(party);
        Assert.assertEquals(partyA, party1);
    }

    @Test
    public void testResolveIdentity() {
        Mockito.when(baseDao.resolveIdentity(partyA)).thenReturn(partyA);
        Party party = baseService.resolveIdentity(partyA);
        Assert.assertEquals(party, partyA);
    }


    @Test
    public void testGeneratePassword(){
        BCryptPasswordEncoder bCryptPasswordEncoder = new BCryptPasswordEncoder();
        String passwordHash = bCryptPasswordEncoder.encode("user");
        System.out.println(passwordHash);

    }

}
