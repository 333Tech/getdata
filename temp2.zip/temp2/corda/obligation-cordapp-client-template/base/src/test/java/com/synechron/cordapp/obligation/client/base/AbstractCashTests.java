package com.synechron.cordapp.obligation.client.base;

import java.math.BigDecimal;
import java.util.*;

import org.mockito.Mock;

import net.corda.core.contracts.Amount;
import net.corda.core.contracts.StateAndRef;
import net.corda.finance.contracts.asset.Cash;

public abstract class AbstractCashTests {
    @Mock
    protected StateAndRef<Cash.State> cashState;
    protected List<StateAndRef<Cash.State>> cashStateAndRefs = Collections.singletonList(cashState);
    protected static Currency usd = Currency.getInstance("USD");
    protected static Map<Currency, Amount<Currency>> currencyAmountMap = new HashMap<>();
    protected static Map<Currency, BigDecimal> currencyBigDecimalMap = new HashMap<>();

    static {
        currencyAmountMap.put(usd, Amount.parseCurrency("$1000"));
        currencyBigDecimalMap.put(usd, new BigDecimal("1000"));
    }
}
