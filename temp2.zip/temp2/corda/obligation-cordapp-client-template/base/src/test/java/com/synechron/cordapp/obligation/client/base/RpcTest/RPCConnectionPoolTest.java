package com.synechron.cordapp.obligation.client.base.RpcTest;

import com.synechron.cordapp.obligation.client.base.rpc.RPCConnectionFactory;
import com.synechron.cordapp.obligation.client.base.rpc.RPCConnectionFactoryCreator;
import com.synechron.cordapp.obligation.client.base.rpc.RPCConnectionManager;
import com.synechron.cordapp.obligation.client.base.rpc.RpcHostPort;
import net.corda.client.rpc.CordaRPCConnection;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mock;
import org.powermock.api.mockito.PowerMockito;
import org.powermock.core.classloader.annotations.PowerMockIgnore;
import org.powermock.core.classloader.annotations.PrepareForTest;
import org.powermock.modules.junit4.PowerMockRunner;

import java.lang.reflect.Method;

import static org.mockito.ArgumentMatchers.any;
import static org.powermock.api.mockito.PowerMockito.doReturn;
import static org.powermock.api.mockito.PowerMockito.spy;


/**
 * Test for RPC connection pool
 */
@RunWith(PowerMockRunner.class)
@PrepareForTest(RPCConnectionFactoryCreator.class)
@PowerMockIgnore("javax.management.*")
public class RPCConnectionPoolTest {
    @Mock
    CordaRPCConnection rpcConnection;
    @Mock
    CordaRPCConnection rpcConnection1;
    @Mock
    CordaRPCConnection rpcConnection2;

    RPCConnectionFactory rpcConnectionFactory;
    RPCConnectionManager rpcConnectionManager;

    /**
     * Test for RPC connection pool
     */
    @Test
    public void testRPCconnectionPool() throws Exception {
        rpcConnectionFactory = new RPCConnectionFactory(new RpcHostPort("localhost", 10006),
                "user1", "test");
        RPCConnectionFactory rpcConnectionFactorySpy = spy(rpcConnectionFactory);
        doReturn(rpcConnection).when(rpcConnectionFactorySpy).create();

        assert (rpcConnectionFactorySpy.create() != null);

        PowerMockito.mockStatic(RPCConnectionFactoryCreator.class);
        PowerMockito.when(RPCConnectionFactoryCreator.getInstance(any(), any(), any())).thenReturn(rpcConnectionFactorySpy);
        rpcConnectionManager = new RPCConnectionManager();
        Method postConstruct = RPCConnectionManager.class.getDeclaredMethod("init", null); // methodName,parameters
        postConstruct.setAccessible(true);
        postConstruct.invoke(rpcConnectionManager);

        CordaRPCConnection conn1 = rpcConnectionManager.getConnection();
        assert (rpcConnectionFactorySpy.create() != null);

        doReturn(rpcConnection1).when(rpcConnectionFactorySpy).create();
        CordaRPCConnection conn2 = rpcConnectionManager.getConnection();
        assert (rpcConnectionFactorySpy.create() != null);

        doReturn(rpcConnection2).when(rpcConnectionFactorySpy).create();
        CordaRPCConnection conn3 = rpcConnectionManager.getConnection();
        assert (rpcConnectionFactorySpy.create() != null);

        assert (rpcConnectionManager.genericObjectPool.getNumActive() == 3);
        assert (rpcConnectionManager.genericObjectPool.getCreatedCount() == 3);
        assert (rpcConnectionManager.genericObjectPool.getMaxTotal() == 20);

        rpcConnectionManager.genericObjectPool.returnObject(conn1);
        rpcConnectionManager.genericObjectPool.returnObject(conn2);
        assert (rpcConnectionManager.genericObjectPool.getNumActive() == 1);
        assert (rpcConnectionManager.genericObjectPool.getNumIdle() == 2);
        assert (rpcConnectionManager.genericObjectPool.getReturnedCount() == 2);
        assert (rpcConnectionManager.genericObjectPool.listAllObjects().size() == 3);
    }
}
