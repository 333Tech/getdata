package com.synechron.cordapp.obligation.client.base;

import com.synechron.cordapp.obligation.client.base.rpc.NodeRPCConnection;
import net.corda.core.concurrent.CordaFuture;
import net.corda.core.crypto.SecureHash;
import net.corda.core.identity.Party;
import net.corda.core.messaging.CordaRPCOps;
import net.corda.core.messaging.FlowHandle;
import net.corda.core.node.services.Vault;
import net.corda.core.transactions.SignedTransaction;
import net.corda.finance.workflows.GetBalances;
import org.junit.Before;
import org.junit.runner.RunWith;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.powermock.core.classloader.annotations.PowerMockIgnore;
import org.powermock.core.classloader.annotations.PrepareForTest;
import org.powermock.modules.junit4.PowerMockRunner;

import java.util.Collections;

import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.doReturn;
import static org.mockito.Mockito.when;


@RunWith(PowerMockRunner.class)
@PowerMockIgnore("javax.management.*")
@PrepareForTest({GetBalances.class})
@SuppressWarnings("unchecked")
public abstract class AbstractDaoUnitTests {
    // Mocking of commonly used classes.
    @Mock
    protected Party notary;
    @Mock
    protected Party partyA;
    @Mock
    protected Party partyB;
    @Mock
    protected CordaRPCOps rpcOps;
    @Mock
    protected FlowHandle flowHandle;
    @Mock
    protected CordaFuture future;
    @Mock
    protected Vault.Page vaultPage;
    @Mock
    protected NodeRPCConnection rpcConnection;
    @Mock
    protected SignedTransaction signedTransaction;

    protected SecureHash secureHash = SecureHash.randomSHA256();

    @Before
    public void setup() throws Exception {
        MockitoAnnotations.initMocks(this);
        // Mocking of commonly used object and method calls.
        when(rpcConnection.getProxy()).thenReturn(rpcOps);
        when(flowHandle.getReturnValue()).thenReturn(future);
        doReturn(vaultPage).when(rpcOps).vaultQuery(any());
        // Notary from network.
        doReturn(Collections.singletonList(notary)).when(rpcOps).notaryIdentities();
        // doReturn(Collections.singletonList(partyA)).when(nodeInfo).getLegalIdentities();
        // FlowHandle from start flow constructors.
        when(rpcOps.startFlowDynamic(any(), any())).thenReturn(flowHandle);
        when(rpcOps.startFlowDynamic(any(), any(), any())).thenReturn(flowHandle);
        when(rpcOps.startFlowDynamic(any(), any(), any(), any())).thenReturn(flowHandle);
        when(future.get()).thenReturn(signedTransaction);
        when(signedTransaction.getId()).thenReturn(secureHash);
    }
}
