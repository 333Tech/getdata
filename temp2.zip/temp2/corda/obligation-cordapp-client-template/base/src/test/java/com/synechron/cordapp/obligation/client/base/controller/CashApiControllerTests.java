package com.synechron.cordapp.obligation.client.base.controller;

import static org.mockito.Mockito.doReturn;
import static org.mockito.Mockito.when;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.jsonPath;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.MediaType;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.request.MockMvcRequestBuilders;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.synechron.cordapp.obligation.client.base.AbstractCashTests;
import com.synechron.cordapp.obligation.client.base.model.request.SelfIssueCash;
import com.synechron.cordapp.obligation.client.base.service.CashService;

@RunWith(SpringRunner.class)
@WebMvcTest(value = CashApiController.class, secure = false)
public class CashApiControllerTests extends AbstractCashTests {
    @Autowired
    private MockMvc mvc;
    @Autowired
    ObjectMapper objectMapper;
    @MockBean
    private CashService cashService;

    @SpringBootApplication
    static class TestConfiguration {
    }

    @Test
    public void testGetAllCashState() throws Exception {
        when(cashService.cash()).thenReturn(cashStateAndRefs);

        mvc.perform(MockMvcRequestBuilders.get("/cash").contentType(MediaType.APPLICATION_JSON)).andExpect(status().isOk());
    }

    @Test
    public void testGetCashBalances() throws Exception {
        doReturn(currencyBigDecimalMap).when(cashService).cashBalances();

        mvc.perform(MockMvcRequestBuilders.get("/cash/cash-balances").contentType(MediaType.APPLICATION_JSON)).andExpect(status().isOk())
                .andExpect(jsonPath("$.USD").value(1000));
    }

    @Test
    public void testSelfIssueCash() throws Exception {
        SelfIssueCash selfIssueCash = new SelfIssueCash("USD", 1000L);
        mvc.perform(MockMvcRequestBuilders.post("/cash/self-issue-cash").contentType(MediaType.APPLICATION_JSON_UTF8)
                .content(objectMapper.writeValueAsBytes(selfIssueCash))).andExpect(status().isCreated());
    }
}
