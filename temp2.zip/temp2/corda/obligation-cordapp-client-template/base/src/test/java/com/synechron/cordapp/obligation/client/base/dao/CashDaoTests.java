package com.synechron.cordapp.obligation.client.base.dao;

import static org.junit.Assert.assertEquals;
import static org.mockito.Mockito.doReturn;

import java.util.ArrayList;
import java.util.Currency;
import java.util.HashMap;
import java.util.Map;

import com.synechron.cordapp.obligation.client.base.AbstractDaoUnitTests;
import net.corda.finance.workflows.GetBalances;
import org.junit.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.powermock.api.mockito.PowerMockito;



import net.corda.core.contracts.Amount;
import net.corda.core.contracts.StateAndRef;
import net.corda.finance.contracts.asset.Cash;

public class CashDaoTests extends AbstractDaoUnitTests {
    @InjectMocks
    private CashDaoImpl cashDao;

    @Mock
    private StateAndRef<Cash.State> cashState;

    @Test
    public void testGetAllCashStates() {
        //Build sample list with cash states.
        ArrayList<StateAndRef<Cash.State>> stateAndRefs = new ArrayList<>();
        stateAndRefs.add(cashState);
        doReturn(stateAndRefs).when(vaultPage).getStates();
        assertEquals(cashDao.cash(), stateAndRefs);
    }

    @Test
    public void testGetCashBalances() {
        //Create sample map with Amount data.
        Map<Currency, Amount<Currency>> cashBalances = new HashMap<>();
        cashBalances.put(Currency.getInstance("USD"), Amount.parseCurrency("$1000"));
        PowerMockito.mockStatic(GetBalances.class);
        PowerMockito.when(GetBalances.getCashBalances(rpcOps)).thenReturn(cashBalances);
        assertEquals(cashDao.cashBalances(), cashBalances);
    }

    @Test
    public void testSelfIssueCash() throws Exception {
        cashDao.selfIssueCash(1000, "USD");
    }
}
