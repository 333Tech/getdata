package com.synechron.cordapp.obligation.client.borrower.dao;

import java.util.List;
import java.util.concurrent.ExecutionException;

import org.springframework.data.util.Pair;

//import com.synechron.cordapp.obligation.state.Obligation;

import net.corda.core.contracts.Amount;
import net.corda.core.contracts.UniqueIdentifier;
import net.corda.core.crypto.SecureHash;
import net.corda.core.identity.Party;

public interface ObligationDao {
    /**
     * Issue obligation.
     *
     * @param amount
     * @param lender
     * @param anonymous
     * @return transaction id.
     * @throws InterruptedException
     * @throws ExecutionException
     */
    SecureHash issueObligation(Amount amount, Party lender, boolean anonymous) throws InterruptedException, ExecutionException;

    /**
     * Settle obligation.
     * 
     * @param linearId
     * @param amount
     * @param anonymous
     * @return transaction id.
     * @throws InterruptedException
     * @throws ExecutionException
     */
    SecureHash settleObligation(UniqueIdentifier linearId, Amount amount, boolean anonymous)
            throws InterruptedException, ExecutionException;

    /**
     * Get all Obligation state on the ledger.
     * 
     * @return list of Obligation state.
     */
//    Pair<List<Obligation>, Long> getObligations(Integer page);

    /**
     * Get lender parties from the network
     *
     * @return list of Parties.
     */
    List<com.synechron.cordapp.obligation.client.base.dao.entity.Party> getLenderParties();

    /**
     * Set the network time.
     *
     * @param time
     * @return transaction id.
     * @throws InterruptedException
     * @throws ExecutionException
     */
    SecureHash setNetworkTime(Long time) throws InterruptedException, ExecutionException;

    /**
     * Reset the network time.
     *
     * @return transaction id.
     * @throws InterruptedException
     * @throws ExecutionException
     */
    SecureHash resetNetworkTime() throws InterruptedException, ExecutionException;

}
