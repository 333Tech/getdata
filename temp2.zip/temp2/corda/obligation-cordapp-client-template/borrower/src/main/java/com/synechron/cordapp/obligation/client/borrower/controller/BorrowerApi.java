package com.synechron.cordapp.obligation.client.borrower.controller;

import java.util.concurrent.ExecutionException;

import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestParam;

import com.synechron.cordapp.obligation.client.borrower.model.request.IssueObligation;
import com.synechron.cordapp.obligation.client.borrower.model.request.SettleObligation;

public interface BorrowerApi {

    /**
     * Get node name.
     *
     * @return name of the node.
     */
    ResponseEntity getNodeName();

    /**
     * Issue obligation.
     *
     * @param issueObligation - holds amount,currency type,lender and anonymous.
     * @return transaction id.
     * @throws InterruptedException
     * @throws ExecutionException
     */
    ResponseEntity issueObligation(@RequestBody IssueObligation issueObligation) throws InterruptedException, ExecutionException;

    /**
     * Get all Obligation states on the ledger.
     *
     * @return list of obligation states.
     */
    ResponseEntity getObligations(@RequestParam(value = "page", defaultValue = "1") Integer page);

    /**
     * Settle obligation.
     *
     * @param settleObligation - holds linearId,amount,currency type and anonymous.
     * @return transaction id.
     * @throws InterruptedException
     * @throws ExecutionException
     */
    ResponseEntity settleObligation(@RequestBody SettleObligation settleObligation) throws InterruptedException, ExecutionException;

    /**
     * Get lender parties from the network
     *
     * @return list of Parties.
     */
    ResponseEntity getLenderParties();

    /**
     * Set network time.
     *
     * @param time
     * @return transaction id.
     * @throws InterruptedException
     * @throws ExecutionException
     */
    ResponseEntity setNetworkTime(@RequestBody Long time) throws InterruptedException, ExecutionException;

    /**
     * Reset the network time.
     *
     * @return transaction id.
     * @throws InterruptedException
     * @throws ExecutionException
     */
    ResponseEntity resetNetworkTime() throws InterruptedException, ExecutionException;

}
