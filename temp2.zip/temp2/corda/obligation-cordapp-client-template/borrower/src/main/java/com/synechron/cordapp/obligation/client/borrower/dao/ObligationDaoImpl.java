package com.synechron.cordapp.obligation.client.borrower.dao;

import com.synechron.cordapp.obligation.borrower.flows.IssueObligationInitiatorFlow;
import com.synechron.cordapp.obligation.borrower.flows.SettleObligationInitiatorFlow;
import com.synechron.cordapp.obligation.client.base.exception.IssueObligationException;
import com.synechron.cordapp.obligation.client.base.exception.SettleObligationException;
import com.synechron.cordapp.obligation.client.base.rpc.NodeRPCConnection;
import com.synechron.cordapp.obligation.commons.flows.ResetNetworkTimeInitiatorFlow;
import com.synechron.cordapp.obligation.commons.flows.SetNetworkTimeInitiatorFlow;
import com.synechron.cordapp.obligation.state.Obligation;
import net.corda.core.contracts.Amount;
import net.corda.core.contracts.UniqueIdentifier;
import net.corda.core.crypto.SecureHash;
import net.corda.core.identity.Party;
import net.corda.core.messaging.FlowHandle;
import net.corda.core.node.services.Vault;
import net.corda.core.node.services.vault.PageSpecification;
import net.corda.core.node.services.vault.QueryCriteria;
import net.corda.core.transactions.SignedTransaction;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.PropertySource;
import org.springframework.data.util.Pair;
import org.springframework.stereotype.Repository;

import javax.persistence.EntityManager;
import javax.persistence.Query;
import java.util.List;
import java.util.concurrent.ExecutionException;
import java.util.stream.Collectors;

@Repository("obligationDaoBorrower")
@PropertySource("classpath:sql_query.properties")
public class ObligationDaoImpl implements ObligationDao {

    @Autowired
    private NodeRPCConnection rpcConnection;
    @Autowired
    @Qualifier("clientEntityManager")
    private EntityManager entityManager;
    @Value("${corda.vault.pageSize}")
    private int pageSize;
    @Value("${query.get.party.by.type}")
    private String queryByPartyType;

    /**
     * {@inheritDoc}
     */
    @Override
    public SecureHash issueObligation(Amount amount, Party lender, boolean anonymous) throws InterruptedException, ExecutionException {
        try {
            FlowHandle<SignedTransaction> flowHandle = rpcConnection.getProxy().startFlowDynamic(IssueObligationInitiatorFlow.class, amount,
                    lender, anonymous);
            return flowHandle.getReturnValue().get().getId();
        } catch (Exception exception) {
            String originalExceptionMessage = getOriginalExceptionMessage(exception.getMessage());
            throw new IssueObligationException(originalExceptionMessage);
        }
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public SecureHash settleObligation(UniqueIdentifier linearId, Amount amount, boolean anonymous)
            throws InterruptedException, ExecutionException {
        try {
            FlowHandle<SignedTransaction> flowHandle = rpcConnection.getProxy().startFlowDynamic(SettleObligationInitiatorFlow.class,
                    linearId, amount, anonymous);
            return flowHandle.getReturnValue().get().getId();
        } catch (Exception exception) {
            String originalExceptionMessage = getOriginalExceptionMessage(exception.getMessage());
            throw new SettleObligationException(originalExceptionMessage);
        }

    }

    /**
     * {@inheritDoc}
     */
    @Override
    public Pair<List<Obligation>, Long> getObligations(Integer page) {
        Pair<List<Obligation>, Long> dataAndPageCount;
        QueryCriteria criteria = new QueryCriteria.VaultQueryCriteria(Vault.StateStatus.UNCONSUMED);
        Vault.Page<Obligation> obligationPage = rpcConnection.getProxy().vaultQueryByWithPagingSpec(Obligation.class, criteria,
                new PageSpecification(page, pageSize));
        List<Obligation> obligations = obligationPage.getStates().stream().map(it -> it.getState().getData()).collect(Collectors.toList());
        long totalStatesAvailable = obligationPage.getTotalStatesAvailable();
        totalStatesAvailable = totalStatesAvailable < pageSize ? 1 : ((long) Math.ceil(totalStatesAvailable / ((double) pageSize)));
        dataAndPageCount = Pair.of(obligations, totalStatesAvailable);
        return dataAndPageCount;
    }

    /**
     * {@inheritDoc}
     */
    @SuppressWarnings("unchecked")
    @Override
    public List<com.synechron.cordapp.obligation.client.base.dao.entity.Party> getLenderParties() {
        Query query = entityManager.createQuery(queryByPartyType);
        query.setParameter("type", "Lender");
        return query.getResultList();
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public SecureHash setNetworkTime(Long time) throws InterruptedException, ExecutionException {
        FlowHandle<SecureHash> flowHandle = rpcConnection.getProxy().startFlowDynamic(SetNetworkTimeInitiatorFlow.class, time);
        SecureHash txId = flowHandle.getReturnValue().get();
        return txId;
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public SecureHash resetNetworkTime() throws InterruptedException, ExecutionException {
        FlowHandle<SecureHash> flowHandle = rpcConnection.getProxy().startFlowDynamic(ResetNetworkTimeInitiatorFlow.class);
        SecureHash txId = flowHandle.getReturnValue().get();
        return txId;

    }

    private String getOriginalExceptionMessage(String message) {
        int startIndex = message.indexOf(":");
        String originalMessage = null;
        if (startIndex == -1) {
            int exceptionClassNameIndex = message.indexOf(".");
            if (exceptionClassNameIndex == -1) {
//               Print only original message.
                originalMessage = message;
            } else {
//                Print only exception class name.
                originalMessage = message;
            }
        } else {
            originalMessage = message.substring(startIndex + 1, message.length() - 1);
        }
        return originalMessage;
    }
}
