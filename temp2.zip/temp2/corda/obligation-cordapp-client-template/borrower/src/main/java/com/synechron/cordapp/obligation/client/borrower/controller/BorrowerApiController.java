package com.synechron.cordapp.obligation.client.borrower.controller;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ExecutionException;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Profile;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import com.synechron.cordapp.obligation.client.base.model.response.PartyResponseModel;
import com.synechron.cordapp.obligation.client.base.service.BaseService;
import com.synechron.cordapp.obligation.client.borrower.model.request.IssueObligation;
import com.synechron.cordapp.obligation.client.borrower.model.request.SettleObligation;
import com.synechron.cordapp.obligation.client.borrower.service.ObligationService;

import io.micrometer.core.annotation.Timed;
import io.swagger.annotations.ApiOperation;
import net.corda.core.crypto.SecureHash;

@Timed
@Profile("!mock")
@CrossOrigin
@RestController
@RequestMapping(value = "/borrower/obligation")
public class BorrowerApiController implements BorrowerApi {

    @Autowired
    private ObligationService obligationService;
    @Autowired
    private BaseService baseService;

    /**
     * {@inheritDoc}
     */
    // @PreAuthorize("hasAnyRole('ROLE_USER', 'ROLE_ADMIN')")
    @ApiOperation(value = "Name of the Node", produces = MediaType.APPLICATION_JSON_VALUE)
    @RequestMapping(value = "/name", method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity getNodeName() {
        String nodeName = baseService.getNodeName();
        Map<String, String> map = new HashMap<>();
        map.put("name", nodeName);
        return new ResponseEntity<>(map, HttpStatus.OK);
    }

    /**
     * {@inheritDoc}
     */
    // @PreAuthorize("hasRole('ROLE_ADMIN')")
    @ApiOperation(value = "Issue Obligation", consumes = MediaType.APPLICATION_JSON_VALUE)
    @RequestMapping(value = "/issue-obligation", method = RequestMethod.POST, consumes = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity issueObligation(@RequestBody IssueObligation issueObligation) throws InterruptedException, ExecutionException {
        SecureHash secureHash = obligationService.issueObligation(issueObligation);
        return new ResponseEntity<>(secureHash, HttpStatus.CREATED);
    }

    /**
     * {@inheritDoc}
     */
    // @PreAuthorize("hasAnyRole('ROLE_USER', 'ROLE_ADMIN')")
    @ApiOperation(value = "Obligation list", produces = MediaType.APPLICATION_JSON_VALUE)
    @RequestMapping(value = "/obligations", method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity getObligations(@RequestParam(value = "page", defaultValue = "1") Integer page) {
        Map<String, Object> obligations = obligationService.getObligations(page);
        return new ResponseEntity<>(obligations, HttpStatus.OK);
    }

    /**
     * {@inheritDoc}
     */
    // @PreAuthorize("hasRole('ROLE_ADMIN')")
    @ApiOperation(value = "Settle-Obligation", consumes = MediaType.APPLICATION_JSON_VALUE)
    @RequestMapping(value = "/settle-obligation", method = RequestMethod.POST, consumes = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity settleObligation(@RequestBody SettleObligation settleObligation) throws ExecutionException, InterruptedException {
        SecureHash secureHash = obligationService.settleObligation(settleObligation);
        return new ResponseEntity<>(secureHash, HttpStatus.CREATED);
    }

    /**
     * {@inheritDoc}
     */
    @Override
    // @PreAuthorize("hasAnyRole('ROLE_USER', 'ROLE_ADMIN')")
    @ApiOperation(value = "Lender Parties", produces = MediaType.APPLICATION_JSON_VALUE)
    @RequestMapping(value = "/lender-parties", method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity getLenderParties() {
        List<PartyResponseModel> lenderParties = obligationService.getLenderParties();
        return new ResponseEntity<>(lenderParties, HttpStatus.OK);
    }

    /**
     * {@inheritDoc}
     */
    @Override
    // @PreAuthorize("hasRole('ROLE_ADMIN')")
    @ApiOperation(value = "Set Network Time", consumes = MediaType.APPLICATION_JSON_VALUE)
    @RequestMapping(value = "/set-network-time", method = RequestMethod.POST, consumes = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity setNetworkTime(Long time) throws InterruptedException, ExecutionException {
        SecureHash secureHash = obligationService.setNetworkTime(time);
        return new ResponseEntity<>(secureHash, HttpStatus.OK);
    }

    /**
     * {@inheritDoc}
     */
    @Override
    // @PreAuthorize("hasRole('ROLE_ADMIN')")
    @ApiOperation(value = "Reset Network Time", consumes = MediaType.APPLICATION_JSON_VALUE)
    @RequestMapping(value = "/reset-network-time", method = RequestMethod.POST, consumes = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity resetNetworkTime() throws InterruptedException, ExecutionException {
        SecureHash secureHash = obligationService.resetNetworkTime();
        return new ResponseEntity<>(secureHash, HttpStatus.OK);
    }
}
