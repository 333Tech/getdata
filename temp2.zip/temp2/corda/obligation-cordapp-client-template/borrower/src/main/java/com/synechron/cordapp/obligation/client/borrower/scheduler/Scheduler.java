package com.synechron.cordapp.obligation.client.borrower.scheduler;

import java.sql.Timestamp;
import java.util.Date;
import java.util.TimeZone;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.scheduling.annotation.EnableScheduling;
import org.springframework.scheduling.annotation.SchedulingConfigurer;
import org.springframework.scheduling.config.CronTask;
import org.springframework.scheduling.config.ScheduledTaskRegistrar;
import org.springframework.scheduling.support.CronSequenceGenerator;
import org.springframework.scheduling.support.CronTrigger;
import org.springframework.stereotype.Component;

import com.synechron.cordapp.obligation.client.borrower.service.ObligationServiceImpl;

@Component
@EnableScheduling
public class Scheduler implements SchedulingConfigurer {

    @Autowired
    private ObligationServiceImpl cronJob;
    @Value("${scheduler.cron_expression}")
    private String cronExpression;
    @Value("${scheduler.timezone}")
    private String timezone;

    @Bean
    CronTrigger cronTrigger() {
        return new CronTrigger(cronExpression, TimeZone.getTimeZone(timezone));
    }

    @Override
    public void configureTasks(ScheduledTaskRegistrar taskRegistrar) {
        taskRegistrar.addCronTask(new CronTask(cronJob, cronTrigger()));
    }

    public boolean isObligationSettlementScheduled(Long time) {
        final CronSequenceGenerator generator = new CronSequenceGenerator(cronExpression, TimeZone.getTimeZone(timezone));
        Date date = new Date(time);
        final Date nextExecutionDate = generator.next(date);
        Long diff = java.time.temporal.ChronoUnit.DAYS.between(new Timestamp(time).toLocalDateTime().toLocalDate(),
                new Timestamp(nextExecutionDate.getTime()).toLocalDateTime().toLocalDate());
        return diff != 0;
    }

}
