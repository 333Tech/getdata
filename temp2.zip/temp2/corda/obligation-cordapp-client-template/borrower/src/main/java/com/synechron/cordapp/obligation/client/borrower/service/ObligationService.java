package com.synechron.cordapp.obligation.client.borrower.service;

import java.util.List;
import java.util.Map;
import java.util.concurrent.ExecutionException;

import com.synechron.cordapp.obligation.client.base.model.response.Obligation;
import com.synechron.cordapp.obligation.client.base.model.response.PartyResponseModel;
import com.synechron.cordapp.obligation.client.borrower.model.request.IssueObligation;
import com.synechron.cordapp.obligation.client.borrower.model.request.SettleObligation;

import net.corda.core.crypto.SecureHash;

public interface ObligationService {
    /**
     * Issue Obligation.
     *
     * @param issueObligation
     * @return transaction id.
     * @throws InterruptedException
     * @throws ExecutionException
     */
    SecureHash issueObligation(IssueObligation issueObligation) throws InterruptedException, ExecutionException;

    /**
     * Settle obligation.
     * 
     * @param settleObligation
     * @return transaction id.
     * @throws InterruptedException
     * @throws ExecutionException
     */
    SecureHash settleObligation(SettleObligation settleObligation) throws InterruptedException, ExecutionException;

    /**
     * Get all Obligation state on the ledger.
     * 
     * @return list of Obligation state.
     */
    Map<String, Object> getObligations(Integer page);

    /**
     * Get lender parties from the network
     *
     * @return list of Parties.
     */
    List<PartyResponseModel> getLenderParties();

    /**
     * Set the network time.
     *
     * @param time
     * @return transaction id.
     * @throws InterruptedException
     * @throws ExecutionException
     */
    SecureHash setNetworkTime(Long time) throws InterruptedException, ExecutionException;

    /**
     * Reset the network time.
     *
     * @return transaction id.
     * @throws InterruptedException
     * @throws ExecutionException
     */
    SecureHash resetNetworkTime() throws InterruptedException, ExecutionException;

}
