package com.synechron.cordapp.obligation.client.borrower.service;

import java.util.Currency;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ExecutionException;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.util.Pair;
import org.springframework.stereotype.Service;

import com.synechron.cordapp.obligation.client.base.model.response.Obligation;
import com.synechron.cordapp.obligation.client.base.model.response.PartyResponseModel;
import com.synechron.cordapp.obligation.client.base.service.BaseService;
import com.synechron.cordapp.obligation.client.base.util.CommonUtils;
import com.synechron.cordapp.obligation.client.borrower.dao.ObligationDao;
import com.synechron.cordapp.obligation.client.borrower.model.request.IssueObligation;
import com.synechron.cordapp.obligation.client.borrower.model.request.SettleObligation;

import net.corda.core.contracts.Amount;
import net.corda.core.contracts.UniqueIdentifier;
import net.corda.core.crypto.SecureHash;
import net.corda.core.identity.Party;

@Service("obligationServiceBorrower")
public class ObligationServiceImpl implements ObligationService, Runnable {

    @Autowired
    private ObligationDao obligationDao;
    @Autowired
    private BaseService baseService;

    /**
     * {@inheritDoc}
     */
    @Override
    public SecureHash issueObligation(IssueObligation issueObligation) throws InterruptedException, ExecutionException {
        Party lender = baseService.getParty(issueObligation.getLender());
        Amount amount = Amount.fromDecimal(issueObligation.getAmount(), Currency.getInstance(issueObligation.getCurrency()));
        SecureHash secureHash = obligationDao.issueObligation(amount, lender, issueObligation.isAnonymous());
        return secureHash;
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public SecureHash settleObligation(SettleObligation settleObligation) throws InterruptedException, ExecutionException {
        UniqueIdentifier uniqueIdentifier = CommonUtils.toUniqueIdentifier(settleObligation.getLinearId());
        Amount amount = Amount.fromDecimal(settleObligation.getAmount(), Currency.getInstance(settleObligation.getCurrency()));
        return obligationDao.settleObligation(uniqueIdentifier, amount, settleObligation.isAnonymous());
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public Map<String, Object> getObligations(Integer page) {
      //  Pair<List<com.synechron.cordapp.obligation.state.Obligation>, Long> dataAndPageCount = obligationDao.getObligations(page);
        //List<Obligation> obligationModels = Obligation.getObligations(dataAndPageCount.getFirst(), baseService);
        Map<String, Object> obligationsAndPageCount = new HashMap<>();
//        obligationsAndPageCount.put("obligations", obligationModels);
//        obligationsAndPageCount.put("totalPages", dataAndPageCount.getSecond());
        return obligationsAndPageCount;
    }

    @Override
    public void run() {
        // TODO Implement business logic to be executed by scheduler.
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public List<PartyResponseModel> getLenderParties() {
        List<PartyResponseModel> partyResponseModels = PartyResponseModel.getPartyList(obligationDao.getLenderParties());
        return partyResponseModels;
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public SecureHash setNetworkTime(Long time) throws InterruptedException, ExecutionException {
        SecureHash secureHash = obligationDao.setNetworkTime(time);
        return secureHash;
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public SecureHash resetNetworkTime() throws InterruptedException, ExecutionException {
        SecureHash secureHash = obligationDao.resetNetworkTime();
        return secureHash;
    }
}
