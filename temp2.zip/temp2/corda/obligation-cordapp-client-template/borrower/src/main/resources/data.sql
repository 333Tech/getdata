INSERT INTO USER (ID, USERNAME, PASSWORD, FIRSTNAME, LASTNAME, EMAIL, ENABLED, LASTPASSWORDRESETDATE) VALUES (1, 'admin', '$2a$08$lDnHPz7eUkSi6ao14Twuau08mzhWrL4kyZGGU5xfiGALO/Vxd5DOi', 'admin', 'admin', 'admin@admin.com', 1, PARSEDATETIME('01-01-2016', 'dd-MM-yyyy'));
INSERT INTO USER (ID, USERNAME, PASSWORD, FIRSTNAME, LASTNAME, EMAIL, ENABLED, LASTPASSWORDRESETDATE) VALUES (2, 'user', '$2a$10$S5EO4IwacoT7kSGnSesq6uqrF9dvHgphQWmNTa1FdECqw69ZDRW2C', 'user', 'user', 'enabled@user.com', 1, PARSEDATETIME('01-01-2016','dd-MM-yyyy'));
INSERT INTO USER (ID, USERNAME, PASSWORD, FIRSTNAME, LASTNAME, EMAIL, ENABLED, LASTPASSWORDRESETDATE) VALUES (3, 'disabled', '$2a$08$UkVvwpULis18S19S5pZFn.YHPZt3oaqHZnDwqbCW9pft6uFtkXKDC', 'disabled', 'disabled', 'disabled@user.com', 0, PARSEDATETIME('01-01-2016','dd-MM-yyyy'));

INSERT INTO AUTHORITY (ID, NAME) VALUES (1, 'ROLE_USER');
INSERT INTO AUTHORITY (ID, NAME) VALUES (2, 'ROLE_ADMIN');

INSERT INTO USER_AUTHORITY (USER_ID, AUTHORITY_ID) VALUES (1, 1);
INSERT INTO USER_AUTHORITY (USER_ID, AUTHORITY_ID) VALUES (1, 2);
INSERT INTO USER_AUTHORITY (USER_ID, AUTHORITY_ID) VALUES (2, 1);
INSERT INTO USER_AUTHORITY (USER_ID, AUTHORITY_ID) VALUES (3, 1);

insert into Party(ID,NAME,URI,TYPE,COMMONNAME)values(1,'O=BorrowerA,L=New York,C=US','http://localhost','Borrower','Borrower A');
insert into Party(ID,NAME,URI,TYPE,COMMONNAME)values(2,'O=BorrowerB,L=New York,C=US','http://localhost','Borrower','Borrower B');
insert into Party(ID,NAME,URI,TYPE,COMMONNAME)values(3,'O=BorrowerC,L=New York,C=US','http://localhost','Borrower','Borrower C');
insert into Party(ID,NAME,URI,TYPE,COMMONNAME)values(4,'O=LenderA,L=New York,C=US','http://localhost','Lender','Lender A');
insert into Party(ID,NAME,URI,TYPE,COMMONNAME)values(5,'O=LenderB,L=New York,C=US','http://localhost','Lender','Lender B');
insert into Party(ID,NAME,URI,TYPE,COMMONNAME)values(6,'O=LenderC,L=New York,C=US','http://localhost','Lender','Lender C');
