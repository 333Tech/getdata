package com.synechron.cordapp.obligation.client;

import java.math.BigDecimal;
import java.security.PublicKey;
import java.util.*;
import java.util.concurrent.ExecutionException;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mockito;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.boot.test.web.client.TestRestTemplate;
import org.springframework.data.util.Pair;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.test.context.junit4.SpringRunner;

import com.synechron.cordapp.obligation.client.base.dao.BaseDao;
import com.synechron.cordapp.obligation.client.base.model.response.Obligation;
import com.synechron.cordapp.obligation.client.borrower.dao.ObligationDao;
import com.synechron.cordapp.obligation.client.borrower.model.request.IssueObligation;

import net.corda.core.contracts.Amount;
import net.corda.core.contracts.UniqueIdentifier;
import net.corda.core.crypto.SecureHash;
import net.corda.core.identity.CordaX500Name;
import net.corda.core.identity.Party;

@RunWith(SpringRunner.class)
@SpringBootTest(classes = BorrowerApplication.class, webEnvironment = SpringBootTest.WebEnvironment.RANDOM_PORT)
public class BorrowerIntegrationTest {
    @MockBean
    private ObligationDao obligationDao;
    @MockBean
    private BaseDao baseDao;

    private static final String PARTYA = "PartyA";
    private static final String PARTYB = "PartyB";

    @Autowired
    TestRestTemplate restTemplate;

    @Test
    public void testGetObligations() {
        Obligation obligation = new Obligation();
        obligation.setAmount(BigDecimal.valueOf(2000));
        obligation.setBorrower(PARTYA);
        obligation.setCurrency("USD");
        obligation.setLender(PARTYB);
        obligation.setPaid(BigDecimal.valueOf(500));
        obligation.setLinearId("1_fcdfade0-dfc6-44e4-bae4-ef36c5eadae8");

        Map<String, Object> obligations = new HashMap<>();
        obligations.put("obligations", obligation);
        obligations.put("totalPages", 1);

        Mockito.when(obligationDao.getObligations(1)).thenReturn(getObligations());
        ResponseEntity<String> response = restTemplate.getForEntity("/borrower/obligation/obligations", String.class);

        assert (response.getStatusCode() == HttpStatus.OK);

    }

    @Test
    public void testIssueObligation() throws InterruptedException, ExecutionException {
        IssueObligation issueObligation = new IssueObligation();
        issueObligation.setAmount(BigDecimal.valueOf(2000));
        issueObligation.setLender(PARTYB);
        issueObligation.setCurrency("USD");
        issueObligation.setAnonymous(true);

        PublicKey publicKey = Mockito.mock(PublicKey.class);
        Party lenderParty = new Party(new CordaX500Name(PARTYB, "New York", "US"), publicKey);

        Mockito.when(obligationDao.issueObligation(Amount.parseCurrency("$2000"), lenderParty, true)).thenReturn(SecureHash.randomSHA256());
        ResponseEntity<SecureHash> response = restTemplate.postForEntity("/borrower/obligation/issue-obligation", issueObligation,
                SecureHash.class);

        assert (response.getStatusCode() == HttpStatus.CREATED);
    }

    private Pair getObligations() {
        PublicKey publicKey = Mockito.mock(PublicKey.class);
        Party borrowerParty = new Party(new CordaX500Name(PARTYA, "London", "GB"), publicKey);
        Party lenderParty = new Party(new CordaX500Name(PARTYB, "New York", "US"), publicKey);

        List<com.synechron.cordapp.obligation.state.Obligation> obligationsStateList = new ArrayList<>();
        org.springframework.data.util.Pair<List<com.synechron.cordapp.obligation.state.Obligation>, Long> obligationsStates;

        com.synechron.cordapp.obligation.state.Obligation obligationState = new com.synechron.cordapp.obligation.state.Obligation(
                Amount.parseCurrency("$2000"), lenderParty, borrowerParty, Amount.parseCurrency("$500"),
                new UniqueIdentifier("1", UUID.randomUUID()));

        obligationsStateList.add(obligationState);
        obligationsStates = Pair.of(obligationsStateList, 1L);
        return obligationsStates;
    }

}
