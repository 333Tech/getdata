package com.synechron.cordapp.obligation.client.Borrower.controller;

import static org.mockito.Mockito.when;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

import java.math.BigDecimal;
import java.util.HashMap;
import java.util.Map;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.MediaType;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.request.MockMvcRequestBuilders;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.synechron.cordapp.obligation.client.base.service.BaseService;
import com.synechron.cordapp.obligation.client.borrower.controller.BorrowerApiController;
import com.synechron.cordapp.obligation.client.borrower.model.request.IssueObligation;
import com.synechron.cordapp.obligation.client.borrower.model.request.SettleObligation;
import com.synechron.cordapp.obligation.client.borrower.service.ObligationService;

@RunWith(SpringRunner.class)
@WebMvcTest(value = BorrowerApiController.class, secure = false)
public class BorrowerApiControllerTests {

    @InjectMocks
    private BorrowerApiController borrowerApiController;
    @Autowired
    private MockMvc mvc;
    @MockBean
    private ObligationService obligationService;
    @MockBean
    private BaseService baseService;
    @Autowired
    ObjectMapper objectMapper;

    IssueObligation issueObligation;
    SettleObligation settleObligation;

    @Before
    public void setup() {

        issueObligation = new IssueObligation();
        issueObligation.setAmount(BigDecimal.valueOf(1000));
        issueObligation.setCurrency("USD");
        issueObligation.setLender("PartyB");
        issueObligation.setAnonymous(true);

        settleObligation = new SettleObligation();
        settleObligation.setAmount(BigDecimal.valueOf(500));
        settleObligation.setCurrency("USD");
        settleObligation.setAnonymous(true);

    }

    @Test
    public void testGetNodeName() throws Exception {
        String partyName = "PartyA";
        when(baseService.getNodeName()).thenReturn(partyName);

        mvc.perform(MockMvcRequestBuilders.get("/borrower/obligation/name").contentType(MediaType.APPLICATION_JSON))
                .andExpect(status().isOk());
    }

    @Test
    public void testIssueObligation() throws Exception {
        mvc.perform(MockMvcRequestBuilders.post("/borrower/obligation/issue-obligation").contentType(MediaType.APPLICATION_JSON_UTF8)
                .content(objectMapper.writeValueAsBytes(issueObligation))).andExpect(status().isCreated());
    }

    @Test
    public void testGetObligations() throws Exception {
        Map<String, Object> obligationMap = new HashMap<>();

        when(obligationService.getObligations(1)).thenReturn(obligationMap);

        mvc.perform(MockMvcRequestBuilders.get("/borrower/obligation/obligations").contentType(MediaType.APPLICATION_JSON))
                .andExpect(status().isOk());
    }

    @Test
    public void testSettleObligation() throws Exception {

        mvc.perform(MockMvcRequestBuilders.post("/borrower/obligation/settle-obligation").contentType(MediaType.APPLICATION_JSON_UTF8)
                .content(objectMapper.writeValueAsBytes(settleObligation))).andExpect(status().isCreated());
    }

}
