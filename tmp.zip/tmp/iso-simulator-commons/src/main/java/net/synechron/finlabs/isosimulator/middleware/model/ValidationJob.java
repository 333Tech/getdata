package net.synechron.finlabs.isosimulator.middleware.model;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.ToString;

@Data
@ToString
@NoArgsConstructor
@AllArgsConstructor
public class ValidationJob {
	private String runId;
	private String objectId;
	private String inputType;
	private String msgTypeId;
	private String responseMsgId;
	private String xsdObjectId;
	private String xslObjectId;
}
