package net.synechron.finlabs.isosimulator.middleware.model;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.ToString;

@Data
@ToString
@NoArgsConstructor
@AllArgsConstructor
public class ManualEntryXmlGenJob {
	private String runId;
	private String inputObjectId;
	private String msgId;
	private String msgTypeId;
}
