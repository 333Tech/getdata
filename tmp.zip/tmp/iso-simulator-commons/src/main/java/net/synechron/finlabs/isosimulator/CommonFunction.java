package net.synechron.finlabs.isosimulator;

import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.OffsetDateTime;
import java.time.ZoneOffset;
import java.util.Date;
import java.util.List;
import java.util.UUID;

import org.springframework.stereotype.Component;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.core.json.JsonReadFeature;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.ObjectWriter;
import com.fasterxml.jackson.databind.json.JsonMapper;

import net.synechron.finlabs.isosimulator.middleware.model.MessageDataField;

@Component
public class CommonFunction {

	public String msgDataFieldArrayIntoJsonString(List<MessageDataField> msgDataFields) throws JsonProcessingException {
		ObjectWriter ow = new ObjectMapper().writer().withDefaultPrettyPrinter();
		return ow.writeValueAsString(msgDataFields);
	}

	public MessageDataField[] jsonStringIntoMsgDataField(String jsonMsgDataField) throws JsonProcessingException {
		ObjectMapper mapper = JsonMapper.builder().enable(JsonReadFeature.ALLOW_BACKSLASH_ESCAPING_ANY_CHARACTER)
				.build();
		return mapper.readValue(jsonMsgDataField, MessageDataField[].class);

	}

	public void getAutoGenerateFields(List<MessageDataField> messageDataFields) {
		SimpleDateFormat sdf;
		ZoneOffset offset;
		LocalDateTime localDateTime;
		OffsetDateTime zonedDateTime;
		LocalDate localDate;
		for (int i = 0; i < messageDataFields.size(); i++) {
			MessageDataField msgDataObj = messageDataFields.get(i);
			if (msgDataObj.getIsAutoGenerate()) {
				if (msgDataObj.getFieldDataRepresentation().contains("string")) {
					msgDataObj.setValue((UUID.randomUUID()).toString().replace("-", ""));
				}
				if (msgDataObj.getFieldDataRepresentation().equalsIgnoreCase("date")) {
					if (msgDataObj.getDataKey() != null) {
						offset = ZoneOffset.of(msgDataObj.getDataKey());
						if (msgDataObj.getPatternType().equalsIgnoreCase("yyyy-MM-dd")) {
							localDate = LocalDate.now(offset);
							msgDataObj.setValue(localDate.toString());
						} else {
							localDateTime = LocalDateTime.now(offset);
							zonedDateTime = OffsetDateTime.of(localDateTime, offset);
							msgDataObj.setValue(zonedDateTime.toString());
						}
					} else {
						sdf = new SimpleDateFormat(msgDataObj.getPatternType());
						msgDataObj.setValue(sdf.format(new Date()));
					}
				}
				if (msgDataObj.getTagName().equalsIgnoreCase("UETR")) {
					msgDataObj.setValue(UUID.randomUUID().toString());
				}
			}
		}
	}
}
