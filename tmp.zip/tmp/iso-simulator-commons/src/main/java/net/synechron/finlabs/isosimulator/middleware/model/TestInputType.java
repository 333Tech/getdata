package net.synechron.finlabs.isosimulator.middleware.model;

public enum TestInputType {
	XML, CSV, JSON
}
