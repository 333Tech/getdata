package net.synechron.finlabs.isosimulator;

public enum PaymentType {
	Inbound,
	Outbound
}
