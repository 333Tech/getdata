package net.synechron.finlabs.isosimulator;

public enum TestOutputStatus {
	Pass,
	Fail,
	InvalidXML
}
