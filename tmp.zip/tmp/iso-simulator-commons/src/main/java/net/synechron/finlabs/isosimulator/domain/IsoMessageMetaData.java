package net.synechron.finlabs.isosimulator.domain;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.ToString;

@Entity
@Table(name = "iso_message_metadata")
@Data
@ToString
@NoArgsConstructor
@AllArgsConstructor
public class IsoMessageMetaData implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	//	@GeneratedValue(strategy = GenerationType.AUTO)
	@Column(name = "id")
	private String id;
	@Column(name = "name")
	private String name;
	@Column(name = "version")
	private String version;
	@Column(name = "xmlns")
	private String xmlns;
	@Column(name = "description")
	private String description;
	@Column(name = "xsd_object_id")
	private String xsdObjectId;
	@Column(name = "xsl_object_id")
	private String xslObjectId;
//	@Column(name = "xml_object_id")
//	private String xmlObjectId;
	@Column(name="inbound_msg_id")
	private String inboundMsgId;
	@Column(name="msg_type")
	private String msgType;
	@Column(name="payment_msg_id_xpath")
	private String paymentMsgIdXpath;	
//	@OneToOne(cascade = {CascadeType.ALL},mappedBy = "responseMsgId")
//	private ResponseMessage respMsgId;
//	
//	@OneToOne(cascade = {CascadeType.ALL},mappedBy = "initiatorMsgId")
//	private ResponseMessage respinitid;
}
