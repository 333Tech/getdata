package net.synechron.finlabs.isosimulator.middleware.model;

import javax.xml.bind.annotation.XmlRootElement;

import com.fasterxml.jackson.annotation.JsonProperty;

import java.io.Serializable;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;

@XmlRootElement(name = "MessageDataField")
@XmlAccessorType(XmlAccessType.FIELD)
public class MessageDataField implements Serializable {

	private static final long serialVersionUID = 1L;
	private String fieldDescription;
	private String tagName;
	private String fieldMinLength;
	private String fieldMaxLength;
	private String patternType;
	private String fieldDataRepresentation;
	private String dataKey;
	private String sequenceNum;
	private String groupName;
	private String parentGroupName;
	private String xPath;
	private String value;
	private String isValid;
	private boolean isAutoGenerate;
	private boolean isMandatory;
	private String info;
	
	@JsonProperty(value = "isMandatory")
	public boolean isMandatory() {
		return isMandatory;
	}

	public void setMandatory(boolean isMandatory) {
		this.isMandatory = isMandatory;
	}

	public String getInfo() {
		return info;
	}

	public void setInfo(String info) {
		this.info = info;
	}

	public String getFieldDescription() {
		return fieldDescription;
	}

	public void setFieldDescription(String fieldDescription) {
		this.fieldDescription = fieldDescription;
	}

	public String getTagName() {
		return tagName;
	}

	public void setTagName(String tagName) {
		this.tagName = tagName;
	}

	public String getFieldMinLength() {
		return fieldMinLength;
	}

	public void setFieldMinLength(String fieldMinLength) {
		this.fieldMinLength = fieldMinLength;
	}

	public String getFieldMaxLength() {
		return fieldMaxLength;
	}

	public void setFieldMaxLength(String fieldMaxLength) {
		this.fieldMaxLength = fieldMaxLength;
	}

	public String getPatternType() {
		return patternType;
	}

	public void setPatternType(String patternType) {
		this.patternType = patternType;
	}

	public String getFieldDataRepresentation() {
		return fieldDataRepresentation;
	}

	public void setFieldDataRepresentation(String fieldDataRepresentation) {
		this.fieldDataRepresentation = fieldDataRepresentation;
	}

	public String getDataKey() {
		return dataKey;
	}

	public void setDataKey(String dataKey) {
		this.dataKey = dataKey;
	}

	public String getSequenceNum() {
		return sequenceNum;
	}

	public void setSequenceNum(String sequenceNum) {
		this.sequenceNum = sequenceNum;
	}

	public String getGroupName() {
		return groupName;
	}

	public void setGroupName(String groupName) {
		this.groupName = groupName;
	}

	public String getParentGroupName() {
		return parentGroupName;
	}

	public void setParentGroupName(String parentGroupName) {
		this.parentGroupName = parentGroupName;
	}

	public String getxPath() {
		return xPath;
	}

	public void setxPath(String xPath) {
		this.xPath = xPath;
	}

	public String getValue() {
		return value.replaceAll("\\n\\t\\t\\t", "");
	}

	public void setValue(String value) {
		this.value = value;
	}

	public String getIsValid() {
		return isValid;
	}

	public void setIsValid(String isValid) {
		this.isValid = isValid;
	}

	public static long getSerialversionuid() {
		return serialVersionUID;
	}

	@Override
	public String toString() {
		return "MessageDataField [fieldDescription=" + fieldDescription + ", tagName=" + tagName + ", fieldMinLength="
				+ fieldMinLength + ", fieldMaxLength=" + fieldMaxLength + ", patternType=" + patternType
				+ ", fieldDataRepresentation=" + fieldDataRepresentation + ", dataKey=" + dataKey + ", sequenceNum="
				+ sequenceNum + ", groupName=" + groupName + ", parentGroupName=" + parentGroupName + ", xPath=" + xPath
				+ ", value=" + value + ", isValid=" + isValid + ", isMandatory=" + isMandatory + ", info=" + info + " , isAutoGenerate=" + isAutoGenerate + "]";
	}

	public boolean getIsAutoGenerate() {
		return isAutoGenerate;
	}

	public void setIsAutoGenerate(boolean isAutoGenerate) {
		this.isAutoGenerate = isAutoGenerate;
	}

}
