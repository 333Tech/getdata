package net.synechron.finlabs.isosimulator.middleware.model;

import java.util.List;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.ToString;

@Data
@ToString
@NoArgsConstructor
@AllArgsConstructor
public class OutboundMassageGenerationJob {

	private String runId;
	private String inputObjectId;
	private String msgId;
	private String msgTypeId;
	private String outObjectId;
	private String responseMsgId;
}
