package net.synechron.finlabs.isosimulator.middleware.model;

public enum BusinessValidationStatus {
	Fail, Pass;
}
