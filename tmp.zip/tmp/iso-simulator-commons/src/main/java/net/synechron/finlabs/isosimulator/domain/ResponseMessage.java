package net.synechron.finlabs.isosimulator.domain;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;
import javax.persistence.Table;
import javax.persistence.UniqueConstraint;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.ToString;


/**
 * @author Amol.Mandlik
 *
 */

@Entity
//@Table(name = "response_message",uniqueConstraints = { 
//		@UniqueConstraint(name = "UniqueResMsgIdAndCode", 
//				columnNames = { "response_msgid", "code" }) })
@Table(name = "response_message")
@Data
@ToString
@NoArgsConstructor
@AllArgsConstructor
public class ResponseMessage implements Serializable {

	private static final long serialVersionUID = 1L;
	
	@Id
	@Column(name = "id")
	private String id;
	// TODO We should define the unique composite key on columns [responseMsgId, code].
//	@OneToOne(targetEntity = IsoMessageMetaData.class)
//	@JoinColumn(name ="response_msgid", referencedColumnName="id")
	@Column(name="response_msgid")
	private String responseMsgId;
	@Column(name = "code")
	private String code;
	@Column(name = "name")
	private String name;
	@Column(name = "definition")
	private String definition;
//	@OneToOne(targetEntity = IsoMessageMetaData.class)
//	@JoinColumn(name ="initiator_msgid",referencedColumnName="id")
	@Column(name="initiator_msgid")
	private String initiatorMsgId;
	
}
