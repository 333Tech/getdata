package net.synechron.finlabs.isosimulator.middleware.model;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.ToString;

@Data
@ToString
@NoArgsConstructor
@AllArgsConstructor
public class ValidationErrorData {
	private String xPath;
	private String xmlElement;
	private String fieldName;
	private String data;
	private String errorMessage;
	
	public String getxPath() {
		return xPath;
	}
	public void setxPath(String xPath) {
		this.xPath = xPath;
	}
}
