package net.synechron.finlabs.isosimulator.domain;

import java.io.Serializable;
import java.time.LocalDateTime;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.ToString;

@Entity
@Table(name = "sample_msg_data")
@Data
@ToString
@NoArgsConstructor
@AllArgsConstructor
public class SampleMsgData implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	@Column(name = "id")
	private Long id;
	@Column(name = "xml_object_id")
	private String xmlObjectId;
	@Column(name = "is_valid")
	private boolean isValid;
	@Column(name = "description")
	private String description;
	@Column(name = "iso_msg_id")
	private String isoMsgId;
	@Column(name = "dateModified")
	private LocalDateTime dateModified;
	@Column(name = "size")
	private String size;
	public SampleMsgData(String xmlObjectId,boolean isValid, String description, String isoMsgId, LocalDateTime dateModified,
			String size) {
		super();
		this.xmlObjectId = xmlObjectId;
		this.isValid = isValid;
		this.description = description;
		this.isoMsgId = isoMsgId;
		this.dateModified = dateModified;
		this.size = size;
	}
}
