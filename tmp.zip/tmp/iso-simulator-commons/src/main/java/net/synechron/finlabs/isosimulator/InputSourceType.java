package net.synechron.finlabs.isosimulator;

public enum InputSourceType {
	ManualEntry,	
	FileUpload
}
