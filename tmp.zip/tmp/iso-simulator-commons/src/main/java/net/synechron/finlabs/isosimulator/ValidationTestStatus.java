package net.synechron.finlabs.isosimulator;

public enum ValidationTestStatus {
	InProgress,
	Partial,
	Failed,
	Processed,
	Draft
}
