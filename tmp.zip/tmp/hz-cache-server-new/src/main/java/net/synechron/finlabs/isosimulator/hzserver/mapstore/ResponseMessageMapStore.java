package net.synechron.finlabs.isosimulator.hzserver.mapstore;

import java.util.ArrayList;
import java.util.Collection;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.Properties;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.autoconfigure.domain.EntityScan;
import org.springframework.stereotype.Component;

import com.hazelcast.core.HazelcastInstance;
import com.hazelcast.core.MapLoaderLifecycleSupport;
import com.hazelcast.core.MapStore;
import com.hazelcast.spring.context.SpringAware;

import net.synechron.finlabs.isosimulator.domain.ResponseMessage;
import net.synechron.finlabs.isosimulator.hzserver.repository.ResponseMessageDao;

/**
 * @author Amol.Mandlik
 *
 */

@SpringAware
@Component
@EntityScan("net.synechron.finlabs.isosimulator.domain")
public class ResponseMessageMapStore implements MapStore<String, ResponseMessage>, MapLoaderLifecycleSupport {

	@Autowired
	ResponseMessageDao responseMessageDao;

	@Override
	public ResponseMessage load(String key) {
		Optional<ResponseMessage> respMsgObj = responseMessageDao.findById(key);
		return respMsgObj.isPresent() ? respMsgObj.get() : null;
	}

	@Override
	public Map<String, ResponseMessage> loadAll(Collection<String> keys) {
		Map<String, ResponseMessage> dataMap = new HashMap<>();
		for (String key : keys) {
			ResponseMessage respMsgObj = this.load(key);
			if (respMsgObj != null)
				dataMap.put(key, respMsgObj);
		}
		return dataMap;
	}

	@Override
	public Iterable<String> loadAllKeys() {
		Map<String, ResponseMessage> respMsgObj = new HashMap<>();
		List<ResponseMessage> respMsgObjList = responseMessageDao.findAll();
		for (ResponseMessage responseMessage : respMsgObjList) {
			respMsgObj.put(responseMessage.getId(), responseMessage);
		}
		return respMsgObj.keySet();
	}

	@Override
	public void init(HazelcastInstance hazelcastInstance, Properties properties, String mapName) {
		hazelcastInstance.getConfig().getManagedContext().initialize(this);
	}

	@Override
	public void destroy() {
		// kept it empty as there is no logic to execute on destroy
	}

	@Override
	public void store(String key, ResponseMessage value) {
		responseMessageDao.save(value);
	}

	@Override
	public void storeAll(Map<String, ResponseMessage> map) {
		responseMessageDao.saveAll(new ArrayList<>(map.values()));
	}

	@Override
	public void delete(String key) {
		responseMessageDao.deleteById(key);
	}

	@Override
	public void deleteAll(Collection<String> keys) {
		keys.forEach(responseMessageDao::deleteById);
	}

}
