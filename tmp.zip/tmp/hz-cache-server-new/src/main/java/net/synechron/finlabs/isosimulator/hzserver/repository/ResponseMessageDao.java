package net.synechron.finlabs.isosimulator.hzserver.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import net.synechron.finlabs.isosimulator.domain.ResponseMessage;

/**
 * @author Amol.Mandlik
 *
 */

@Repository
public interface ResponseMessageDao extends JpaRepository<ResponseMessage, String>{

}
