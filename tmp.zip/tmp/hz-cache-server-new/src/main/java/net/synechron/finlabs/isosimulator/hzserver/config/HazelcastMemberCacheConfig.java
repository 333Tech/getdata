package net.synechron.finlabs.isosimulator.hzserver.config;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import com.hazelcast.config.Config;
import com.hazelcast.config.EvictionPolicy;
import com.hazelcast.config.ManagementCenterConfig;
import com.hazelcast.config.MapConfig;
import com.hazelcast.config.MapStoreConfig;
import com.hazelcast.config.MapStoreConfig.InitialLoadMode;
import com.hazelcast.config.MaxSizeConfig;
import com.hazelcast.config.cp.CPSubsystemConfig;
import com.hazelcast.config.cp.FencedLockConfig;
import com.hazelcast.core.Hazelcast;
import com.hazelcast.core.HazelcastInstance;
import com.hazelcast.spring.context.SpringManagedContext;
import net.synechron.finlabs.isosimulator.hzserver.mapstore.IsoMessageMetaDataMapStore;
import net.synechron.finlabs.isosimulator.hzserver.mapstore.ReferenceDataMapStore;
import net.synechron.finlabs.isosimulator.hzserver.mapstore.ResponseMessageMapStore;

@Configuration
public class HazelcastMemberCacheConfig {

	@Value(value = "${hazelcast.server.url}")
	String url;

	@Value(value = "${hazelcast.config.liveseconds}")
	String liveseconds;

	@Value(value = "${hazelcast.config.maxsize}")
	String maxsize;

	@Value(value = "${hazelcast.config.backupcount}")
	String backupcount;

	@Value(value = "${hazelcast.config.isomessages}")
	String isoMessages;
	
	@Value(value = "${hazelcast.config.responseMessage}")
	private String responseMessage;
	
	@Value(value = "${hazelcast.config.referenceData}")
	private String referenceData;

	@Bean
	public Config hazelcastConfig() {

		ManagementCenterConfig manCenterCfg = new ManagementCenterConfig();
		manCenterCfg.setEnabled(true).setUrl(url);

		IsoMessageMetaDataMapStore metaDataMapstoreObj = new IsoMessageMetaDataMapStore();		
		MapStoreConfig IsoMessageMetaDataMapStoreConfig = new MapStoreConfig();
		IsoMessageMetaDataMapStoreConfig.setEnabled(true)
				.setClassName("net.synechron.finlabs.isosimulator.hzserver.mapstore.IsoMessageMetaDataMapStore");
		IsoMessageMetaDataMapStoreConfig.setInitialLoadMode(InitialLoadMode.EAGER);
		IsoMessageMetaDataMapStoreConfig.setImplementation(metaDataMapstoreObj);
		IsoMessageMetaDataMapStoreConfig.setWriteDelaySeconds(0);
		
		ResponseMessageMapStore resMsgMapStroreObj = new ResponseMessageMapStore();
		MapStoreConfig responseMessageMapStoreConfig = new MapStoreConfig();
		responseMessageMapStoreConfig.setEnabled(true)
				.setClassName("net.synechron.finlabs.isosimulator.hzserver.mapstore.ResponseMessageMapStore");
		responseMessageMapStoreConfig.setInitialLoadMode(InitialLoadMode.EAGER);
		responseMessageMapStoreConfig.setImplementation(resMsgMapStroreObj);
		responseMessageMapStoreConfig.setWriteDelaySeconds(0);

		//ReferenceData Start
		ReferenceDataMapStore referenceDataMapStore = new ReferenceDataMapStore();
		MapStoreConfig referenceDataMapStoreConfig = new MapStoreConfig();
		referenceDataMapStoreConfig.setEnabled(true)
				.setClassName("net.synechron.finlabs.isosimulator.hzserver.mapstore.ReferenceDataMapStore");
		referenceDataMapStoreConfig.setInitialLoadMode(InitialLoadMode.EAGER);
		referenceDataMapStoreConfig.setImplementation(referenceDataMapStore);
		//ReferenceData End		
		
		CPSubsystemConfig cpSubsystemConfig = new CPSubsystemConfig();
		cpSubsystemConfig.setCPMemberCount(3);
		cpSubsystemConfig.addLockConfig(new FencedLockConfig("non-reentrant-lock", 1));
		cpSubsystemConfig.setSessionHeartbeatIntervalSeconds(1);
		cpSubsystemConfig.setSessionTimeToLiveSeconds(5);
		cpSubsystemConfig.setMissingCPMemberAutoRemovalSeconds(10);
		
		Config config = new Config();
		config.setProperty("hazelcast.logging.type", "slf4j");
		config.setManagedContext(managedContext());
		config.setManagementCenterConfig(manCenterCfg).setCPSubsystemConfig(cpSubsystemConfig)
				.addMapConfig(new MapConfig().setName(isoMessages)
						.setMaxSizeConfig(new MaxSizeConfig(Integer.parseInt(maxsize),
								MaxSizeConfig.MaxSizePolicy.FREE_HEAP_SIZE))
						.setEvictionPolicy(EvictionPolicy.LRU).setBackupCount(Integer.parseInt(backupcount))
						.setTimeToLiveSeconds(Integer.parseInt(liveseconds))
						.setMapStoreConfig(IsoMessageMetaDataMapStoreConfig))
				.addMapConfig(new MapConfig().setName(responseMessage)
						.setMaxSizeConfig(new MaxSizeConfig(Integer.parseInt(maxsize),
								MaxSizeConfig.MaxSizePolicy.FREE_HEAP_SIZE))
						.setEvictionPolicy(EvictionPolicy.LRU).setBackupCount(Integer.parseInt(backupcount))
						.setTimeToLiveSeconds(Integer.parseInt(liveseconds))
						.setMapStoreConfig(responseMessageMapStoreConfig))
				.addMapConfig(new MapConfig().setName(referenceData)
						.setMaxSizeConfig(new MaxSizeConfig(Integer.parseInt(maxsize),
								MaxSizeConfig.MaxSizePolicy.FREE_HEAP_SIZE))
						.setEvictionPolicy(EvictionPolicy.LRU).setBackupCount(Integer.parseInt(backupcount))
						.setTimeToLiveSeconds(Integer.parseInt(liveseconds))
						.setMapStoreConfig(referenceDataMapStoreConfig));

		// Setting three more members HazelcastInstance hz1 =
		Hazelcast.newHazelcastInstance(config);
		HazelcastInstance hz2 = Hazelcast.newHazelcastInstance(config);
		HazelcastInstance hz3 = Hazelcast.newHazelcastInstance(config);
		return config;
	}

	@Bean
	public SpringManagedContext managedContext() {
		return new SpringManagedContext();
	}
}
