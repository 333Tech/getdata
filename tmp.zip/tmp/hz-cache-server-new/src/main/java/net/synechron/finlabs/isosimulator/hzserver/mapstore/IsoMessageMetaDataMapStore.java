package net.synechron.finlabs.isosimulator.hzserver.mapstore;

import com.hazelcast.core.MapLoaderLifecycleSupport;
import com.hazelcast.core.MapStore;

import java.util.ArrayList;
import java.util.Collection;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.Properties;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.autoconfigure.domain.EntityScan;
import org.springframework.stereotype.Component;

import com.hazelcast.core.HazelcastInstance;
import com.hazelcast.spring.context.SpringAware;

import net.synechron.finlabs.isosimulator.domain.IsoMessageMetaData;
import net.synechron.finlabs.isosimulator.hzserver.repository.IsoMessageMetaDataDao;

@SpringAware
@Component
@EntityScan("net.synechron.finlabs.isosimulator.domain")
public class IsoMessageMetaDataMapStore implements MapStore<String, IsoMessageMetaData>, MapLoaderLifecycleSupport {

	@Autowired
	private IsoMessageMetaDataDao isoMessageMetaDataDaoObj;

	@Override
	public IsoMessageMetaData load(String key) {
		Optional<IsoMessageMetaData> metaDataObj = isoMessageMetaDataDaoObj.findById(key);
		return metaDataObj.isPresent() ? metaDataObj.get() : null;
	}

	@Override
	public Map<String, IsoMessageMetaData> loadAll(Collection<String> keys) {
		Map<String, IsoMessageMetaData> result = new HashMap<>();
		for (String key : keys) {

			IsoMessageMetaData metaDataObj = this.load(key);
			if (metaDataObj != null) {
				result.put(key, metaDataObj);
			}
		}
		return result;
	}

	@Override
	public Iterable<String> loadAllKeys() {
		Map<String, IsoMessageMetaData> metaDataMpObj = new HashMap<>();
		List<IsoMessageMetaData> metaDataListObj = isoMessageMetaDataDaoObj.findAll();
		for (IsoMessageMetaData metaData : metaDataListObj) {
			metaDataMpObj.put(metaData.getId(), metaData);
		}
		return metaDataMpObj.keySet();
	}

	@Override
	public void store(String key, IsoMessageMetaData value) {
		isoMessageMetaDataDaoObj.save(value);

	}

	@Override
	public void storeAll(Map<String, IsoMessageMetaData> map) {
		isoMessageMetaDataDaoObj.saveAll(new ArrayList<>(map.values()));

	}

	@Override
	public void delete(String key) {
		isoMessageMetaDataDaoObj.deleteById(key);

	}

	@Override
	public void deleteAll(Collection<String> keys) {
		keys.forEach(isoMessageMetaDataDaoObj::deleteById);

	}

	@Override
	public void init(HazelcastInstance hazelcastInstance, Properties properties, String mapName) {

		hazelcastInstance.getConfig().getManagedContext().initialize(this);
	}

	@Override
	public void destroy() {
		// kept it empty as there is no logic to execute on destroy

	}

}
