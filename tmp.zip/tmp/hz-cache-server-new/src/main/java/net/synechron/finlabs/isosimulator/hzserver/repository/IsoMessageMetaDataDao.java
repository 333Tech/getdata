package net.synechron.finlabs.isosimulator.hzserver.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import net.synechron.finlabs.isosimulator.domain.IsoMessageMetaData;

@Repository
public interface IsoMessageMetaDataDao extends JpaRepository<IsoMessageMetaData, String> {
}