package net.synechron.finlabs.isosimulator.hzserver.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import net.synechron.finlabs.isosimulator.domain.ReferenceData;

@Repository
public interface ReferenceDataDao extends JpaRepository<ReferenceData, Integer> {
	
	List<ReferenceData> findByDatakey(String datakey);
	
	@Transactional
	Integer deleteByDatakey(String datakey);

}
