package net.synechron.finlabs.isosimulator.hzserver.mapstore;

import java.util.Collection;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Properties;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.autoconfigure.domain.EntityScan;
import org.springframework.stereotype.Component;

import com.hazelcast.core.HazelcastInstance;
import com.hazelcast.core.MapLoaderLifecycleSupport;
import com.hazelcast.core.MapStore;
import com.hazelcast.spring.context.SpringAware;
import net.synechron.finlabs.isosimulator.domain.ReferenceData;
import net.synechron.finlabs.isosimulator.hzserver.repository.ReferenceDataDao;

@SpringAware
@Component
@EntityScan("net.synechron.finlabs.isosimulator.domain")
public class ReferenceDataMapStore implements MapStore<String, List<ReferenceData>>, MapLoaderLifecycleSupport {

	@Autowired
	ReferenceDataDao referenceDataDao;

	@Override
	public List<ReferenceData> load(String key) {
		return referenceDataDao.findByDatakey(key);
	}

	@Override
	public Map<String, List<ReferenceData>> loadAll(Collection<String> keys) {
		Map<String, List<ReferenceData>> result = new HashMap<>();
		keys.forEach(name -> {
			List<ReferenceData> applicationComponentSettings = this.load(name);
			if (applicationComponentSettings != null)
				result.put(name, applicationComponentSettings);
		});
		return result;
	}

	@Override
	public Iterable<String> loadAllKeys() {
		Map<String, ReferenceData> referenceDatamap = new HashMap<>();
		List<ReferenceData> referenceDatalist = referenceDataDao.findAll();
		for (ReferenceData c : referenceDatalist) {
			referenceDatamap.put(c.getDatakey(), c);
		}
		return referenceDatamap.keySet();
	}

	@Override
	public void init(HazelcastInstance hazelcastInstance, Properties properties, String mapName) {
		hazelcastInstance.getConfig().getManagedContext().initialize(this);

	}

	@Override
	public void destroy() {
		// kept it empty as there is no logic to execute on destroy
	}

	@Override
	public void store(String key, List<ReferenceData> values) {
		List<ReferenceData> data = load(key);
		Map<String, List<ReferenceData>> map = new HashMap<>();
		if (data.isEmpty()) {
			map.put(key, values);
			storeAll(map);
		} else {

			if (data.get(0).getDatakey().trim().equalsIgnoreCase(values.get(0).getDatakey().trim())) {
				delete(data.get(0).getDatakey());
			}
			map.put(key, values);
			storeAll(map);
		}
	}
	
	@Override
	public void storeAll(Map<String, List<ReferenceData>> map) {
		for (Map.Entry<String, List<ReferenceData>> entry : map.entrySet()) {
			referenceDataDao.saveAll(entry.getValue());
		}
	}

	@Override
	public void delete(String datakey) {
		referenceDataDao.deleteByDatakey(datakey);	
	}

	@Override
	public void deleteAll(Collection<String> datakeys) {
		datakeys.forEach(referenceDataDao::deleteByDatakey);
	}

}
