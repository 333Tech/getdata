/**
 * Service layer beans.
 */
package net.synechron.finlabs.isosimulator.msghandler.service;
