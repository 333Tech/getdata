package net.synechron.finlabs.isosimulator.msghandler.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import net.synechron.finlabs.isosimulator.msghandler.repository.BridgeServiceDaoImpl;

@Service
public class BridgeServiceImpl implements BridgeService {

	@Autowired
	private BridgeServiceDaoImpl bridgeServiceDaoImpl;

	@Override
	public String findResponseMsgId(String msgId) {
		return bridgeServiceDaoImpl.findResponseMsgId(msgId);
	}
}
