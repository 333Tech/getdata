package net.synechron.finlabs.isosimulator.msghandler.repository;

import java.io.IOException;
import java.util.List;

import org.springframework.web.multipart.MultipartFile;

import net.synechron.finlabs.isosimulator.msghandler.domain.InboundDetailUpload;
import net.synechron.finlabs.isosimulator.msghandler.entities.ValidationTest;

public interface ValidationTestDao {
	public ValidationTest validationTestSave(InboundDetailUpload inboundDetailUpload, List<MultipartFile> testInputFiles) throws IOException;
}
