package net.synechron.finlabs.isosimulator.msghandler.config;

import org.springframework.boot.context.properties.ConfigurationProperties;

/**
 * Properties specific to Message Handler Service.
 * <p>
 * Properties are configured in the {@code application.yml} file. See
 * {@link tech.jhipster.config.JHipsterProperties} for a good example.
 */
@ConfigurationProperties(prefix = "application", ignoreUnknownFields = false)
public class ApplicationProperties {

	private final Minio minio = new Minio();
	private final RabbitMQ rabbitMq = new RabbitMQ();
	private final BridgeService bridgeService = new BridgeService();
	
	public RabbitMQ getRabbitMq() {
		return rabbitMq;
	}

	public Minio getMinio() {
		return minio;
	}
	
	public BridgeService getBridgeService() {
		return bridgeService;
	}

	public static class RabbitMQ {
		private String queueMsgValidationFailure = ApplicationDefaultMessgHandler.RabbitMQ.queueMsgValidationFailure;
		private String queueBusinessValidationOutcome = ApplicationDefaultMessgHandler.RabbitMQ.queueBusinessValidationOutcome;
		private String rkeyXmlValidationJob = ApplicationDefaultMessgHandler.RabbitMQ.rkeyXmlValidationJob;
		private String rkeyBusinessValidationResult = ApplicationDefaultMessgHandler.RabbitMQ.rkeyBusinessValidationResult;
		private String rkeyXmlValidationFailure = ApplicationDefaultMessgHandler.RabbitMQ.rkeyXmlValidationFailure;
		private String rkeyOutboundMsgResult = ApplicationDefaultMessgHandler.RabbitMQ.rkeyOutboundMsgResult;
		private String queueOutboundMsgResult = ApplicationDefaultMessgHandler.RabbitMQ.queueOutboundMsgResult;
		private String rkeyManualEntryBizValidationJob = ApplicationDefaultMessgHandler.RabbitMQ.rkeyManualEntryBizValidationJob;
		private String queueManualEntryBizValidationFailure = ApplicationDefaultMessgHandler.RabbitMQ.queueManualEntryBizValidationFailure;
		private String queueManualEntryValidationResult = ApplicationDefaultMessgHandler.RabbitMQ.queueManualEntryValidationResult;
		private String rkeyManualEntryValidationResult = ApplicationDefaultMessgHandler.RabbitMQ.rkeyManualEntryValidationResult;
		private String rkeyManualEntryBizValidationFailure = ApplicationDefaultMessgHandler.RabbitMQ.rkeyManualEntryBizValidationFailure;
		private String queueManualEntryOutboundValidationResult = ApplicationDefaultMessgHandler.RabbitMQ.queueManualEntryOutboundValidationResult;
		private String rkeyManualEntryOutboundValidationResult = ApplicationDefaultMessgHandler.RabbitMQ.rkeyManualEntryOutboundValidationResult;
		private String rkeyBridgeServiceMessagePublish = ApplicationDefaultMessgHandler.RabbitMQ.rkeyBridgeServiceMessagePublish;
		private String queueBridgeServiceMessagePublish = ApplicationDefaultMessgHandler.RabbitMQ.queueBridgeServiceMessagePublish;
		private String queueBridgeServiceInboundMsgReceive = ApplicationDefaultMessgHandler.RabbitMQ.queueBridgeServiceInboundMsgReceive;
		private String rkeyBridgeServiceInboundMsgReceive = ApplicationDefaultMessgHandler.RabbitMQ.rkeyBridgeServiceInboundMsgReceive;
		private String rkeyBridgeServiceInboundMsgProcess = ApplicationDefaultMessgHandler.RabbitMQ.rkeyBridgeServiceInboundMsgProcess;
		
		
		
		public String getQueueBridgeServiceInboundMsgReceive() {
			return queueBridgeServiceInboundMsgReceive;
		}

		public void setQueueBridgeServiceInboundMsgReceive(String queueBridgeServiceInboundMsgReceive) {
			this.queueBridgeServiceInboundMsgReceive = queueBridgeServiceInboundMsgReceive;
		}

		public String getRkeyBridgeServiceInboundMsgReceive() {
			return rkeyBridgeServiceInboundMsgReceive;
		}

		public void setRkeyBridgeServiceInboundMsgReceive(String rkeyBridgeServiceInboundMsgReceive) {
			this.rkeyBridgeServiceInboundMsgReceive = rkeyBridgeServiceInboundMsgReceive;
		}

		public String getRkeyBridgeServiceInboundMsgProcess() {
			return rkeyBridgeServiceInboundMsgProcess;
		}

		public void setRkeyBridgeServiceInboundMsgProcess(String rkeyBridgeServiceInboundMsgProcess) {
			this.rkeyBridgeServiceInboundMsgProcess = rkeyBridgeServiceInboundMsgProcess;
		}

		public String getRkeyBridgeServiceMessagePublish() {
			return rkeyBridgeServiceMessagePublish;
		}

		public void setRkeyBridgeServiceMessagePublish(String rkeyBridgeServiceMessagePublish) {
			this.rkeyBridgeServiceMessagePublish = rkeyBridgeServiceMessagePublish;
		}

		public String getQueueBridgeServiceMessagePublish() {
			return queueBridgeServiceMessagePublish;
		}

		public void setQueueBridgeServiceMessagePublish(String queueBridgeServiceMessagePublish) {
			this.queueBridgeServiceMessagePublish = queueBridgeServiceMessagePublish;
		}

		public String getRkeyManualEntryOutboundValidationResult() {
			return rkeyManualEntryOutboundValidationResult;
		}

		public void setRkeyManualEntryOutboundValidationResult(String rkeyManualEntryOutboundValidationResult) {
			this.rkeyManualEntryOutboundValidationResult = rkeyManualEntryOutboundValidationResult;
		}

		public String getQueueManualEntryOutboundValidationResult() {
			return queueManualEntryOutboundValidationResult;
		}

		public void setQueueManualEntryOutboundValidationResult(String queueManualEntryOutboundValidationResult) {
			this.queueManualEntryOutboundValidationResult = queueManualEntryOutboundValidationResult;
		}

		public String getRkeyOutboundMsgResult() {
			return rkeyOutboundMsgResult;
		}

		public void setRkeyOutboundMsgResult(String rkeyOutboundMsgResult) {
			this.rkeyOutboundMsgResult = rkeyOutboundMsgResult;
		}

		private String xchangeIsoSimulator = ApplicationDefaultMessgHandler.RabbitMQ.xchangeIsoSimulator;

		public String getQueueOutboundMsgResult() {
			return queueOutboundMsgResult;
		}

		public void setQueueOutboundMsgResult(String queueOutboundMsgResult) {
			this.queueOutboundMsgResult = queueOutboundMsgResult;
		}

		public String getRkeyBusinessValidationResult() {
			return rkeyBusinessValidationResult;
		}

		public void setRkeyBusinessValidationResult(String rkeyBusinessValidationResult) {
			this.rkeyBusinessValidationResult = rkeyBusinessValidationResult;
		}

		public String getRkeyXmlValidationFailure() {
			return rkeyXmlValidationFailure;
		}

		public void setRkeyXmlValidationFailure(String rkeyXmlValidationFailure) {
			this.rkeyXmlValidationFailure = rkeyXmlValidationFailure;
		}

		public String getQueueBusinessValidationOutcome() {
			return queueBusinessValidationOutcome;
		}

		public void setQueueBusinessValidationOutcome(String queueBusinessValidationOutcome) {
			this.queueBusinessValidationOutcome = queueBusinessValidationOutcome;
		}

		public String getQueueMsgValidationFailure() {
			return queueMsgValidationFailure;
		}

		public void setQueueMsgValidationFailure(String queueMsgValidationFailure) {
			this.queueMsgValidationFailure = queueMsgValidationFailure;
		}

		public String getXchangeIsoSimulator() {
			return xchangeIsoSimulator;
		}

		public void setXchangeIsoSimulator(String xchangeIsoSimulator) {
			this.xchangeIsoSimulator = xchangeIsoSimulator;
		}

		public String getRkeyXmlValidationJob() {
			return rkeyXmlValidationJob;
		}

		public void setRkeyXmlValidationJob(String rkeyXmlValidationJob) {
			this.rkeyXmlValidationJob = rkeyXmlValidationJob;
		}

		public String getRkeyManualEntryBizValidationJob() {
			return rkeyManualEntryBizValidationJob;
		}

		public void setRkeyManualEntryBizValidationJob(String rkeyManualEntryBizValidationJob) {
			this.rkeyManualEntryBizValidationJob = rkeyManualEntryBizValidationJob;
		}

		public String getRkeyManualEntryValidationResult() {
			return rkeyManualEntryValidationResult;
		}

		public void setRkeyManualEntryValidationResult(String rkeyManualEntryValidationResult) {
			this.rkeyManualEntryValidationResult = rkeyManualEntryValidationResult;
		}

		public String getRkeyManualEntryBizValidationFailure() {
			return rkeyManualEntryBizValidationFailure;
		}

		public void setRkeyManualEntryBizValidationFailure(String rkeyManualEntryBizValidationFailure) {
			this.rkeyManualEntryBizValidationFailure = rkeyManualEntryBizValidationFailure;
		}

		public String getQueueManualEntryBizValidationFailure() {
			return queueManualEntryBizValidationFailure;
		}

		public void setQueueManualEntryBizValidationFailure(String queueManualEntryBizValidationFailure) {
			this.queueManualEntryBizValidationFailure = queueManualEntryBizValidationFailure;
		}

		public String getQueueManualEntryValidationResult() {
			return queueManualEntryValidationResult;
		}

		public void setQueueManualEntryValidationResult(String queueManualEntryValidationResult) {
			this.queueManualEntryValidationResult = queueManualEntryValidationResult;
		}

	}

	public static class Minio {
		private String minioBucketNm = ApplicationDefaultMessgHandler.Minio.minioBucketNm;
		private String minioDBUrl = ApplicationDefaultMessgHandler.Minio.minioDBUrl;
		private String minioDBUserNm = ApplicationDefaultMessgHandler.Minio.minioDBUserNm;
		private String minioDBPw = ApplicationDefaultMessgHandler.Minio.minioDBPw;
		private String minioDFlod = ApplicationDefaultMessgHandler.Minio.minioDFlod;

		public String getMinioBucketNm() {
			return minioBucketNm;
		}

		public void setMinioBucketNm(String minioBucketNm) {
			this.minioBucketNm = minioBucketNm;
		}

		public String getMinioDBUrl() {
			return minioDBUrl;
		}

		public void setMinioDBUrl(String minioDBUrl) {
			this.minioDBUrl = minioDBUrl;
		}

		public String getMinioDBUserNm() {
			return minioDBUserNm;
		}

		public void setMinioDBUserNm(String minioDBUserNm) {
			this.minioDBUserNm = minioDBUserNm;
		}

		public String getMinioDBPw() {
			return minioDBPw;
		}

		public void setMinioDBPw(String minioDBPw) {
			this.minioDBPw = minioDBPw;
		}

		public String getMinioDFlod() {
			return minioDFlod;
		}

		public void setMinioDFlod(String minioDFlod) {
			this.minioDFlod = minioDFlod;
		}
	}

	public static class BridgeService {
		private String url = ApplicationDefaultMessgHandler.BridgeService.url;
		private Boolean isActive = ApplicationDefaultMessgHandler.BridgeService.isActive;
	
		public Boolean getIsActive() {
			return isActive;
		}
		public void setIsActive(Boolean isActive) {
			this.isActive = isActive;
		}
		public String getUrl() {
			return url;
		}
		public void setUrl(String url) {
			this.url = url;
		}		
	}
}
