package net.synechron.finlabs.isosimulator.msghandler.repository;

import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.security.InvalidKeyException;
import java.security.NoSuchAlgorithmException;
import java.sql.Timestamp;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import io.minio.BucketExistsArgs;
import io.minio.GetObjectArgs;
import io.minio.MakeBucketArgs;
import io.minio.MinioClient;
import io.minio.PutObjectArgs;
import io.minio.UploadObjectArgs;
import io.minio.errors.ErrorResponseException;
import io.minio.errors.InsufficientDataException;
import io.minio.errors.InternalException;
import io.minio.errors.InvalidBucketNameException;
import io.minio.errors.InvalidResponseException;
import io.minio.errors.RegionConflictException;
import io.minio.errors.ServerException;
import io.minio.errors.XmlParserException;
import lombok.extern.slf4j.Slf4j;
import net.synechron.finlabs.isosimulator.msghandler.config.ApplicationProperties;
import net.synechron.finlabs.isosimulator.msghandler.web.rest.errors.MinioClientException;

@Repository
@Slf4j
public class TestServiceMinioDaoImpl implements TestServiceMinioDao {

	@Autowired
	private ApplicationProperties appPropertiesObj;

	@Autowired
	MinioClient minioClient;

	public String storeXMLFile(File file, Long runId) {
		String minioFileNameWithPath;
		try {
			Timestamp timestamp = new Timestamp(System.currentTimeMillis());
			minioFileNameWithPath = timestamp.getTime() + "_" + runId + ".xml";
			if (!minioClient.bucketExists(
					BucketExistsArgs.builder().bucket(appPropertiesObj.getMinio().getMinioBucketNm()).build())) {
				minioClient.makeBucket(
						MakeBucketArgs.builder().bucket(appPropertiesObj.getMinio().getMinioBucketNm()).build());
			}

			UploadObjectArgs uploadObjectArgs = UploadObjectArgs.builder()
					.bucket(appPropertiesObj.getMinio().getMinioBucketNm()).object(minioFileNameWithPath)
					.filename(file.getName()).build();
			minioClient.uploadObject(uploadObjectArgs);

		} catch (InvalidKeyException | ErrorResponseException | IllegalArgumentException | InsufficientDataException
				| InternalException | InvalidBucketNameException | InvalidResponseException | NoSuchAlgorithmException
				| ServerException | XmlParserException | RegionConflictException | IOException e) {
			minioFileNameWithPath = "fail";
			// e.printStackTrace();
			log.error("Getting error while storing file in server", e);
		} finally {
			if (file.exists()) {
				file.delete();
			}
		}
		log.info("File has been uploaded successfully with Name");
		return minioFileNameWithPath;
	}

	@Override
	public InputStream downloadFile(String objectName) {
		try {
			return minioClient.getObject(GetObjectArgs.builder().bucket(appPropertiesObj.getMinio().getMinioBucketNm())
					.object(objectName).build());
		} catch (InvalidKeyException | ErrorResponseException | IllegalArgumentException | InsufficientDataException
				| InternalException | InvalidBucketNameException | InvalidResponseException | NoSuchAlgorithmException
				| ServerException | XmlParserException | IOException e) {

			log.error("Unable to get file from MinIO storage:", e);
			throw new MinioClientException("Unable to get file from MinIO storage :" + e.getMessage(), "", "");
		}

	}

	@Override
	public String storeObject(InputStream messageDataFields, String runId) {

		String minioObjectName;
		try {
			Timestamp timestamp = new Timestamp(System.currentTimeMillis());
			minioObjectName = timestamp.getTime() + "_" + runId;
			if (!minioClient.bucketExists(
					BucketExistsArgs.builder().bucket(appPropertiesObj.getMinio().getMinioBucketNm()).build())) {
				minioClient.makeBucket(
						MakeBucketArgs.builder().bucket(appPropertiesObj.getMinio().getMinioBucketNm()).build());
			}

			minioClient.putObject(PutObjectArgs.builder().bucket(appPropertiesObj.getMinio().getMinioBucketNm())
					.object(minioObjectName).stream(messageDataFields, -1, 10485760).build());

		} catch (InvalidKeyException | ErrorResponseException | IllegalArgumentException | InsufficientDataException
				| InternalException | InvalidBucketNameException | InvalidResponseException | NoSuchAlgorithmException
				| ServerException | XmlParserException | RegionConflictException | IOException e1) {
			log.error("Getting error while storing object in server" + e1);
			minioObjectName = "fail";
		}
		log.info("Object has been uploaded successfully with Name");
		return minioObjectName;
	}

	@Override
	public void updateObject(InputStream messageDataFields, String runId, String ObjectId) {

		try {
			if (!minioClient.bucketExists(
					BucketExistsArgs.builder().bucket(appPropertiesObj.getMinio().getMinioBucketNm()).build())) {
				minioClient.makeBucket(
						MakeBucketArgs.builder().bucket(appPropertiesObj.getMinio().getMinioBucketNm()).build());
			}

			minioClient.putObject(PutObjectArgs.builder().bucket(appPropertiesObj.getMinio().getMinioBucketNm())
					.object(ObjectId).stream(messageDataFields, -1, 10485760).build());

		} catch (InvalidKeyException | ErrorResponseException | IllegalArgumentException | InsufficientDataException
				| InternalException | InvalidBucketNameException | InvalidResponseException | NoSuchAlgorithmException
				| ServerException | XmlParserException | RegionConflictException | IOException e1) {
			log.error("Getting error while Updating object in server" + e1);
		}
	}

	@Override
	public InputStream getObject(String runId) {
		try {
			return minioClient.getObject(GetObjectArgs.builder().bucket(appPropertiesObj.getMinio().getMinioBucketNm())
					.object(runId).build());
		} catch (InvalidKeyException | ErrorResponseException | IllegalArgumentException | InsufficientDataException
				| InternalException | InvalidBucketNameException | InvalidResponseException | NoSuchAlgorithmException
				| ServerException | XmlParserException | IOException e) {

			log.error("Unable to get file from MinIO storage:", e);
			throw new MinioClientException("Unable to get file from MinIO storage :" + e.getMessage(), "", "");
		}
	}
}
