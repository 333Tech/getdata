package net.synechron.finlabs.isosimulator.msghandler.domain;

import java.util.List;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.ToString;

@Data
@ToString
@NoArgsConstructor
@AllArgsConstructor
public class InboundDetailUpload {

	private String testName;
	private String testDescription;
	private String createdOn;
	private List<UploadFileDetails> files;

}
