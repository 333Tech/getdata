package net.synechron.finlabs.isosimulator.msghandler.service;

import java.io.File;
import java.io.IOException;
import java.io.InputStream;


public interface InboundTestServiceMinioService {
	public String storeXMLFile(File file,Long runId) throws IOException;
	public InputStream downloadFile(String objectName);
	public void storeObject(InputStream messageDataFields,String runId);
	public InputStream getObject(String runId);
	public void updateObject(InputStream messageDataFields, String runId, String ObjectId);
}
