package net.synechron.finlabs.isosimulator.msghandler.service;

public interface BridgeService {

	String findResponseMsgId(String msgId);

}
