package net.synechron.finlabs.isosimulator.msghandler.config;

import java.io.Serializable;
import java.util.List;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;

import lombok.AllArgsConstructor;
import lombok.NoArgsConstructor;
import lombok.ToString;
import net.synechron.finlabs.isosimulator.middleware.model.MessageDataField;


@ToString
@AllArgsConstructor
@NoArgsConstructor
@XmlRootElement(name = "Document")
@XmlAccessorType(XmlAccessType.FIELD)
public class MessageDataFields implements Serializable {
	/**
	* 
	*/
	private static final long serialVersionUID = 1L;
	@XmlElement(name = "MessageDataField")
	private List<MessageDataField> messageDataField;

	public List<MessageDataField> getMessageDataField() {
		return messageDataField;
	}

	public void setMessageDataField(List<MessageDataField> messageDataField) {
		this.messageDataField = messageDataField;
	}

}
