package net.synechron.finlabs.isosimulator.msghandler.repository;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.util.StringUtils;
import org.springframework.web.multipart.MultipartFile;

import lombok.extern.slf4j.Slf4j;
import net.synechron.finlabs.isosimulator.InputSourceType;
import net.synechron.finlabs.isosimulator.TestOutputStatus;
import net.synechron.finlabs.isosimulator.ValidationTestStatus;
import net.synechron.finlabs.isosimulator.middleware.model.TestInputType;
import net.synechron.finlabs.isosimulator.middleware.model.ValidationJob;
import net.synechron.finlabs.isosimulator.msghandler.config.MessageHandlerQueueConfig;
import net.synechron.finlabs.isosimulator.msghandler.domain.InboundDetailUpload;
import net.synechron.finlabs.isosimulator.msghandler.domain.UploadFileDetails;
import net.synechron.finlabs.isosimulator.msghandler.entities.TestInputData;
import net.synechron.finlabs.isosimulator.msghandler.entities.TestOutputData;
import net.synechron.finlabs.isosimulator.msghandler.entities.ValidationTest;

@Repository
@Slf4j
@Transactional
public class ValidationTestDaoImpl implements ValidationTestDao {
	@Autowired
	private ValidationTestStatusUpdateDao validationTestDao;
	@Autowired
	private TestInputDao testInputDao;
	@Autowired
	private TestOutputDataDao inboundTestOutputDataDao;
	@Autowired
	private TestServiceMinioDaoImpl inboundTestServiceMinioDaoImpl;
	@Autowired
	private MessageHandlerQueueConfig messageHandlerQueueConfig;
	//@Autowired
	//private InboundTestIsoMessageDao inboundTestIsoMessageDao;

	@Override
	public ValidationTest validationTestSave(InboundDetailUpload inboundDetailUpload, List<MultipartFile> testInputFiles) {
		log.info("==InboundTestDaoImpl validationTestSave() ===");
		ValidationTest validationTest = new ValidationTest();
		validationTest.setTestName(inboundDetailUpload.getTestName());
		validationTest.setDescription(inboundDetailUpload.getTestDescription());
		// date in String
		String dateString = inboundDetailUpload.getCreatedOn();
		DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm");
		// Parse String to LocalDateTime
		LocalDateTime dateTime = LocalDateTime.parse(dateString, formatter);
		validationTest.setCreatedOn(dateTime);
		validationTest.setPaymentType(net.synechron.finlabs.isosimulator.PaymentType.Inbound.name());
		validationTest.setStatus(ValidationTestStatus.InProgress.name());
		validationTest.setInputSourceType(InputSourceType.FileUpload.name());
		validationTest.setTags(null);
		validationTest.setUserId(null);
		ValidationTest validationTestObject = new ValidationTest();
		try {
			validationTestObject = validationTestDao.save(validationTest);
			ValidationJob validationJob;
			File fileObj = null;
			TestInputData testInputData;
			TestOutputData testOutPutData;
			String objectId = "";
			Map<String, UploadFileDetails> filesMap = new HashMap<>();
			for (UploadFileDetails upd : inboundDetailUpload.getFiles()) {
				filesMap.put(upd.getFileName(), upd);
			}
			for (MultipartFile mulitpartFile : testInputFiles) {
				validationJob = new ValidationJob();
				String filename = StringUtils.cleanPath(mulitpartFile.getOriginalFilename());
				if (filename.contains(".xml")) {
					validationJob.setInputType(TestInputType.XML.name());
				} else if (filename.contains(".csv")) {
					validationJob.setInputType(TestInputType.CSV.name());
				} else {
					validationJob.setInputType(TestInputType.JSON.name());
				}
				try {
					fileObj = convertUploadFile(mulitpartFile);
				} catch (IOException e) {
					log.error("Getting error while convertUploadFile", e);
				}
				// call store file
					Long runIdforStoreFile = validationTestObject.getRunId();
					objectId = inboundTestServiceMinioDaoImpl.storeXMLFile(fileObj, runIdforStoreFile);
					testInputData = new TestInputData();
					testInputData.setRunId(validationTestObject.getRunId());
					testInputData.setObjectId(objectId);
					testInputData.setObjectName(filename);
					testInputData.setDescription(filesMap.get(filename).getComments());
					testInputData.setInputType(validationJob.getInputType());
					testInputData.setMsgTypeId(filesMap.get(filename).getMsgTypeId());
					testInputDao.save(testInputData);

				if (objectId.equalsIgnoreCase(TestOutputStatus.Fail.toString())) {
					testOutPutData = new TestOutputData();
					testOutPutData.setInputObjectId(objectId);
					testOutPutData.setRunId(validationTestObject.getRunId());
					String testOutputStatus = TestOutputStatus.Fail.name();
					testOutPutData.setStatus(testOutputStatus);
					inboundTestOutputDataDao.save(testOutPutData);
					// update status fail in ValidationTest entities and break the loop if one of
					// file has failed
					validationTest.setStatus(ValidationTestStatus.Failed.name());
					validationTestDao.save(validationTest);
					break;
				} else {
					validationJob.setRunId(validationTestObject.getRunId().toString());
					validationJob.setObjectId(objectId);
					validationJob.setMsgTypeId(filesMap.get(filename).getMsgTypeId());
					// get mesgId from isoMessageMetadata
					log.info(" started validation object push in rabbitMq");
					messageHandlerQueueConfig.pushValidationJob(validationJob);
				}

			}
			return validationTestObject;
		}catch(Exception e) {
			log.info("RunId#"+validationTestObject.getRunId()+"processedOn#0");
			e.printStackTrace();
			return new ValidationTest();
		}
		
	}
	public File convertUploadFile(MultipartFile file) throws IOException {
		String filename = StringUtils.cleanPath(file.getOriginalFilename());
		File convFile = new File(filename);
		convFile.createNewFile();
		FileOutputStream fos = new FileOutputStream(convFile);
		fos.write(file.getBytes());
		fos.close();
		return convFile;
	}
}
