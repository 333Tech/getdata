package net.synechron.finlabs.isosimulator.msghandler.repository;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;

import lombok.extern.slf4j.Slf4j;

@Repository
@Slf4j
public class BridgeServiceDaoImpl implements BridgeServiceDao {

	@Autowired
	private JdbcTemplate jdbcTemplate;

	@Override
	public String findResponseMsgId(String msgId) {
		String query = "SELECT response_msg_id FROM test_input_data where msg_id ='" + msgId + "' LIMIT 1";
		return jdbcTemplate.queryForMap(query).get("response_msg_id").toString();
	}
}
