package net.synechron.finlabs.isosimulator.msghandler.repository;

public interface BridgeServiceDao {

	public String findResponseMsgId(String msgId);
}
