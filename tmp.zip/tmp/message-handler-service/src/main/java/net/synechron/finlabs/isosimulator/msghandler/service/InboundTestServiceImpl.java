package net.synechron.finlabs.isosimulator.msghandler.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.multipart.MultipartFile;

import lombok.extern.slf4j.Slf4j;
import net.synechron.finlabs.isosimulator.msghandler.domain.InboundDetailUpload;
import net.synechron.finlabs.isosimulator.msghandler.entities.ValidationTest;
import net.synechron.finlabs.isosimulator.msghandler.repository.ValidationTestDaoImpl;

@Slf4j
@Service
public class InboundTestServiceImpl implements InboundTestService {

	@Autowired
	private ValidationTestDaoImpl inboundTestDaoImpl;

	@Override
	@Transactional
	public ValidationTest validationTestSave(InboundDetailUpload inboundDetailUpload, List<MultipartFile> testInputFiles) {
		log.info("== InboundTestServiceImpl validationTestSave()===");
		return inboundTestDaoImpl.validationTestSave(inboundDetailUpload, testInputFiles);
	}

}
