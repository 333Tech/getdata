package net.synechron.finlabs.isosimulator.msghandler.repository;

import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import net.synechron.finlabs.isosimulator.domain.IsoMessageMetaData;


@Repository
public interface ManualEntryIsoMessageMetadataDao extends JpaRepository<IsoMessageMetaData, String> {

	//@Query("SELECT t.version,t.name FROM IsoMessageMetaData t WHERE t.id =:mesgTypeId")
	//public IsoMessageMetaData getIsoMsgDtls(@Param("mesgTypeId") String mesgTypeId);
	public Optional<IsoMessageMetaData> findById(String id);

	//@Query("SELECT t.name FROM IsoMessageMetaData t WHERE t.id =:mesgTypeId")
	//public String getMesgTypeName(@Param("mesgTypeId") String mesgTypeId);
}
