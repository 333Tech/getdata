/**
 * JPA domain objects.
 */
package net.synechron.finlabs.isosimulator.msghandler.domain;
