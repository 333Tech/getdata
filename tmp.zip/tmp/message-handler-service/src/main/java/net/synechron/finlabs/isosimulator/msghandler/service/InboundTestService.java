package net.synechron.finlabs.isosimulator.msghandler.service;

import java.util.List;

import org.springframework.web.multipart.MultipartFile;

import net.synechron.finlabs.isosimulator.msghandler.domain.InboundDetailUpload;
import net.synechron.finlabs.isosimulator.msghandler.entities.ValidationTest;

public interface InboundTestService {
	public ValidationTest validationTestSave(InboundDetailUpload inboundDetailUpload,List<MultipartFile> testInputFiles);
}
