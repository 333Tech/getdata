package net.synechron.finlabs.isosimulator.msghandler.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import net.synechron.finlabs.isosimulator.msghandler.entities.ValidationTest;

@Repository
public interface ValidationTestStatusUpdateDao extends JpaRepository<ValidationTest, Long> {

	@Transactional
	@Modifying(clearAutomatically = true)
	@Query("UPDATE ValidationTest t SET t.status =:status where t.runId =:runId")
	public void updateValidationTest(@Param("status") String status, @Param("runId") long runId);

	@Transactional
	@Modifying(clearAutomatically = true)
	@Query("UPDATE ValidationTest t SET t.tags =:tags where t.runId =:runId")
	public void updateValidationTestTags(@Param("tags") String tags, @Param("runId") long runId);

}
