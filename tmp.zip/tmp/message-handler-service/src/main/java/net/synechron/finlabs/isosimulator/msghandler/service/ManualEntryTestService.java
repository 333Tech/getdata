package net.synechron.finlabs.isosimulator.msghandler.service;

import java.io.IOException;

import javax.xml.bind.JAXBException;
import javax.xml.parsers.ParserConfigurationException;
import javax.xml.transform.TransformerException;

import org.springframework.stereotype.Service;
import org.xml.sax.SAXException;

import net.synechron.finlabs.isosimulator.msghandler.domain.ManualEntryData;
import net.synechron.finlabs.isosimulator.msghandler.domain.ManualEntryDataResp;

@Service
public interface ManualEntryTestService {

	public ManualEntryDataResp manualEntryDataSave(ManualEntryData manualEntryData)
			throws IOException, TransformerException, ParserConfigurationException, SAXException, JAXBException;
	public void manualEntryDataSaveAsDraft(ManualEntryDataResp messageDataFields,String rundId) throws IOException;
	public void manualEntryValidateData(ManualEntryDataResp messageDataFields,String rundId) throws IOException;
	public void manualEntryOutputValidateData(ManualEntryDataResp messageDataFields, String rundId) throws Exception;
}
