package net.synechron.finlabs.isosimulator.msghandler.repository;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.util.StringUtils;
import org.springframework.web.multipart.MultipartFile;

import lombok.extern.slf4j.Slf4j;
import net.synechron.finlabs.isosimulator.InputSourceType;
import net.synechron.finlabs.isosimulator.TestOutputStatus;
import net.synechron.finlabs.isosimulator.ValidationTestStatus;
import net.synechron.finlabs.isosimulator.middleware.model.TestInputType;
import net.synechron.finlabs.isosimulator.middleware.model.ValidationJob;
import net.synechron.finlabs.isosimulator.msghandler.config.MessageHandlerQueueConfig;
import net.synechron.finlabs.isosimulator.msghandler.domain.InboundDetailUpload;
import net.synechron.finlabs.isosimulator.msghandler.domain.UploadFileDetails;
import net.synechron.finlabs.isosimulator.msghandler.entities.TestInputData;
import net.synechron.finlabs.isosimulator.msghandler.entities.TestOutputData;
import net.synechron.finlabs.isosimulator.msghandler.entities.ValidationTest;
import net.synechron.finlabs.isosimulator.msghandler.web.rest.errors.BadRequestAlertException;

@Repository
@Slf4j
@Transactional
public class ValidationTestOutboundDaoImpl implements ValidationTestOutboundDao {

	@Autowired
	private ValidationTestStatusUpdateDao validationTestDao;
	@Autowired
	private TestServiceMinioDaoImpl inboundTestServiceMinioDaoImpl;
	@Autowired
	private TestInputDao testInputDao;
	@Autowired
	private TestOutputDataDao inboundTestOutputDataDao;
	@Autowired
	private MessageHandlerQueueConfig messageHandlerQueueConfig;

	@Override
	public ValidationTest validationTestOutboundSave(InboundDetailUpload inboundDetailUpload,
			List<MultipartFile> testInputFiles) throws IOException {
		log.info("==validationTestOutboundSave ===");
		ValidationTest validationTest = new ValidationTest();
		validationTest.setTestName(inboundDetailUpload.getTestName());
		validationTest.setDescription(inboundDetailUpload.getTestDescription());
		// date in String
		String dateString = inboundDetailUpload.getCreatedOn();
		DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm");
		// Parse String to LocalDateTime
		LocalDateTime dateTime = LocalDateTime.parse(dateString, formatter);
		validationTest.setCreatedOn(dateTime);
		validationTest.setPaymentType(net.synechron.finlabs.isosimulator.PaymentType.Outbound.name());
		validationTest.setStatus(ValidationTestStatus.InProgress.name());
		validationTest.setInputSourceType(InputSourceType.FileUpload.name());
		ValidationTest validationTestObject = new ValidationTest();
		try {
			validationTestObject = validationTestDao.save(validationTest);
			ValidationJob validationJob;
			File fileObj = null;
			TestInputData testInputData;
			TestOutputData testOutPutData;
			String objectId = "";
			Map<String, MultipartFile> filesMap = new HashMap<>();
			for (MultipartFile file : testInputFiles) {
				String filename = StringUtils.cleanPath(file.getOriginalFilename());
				filesMap.put(filename, file);
			}
			for (UploadFileDetails fileMeta : inboundDetailUpload.getFiles()) {
				validationJob = new ValidationJob();

				if ((null != fileMeta.getResponseMSgId() && !fileMeta.getResponseMSgId().isEmpty())) {
					if (fileMeta.getFileName().contains(".xml")) {
						validationJob.setInputType(TestInputType.XML.name());
					} else if (fileMeta.getFileName().contains(".csv")) {
						validationJob.setInputType(TestInputType.CSV.name());
					}
					try {
						fileObj = convertUploadFile(filesMap.get(fileMeta.getFileName()));
					} catch (IOException e) {
						log.error("Getting error while convertUploadFile", e);
					}

					// call store file
					Long runIdforStoreFile = validationTestObject.getRunId();
					objectId = inboundTestServiceMinioDaoImpl.storeXMLFile(fileObj, runIdforStoreFile);
					testInputData = new TestInputData();
					testInputData.setRunId(validationTestObject.getRunId());
					testInputData.setObjectId(objectId);
					testInputData.setObjectName(fileMeta.getFileName());
					testInputData.setInputType(validationJob.getInputType());
					testInputData.setMsgTypeId(fileMeta.getMsgTypeId());
					testInputData.setResponseMsgId(fileMeta.getResponseMSgId());
					testInputDao.save(testInputData);

					if (objectId.equalsIgnoreCase(TestOutputStatus.Fail.toString())) {
						testOutPutData = new TestOutputData();
						testOutPutData.setRunId(validationTestObject.getRunId());
						String testOutputStatus = TestOutputStatus.Fail.name();
						testOutPutData.setStatus(testOutputStatus);
						testOutPutData.setResponseMsgId(fileMeta.getResponseMSgId());
						inboundTestOutputDataDao.save(testOutPutData);
						// update status fail in ValidationTest entities and break the loop if one of
						// file has failed
						validationTest.setStatus(ValidationTestStatus.Failed.name());
						validationTestDao.save(validationTest);
						break;
					} else {
						validationJob.setRunId(validationTestObject.getRunId().toString());
						validationJob.setObjectId(objectId);
						validationJob.setMsgTypeId(fileMeta.getMsgTypeId());
						validationJob.setResponseMsgId(fileMeta.getResponseMSgId());
						log.info(" started validation object push in rabbitMq");
						messageHandlerQueueConfig.pushValidationJob(validationJob);
					}
				} else {
					throw new BadRequestAlertException(
							"Invalid input for Response Message Id. Please retry with valid data.", "", "");
				}
			}
			return validationTestObject;
		}catch(Exception e) {
			log.info("RunId#"+validationTestObject.getRunId()+"processedOn#0");
			e.printStackTrace();
			return new ValidationTest();
		}
		
	}

	public File convertUploadFile(MultipartFile file) throws IOException {
		String filename = StringUtils.cleanPath(file.getOriginalFilename());
		File convFile = new File(filename);
		convFile.createNewFile();
		FileOutputStream fos = new FileOutputStream(convFile);
		fos.write(file.getBytes());
		fos.close();
		return convFile;
	}

}
