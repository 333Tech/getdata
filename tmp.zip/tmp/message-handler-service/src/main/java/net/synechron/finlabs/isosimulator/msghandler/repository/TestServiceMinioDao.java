package net.synechron.finlabs.isosimulator.msghandler.repository;

import java.io.File;
import java.io.IOException;
import java.io.InputStream;

public interface TestServiceMinioDao {
	public String storeXMLFile(File file, Long runId) throws IOException;

	public InputStream downloadFile(String objectName);

	public String storeObject(InputStream messageDataFields, String runId);

	public InputStream getObject(String runId);

	public void updateObject(InputStream messageDataFields, String runId, String ObjectId);
}
