package net.synechron.finlabs.isosimulator.msghandler.entities;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.ToString;

@Entity
@Table(name = "test_input_data")
@Data
@ToString
@NoArgsConstructor
@AllArgsConstructor
public class TestInputData {
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	private Long id;
	@Column(name = "run_id")
	private Long runId;
	@Column(name = "object_id")
	private String objectId;
	@Column(name = "object_name")
	private String objectName;
	@Column(name = "description")
	private String description;
	@Column(name = "input_type")
	private String inputType;
	@Column(name = "msg_type_id")
	private String msgTypeId;
	@Column(name = "response_msg_id")
	private String responseMsgId;
	@Column(name = "msg_id")
	private String msgId;
	//@OneToOne(fetch = FetchType.LAZY, mappedBy = "testInputData")
	//private ValidationTest validationTest;
	@ManyToOne // TODO add join column annotation.
	private ValidationTest validationtest;
}
