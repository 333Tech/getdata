package net.synechron.finlabs.isosimulator.msghandler.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import net.synechron.finlabs.isosimulator.msghandler.entities.ValidationError;

public interface ValidationErrorDao extends JpaRepository<ValidationError, Long>{

}
