package net.synechron.finlabs.isosimulator.msghandler.entities;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.ToString;

@Entity
@Table(name = "test_output_data")
@Data
@ToString
@NoArgsConstructor
@AllArgsConstructor
public class TestOutputData {
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	@Column(name = "id")
	private Long id;
	@Column(name = "run_id")
	private Long runId;
	@Column(name = "input_object_id")
	private String inputObjectId;
	@Column(name = "msg_id")
	private String msgId;
	@Column(name = "out_object_id")
	private String outObjectId;
	@Column(name = "out_object_name")
	private String outObjectName;
	@Column(name = "response_msg_id")
	private String responseMsgId;
	@Column(name = "status")
	private String status;

}
