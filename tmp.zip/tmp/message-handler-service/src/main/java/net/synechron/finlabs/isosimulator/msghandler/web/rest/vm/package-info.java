/**
 * View Models used by Spring MVC REST controllers.
 */
package net.synechron.finlabs.isosimulator.msghandler.web.rest.vm;
