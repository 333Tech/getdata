package net.synechron.finlabs.isosimulator.msghandler.repository;

import java.io.IOException;
import java.util.List;

import org.springframework.web.multipart.MultipartFile;

import net.synechron.finlabs.isosimulator.msghandler.domain.InboundDetailUpload;
import net.synechron.finlabs.isosimulator.msghandler.entities.ValidationTest;

public interface ValidationTestOutboundDao {
	public ValidationTest validationTestOutboundSave(InboundDetailUpload inboundDetailUpload, List<MultipartFile> testInputFiles) throws IOException;
}
