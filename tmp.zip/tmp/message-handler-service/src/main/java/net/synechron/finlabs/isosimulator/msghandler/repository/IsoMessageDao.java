package net.synechron.finlabs.isosimulator.msghandler.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import net.synechron.finlabs.isosimulator.domain.IsoMessageMetaData;

@Repository
public interface IsoMessageDao extends JpaRepository<IsoMessageMetaData, String> {
}
