	package net.synechron.finlabs.isosimulator.msghandler.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import net.synechron.finlabs.isosimulator.msghandler.entities.TestInputData;

@Repository
public interface TestInputDao extends JpaRepository<TestInputData, Long> {

	@Query("SELECT COUNT(t1) FROM TestInputData t1 where t1.runId =:runId")
	public Long getCountTestInputRunId(@Param("runId") long runId);

	@Transactional
	@Modifying(clearAutomatically = true)
	@Query("UPDATE TestInputData t SET t.description =:description where t.runId =:runId")
	public void updateTestInputDescription(@Param("description") String description,@Param("runId") long runId);

	@Transactional
	@Modifying(clearAutomatically = true)
	@Query("UPDATE TestInputData t SET t.objectId =:objectId where t.runId =:runId")
	public void updateTestInputObjectId(@Param("objectId") String objectId,@Param("runId") long runId);
	
	@Transactional
	@Modifying(clearAutomatically = true)
	@Query("UPDATE TestInputData t SET t.description =:description,t.msgId=:msgId where t.runId =:runId")
	public void updateTestInputDescriptionPayMsgId(@Param("description") String description,@Param("msgId") String msgId, @Param("runId") long runId);

	@Query("SELECT COUNT(t) FROM TestInputData t WHERE t.msgId=:msgId and t.runId != :runId")
	public Long getTestInputDataMsgId(@Param("msgId") String msgId,@Param("runId") long runId);
}
