/**
 * Spring Security configuration.
 */
package net.synechron.finlabs.isosimulator.msghandler.security;
