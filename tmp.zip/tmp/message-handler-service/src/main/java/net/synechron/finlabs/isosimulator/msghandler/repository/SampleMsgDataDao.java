package net.synechron.finlabs.isosimulator.msghandler.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;
import net.synechron.finlabs.isosimulator.domain.SampleMsgData;


@Repository
public interface SampleMsgDataDao extends JpaRepository<SampleMsgData, Long> {
	public SampleMsgData findByIsoMsgIdAndIsValid(String isoMsgId,Boolean isValid);
}
