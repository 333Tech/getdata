package net.synechron.finlabs.isosimulator.msghandler.domain;

import java.io.Serializable;
import java.util.List;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.ToString;
import net.synechron.finlabs.isosimulator.middleware.model.MessageDataField;



@Data
@ToString
@NoArgsConstructor
@AllArgsConstructor
public class ManualEntryDataResp implements Serializable{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private String rundId;
	private String testName;
	private String testDesc;
	private String datetime;
	private String msgTypeId;
	private String msgTypeName;
	private String msgTypeVersion;
	private String fileName;
	private String fileDesc;
	private String tags;
	private String msgId;
	private String responseMsgId;
	private List<MessageDataField> messageDataFields;
}
