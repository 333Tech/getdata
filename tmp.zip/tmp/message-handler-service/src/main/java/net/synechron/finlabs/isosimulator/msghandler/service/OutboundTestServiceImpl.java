package net.synechron.finlabs.isosimulator.msghandler.service;

import java.io.IOException;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

import lombok.extern.slf4j.Slf4j;
import net.synechron.finlabs.isosimulator.msghandler.domain.InboundDetailUpload;
import net.synechron.finlabs.isosimulator.msghandler.entities.ValidationTest;
import net.synechron.finlabs.isosimulator.msghandler.repository.ValidationTestOutboundDaoImpl;

@Slf4j
@Service
public class OutboundTestServiceImpl implements OutboundTestService {

	@Autowired
	private ValidationTestOutboundDaoImpl validationTestOutboundDaoImpl;

	@Override
	public ValidationTest validationTestSave(InboundDetailUpload inboundDetailUpload,
			List<MultipartFile> testInputFiles) throws IOException {
		log.info("== InboundTestServiceImpl validationTestSave()===");
		return validationTestOutboundDaoImpl.validationTestOutboundSave(inboundDetailUpload, testInputFiles);
	}

}
