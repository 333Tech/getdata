package net.synechron.finlabs.isosimulator.msghandler.domain;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.ToString;

@Data
@ToString
@NoArgsConstructor
@AllArgsConstructor
public class ValidationTestRespData {
	private Long runId;
}
