package net.synechron.finlabs.isosimulator.msghandler.repository;

import java.io.BufferedReader;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.io.StringWriter;
import java.io.Writer;
import java.nio.charset.StandardCharsets;
import java.text.SimpleDateFormat;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.Date;
import java.util.List;
import java.util.Optional;
import java.util.UUID;

import javax.transaction.Transactional;
import javax.xml.bind.JAXBContext;
import javax.xml.bind.JAXBElement;
import javax.xml.bind.JAXBException;
import javax.xml.bind.Unmarshaller;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;
import javax.xml.transform.Result;
import javax.xml.transform.Source;
import javax.xml.transform.Templates;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerException;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;
import javax.xml.transform.stream.StreamSource;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;
import org.w3c.dom.Document;
import org.xml.sax.SAXException;

import lombok.extern.slf4j.Slf4j;
import net.synechron.finlabs.isosimulator.CommonFunction;
import net.synechron.finlabs.isosimulator.InputSourceType;
import net.synechron.finlabs.isosimulator.ValidationTestStatus;
import net.synechron.finlabs.isosimulator.domain.IsoMessageMetaData;
import net.synechron.finlabs.isosimulator.domain.SampleMsgData;
import net.synechron.finlabs.isosimulator.middleware.model.BusinessValidationJob;
import net.synechron.finlabs.isosimulator.middleware.model.MessageDataField;
import net.synechron.finlabs.isosimulator.msghandler.config.MessageDataFields;
import net.synechron.finlabs.isosimulator.msghandler.config.MessageHandlerQueueConfig;
import net.synechron.finlabs.isosimulator.msghandler.domain.ManualEntryData;
import net.synechron.finlabs.isosimulator.msghandler.domain.ManualEntryDataResp;
import net.synechron.finlabs.isosimulator.msghandler.entities.TestInputData;
import net.synechron.finlabs.isosimulator.msghandler.entities.ValidationTest;
import net.synechron.finlabs.isosimulator.msghandler.web.rest.errors.DuplicateMsgIdAlertException;

@Repository
@Slf4j
@Transactional
public class ManualEntryTestDaoImpl implements ManualEntryTestDao {

	@Autowired
	private ValidationTestStatusUpdateDao validationTestDao;

	@Autowired
	private TestServiceMinioDaoImpl inboundTestServiceMinioDaoImpl;

	@Autowired
	private TestInputDao testInputDao;

	@Autowired
	private MessageHandlerQueueConfig messageHandlerQueueConfig;

	@Autowired
	private ManualEntryIsoMessageMetadataDao manualEntryIsoMessageMetadataDao;
	
	@Autowired
	private SampleMsgDataDao sampleMsgDataDao;
	
	@Autowired
	private IsoMessageDao isoMessageDao;	
	
	@Autowired
	private JdbcTemplate jdbcTemplate;

	@Override
	public ManualEntryDataResp manualEntryDataSave(ManualEntryData manualEntryData)
			throws IOException, TransformerException, ParserConfigurationException, SAXException, JAXBException {

		log.info("===ManualEntryTestDaoImpl manualEntryDataSave===");
		ValidationTest validationTest = new ValidationTest();
		validationTest.setTestName(manualEntryData.getTestName());
		validationTest.setDescription(manualEntryData.getTestDesc());
		// date in String
		String dateString = manualEntryData.getCreatedOn();
		DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm");
		// Parse String to LocalDateTime
		LocalDateTime dateTime = LocalDateTime.parse(dateString, formatter);
		validationTest.setCreatedOn(dateTime);
		if (manualEntryData.getResponseMsgIds() != null) {
			validationTest.setPaymentType(net.synechron.finlabs.isosimulator.PaymentType.Outbound.name());
		} else {
			validationTest.setPaymentType(net.synechron.finlabs.isosimulator.PaymentType.Inbound.name());
		}
		validationTest.setStatus(ValidationTestStatus.Draft.name());
		validationTest.setInputSourceType(InputSourceType.ManualEntry.name());
		validationTest.setTags(manualEntryData.getTags());
		ValidationTest ValidationTestObj = validationTestDao.save(validationTest);

		MessageDataFields convertXslToXmlToJavaObj = convertXslToXmlToJavaObj(ValidationTestObj.getRunId().toString(),
				manualEntryData);
		ManualEntryDataResp manualEntryDataResp = new ManualEntryDataResp();
		manualEntryDataResp.setMessageDataFields(convertXslToXmlToJavaObj.getMessageDataField());
		manualEntryDataResp.setTestName(manualEntryData.getTestName());
		manualEntryDataResp.setTestDesc(manualEntryData.getTestDesc());
		manualEntryDataResp.setDatetime(manualEntryData.getCreatedOn());
		manualEntryDataResp.setRundId((ValidationTestObj.getRunId()).toString());
		manualEntryDataResp.setFileName(manualEntryData.getFileName());
		manualEntryDataResp.setFileDesc(manualEntryData.getFileDesc());
		manualEntryDataResp.setMsgTypeId(manualEntryData.getMsgTypeId());

		Optional<IsoMessageMetaData> isoMessageMetaData = manualEntryIsoMessageMetadataDao
				.findById(manualEntryData.getMsgTypeId());
		IsoMessageMetaData isoMsgData = isoMessageMetaData.get();

		manualEntryDataResp.setMsgTypeName(isoMsgData.getName());
		manualEntryDataResp.setMsgTypeVersion(isoMsgData.getVersion());
		manualEntryDataResp.setTags(manualEntryData.getTags());

		return manualEntryDataResp;
	}
	
	public void getAutoGenerateFields(List<MessageDataField> messageDataFields) {
		SimpleDateFormat sdf;
		for(int i=0;i<messageDataFields.size();i++) {
			MessageDataField msgDataObj=messageDataFields.get(i);
			if(msgDataObj.getIsAutoGenerate())
			{
				if(msgDataObj.getFieldDataRepresentation().contains("string")) {
					msgDataObj.setValue((UUID.randomUUID()).toString().replace("-",""));
				}
				if(msgDataObj.getFieldDataRepresentation().equalsIgnoreCase("date")) {
					sdf= new SimpleDateFormat(msgDataObj.getPatternType());
					msgDataObj.setValue(sdf.format(new Date()));
				}
				if(msgDataObj.getTagName().equalsIgnoreCase("UETR")) {
					msgDataObj.setValue(UUID.randomUUID().toString());
				}
			}		
		}
	}

	public MessageDataFields convertXslToXmlToJavaObj(String runId, ManualEntryData manualEntryData)
			throws TransformerException, ParserConfigurationException, SAXException, IOException, JAXBException {

		Optional<IsoMessageMetaData> isoMessageMetaData = manualEntryIsoMessageMetadataDao
				.findById(manualEntryData.getMsgTypeId());
		IsoMessageMetaData isoMsgData = isoMessageMetaData.get();
		
		SampleMsgData sampleMsgDataObj = sampleMsgDataDao.findByIsoMsgIdAndIsValid(isoMsgData.getId(),true);
		MessageDataFields messageDataFields = new MessageDataFields();
		if(sampleMsgDataObj!=null && sampleMsgDataObj.getXmlObjectId()!=null) {
			JAXBContext jaxbContext = JAXBContext.newInstance(MessageDataFields.class);
			Unmarshaller jaxbUnmarshaller = jaxbContext.createUnmarshaller();
			JAXBElement<MessageDataFields> jaxbElement = jaxbUnmarshaller.unmarshal(
				new StreamSource(xferXmlByAppyingXls(isoMsgData)), MessageDataFields.class);
			messageDataFields = jaxbElement.getValue();
		}else {
				messageDataFields = convertXslToJsonData(isoMsgData);
		}
		
		CommonFunction data = new CommonFunction();
		data.getAutoGenerateFields(messageDataFields.getMessageDataField());
		
		String jsonString = data.msgDataFieldArrayIntoJsonString(messageDataFields.getMessageDataField());
		String jsonFormatting = jsonString.replace("\\\\", "\\");
		InputStream input = new ByteArrayInputStream(jsonFormatting.getBytes());

		String storeObject = inboundTestServiceMinioDaoImpl.storeObject(input, runId);

		if (manualEntryData.getResponseMsgIds() != null) {
			TestInputData testInputData;
			for (int i = 0; i < manualEntryData.getResponseMsgIds().length; i++) {
				testInputData = new TestInputData();
				testInputData.setRunId(Long.parseLong(runId));
				// testInputData.setInputType(TestInputType.JSON.name());
				testInputData.setMsgTypeId(manualEntryData.getMsgTypeId());
				testInputData.setObjectName(manualEntryData.getFileName());
				testInputData.setObjectId(storeObject);
				testInputData.setDescription(manualEntryData.getFileDesc());
				testInputData.setResponseMsgId(manualEntryData.getResponseMsgIds()[i]);
				testInputDao.save(testInputData);
			}
		} else {
			TestInputData testInputData = new TestInputData();
			testInputData.setRunId(Long.parseLong(runId));
			// testInputData.setInputType(TestInputType.JSON.name());
			testInputData.setMsgTypeId(manualEntryData.getMsgTypeId());
			testInputData.setObjectName(manualEntryData.getFileName());
			testInputData.setObjectId(storeObject);
			testInputData.setDescription(manualEntryData.getFileDesc());
			testInputDao.save(testInputData);
		}
		return messageDataFields;
	}
	
	public InputStream xferXmlByAppyingXls(IsoMessageMetaData isoMsgData)
			throws TransformerException, ParserConfigurationException, SAXException, IOException, JAXBException {

		TransformerFactory factory = TransformerFactory.newInstance();
		Templates template = factory.newTemplates(
				new StreamSource(inboundTestServiceMinioDaoImpl.downloadFile(isoMsgData.getXslObjectId())));// xls
		Transformer xformer = template.newTransformer();
		OutputStream stream = new ByteArrayOutputStream();
		SampleMsgData sampleMsgDataObj = sampleMsgDataDao.findByIsoMsgIdAndIsValid(isoMsgData.getId(), true);
		DocumentBuilderFactory dbfxml = DocumentBuilderFactory.newInstance();
		DocumentBuilder dbxml = dbfxml.newDocumentBuilder();
		Document docXml = dbxml.parse(inboundTestServiceMinioDaoImpl.downloadFile(sampleMsgDataObj.getXmlObjectId()));
		Source source = new DOMSource(docXml);// xml
		Result result = new StreamResult(stream);
		xformer.transform(source, result);
		return new ByteArrayInputStream(((ByteArrayOutputStream) stream).toByteArray());

	}
	
	private MessageDataFields convertXslToJsonData(IsoMessageMetaData isoMsgData)
			throws TransformerException, ParserConfigurationException, SAXException, IOException, JAXBException {
		
		BufferedReader reader = new BufferedReader(
				new InputStreamReader(inboundTestServiceMinioDaoImpl.downloadFile(isoMsgData.getXslObjectId())));
		Writer writer = new StringWriter();
		String currentLine;
		boolean flag = false;
		writer.write('\n' + "<Document>" + System.getProperty("line.separator"));
		while ((currentLine = reader.readLine()) != null) {
			if (currentLine.trim().startsWith("<MessageDataField>")) {
				flag = true;
			}
			if (currentLine.trim().startsWith("</MessageDataField>")) {
				flag = false;
			}
			if (flag) {
				String linesToRemoveStartsWith = "<xsl";
				if (!currentLine.trim().startsWith(linesToRemoveStartsWith)) {
					if (currentLine.trim().contains("</info>")) {
						writer.write(currentLine + "\n		</MessageDataField>"
								+ System.getProperty("line.separator"));
					} else {
						writer.write(currentLine + System.getProperty("line.separator"));
					}
				}
			}
		}
		writer.write( "\n </Document> " + System.getProperty("line.separator"));
		writer.close();
		reader.close();
		JAXBContext jaxbContext = JAXBContext.newInstance(MessageDataFields.class);
		Unmarshaller jaxbUnmarshaller = jaxbContext.createUnmarshaller();
		JAXBElement<MessageDataFields> jaxbElement = jaxbUnmarshaller.unmarshal(
				new StreamSource(new ByteArrayInputStream(writer.toString().getBytes(StandardCharsets.UTF_8))), MessageDataFields.class);
		MessageDataFields value = jaxbElement.getValue();
		return value;
	}
	
	@Override
	public void manualEntryDataSaveAsDraft(ManualEntryDataResp messageDataFields, String runId) throws IOException {
		log.info("storing MessageDataFields as draft in minio");
		testInputDao.updateTestInputDescription(messageDataFields.getFileDesc(), Long.parseLong(runId));
		if (null != messageDataFields.getTags() && !messageDataFields.getTags().isEmpty()) {
			validationTestDao.updateValidationTestTags(messageDataFields.getTags(), Long.parseLong(runId));
		}
		//getAutoGenerateFields(messageDataFields.getMessageDataFields());
		String ObjectId = findInputObjectId(Long.parseLong(runId));
		CommonFunction data = new CommonFunction();
		String jsonString = data.msgDataFieldArrayIntoJsonString(messageDataFields.getMessageDataFields());

		InputStream input = new ByteArrayInputStream(jsonString.getBytes());
		inboundTestServiceMinioDaoImpl.updateObject(input, runId, ObjectId);
	}
	
	@Override
	public void manualEntryValidateData(ManualEntryDataResp messageDataFields, String runId) throws IOException {
		try {
			log.info("MessageDataFields storing and validate");
			testInputDao.updateTestInputDescription(messageDataFields.getFileDesc(), Long.parseLong(runId));
			if (null != messageDataFields.getTags() && !messageDataFields.getTags().isEmpty()) {
				validationTestDao.updateValidationTestTags(messageDataFields.getTags(), Long.parseLong(runId));
			}
			String inputObjectId = findInputObjectId(Long.parseLong(runId));
			//
			CommonFunction data = new CommonFunction();
			String jsonString = data.msgDataFieldArrayIntoJsonString(messageDataFields.getMessageDataFields());

			/**/
			// ByteArrayOutputStream baos = new ByteArrayOutputStream();
			// ObjectOutputStream oos = new ObjectOutputStream(baos);

			// oos.writeObject(messageDataFields.getMessageDataFields());

			// oos.flush();
			// oos.close();

			// InputStream input = new ByteArrayInputStream(baos.toByteArray());

			InputStream input = new ByteArrayInputStream(jsonString.getBytes());
			inboundTestServiceMinioDaoImpl.updateObject(input, runId, inputObjectId);
			BusinessValidationJob businessValidationJob = new BusinessValidationJob();
			businessValidationJob.setRunId(runId);
			businessValidationJob.setInputObjectId(inputObjectId);
			businessValidationJob.setMessageDataFields(messageDataFields.getMessageDataFields());
			businessValidationJob.setMsgTypeId(messageDataFields.getMsgTypeId());
			messageHandlerQueueConfig.pushManualEntryBusinessValidationJob(businessValidationJob);
		} catch (Exception e) {
			log.info("RunId#"+runId+"processedOn#"+0);
			e.printStackTrace();
		}
	}
	
	public String getMsgDataValue(ManualEntryDataResp messageDataFields) {

		Optional<IsoMessageMetaData> isoMsgDataObj = isoMessageDao.findById(messageDataFields.getMsgTypeId());
		for (int i = 0; i <= messageDataFields.getMessageDataFields().size(); i++) {
			if (messageDataFields.getMessageDataFields().get(i).getxPath()
					.equalsIgnoreCase(isoMsgDataObj.get().getPaymentMsgIdXpath())) {
				return messageDataFields.getMessageDataFields().get(i).getValue();
			}
		}
		return null;
	}
	
	@Override
	public void manualEntryOutputValidateData(ManualEntryDataResp messageDataFields, String runId) throws Exception {
		try {
			log.info("MessageDataFields storing and validate");
			if (null != messageDataFields.getTags() && !messageDataFields.getTags().isEmpty()) {
				validationTestDao.updateValidationTestTags(messageDataFields.getTags(), Long.parseLong(runId));
			}
			String inputObjectId = findInputObjectId(Long.parseLong(runId));
			//
			CommonFunction data = new CommonFunction();
			String jsonString = data.msgDataFieldArrayIntoJsonString(messageDataFields.getMessageDataFields());

			/**/
			// ByteArrayOutputStream baos = new ByteArrayOutputStream();
			// ObjectOutputStream oos = new ObjectOutputStream(baos);

			// oos.writeObject(messageDataFields.getMessageDataFields());

			// oos.flush();
			// oos.close();

			// InputStream input = new ByteArrayInputStream(baos.toByteArray());
			
			InputStream input = new ByteArrayInputStream(jsonString.getBytes());
			inboundTestServiceMinioDaoImpl.updateObject(input, runId, inputObjectId);
			messageDataFields.setMsgId(getMsgDataValue(messageDataFields));
			if(testInputDao.getTestInputDataMsgId(messageDataFields.getMsgId(),Long.parseLong(runId)) > 0)
			{
				throw new Exception("Duplicate Message Identification. Try again by providing unique value for Msg Id element.");
			}
			testInputDao.updateTestInputDescriptionPayMsgId(messageDataFields.getFileDesc(),messageDataFields.getMsgId(), Long.parseLong(runId));
			BusinessValidationJob businessValidationJob = new BusinessValidationJob();
			businessValidationJob.setRunId(runId);
			businessValidationJob.setInputObjectId(inputObjectId);
			businessValidationJob.setMessageDataFields(messageDataFields.getMessageDataFields());
			businessValidationJob.setMsgTypeId(messageDataFields.getMsgTypeId());
			businessValidationJob.setMsgId(messageDataFields.getMsgId());			
			businessValidationJob.setResponseMsgId(findInputResponseMsgId(Long.parseLong(runId)));
			messageHandlerQueueConfig.pushManualEntryBusinessValidationJob(businessValidationJob);
		} catch (Exception e) {
			log.info("RunId#"+runId+"processedOn#"+0);
			e.printStackTrace();
			throw e;
		}
	}
	
	public String findInputObjectId(Long runId) {
		String query = "SELECT object_id FROM test_input_data  WHERE run_id =" + runId + " LIMIT 1";
		return jdbcTemplate.queryForMap(query).get("object_id").toString();

	}
	
	public String findInputResponseMsgId(Long runId) {
		String query = "SELECT STRING_AGG(response_msg_id,',') as response_msg_id FROM test_input_data WHERE run_id = "+runId;
		return jdbcTemplate.queryForMap(query).get("response_msg_id").toString();

	}

}
