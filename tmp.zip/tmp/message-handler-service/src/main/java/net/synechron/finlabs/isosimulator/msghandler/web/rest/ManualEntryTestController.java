package net.synechron.finlabs.isosimulator.msghandler.web.rest;

import java.io.IOException;

import javax.xml.bind.JAXBException;
import javax.xml.parsers.ParserConfigurationException;
import javax.xml.transform.TransformerException;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import org.xml.sax.SAXException;

import io.swagger.annotations.ApiOperation;
import lombok.extern.slf4j.Slf4j;
import net.synechron.finlabs.isosimulator.msghandler.domain.ManualEntryData;
import net.synechron.finlabs.isosimulator.msghandler.domain.ManualEntryDataResp;
import net.synechron.finlabs.isosimulator.msghandler.domain.ValidationTestRespData;
import net.synechron.finlabs.isosimulator.msghandler.service.ManualEntryTestService;

@RestController
@Slf4j
@RequestMapping(path = "/api/payments")
@CrossOrigin("*")
public class ManualEntryTestController {

	@Autowired
	private ManualEntryTestService manualEntryTestService;

	@ApiOperation(value = "Create Manual Entry Test")
	@PostMapping(value = "/inbounds/tests/manualEntry", produces = MediaType.APPLICATION_JSON_VALUE, consumes = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<ValidationTestRespData> manualEntryData(@RequestBody ManualEntryData manualEntryData)
			throws IOException, TransformerException, ParserConfigurationException, SAXException, JAXBException {
		log.info("===enter into ManualEntryTestController manualEntryData===");
		ManualEntryDataResp manualEntryDataSave = manualEntryTestService.manualEntryDataSave(manualEntryData);
		ValidationTestRespData validationTestResp = new ValidationTestRespData();
		validationTestResp.setRunId(Long.parseLong(manualEntryDataSave.getRundId()));
		return new ResponseEntity<>(validationTestResp, HttpStatus.CREATED);
	}

	@ApiOperation(value = "Manual Entry Save as Draft")
	@PostMapping(value = "/inbounds/tests/{runId}/saveAsDraft", produces = MediaType.APPLICATION_JSON_VALUE, consumes = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<ValidationTestRespData> saveAsDraft(@RequestBody ManualEntryDataResp messageDataFields,
			@PathVariable String runId) throws IOException {
		log.info("===enter into ManualEntryTestController saveAsDraft===");
		manualEntryTestService.manualEntryDataSaveAsDraft(messageDataFields, runId);
		ValidationTestRespData validationTestResp = new ValidationTestRespData();
		validationTestResp.setRunId(Long.parseLong(runId));
		return new ResponseEntity<>(validationTestResp, HttpStatus.CREATED);
	}

	@ApiOperation(value = "Validate Manual Entry Data")
	@PostMapping(value = "/inbounds/tests/{runId}/validateData", produces = MediaType.APPLICATION_JSON_VALUE, consumes = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<ValidationTestRespData> validateData(@PathVariable String runId, @RequestBody ManualEntryDataResp messageDataFields)
			throws IOException {
		log.info("===enter into ManualEntryTestController validateData===");
		Long submittedOn = System.currentTimeMillis();
		manualEntryTestService.manualEntryValidateData(messageDataFields, runId);
		ValidationTestRespData validationTestResp = new ValidationTestRespData();
		validationTestResp.setRunId(Long.parseLong(runId));
		log.info("RunId#"+runId+"#userRequestSubmittedOn#"+submittedOn);
		return new ResponseEntity<>(validationTestResp,HttpStatus.CREATED);
	}
	
	@ApiOperation(value = "Create Manual Entry Outbound Test")
	@PostMapping(value = "/outbounds/tests/manualEntry", produces = MediaType.APPLICATION_JSON_VALUE, consumes = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<ValidationTestRespData> manualEntryOutbound(@RequestBody ManualEntryData manualEntryData)
			throws IOException, TransformerException, ParserConfigurationException, SAXException, JAXBException {
		log.info("===enter into ManualEntryTestController manualEntryOutbound===");
		ManualEntryDataResp manualEntryDataSave = manualEntryTestService.manualEntryDataSave(manualEntryData);
		ValidationTestRespData validationTestResp = new ValidationTestRespData();
		validationTestResp.setRunId(Long.parseLong(manualEntryDataSave.getRundId()));
		return new ResponseEntity<>(validationTestResp, HttpStatus.CREATED);
	}
	
	@ApiOperation(value = "Validate Manual Entry Data validateDataOutbound")
	@PostMapping(value = "/outbounds/tests/{runId}/validateData", produces = MediaType.APPLICATION_JSON_VALUE, consumes = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<ValidationTestRespData> validateDataOutbound(@PathVariable String runId, @RequestBody ManualEntryDataResp messageDataFields)
			throws Exception {
		log.info("===enter into ManualEntryTestController validateDataOutbound===");
		Long submittedOn = System.currentTimeMillis();
		manualEntryTestService.manualEntryOutputValidateData(messageDataFields, runId);
		ValidationTestRespData validationTestResp = new ValidationTestRespData();
		validationTestResp.setRunId(Long.parseLong(runId));
		log.info("RunId#"+runId+"#userRequestSubmittedOn#"+submittedOn);
		return new ResponseEntity<>(validationTestResp,HttpStatus.CREATED);
	}
	
	@ApiOperation(value = "outbounds Manual Entry Save as Draft")
	@PostMapping(value = "/outbounds/tests/{runId}/saveAsDraft", produces = MediaType.APPLICATION_JSON_VALUE, consumes = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<ValidationTestRespData> saveAsDraftOutbounds(@RequestBody ManualEntryDataResp messageDataFields,
			@PathVariable String runId) throws IOException {
		log.info("===enter into ManualEntryTestController saveAsDraftOutbounds===");
		manualEntryTestService.manualEntryDataSaveAsDraft(messageDataFields, runId);
		ValidationTestRespData validationTestResp = new ValidationTestRespData();
		validationTestResp.setRunId(Long.parseLong(runId));
		return new ResponseEntity<>(validationTestResp, HttpStatus.CREATED);
	}

}
