package net.synechron.finlabs.isosimulator.msghandler.domain;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.ToString;

@Data
@ToString
@NoArgsConstructor
@AllArgsConstructor
public class ManualEntryData {
	private String msgTypeId;
	private String testName;
	private String testDesc;
	private String tags;
	private String createdOn;
	private String fileName;
	private String fileDesc;
	private String[] responseMsgIds;
}
