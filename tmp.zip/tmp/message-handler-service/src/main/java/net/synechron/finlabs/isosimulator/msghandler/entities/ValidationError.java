package net.synechron.finlabs.isosimulator.msghandler.entities;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.ToString;

@Entity
@Table(name = "validation_error")
@Data
@ToString
@NoArgsConstructor
@AllArgsConstructor
public class ValidationError {
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	@Column(name = "id")
	private Long id;
	@Column(name = "run_id")
	private Long runId;
	@Column(name = "object_id")
	private String objectId;
	@Column(name = "msg_id")
	private String msgId;
	@Column(name = "xpath")
	private String xpath;
	@Column(name = "xml_element")
	private String xmlElement;
	@Column(name = "field_name")
	private String fieldName;
	@Column(name = "data")
	private String data;
	@Column(name = "error_message")
	private String errorMessage;

}
