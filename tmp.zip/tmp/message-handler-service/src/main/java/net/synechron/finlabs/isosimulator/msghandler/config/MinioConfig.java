package net.synechron.finlabs.isosimulator.msghandler.config;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import io.minio.MinioClient;
@Configuration
public class MinioConfig {
	
	@Value(value = "${application.minio.minioDBUrl}")
	String url;
	@Value(value = "${application.minio.minioDBUserNm}")
	String unm;
	@Value(value = "${application.minio.minioDBPw}")
	String pw;

	

    @Bean
    public MinioClient generateMinioClient() {
       	
			return MinioClient.builder().endpoint(url).credentials(unm, pw).build();

    }
}
