package net.synechron.finlabs.isosimulator.msghandler.service;

import java.io.File;
import java.io.IOException;
import java.io.InputStream;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import net.synechron.finlabs.isosimulator.msghandler.repository.TestServiceMinioDaoImpl;

@Service
public class InboundTestServiceMinioServiceImpl implements InboundTestServiceMinioService {

	@Autowired
	private TestServiceMinioDaoImpl inboundTestServiceMinioDaoImpl;

	@Override
	public String storeXMLFile(File file, Long runId) throws IOException {

		return inboundTestServiceMinioDaoImpl.storeXMLFile(file, runId);
	}

	@Override
	public InputStream downloadFile(String objectName) {

		return inboundTestServiceMinioDaoImpl.downloadFile(objectName);
	}

	@Override
	public void storeObject(InputStream messageDataFields, String runId) {

		inboundTestServiceMinioDaoImpl.storeObject(messageDataFields, runId);
	}

	@Override
	public InputStream getObject(String runId) {

		return inboundTestServiceMinioDaoImpl.getObject(runId);
	}

	@Override
	public void updateObject(InputStream messageDataFields, String runId, String ObjectId) {

		inboundTestServiceMinioDaoImpl.updateObject(messageDataFields, runId, ObjectId);

	}

}
