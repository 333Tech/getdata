package net.synechron.finlabs.isosimulator.msghandler.web.rest;

import java.io.IOException;
import java.io.StringReader;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;

import org.springframework.amqp.rabbit.annotation.RabbitListener;
import org.springframework.amqp.rabbit.core.RabbitTemplate;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestPart;
import org.springframework.web.bind.annotation.RestController;
import org.w3c.dom.Document;
import org.xml.sax.InputSource;
import org.xml.sax.SAXException;

import lombok.extern.slf4j.Slf4j;
import net.synechron.finlabs.isosimulator.middleware.model.ResponseMsgGenJob;
import net.synechron.finlabs.isosimulator.msghandler.config.ApplicationProperties;
import net.synechron.finlabs.isosimulator.msghandler.service.BridgeService;

@RestController
@Slf4j
@RequestMapping(path = "/api")
@CrossOrigin("*")
public class BridgeServiceController {

	@Autowired
	private ApplicationProperties appPropertiesObj;

	@Autowired
	private BridgeService bridgeService;

	@Autowired
	private RabbitTemplate template;

	@CrossOrigin("*")
	@PostMapping("/inbounds/messages")
	public void receiveMessages(String strXmlFile) {
		if (appPropertiesObj.getBridgeService().getIsActive()) {
			template.convertAndSend(appPropertiesObj.getRabbitMq().getXchangeIsoSimulator(),
					appPropertiesObj.getRabbitMq().getRkeyBridgeServiceInboundMsgReceive(), strXmlFile);
		}
	}

	@RabbitListener(queues = "${application.rabbitMq.queueBridgeServiceInboundMsgReceive}")
	public void inboundMsgReceive(String strXmlFile) throws ParserConfigurationException, SAXException, IOException {
		
		DocumentBuilderFactory dbfxsd = DocumentBuilderFactory.newInstance();
		DocumentBuilder dbxsd = dbfxsd.newDocumentBuilder();
		Document docXsd = dbxsd.parse(new InputSource(new StringReader(strXmlFile)));
		ResponseMsgGenJob responseMsgGenJob = new ResponseMsgGenJob();
		responseMsgGenJob.setXmlData(strXmlFile);
		responseMsgGenJob.setResponseMsgCodeId(
				bridgeService.findResponseMsgId(docXsd.getElementsByTagName("MsgId").item(0).getTextContent()));

		template.convertAndSend(appPropertiesObj.getRabbitMq().getXchangeIsoSimulator(),
				appPropertiesObj.getRabbitMq().getRkeyBridgeServiceInboundMsgProcess(), responseMsgGenJob);
	}
}
