package net.synechron.finlabs.isosimulator.msghandler.config;

public class ApplicationDefaultMessgHandler {

	interface Minio {
		String minioBucketNm = null;
		String minioDBUrl = null;
		String minioDBUserNm = null;
		String minioDBPw = null;
		String minioDFlod = null;
	}

	interface RabbitMQ {
		String queueMsgValidationFailure = null;
		String queueBusinessValidationOutcome = null;
		String rkeyXmlValidationJob = null;
		String xchangeIsoSimulator = null;
		String rkeyBusinessValidationResult = null;
		String rkeyXmlValidationFailure = null;
		String queueOutboundMsgResult = null;
		String rkeyOutboundMsgResult = null;	
		String queueManualEntryBizValidationFailure = null;
		String rkeyManualEntryBizValidationFailure = null;
		String queueManualEntryValidationResult = null;
		String rkeyManualEntryValidationResult = null;
		String rkeyManualEntryBizValidationJob = null;	
		String queueManualEntryOutboundValidationResult=null;
		String rkeyManualEntryOutboundValidationResult=null;		
		String rkeyBridgeServiceMessagePublish=null;
		String queueBridgeServiceMessagePublish=null;		
		String queueBridgeServiceInboundMsgReceive=null;
		String rkeyBridgeServiceInboundMsgReceive=null;
		String rkeyBridgeServiceInboundMsgProcess=null;
		
	}
	
	interface BridgeService {
		String url = null;
		Boolean isActive = false;
	}

}
