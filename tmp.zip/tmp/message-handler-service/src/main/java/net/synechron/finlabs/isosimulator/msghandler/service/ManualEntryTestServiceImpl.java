package net.synechron.finlabs.isosimulator.msghandler.service;

import java.io.IOException;

import javax.xml.bind.JAXBException;
import javax.xml.parsers.ParserConfigurationException;
import javax.xml.transform.TransformerException;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.xml.sax.SAXException;

import net.synechron.finlabs.isosimulator.msghandler.domain.ManualEntryData;
import net.synechron.finlabs.isosimulator.msghandler.domain.ManualEntryDataResp;
import net.synechron.finlabs.isosimulator.msghandler.repository.ManualEntryTestDaoImpl;

@Service
public class ManualEntryTestServiceImpl implements ManualEntryTestService {
	@Autowired
	private ManualEntryTestDaoImpl manualEntryTestDaoImpl;

	@Override
	public ManualEntryDataResp manualEntryDataSave(ManualEntryData manualEntryData)
			throws IOException, TransformerException, ParserConfigurationException, SAXException, JAXBException {

		return manualEntryTestDaoImpl.manualEntryDataSave(manualEntryData);
	}

	@Override
	public void manualEntryDataSaveAsDraft(ManualEntryDataResp messageDataFields, String rundId) throws IOException {

		manualEntryTestDaoImpl.manualEntryDataSaveAsDraft(messageDataFields, rundId);
	}

	@Override
	public void manualEntryValidateData(ManualEntryDataResp messageDataFields, String rundId) throws IOException {

		manualEntryTestDaoImpl.manualEntryValidateData(messageDataFields, rundId);

	}

	@Override
	public void manualEntryOutputValidateData(ManualEntryDataResp messageDataFields, String rundId) throws Exception {

		manualEntryTestDaoImpl.manualEntryOutputValidateData(messageDataFields, rundId);

	}
}
