package net.synechron.finlabs.isosimulator.msghandler.config;

import org.springframework.amqp.core.AmqpTemplate;
import org.springframework.amqp.core.Binding;
import org.springframework.amqp.core.BindingBuilder;
import org.springframework.amqp.core.Queue;
import org.springframework.amqp.core.TopicExchange;
import org.springframework.amqp.rabbit.connection.ConnectionFactory;
import org.springframework.amqp.rabbit.core.RabbitTemplate;
import org.springframework.amqp.support.converter.Jackson2JsonMessageConverter;
import org.springframework.amqp.support.converter.MessageConverter;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

@Configuration
public class MQConfig {

	@Autowired
	private ApplicationProperties appPropertiesObj;

	@Bean
	public Queue queueMsgValidationFailure() {
		return new Queue(appPropertiesObj.getRabbitMq().getQueueMsgValidationFailure());
	}

	@Bean
	public Queue queueBusinessValidationOutcome() {
		return new Queue(appPropertiesObj.getRabbitMq().getQueueBusinessValidationOutcome());
	}

	@Bean
	public Queue queueOutboundMsgResult() {
		return new Queue(appPropertiesObj.getRabbitMq().getQueueOutboundMsgResult());
	}

	@Bean
	public TopicExchange exchange() {
		return new TopicExchange(appPropertiesObj.getRabbitMq().getXchangeIsoSimulator());
	}

	@Bean
	public Binding bindingFrmMsgHndlrFailure(@Qualifier("queueMsgValidationFailure") Queue queue,
			TopicExchange exchange) {
		return BindingBuilder.bind(queue).to(exchange)
				.with(appPropertiesObj.getRabbitMq().getRkeyXmlValidationFailure());
	}

	@Bean
	public Binding bindingFrmMsgHndlrResult(@Qualifier("queueBusinessValidationOutcome") Queue queue,
			TopicExchange exchange) {
		return BindingBuilder.bind(queue).to(exchange)
				.with(appPropertiesObj.getRabbitMq().getRkeyBusinessValidationResult());
	}

	@Bean
	public Binding bindingFrmXferServiceResult(@Qualifier("queueOutboundMsgResult") Queue queue,
			TopicExchange exchange) {
		return BindingBuilder.bind(queue).to(exchange).with(appPropertiesObj.getRabbitMq().getRkeyOutboundMsgResult());
	}

	@Bean
	public Queue queueManualEntryBizValidationFailure() {

		return new Queue(appPropertiesObj.getRabbitMq().getQueueManualEntryBizValidationFailure());
	}

	@Bean
	public Queue queueManualEntryValidationResult() {

		return new Queue(appPropertiesObj.getRabbitMq().getQueueManualEntryValidationResult());
	}
	
	@Bean
	public Queue queueManualEntryOutboundValidationResult() {

		return new Queue(appPropertiesObj.getRabbitMq().getQueueManualEntryOutboundValidationResult());
	}
	
	@Bean
	public Queue queueBridgeServiceInboundMsgReceive() {

		return new Queue(appPropertiesObj.getRabbitMq().getQueueBridgeServiceInboundMsgReceive());
	}
	
	@Bean
	public Binding bindingBridgeServiceInboundMsgReceive(@Qualifier("queueBridgeServiceInboundMsgReceive") Queue queue,
			TopicExchange exchange) {
		return BindingBuilder.bind(queue).to(exchange)
				.with(appPropertiesObj.getRabbitMq().getRkeyBridgeServiceInboundMsgReceive());
	}

	@Bean
	public Binding bindingManualEntryBizValidationFailure(@Qualifier("queueManualEntryBizValidationFailure") Queue queue,
			TopicExchange exchange) {
		return BindingBuilder.bind(queue).to(exchange)
				.with(appPropertiesObj.getRabbitMq().getRkeyManualEntryBizValidationFailure());
	}
	@Bean
	public Binding bindingManualEntryValidationResult(@Qualifier("queueManualEntryValidationResult") Queue queue,
			TopicExchange exchange) {
		return BindingBuilder.bind(queue).to(exchange)
				.with(appPropertiesObj.getRabbitMq().getRkeyManualEntryValidationResult());
	}
	
	@Bean
	public Binding bindingQueueManualEntryOutboundValidationResult(@Qualifier("queueManualEntryOutboundValidationResult") Queue queue,
			TopicExchange exchange) {
		return BindingBuilder.bind(queue).to(exchange)
				.with(appPropertiesObj.getRabbitMq().getRkeyManualEntryOutboundValidationResult());
	}

	@Bean
	public Queue queueBridgeServiceMessagePublish() {

		return new Queue(appPropertiesObj.getRabbitMq().getQueueBridgeServiceMessagePublish());
	}

	@Bean
	public Binding bindingManualBridgeServiceMessagePublish(@Qualifier("queueBridgeServiceMessagePublish") Queue queue,
			TopicExchange exchange) {
		return BindingBuilder.bind(queue).to(exchange)
				.with(appPropertiesObj.getRabbitMq().getRkeyBridgeServiceMessagePublish());
	}
	
	@Bean
	public MessageConverter messageConverter() {
		return new Jackson2JsonMessageConverter();
	}

	@Bean
	public AmqpTemplate rabbitMqTemplate(ConnectionFactory connectionFactory) {
		RabbitTemplate template = new RabbitTemplate(connectionFactory);
		template.setMessageConverter(messageConverter());
		return template;
	}
}
