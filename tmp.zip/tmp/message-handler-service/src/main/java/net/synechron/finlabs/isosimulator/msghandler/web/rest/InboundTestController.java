package net.synechron.finlabs.isosimulator.msghandler.web.rest;

import java.io.IOException;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestPart;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;

import io.swagger.annotations.ApiOperation;
import lombok.extern.slf4j.Slf4j;
import net.synechron.finlabs.isosimulator.msghandler.domain.InboundDetailUpload;
import net.synechron.finlabs.isosimulator.msghandler.domain.ValidationTestRespData;
import net.synechron.finlabs.isosimulator.msghandler.entities.ValidationTest;
import net.synechron.finlabs.isosimulator.msghandler.service.InboundTestService;

@RestController
@Slf4j
@RequestMapping(path = "/api/payments")
@CrossOrigin("*")
public class InboundTestController {

	@Autowired
	private InboundTestService inboundTestService;

	@ApiOperation(value = "Create Inbound Test")
	@PostMapping(value = "/inbounds/tests",
			produces = MediaType.APPLICATION_JSON_VALUE, 
			consumes = {MediaType.APPLICATION_JSON_VALUE, MediaType.MULTIPART_FORM_DATA_VALUE})
	public ResponseEntity<ValidationTestRespData> uploadallFile(
			@RequestPart List<MultipartFile> file,
			@RequestPart(required = false, value="inboundDetailUpload") InboundDetailUpload inboundDetailUpload) throws IOException {
		log.info("Saving metadata to postgreSql server");
		Long submittedOn = System.currentTimeMillis();
		ValidationTest validationTestSave = inboundTestService.validationTestSave(inboundDetailUpload, file);
		ValidationTestRespData validationTestResp = new ValidationTestRespData();
		if(validationTestSave.getRunId()!=null) {
			log.info("RunId#"+validationTestSave.getRunId()+"#userRequestSubmittedOn#"+submittedOn);
			validationTestResp.setRunId(validationTestSave.getRunId());
			return new ResponseEntity<>(validationTestResp, HttpStatus.CREATED);
		}else {
			log.info("Exception while processing Inbound flow");
			return new ResponseEntity<>(validationTestResp, HttpStatus.INTERNAL_SERVER_ERROR);
		}
		
	}

}
