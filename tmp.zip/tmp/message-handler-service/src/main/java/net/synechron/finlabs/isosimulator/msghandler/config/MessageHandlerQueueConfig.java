package net.synechron.finlabs.isosimulator.msghandler.config;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

import org.apache.commons.io.IOUtils;
import org.springframework.amqp.rabbit.annotation.RabbitListener;
import org.springframework.amqp.rabbit.core.RabbitTemplate;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.stereotype.Component;
import org.springframework.web.client.RestTemplate;

import lombok.extern.slf4j.Slf4j;
import net.synechron.finlabs.isosimulator.TestOutputStatus;
import net.synechron.finlabs.isosimulator.ValidationTestStatus;
import net.synechron.finlabs.isosimulator.middleware.model.BusinessValidationJob;
import net.synechron.finlabs.isosimulator.middleware.model.BusinessValidationResult;
import net.synechron.finlabs.isosimulator.middleware.model.ManualEntryValidationResult;
import net.synechron.finlabs.isosimulator.middleware.model.OutboundMassageResult;
import net.synechron.finlabs.isosimulator.middleware.model.StructureValidationFail;
import net.synechron.finlabs.isosimulator.middleware.model.ValidationErrorData;
import net.synechron.finlabs.isosimulator.middleware.model.ValidationJob;
import net.synechron.finlabs.isosimulator.msghandler.entities.TestOutputData;
import net.synechron.finlabs.isosimulator.msghandler.entities.ValidationError;
import net.synechron.finlabs.isosimulator.msghandler.repository.ValidationTestStatusUpdateDao;
import net.synechron.finlabs.isosimulator.msghandler.repository.TestInputDao;
import net.synechron.finlabs.isosimulator.msghandler.repository.TestOutputDataDao;
import net.synechron.finlabs.isosimulator.msghandler.repository.TestServiceMinioDaoImpl;
import net.synechron.finlabs.isosimulator.msghandler.repository.ValidationErrorDao;

@Slf4j
@Component
public class MessageHandlerQueueConfig {

	@Autowired
	private ValidationErrorDao validationErrorDao;
	@Autowired
	private TestOutputDataDao testOutputDataDao;
	@Autowired
	private RabbitTemplate template;
	@Autowired
	private ApplicationProperties appPropertiesObj;
	@Autowired
	private TestInputDao inboundTestInputDao;
	@Autowired
	private TestOutputDataDao inboundTestOutPutDataDao;
	@Autowired
	private ValidationTestStatusUpdateDao inboundValidationTestDao;
	@Autowired
	private TestServiceMinioDaoImpl inboundTestServiceMinioDaoImpl;
	
	public void pushValidationJob(ValidationJob validationJob) {
		log.info("===validation object push in rabbitMq====queueManualEntryBizValidationJob");
		log.info("RunId#"+validationJob.getRunId()+"#taskSubmittedOn#"+System.currentTimeMillis());
		template.convertAndSend(appPropertiesObj.getRabbitMq().getXchangeIsoSimulator(),
				appPropertiesObj.getRabbitMq().getRkeyXmlValidationJob(), validationJob);
	}

	@RabbitListener(queues = "${application.rabbitMq.queueMsgValidationFailure}")
	public void getDataStructureValidationFail(StructureValidationFail strValidationFail) {
		
		TestOutputData testOutputDataTansformerService = new TestOutputData();
		log.debug("===>Read from Transformer Service to Message Handler===" + strValidationFail);
		String runId = strValidationFail.getRunId();
		testOutputDataTansformerService.setInputObjectId(strValidationFail.getInputObjectId());
		testOutputDataTansformerService.setStatus(TestOutputStatus.InvalidXML.name());
		testOutputDataTansformerService.setRunId(Long.parseLong(runId));
		testOutputDataTansformerService.setMsgId(strValidationFail.getMsgId());
		// save testOutputDataTansformerService
		testOutputDataDao.save(testOutputDataTansformerService);
		ValidationError validationError = new ValidationError();
		validationError.setRunId(Long.parseLong(runId));
		validationError.setObjectId(strValidationFail.getInputObjectId());
		validationError.setErrorMessage(strValidationFail.getErrorMessage());
		validationError.setMsgId(strValidationFail.getMsgId());
		// save validationError
		validationErrorDao.save(validationError);
		/**
		 * validationTest status update
		 */
		updatValidationTestStatus(Long.parseLong(runId), TestOutputStatus.Pass.name());
		log.info("RunId#"+runId+"#processedOn#"+System.currentTimeMillis());
	}

	@RabbitListener(queues = "${application.rabbitMq.queueBusinessValidationOutcome}")
	public void getBusinessValidationResult(BusinessValidationResult businessValidationResult) {
		log.debug("===>From Message Validator service to Message Handler===" + businessValidationResult.toString());
		TestOutputData testOutputDataBusinessValJob = new TestOutputData();
		String runId = businessValidationResult.getRunId();
		testOutputDataBusinessValJob.setRunId(Long.parseLong(runId));
		testOutputDataBusinessValJob.setInputObjectId(businessValidationResult.getInputObjectId());
		testOutputDataBusinessValJob.setStatus(businessValidationResult.getStatus().name());
		testOutputDataBusinessValJob.setMsgId(businessValidationResult.getMsgId());
		testOutputDataDao.save(testOutputDataBusinessValJob);

		if (businessValidationResult.getStatus().toString().equalsIgnoreCase(TestOutputStatus.Fail.toString())) {
			List<ValidationError> validationErrorList = new ArrayList<>();
			ValidationError validationError;
			List<ValidationErrorData> listValidationData = businessValidationResult.getValidationErrors();
			for (int i = 0; i < listValidationData.size(); i++) {
				validationError = new ValidationError();
				validationError.setXpath(listValidationData.get(i).getxPath());
				validationError.setXmlElement(listValidationData.get(i).getXmlElement());
				validationError.setFieldName(listValidationData.get(i).getFieldName());
				validationError.setData(listValidationData.get(i).getData());
				validationError.setErrorMessage(listValidationData.get(i).getErrorMessage());
				validationError.setRunId(Long.parseLong(runId));
				validationError.setObjectId(businessValidationResult.getInputObjectId());
				validationErrorList.add(validationError);
			}
			validationErrorDao.saveAll(validationErrorList);
		}
		/**
		 * validationTest status update
		 */
		updatValidationTestStatus(Long.parseLong(runId), TestOutputStatus.Pass.toString());
		log.info("RunId#"+runId+"#processedOn#"+System.currentTimeMillis());
	}

	public void updatValidationTestStatus(Long runId, String status) {
		Long countTestInputRunId = inboundTestInputDao.getCountTestInputRunId(runId);
		Long countTestOutputRunId = inboundTestOutPutDataDao.getCountTestOutputRunId(runId);

		if (countTestInputRunId == countTestOutputRunId) {
			Long passTestCnt = inboundTestOutPutDataDao.getStatusFrmRunIdWithStatus(runId, status);// pass
			if (passTestCnt == countTestInputRunId) {
				inboundValidationTestDao.updateValidationTest(ValidationTestStatus.Processed.toString(), runId);
			} else if (passTestCnt == 0) {
				inboundValidationTestDao.updateValidationTest(ValidationTestStatus.Failed.toString(), runId);
			} else {
				inboundValidationTestDao.updateValidationTest(ValidationTestStatus.Partial.toString(), runId);
			}
		}
	}

	@RabbitListener(queues = "${application.rabbitMq.queueOutboundMsgResult}")
	public void getOutBoundMessageResult(OutboundMassageResult outboundMsgResult) {
		log.debug("===>Read from Outbound Transformer Service to Message Handler===" + outboundMsgResult);
		TestOutputData testOutputOutboundMsgResult = new TestOutputData();
		String runId = outboundMsgResult.getRunId();
		testOutputOutboundMsgResult.setRunId(Long.parseLong(runId));
		testOutputOutboundMsgResult.setInputObjectId(outboundMsgResult.getInputObjectId());
		testOutputOutboundMsgResult.setOutObjectId(outboundMsgResult.getOutObjectId());
		testOutputOutboundMsgResult.setOutObjectName(outboundMsgResult.getOutObjectName());
		testOutputOutboundMsgResult.setResponseMsgId(outboundMsgResult.getResponseMsgId());
		testOutputOutboundMsgResult.setStatus(outboundMsgResult.getStatus());
		testOutputOutboundMsgResult.setMsgId(outboundMsgResult.getMsgId());
		testOutputDataDao.save(testOutputOutboundMsgResult);
		if (outboundMsgResult.getStatus().equalsIgnoreCase(TestOutputStatus.Fail.toString())) {
			ValidationError validationError = new ValidationError();
			validationError.setErrorMessage(outboundMsgResult.getErrorMessage());
			validationError.setMsgId(outboundMsgResult.getMsgId());
			validationError.setRunId(Long.parseLong(runId));
			validationError.setObjectId(outboundMsgResult.getInputObjectId());
			validationErrorDao.save(validationError);
		}
		updatValidationTestStatus(Long.parseLong(runId), TestOutputStatus.Pass.toString());
		log.info("RunId#"+runId+"#processedOn#"+System.currentTimeMillis());
		
		if (appPropertiesObj.getBridgeService().getIsActive()) {
			template.convertAndSend(appPropertiesObj.getRabbitMq().getXchangeIsoSimulator(),
					appPropertiesObj.getRabbitMq().getRkeyBridgeServiceMessagePublish(),
					outboundMsgResult.getInputObjectId());
		}
	}

	public void pushManualEntryBusinessValidationJob(BusinessValidationJob businessValidationJob) {
		log.info("===businessValidationJob object push in rabbitMq for validator service====");
		template.convertAndSend(appPropertiesObj.getRabbitMq().getXchangeIsoSimulator(),
				appPropertiesObj.getRabbitMq().getRkeyManualEntryBizValidationJob(), businessValidationJob);
	}

	@RabbitListener(queues = "${application.rabbitMq.queueManualEntryBizValidationFailure}")
	public void getManualEntryBusinessValidationResultFailure(
			BusinessValidationResult manualEntrybusinessValidationResult) {
		log.debug("===getManualEntryValidatorResult ====");
		TestOutputData testOutputDataBizValidation = new TestOutputData();
		testOutputDataBizValidation.setRunId(Long.parseLong(manualEntrybusinessValidationResult.getRunId()));
		testOutputDataBizValidation.setInputObjectId(manualEntrybusinessValidationResult.getInputObjectId());
		testOutputDataBizValidation.setMsgId(manualEntrybusinessValidationResult.getMsgId());
		testOutputDataBizValidation.setStatus(manualEntrybusinessValidationResult.getStatus().name());
		testOutputDataDao.save(testOutputDataBizValidation);
		if (manualEntrybusinessValidationResult.getStatus().toString()
				.equalsIgnoreCase(TestOutputStatus.Fail.toString())) {
			List<ValidationError> validationErrorList = new ArrayList<>();
			ValidationError validationError;
			List<ValidationErrorData> listValidationData = manualEntrybusinessValidationResult.getValidationErrors();
			for (int i = 0; i < listValidationData.size(); i++) {
				validationError = new ValidationError();
				validationError.setXpath(listValidationData.get(i).getxPath());
				validationError.setXmlElement(listValidationData.get(i).getXmlElement());
				validationError.setFieldName(listValidationData.get(i).getFieldName());
				validationError.setData(listValidationData.get(i).getData());
				validationError.setErrorMessage(listValidationData.get(i).getErrorMessage());
				validationError.setRunId(Long.parseLong(manualEntrybusinessValidationResult.getRunId()));
				validationError.setObjectId(manualEntrybusinessValidationResult.getInputObjectId());
				validationErrorList.add(validationError);
			}
			validationErrorDao.saveAll(validationErrorList);
		}
		/**
		 * validationTest status update
		 */
		updatValidationTestStatus(Long.parseLong(manualEntrybusinessValidationResult.getRunId()),
				TestOutputStatus.Pass.name());
		log.info("RunId#"+testOutputDataBizValidation.getRunId()+"#processedOn#"+System.currentTimeMillis());
	}

	@RabbitListener(queues = "${application.rabbitMq.queueManualEntryValidationResult}")
	public void getManualEntryValidationResult(ManualEntryValidationResult manualEntryValidationResult) {
		log.info("===getManualEntryValidatorResult ====");
		TestOutputData testOutputDataManualEntryXfservice = new TestOutputData();
		testOutputDataManualEntryXfservice.setRunId(Long.parseLong(manualEntryValidationResult.getRunId()));
		testOutputDataManualEntryXfservice.setInputObjectId(manualEntryValidationResult.getInputObjectId());
		testOutputDataManualEntryXfservice.setMsgId(manualEntryValidationResult.getMsgId());
		testOutputDataManualEntryXfservice.setOutObjectName(manualEntryValidationResult.getOutObjectName());
		testOutputDataManualEntryXfservice.setOutObjectId(manualEntryValidationResult.getOutObjectId());
		testOutputDataManualEntryXfservice.setStatus(manualEntryValidationResult.getStatus());
		testOutputDataDao.save(testOutputDataManualEntryXfservice);
		if (manualEntryValidationResult.getStatus().equalsIgnoreCase(TestOutputStatus.Fail.toString())) {
			ValidationError validationError = new ValidationError();
			validationError.setRunId(Long.parseLong(manualEntryValidationResult.getRunId()));
			validationError.setObjectId(manualEntryValidationResult.getInputObjectId());
			validationError.setErrorMessage(manualEntryValidationResult.getErrorMessage());
			validationError.setMsgId(manualEntryValidationResult.getMsgId());
			// save validationError
			validationErrorDao.save(validationError);
		}
		/**
		 * validationTest status update
		 */
		updatValidationTestStatus(Long.parseLong(manualEntryValidationResult.getRunId()), TestOutputStatus.Pass.name());
		log.info("RunId#"+testOutputDataManualEntryXfservice.getRunId()+"#processedOn#"+System.currentTimeMillis());
	}
	
	@RabbitListener(queues = "${application.rabbitMq.queueManualEntryOutboundValidationResult}")
	public void getManualEntryOutboundValidationResult(ArrayList<ManualEntryValidationResult> manualEntryValidationResult) {

		log.info("===getManualEntryOutboundValidationResult ===="+manualEntryValidationResult);
		for (int i = 0; i < manualEntryValidationResult.size(); i++) {
			TestOutputData testOutputDataManualEntryXfservice = new TestOutputData();
			testOutputDataManualEntryXfservice.setRunId(Long.parseLong(manualEntryValidationResult.get(i).getRunId()));
			testOutputDataManualEntryXfservice.setInputObjectId(manualEntryValidationResult.get(i).getInputObjectId());
			testOutputDataManualEntryXfservice.setMsgId(manualEntryValidationResult.get(i).getMsgId());
			testOutputDataManualEntryXfservice.setOutObjectName(manualEntryValidationResult.get(i).getOutObjectName());
			testOutputDataManualEntryXfservice.setOutObjectId(manualEntryValidationResult.get(i).getOutObjectId());
			testOutputDataManualEntryXfservice.setStatus(manualEntryValidationResult.get(i).getStatus());
			testOutputDataManualEntryXfservice.setResponseMsgId(manualEntryValidationResult.get(i).getResponseMsgId());
			testOutputDataDao.save(testOutputDataManualEntryXfservice);
			inboundTestInputDao.updateTestInputObjectId(manualEntryValidationResult.get(i).getInputObjectId(), Long.parseLong(manualEntryValidationResult.get(i).getRunId()));

			if (manualEntryValidationResult.get(i).getStatus().equalsIgnoreCase(TestOutputStatus.Fail.toString())) {
				ValidationError validationError = new ValidationError();
				validationError.setRunId(Long.parseLong(manualEntryValidationResult.get(i).getRunId()));
				validationError.setObjectId(manualEntryValidationResult.get(i).getInputObjectId());
				validationError.setErrorMessage(manualEntryValidationResult.get(i).getErrorMessage());
				validationError.setMsgId(manualEntryValidationResult.get(i).getMsgId());
				// save validationError
				validationErrorDao.save(validationError);
			}
			/**
			 * validationTest status update
			 */
			updatValidationTestStatus(Long.parseLong(manualEntryValidationResult.get(i).getRunId()), TestOutputStatus.Pass.name());
//			log.info("RunId#"+testOutputDataManualEntryXfservice.getRunId()+"#processedOn#"+System.currentTimeMillis());
				
		}
		if (appPropertiesObj.getBridgeService().getIsActive()) {
			template.convertAndSend(appPropertiesObj.getRabbitMq().getXchangeIsoSimulator(),
					appPropertiesObj.getRabbitMq().getRkeyBridgeServiceMessagePublish(),
					manualEntryValidationResult.get(0).getInputObjectId());
		}
	}
	
	@RabbitListener(queues = "${application.rabbitMq.queueBridgeServiceMessagePublish}")
	public void listernerQueueBridgeServiceMessagePublish(String inputObjectId) throws IOException {
		HttpHeaders headers = new HttpHeaders();
		headers.setContentType(MediaType.TEXT_PLAIN);
		HttpEntity<String> entity = new HttpEntity<String>(
				IOUtils.toString(inboundTestServiceMinioDaoImpl.getObject(inputObjectId), StandardCharsets.UTF_8),
				headers);
		new RestTemplate().postForObject(appPropertiesObj.getBridgeService().getUrl(), entity, String.class);
	}
}
