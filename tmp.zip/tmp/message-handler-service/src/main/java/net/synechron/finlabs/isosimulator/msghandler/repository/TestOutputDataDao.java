package net.synechron.finlabs.isosimulator.msghandler.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import net.synechron.finlabs.isosimulator.msghandler.entities.TestOutputData;

@Repository
public interface TestOutputDataDao extends JpaRepository<TestOutputData, Long> {

	@Query("SELECT COUNT(t1) FROM TestOutputData t1 where t1.runId =:runId")
	public Long getCountTestOutputRunId(@Param("runId") long runId);
	
	@Query("SELECT t1.status FROM TestOutputData t1 where t1.runId =:testRunId")
	public String getStatus(@Param("testRunId") long testRunId);
	
	@Query("SELECT COUNT(t1) FROM TestOutputData t1 where t1.runId =:testRunId AND t1.status =:status")
	public Long getStatusFrmRunIdWithStatus(@Param("testRunId") long testRunId,@Param("status") String status);
}
