package net.synechron.finlabs.isosimulator.msghandler.web.rest;

import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

import java.io.IOException;
import java.security.InvalidKeyException;
import java.security.NoSuchAlgorithmException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import org.junit.jupiter.api.BeforeEach;
import org.junit.runner.RunWith;
import org.mockito.Mockito;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.MediaType;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.test.web.servlet.MockMvc;

import com.fasterxml.jackson.databind.ObjectMapper;

import io.minio.MinioClient;
import io.minio.UploadObjectArgs;
import io.minio.errors.ErrorResponseException;
import io.minio.errors.InsufficientDataException;
import io.minio.errors.InternalException;
import io.minio.errors.InvalidBucketNameException;
import io.minio.errors.InvalidResponseException;
import io.minio.errors.RegionConflictException;
import io.minio.errors.ServerException;
import io.minio.errors.XmlParserException;
import lombok.extern.slf4j.Slf4j;
import net.synechron.finlabs.isosimulator.domain.IsoMessageMetaData;
import net.synechron.finlabs.isosimulator.domain.SampleMsgData;
import net.synechron.finlabs.isosimulator.middleware.model.MessageDataField;
import net.synechron.finlabs.isosimulator.msghandler.AbstractIT;
import net.synechron.finlabs.isosimulator.msghandler.config.MessageHandlerQueueConfig;
import net.synechron.finlabs.isosimulator.msghandler.domain.ManualEntryData;
import net.synechron.finlabs.isosimulator.msghandler.domain.ManualEntryDataResp;
import net.synechron.finlabs.isosimulator.msghandler.repository.IsoMesageMetaDataTestDao;
import net.synechron.finlabs.isosimulator.msghandler.repository.ManualEntryTestDaoImplTest;
import net.synechron.finlabs.isosimulator.msghandler.repository.SampleMsgDataDao;
import net.synechron.finlabs.isosimulator.msghandler.service.ManualEntryTestServiceImpl;

@AutoConfigureMockMvc
@Slf4j
public class ManualEntryTestControllerTest extends AbstractIT {

	@Autowired
	private MockMvc mockMvc;

	@Autowired
	public ManualEntryTestServiceImpl manualEntryTestServiceImpl;

	@MockBean
	private MessageHandlerQueueConfig messageHandlerQueueConfig;

	@Autowired
	private IsoMesageMetaDataTestDao isoMessageDataTest;
	
	@Autowired
	SampleMsgDataDao sampleMsgData;
	
	@Autowired
	MinioClient minioClient;

	private static ObjectMapper mapper = new ObjectMapper();

	public void storeFile() {
		System.out.println("storeFile()");
		String minioFileNameWithPath;
		String objectName = "pacs.008.001.08.xsl";
		try {
			minioFileNameWithPath = "C:\\git\\develop_14_02\\message-handler-service\\src\\test\\resources\\pacs.008.001.08.xsl";

			minioClient.makeBucket(BUCKET_NAME);
			UploadObjectArgs uploadObjectArgs = UploadObjectArgs.builder().bucket(BUCKET_NAME).object(objectName)
					.filename(minioFileNameWithPath).build();
			minioClient.uploadObject(uploadObjectArgs);
		} catch (InvalidKeyException | ErrorResponseException | IllegalArgumentException | InsufficientDataException
				| InternalException | InvalidBucketNameException | InvalidResponseException | NoSuchAlgorithmException
				| ServerException | XmlParserException | RegionConflictException | IOException e) {
			minioFileNameWithPath = "fail";
			log.error("Getting error while storing file in server", e);
		}
	}
	
	@BeforeEach
	public void initEach() {
		ManualEntryTestDaoImplTest manualEntryTestDaoImplTest = new ManualEntryTestDaoImplTest();
		// Store the xls files.
		storeFile();

		System.out.println("isoMesgDataSaveTest method call");
		IsoMessageMetaData msgData = new IsoMessageMetaData();
		msgData.setId("pacs.008.001.08");
		msgData.setName("pacs.008");
		msgData.setVersion("001.08");
		msgData.setXmlns("urn:iso:std:iso:20022:tech:xsd:pacs.008.001.08");
		msgData.setXsdObjectId("pacs.008.001.08.xsd");
		msgData.setXslObjectId("pacs.008.001.08.xsl");
		IsoMessageMetaData save = isoMessageDataTest.save(msgData);
		SampleMsgData smlObj=new SampleMsgData();
		smlObj.setDescription("pacs.008");
		smlObj.setIsoMsgId("pacs.008.001.08");
		SampleMsgData saveSmpl = sampleMsgData.save(smlObj);

		String id = save.getId();

	}
	
	@org.junit.jupiter.api.Test
	public void testManualEntryData() throws Exception {
		ManualEntryData manualEntryData = new ManualEntryData();
		manualEntryData.setCreatedOn("2022-01-25 10:44");
		manualEntryData.setFileName("file");
		manualEntryData.setFileDesc("fileDesc");
		manualEntryData.setMsgTypeId("pacs.008.001.08");
		manualEntryData.setTags("tags");
		manualEntryData.setTestName("test1");
		manualEntryData.setTestDesc("test1Desc");

		ManualEntryDataResp respData = new ManualEntryDataResp();

		manualEntryTestServiceImpl = org.mockito.Mockito.mock(ManualEntryTestServiceImpl.class);

		Mockito.when(manualEntryTestServiceImpl.manualEntryDataSave(manualEntryData)).thenReturn(respData);
		String json = mapper.writeValueAsString(manualEntryData);
		mockMvc.perform(post("/payments/inbounds/tests/manualEntry").contentType(MediaType.APPLICATION_JSON)
				.characterEncoding("utf-8").content(json).accept(MediaType.APPLICATION_JSON))
				.andExpect(status().isCreated());
	}

	@org.junit.jupiter.api.Test
	public void testSaveAsDraft() throws Exception {
		ManualEntryDataResp manualEntryDataResp = new ManualEntryDataResp();
		manualEntryDataResp.setFileDesc("manual testing");
		manualEntryDataResp.setTags("manual_1");

		MessageDataField msgField = new MessageDataField();
		msgField.setDataKey("");
		msgField.setFieldDataRepresentation("string,unique");
		msgField.setFieldDescription("MessageIdentification");
		msgField.setFieldMaxLength("35");
		msgField.setFieldMinLength("1");
		msgField.setGroupName("");
		// msgField.setIsValid();
		msgField.setParentGroupName("");
		msgField.setPatternType("");
		msgField.setSequenceNum("");
		msgField.setTagName("MsgId");
		msgField.setValue("34634754753463475475346388");
		msgField.setxPath("FIToFICstmrCdtTrf/GrpHdr/MsgId");
		List<MessageDataField> msg = new ArrayList<>(Arrays.asList(msgField));
		manualEntryDataResp.setMessageDataFields(msg);
		// String runId = "700";
		String json = mapper.writeValueAsString(msgField);
		mockMvc.perform(post("/payments/inbounds/tests/700/saveAsDraft").contentType(MediaType.APPLICATION_JSON)
				.characterEncoding("utf-8").content(json).accept(MediaType.APPLICATION_JSON))
				.andExpect(status().isCreated());
	}

	@org.junit.jupiter.api.Test
	public void testValidateData() throws Exception {
		ManualEntryDataResp manualEntryDataResp = new ManualEntryDataResp();
		manualEntryDataResp.setFileDesc("manual testing");
		manualEntryDataResp.setTags("manual_1");

		MessageDataField msgField = new MessageDataField();
		msgField.setDataKey("");
		msgField.setFieldDataRepresentation("string,unique");
		msgField.setFieldDescription("MessageIdentification");
		msgField.setFieldMaxLength("35");
		msgField.setFieldMinLength("1");
		msgField.setGroupName("");
		// msgField.setIsValid();
		msgField.setParentGroupName("");
		msgField.setPatternType("");
		msgField.setSequenceNum("");
		msgField.setTagName("MsgId");
		msgField.setValue("34634754753463475475346388");
		msgField.setxPath("FIToFICstmrCdtTrf/GrpHdr/MsgId");
		List<MessageDataField> msg = new ArrayList<>(Arrays.asList(msgField));
		// String runId = "700";
		manualEntryDataResp.setMessageDataFields(msg);
		String json = mapper.writeValueAsString(msgField);
		mockMvc.perform(post("/payments/inbounds/tests/700/validateData").contentType(MediaType.APPLICATION_JSON)
				.characterEncoding("utf-8").content(json).accept(MediaType.APPLICATION_JSON))
				.andExpect(status().isCreated());
	}

}
