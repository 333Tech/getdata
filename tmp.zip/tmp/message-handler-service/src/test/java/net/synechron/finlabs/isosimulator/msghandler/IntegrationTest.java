package net.synechron.finlabs.isosimulator.msghandler;

import java.lang.annotation.ElementType;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;
import net.synechron.finlabs.isosimulator.msghandler.MessageHandlerServiceApp;
import org.springframework.boot.test.context.SpringBootTest;

/**
 * Base composite annotation for integration tests.
 */
@Target(ElementType.TYPE)
@Retention(RetentionPolicy.RUNTIME)
@SpringBootTest(classes = MessageHandlerServiceApp.class)
public @interface IntegrationTest {
}
