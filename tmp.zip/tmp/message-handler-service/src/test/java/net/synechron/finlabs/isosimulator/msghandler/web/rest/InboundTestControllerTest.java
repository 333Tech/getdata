package net.synechron.finlabs.isosimulator.msghandler.web.rest;

import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.when;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import org.mockito.Mock;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.MediaType;
import org.springframework.mock.web.MockMultipartFile;
import org.springframework.web.multipart.MultipartFile;

import net.synechron.finlabs.isosimulator.msghandler.AbstractIT;
import net.synechron.finlabs.isosimulator.msghandler.config.MessageHandlerQueueConfig;
import net.synechron.finlabs.isosimulator.msghandler.domain.InboundDetailUpload;
import net.synechron.finlabs.isosimulator.msghandler.domain.UploadFileDetails;
import net.synechron.finlabs.isosimulator.msghandler.entities.ValidationTest;
import net.synechron.finlabs.isosimulator.msghandler.service.InboundTestService;


@AutoConfigureMockMvc
public class InboundTestControllerTest extends AbstractIT {

	@Autowired
	InboundTestController inboundTestController;

	@Mock
	private InboundTestService inboundTestService;

	@MockBean
	ValidationTest validationTest;

	@MockBean
	MessageHandlerQueueConfig messageHandlerQueueConfig;

	@org.junit.jupiter.api.Test
	public void testUploadFile() throws IOException {

		InboundDetailUpload inboundDetailUpload = new InboundDetailUpload();
		inboundDetailUpload.setTestName("test upload");
		inboundDetailUpload.setTestDescription("upload file");
		inboundDetailUpload.setCreatedOn("2022-01-25 10:44");

		UploadFileDetails uploadFileDetails = new UploadFileDetails();
		uploadFileDetails.setComments("test");
		uploadFileDetails.setFileName("hello.xml");
		uploadFileDetails.setMsgTypeId("pacs.008.001.08");
		uploadFileDetails.setResponseMSgId("pacs.008.1.1.AC01");

		List<UploadFileDetails> uploadFileDetailsList = new ArrayList<UploadFileDetails>();
		uploadFileDetailsList.add(uploadFileDetails);
		inboundDetailUpload.setFiles(uploadFileDetailsList);

		MultipartFile file = new MockMultipartFile("file", "hello.xml", MediaType.TEXT_XML_VALUE,
				"Hello, World!".getBytes());
		List<MultipartFile> testInputFiles = new ArrayList<>();
		testInputFiles.add(file);

		when(inboundTestService.validationTestSave(any(InboundDetailUpload.class),
				(List<MultipartFile>) any(MultipartFile.class))).thenReturn(validationTest);

		inboundTestController.uploadallFile(testInputFiles, inboundDetailUpload);

	}

}
