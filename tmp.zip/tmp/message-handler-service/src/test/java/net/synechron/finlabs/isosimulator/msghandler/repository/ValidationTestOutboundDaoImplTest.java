package net.synechron.finlabs.isosimulator.msghandler.repository;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;

import java.io.IOException;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.List;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.MediaType;
import org.springframework.mock.web.MockMultipartFile;
import org.springframework.web.multipart.MultipartFile;

import net.synechron.finlabs.isosimulator.InputSourceType;
import net.synechron.finlabs.isosimulator.ValidationTestStatus;
import net.synechron.finlabs.isosimulator.msghandler.AbstractIT;
import net.synechron.finlabs.isosimulator.msghandler.config.MessageHandlerQueueConfig;
import net.synechron.finlabs.isosimulator.msghandler.domain.InboundDetailUpload;
import net.synechron.finlabs.isosimulator.msghandler.domain.UploadFileDetails;
import net.synechron.finlabs.isosimulator.msghandler.entities.ValidationTest;

class ValidationTestOutboundDaoImplTest extends AbstractIT {
	@Autowired
	private ValidationTestOutboundDaoImpl validationTestOutboundDaoImpl;
	
	@MockBean
	private MessageHandlerQueueConfig messageHandlerQueueConfig;

	@Test
	void testValidationTestOutboundSave() throws IOException {
		InboundDetailUpload inboundDetailUpload = new InboundDetailUpload();
		ValidationTest validationTest = new ValidationTest();
		inboundDetailUpload.setTestName("test upload");
		inboundDetailUpload.setTestDescription("upload file");
		inboundDetailUpload.setCreatedOn("2022-01-25 10:44");

		UploadFileDetails uploadFileDetails = new UploadFileDetails();
		uploadFileDetails.setComments("test");
		uploadFileDetails.setFileName("hello.xml");
		uploadFileDetails.setMsgTypeId("pacs.008.001.08");
		uploadFileDetails.setResponseMSgId("pacs.008.1.1.AC01");

		validationTest.setTestName(inboundDetailUpload.getTestName());
		validationTest.setDescription(inboundDetailUpload.getTestDescription());
		// date in String
		String dateString = inboundDetailUpload.getCreatedOn();
		DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm");
		// Parse String to LocalDateTime
		LocalDateTime dateTime = LocalDateTime.parse(dateString, formatter);
		validationTest.setCreatedOn(dateTime);
		validationTest.setPaymentType(net.synechron.finlabs.isosimulator.PaymentType.Outbound.name());
		validationTest.setStatus(ValidationTestStatus.InProgress.name());
		validationTest.setInputSourceType(InputSourceType.FileUpload.name());

		List<UploadFileDetails> uploadFileDetailsList = new ArrayList<UploadFileDetails>();
		uploadFileDetailsList.add(uploadFileDetails);
		inboundDetailUpload.setFiles(uploadFileDetailsList);
		MultipartFile file = new MockMultipartFile("file", "hello.xml", MediaType.TEXT_XML_VALUE,
				"Hello, World!".getBytes());
		List<MultipartFile> testInputFiles = new ArrayList<>();
		testInputFiles.add(file);
		ValidationTest validationTestOutboundSave = validationTestOutboundDaoImpl.validationTestOutboundSave(inboundDetailUpload, testInputFiles);
		assertEquals((Object)1L, (Object)validationTestOutboundSave.getRunId());

	}

	@Test
	void testConvertUploadFile() throws IOException {
		
		assertNotNull(validationTestOutboundDaoImpl.convertUploadFile(
				new MockMultipartFile("foo", "foo.xml", MediaType.TEXT_XML_VALUE, "Hello World".getBytes())));

	}

}
