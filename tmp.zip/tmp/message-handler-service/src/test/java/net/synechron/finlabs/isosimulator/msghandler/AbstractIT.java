package net.synechron.finlabs.isosimulator.msghandler;

import java.time.Duration;

import org.springframework.boot.test.autoconfigure.jdbc.AutoConfigureTestDatabase;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.context.ApplicationContextInitializer;
import org.springframework.context.ConfigurableApplicationContext;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.support.TestPropertySourceUtils;
import org.testcontainers.containers.GenericContainer;
import org.testcontainers.containers.PostgreSQLContainer;
import org.testcontainers.containers.wait.strategy.HttpWaitStrategy;
import org.testcontainers.junit.jupiter.Testcontainers;

@ActiveProfiles("test")
@SpringBootTest(webEnvironment = SpringBootTest.WebEnvironment.RANDOM_PORT)
@AutoConfigureTestDatabase(replace = AutoConfigureTestDatabase.Replace.NONE)
@ContextConfiguration(initializers = { AbstractIT.DockerPostgreDataSourceInitializer.class,
		AbstractIT.DockerMinioInitializer.class })
@Testcontainers
public class AbstractIT {
	public static PostgreSQLContainer<?> postgreDBContainer = new PostgreSQLContainer<>("postgres:9.4");

	public static final String ADMIN_ACCESS_KEY = "minioadmin";
	public static final String ADMIN_SECRET_KEY = "minioadmin";
	
	public final static String BUCKET_NAME = "iso-simulator";
	//TODO Change to random port. 
	static int port = 9000;
	public static GenericContainer<?> minioServer = new GenericContainer<>("minio/minio").withEnv("MINIO_ACCESS_KEY", ADMIN_ACCESS_KEY)
			.withEnv("MINIO_SECRET_KEY", ADMIN_SECRET_KEY).withCommand("server /data").withExposedPorts(port)
			.waitingFor(new HttpWaitStrategy().forPath("/minio/health/ready").forPort(port)
					.withStartupTimeout(Duration.ofSeconds(10)));
					
	static {
		postgreDBContainer.start();
		minioServer.start();
	}

	public static class DockerPostgreDataSourceInitializer
			implements ApplicationContextInitializer<ConfigurableApplicationContext> {

		@Override
		public void initialize(ConfigurableApplicationContext applicationContext) {

			TestPropertySourceUtils.addInlinedPropertiesToEnvironment(applicationContext,
					"spring.datasource.url=" + postgreDBContainer.getJdbcUrl(),
					"spring.datasource.username=" + postgreDBContainer.getUsername(),
					"spring.datasource.password=" + postgreDBContainer.getPassword());

		}
	}

	public static class DockerMinioInitializer
			implements ApplicationContextInitializer<ConfigurableApplicationContext> {
		
		@Override
		public void initialize(ConfigurableApplicationContext applicationContext) {
			Integer mappedPort = minioServer.getFirstMappedPort();
			String minioServerUrl = String.format("http://%s:%s", minioServer.getContainerIpAddress(), mappedPort);
			
			TestPropertySourceUtils.addInlinedPropertiesToEnvironment(applicationContext,
					"application.minio.minioDBUrl=" + minioServerUrl,
					"application.minio.minioDBUserNm=" + ADMIN_ACCESS_KEY,
					"application.minio.minioDBPw=" + ADMIN_SECRET_KEY,
					"application.minio.minioBucketNm=" +BUCKET_NAME);
		}

	}
}
