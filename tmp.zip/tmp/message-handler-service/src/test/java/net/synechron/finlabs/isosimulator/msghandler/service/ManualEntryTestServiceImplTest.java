package net.synechron.finlabs.isosimulator.msghandler.service;

import static org.junit.Assert.assertNotNull;

import java.io.IOException;

import javax.xml.bind.JAXBException;
import javax.xml.parsers.ParserConfigurationException;
import javax.xml.transform.TransformerException;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringRunner;
import org.xml.sax.SAXException;

import net.synechron.finlabs.isosimulator.msghandler.domain.ManualEntryData;
import net.synechron.finlabs.isosimulator.msghandler.domain.ManualEntryDataResp;

@RunWith(SpringRunner.class)
@SpringBootTest
public class ManualEntryTestServiceImplTest {

	@Autowired
	private ManualEntryTestServiceImpl manualEntryTestServiceImpl;

	@Test
	public void testManualEntryDataSave()
			throws IOException, TransformerException, ParserConfigurationException, SAXException, JAXBException {
		ManualEntryData manualEntryData = new ManualEntryData();
		manualEntryData.setCreatedOn("2022-01-25 10:44");
		manualEntryData.setFileDesc("file");
		manualEntryData.setFileName("fileDesc");
		manualEntryData.setMsgTypeId("pacs.008.001.08");
		manualEntryData.setTags("tags");
		manualEntryData.setTestName("test1");
		manualEntryData.setTestDesc("test1Desc");
		assertNotNull(manualEntryTestServiceImpl.manualEntryDataSave(manualEntryData));

	}

	@Test
	public void testManualEntryDataSaveAsDraft() throws IOException {
		ManualEntryDataResp manualEntryDataResp = new ManualEntryDataResp();
		manualEntryDataResp.setFileDesc("manual testing");
		manualEntryDataResp.setTags("manual_1");
		String runId = "677";

		manualEntryTestServiceImpl.manualEntryDataSaveAsDraft(manualEntryDataResp, runId);
	}

	@Test
	public void testManualEntryValidateData() throws IOException {
		
		String runId = "677";
		ManualEntryDataResp manualEntryDataResp = new ManualEntryDataResp();
		manualEntryDataResp.setFileDesc("manual testing");
		manualEntryDataResp.setTags("manual_1");
		
		manualEntryTestServiceImpl.manualEntryValidateData(manualEntryDataResp, runId);

	}

}
