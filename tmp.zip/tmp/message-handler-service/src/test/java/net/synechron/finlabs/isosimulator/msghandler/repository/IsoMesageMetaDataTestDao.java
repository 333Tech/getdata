package net.synechron.finlabs.isosimulator.msghandler.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import net.synechron.finlabs.isosimulator.domain.IsoMessageMetaData;

public interface IsoMesageMetaDataTestDao extends JpaRepository<IsoMessageMetaData, String> {

}
