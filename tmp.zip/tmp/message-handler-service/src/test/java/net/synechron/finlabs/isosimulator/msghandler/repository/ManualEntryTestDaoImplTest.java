package net.synechron.finlabs.isosimulator.msghandler.repository;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertEquals;

import java.io.IOException;
import java.security.InvalidKeyException;
import java.security.NoSuchAlgorithmException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import javax.xml.bind.JAXBException;
import javax.xml.parsers.ParserConfigurationException;
import javax.xml.transform.TransformerException;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Disabled;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.xml.sax.SAXException;

import io.minio.MinioClient;
import io.minio.UploadObjectArgs;
import io.minio.errors.ErrorResponseException;
import io.minio.errors.InsufficientDataException;
import io.minio.errors.InternalException;
import io.minio.errors.InvalidBucketNameException;
import io.minio.errors.InvalidResponseException;
import io.minio.errors.RegionConflictException;
import io.minio.errors.ServerException;
import io.minio.errors.XmlParserException;
import lombok.extern.slf4j.Slf4j;
import net.synechron.finlabs.isosimulator.domain.IsoMessageMetaData;
import net.synechron.finlabs.isosimulator.domain.SampleMsgData;
import net.synechron.finlabs.isosimulator.middleware.model.MessageDataField;
import net.synechron.finlabs.isosimulator.msghandler.AbstractIT;
import net.synechron.finlabs.isosimulator.msghandler.config.MessageDataFields;
import net.synechron.finlabs.isosimulator.msghandler.config.MessageHandlerQueueConfig;
import net.synechron.finlabs.isosimulator.msghandler.domain.ManualEntryData;
import net.synechron.finlabs.isosimulator.msghandler.domain.ManualEntryDataResp;

@Slf4j
public class ManualEntryTestDaoImplTest extends AbstractIT {

	@Autowired
	private ManualEntryTestDaoImpl manualEntryTestDaoImpl;

	@Autowired
	IsoMesageMetaDataTestDao isoMessageDataTest;
	
	@Autowired
	SampleMsgDataDao sampleMsgData;

	@Autowired
	MinioClient minioClient;

	@MockBean
	private MessageHandlerQueueConfig messageHandlerQueueConfig;

	public void storeFile() {
		System.out.println("storeFile()");
		String minioFileNameWithPath;
		String objectName = "pacs.008.001.08.xsl";
		try {
			minioFileNameWithPath = "C:\\git\\develop_14_02\\message-handler-service\\src\\test\\resources\\pacs.008.001.08.xsl";

			minioClient.makeBucket(BUCKET_NAME);
			UploadObjectArgs uploadObjectArgs = UploadObjectArgs.builder().bucket(BUCKET_NAME).object(objectName)
					.filename(minioFileNameWithPath).build();
			minioClient.uploadObject(uploadObjectArgs);
		} catch (InvalidKeyException | ErrorResponseException | IllegalArgumentException | InsufficientDataException
				| InternalException | InvalidBucketNameException | InvalidResponseException | NoSuchAlgorithmException
				| ServerException | XmlParserException | RegionConflictException | IOException e) {
			minioFileNameWithPath = "fail";
			log.error("Getting error while storing file in server", e);
		}
	}

	@BeforeEach
	public void initEach() {
		// Store the xls files.
		storeFile();

		System.out.println("isoMesgDataSaveTest method call");
		IsoMessageMetaData msgData = new IsoMessageMetaData();
		msgData.setId("pacs.008.001.08");
		msgData.setName("pacs.008");
		msgData.setVersion("001.08");
		msgData.setXmlns("urn:iso:std:iso:20022:tech:xsd:pacs.008.001.08");
		msgData.setXsdObjectId("pacs.008.001.08.xsd");
		msgData.setXslObjectId("pacs.008.001.08.xsl");
		IsoMessageMetaData save = isoMessageDataTest.save(msgData);
		SampleMsgData smlObj=new SampleMsgData();
		smlObj.setDescription("pacs.008");
		smlObj.setIsoMsgId("pacs.008.001.08");
		SampleMsgData saveSmpl = sampleMsgData.save(smlObj);
		String id = save.getId();
		log.info("id==>" + id);
	}

	@org.junit.jupiter.api.Test
	public void testManualEntryDataSave()
			throws IOException, TransformerException, ParserConfigurationException, SAXException, JAXBException {

		ManualEntryData manualEntryData = new ManualEntryData();
		manualEntryData.setCreatedOn("2022-01-25 10:44");
		manualEntryData.setFileDesc("file");
		manualEntryData.setFileName("fileDesc");
		manualEntryData.setMsgTypeId("pacs.008.001.08");
		manualEntryData.setTags("tags");
		manualEntryData.setTestName("test1");
		manualEntryData.setTestDesc("test1Desc");
		// assertNotNull(manualEntryTestDaoImpl.manualEntryDataSave(manualEntryData));
		ManualEntryDataResp manualEntryDataSave = manualEntryTestDaoImpl.manualEntryDataSave(manualEntryData);
		Long runId= Long.parseLong(manualEntryDataSave.getRundId());
		assertEquals(1L,runId);
	}

	@org.junit.jupiter.api.Test
	public void testConvertXslToXmlToJavaObj()
			throws TransformerException, ParserConfigurationException, SAXException, IOException, JAXBException {
		MessageDataFields msgData = new MessageDataFields();
		ManualEntryData manualEntryData = new ManualEntryData();
		manualEntryData.setCreatedOn("2022-01-25 10:44");
		manualEntryData.setFileDesc("file");
		manualEntryData.setFileName("fileDesc");
		manualEntryData.setMsgTypeId("pacs.008.001.08");
		manualEntryData.setTags("tags");
		manualEntryData.setTestName("test2");
		manualEntryData.setTestDesc("test2Desc");
		String runId = "1";
	    manualEntryTestDaoImpl.convertXslToXmlToJavaObj(runId,
				manualEntryData);
	}

	/*
	 * use this @Disabled annotation if any one want to disabled specific test case
	 */
	// @Disabled
	@org.junit.jupiter.api.Test
	public void testManualEntryDataSaveAsDraft() throws IOException {
		ManualEntryDataResp manualEntryDataResp = new ManualEntryDataResp();
		manualEntryDataResp.setFileDesc("manual testing");
		manualEntryDataResp.setTags("manual_1");

		MessageDataField msgField = new MessageDataField();
		msgField.setDataKey("");
		msgField.setFieldDataRepresentation("string,unique");
		msgField.setFieldDescription("MessageIdentification");
		msgField.setFieldMaxLength("35");
		msgField.setFieldMinLength("1");
		msgField.setGroupName("");
		// msgField.setIsValid();
		msgField.setParentGroupName("");
		msgField.setPatternType("");
		msgField.setSequenceNum("");
		msgField.setTagName("MsgId");
		msgField.setValue("34634754753463475475346388");
		msgField.setxPath("FIToFICstmrCdtTrf/GrpHdr/MsgId");

		List<MessageDataField> msg = new ArrayList<>(Arrays.asList(msgField));

		manualEntryDataResp.setMessageDataFields(msg);

		String runId = "1";
		manualEntryTestDaoImpl.manualEntryDataSaveAsDraft(manualEntryDataResp, runId);

	}

	@org.junit.jupiter.api.Test
	public void testManualEntryValidateData() throws IOException {
		String runId = "1";
		ManualEntryDataResp manualEntryDataResp = new ManualEntryDataResp();
		manualEntryDataResp.setFileDesc("manual testing");
		manualEntryDataResp.setTags("manual_1");

		MessageDataField msgField = new MessageDataField();
		msgField.setDataKey("");
		msgField.setFieldDataRepresentation("string,unique");
		msgField.setFieldDescription("MessageIdentification");
		msgField.setFieldMaxLength("35");
		msgField.setFieldMinLength("1");
		msgField.setGroupName("");
		// msgField.setIsValid("tt");
		msgField.setParentGroupName("");
		msgField.setPatternType("");
		msgField.setSequenceNum("");
		msgField.setTagName("MsgId");
		msgField.setValue("34634754753463475475346388");
		msgField.setxPath("FIToFICstmrCdtTrf/GrpHdr/MsgId");

		List<MessageDataField> msg = new ArrayList<>(Arrays.asList(msgField));
		manualEntryDataResp.setMessageDataFields(msg);
		manualEntryTestDaoImpl.manualEntryValidateData(manualEntryDataResp, runId);
	}

}
