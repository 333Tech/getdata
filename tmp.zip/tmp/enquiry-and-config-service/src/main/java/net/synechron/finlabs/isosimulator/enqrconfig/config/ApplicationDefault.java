package net.synechron.finlabs.isosimulator.enqrconfig.config;

public interface ApplicationDefault {
	
	interface Minio {
		String minioBucketNm = null;
		String minioDBUrl = null;
		String minioDBUserNm = null;
		String minioDBPw = null;
		String minioDFlod = null;
	}
}
