package net.synechron.finlabs.isosimulator.enqrconfig.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import io.swagger.annotations.ApiOperation;
import lombok.extern.slf4j.Slf4j;
import net.synechron.finlabs.isosimulator.enqrconfig.dto.DashboardDto;
import net.synechron.finlabs.isosimulator.enqrconfig.dto.SimulatorResponseDto;
import net.synechron.finlabs.isosimulator.enqrconfig.service.DashboardService;

/**
 * @author Amol.Mandlik
 *
 */

@RestController
@Slf4j
@RequestMapping(path = "/api")
@CrossOrigin("*")
public class DashboardController {
	
	@Autowired
	DashboardService dashboardService;
	
	@ApiOperation(value = "Get Dashboard Details")
	@GetMapping(path = "/dashboard")
	public ResponseEntity<DashboardDto> displayDashboard(){
		DashboardDto dashboardDto = new DashboardDto();
		try {
			dashboardDto.setStatusCounts(dashboardService.displayQuickSummaryDashboard());
			dashboardDto.setRecentTests(dashboardService.recentTests(10));
			dashboardDto.setTotalTestRuns(dashboardService.getAllTestsCount());
			return new ResponseEntity<>(dashboardDto, HttpStatus.OK);
		} catch (Exception e) {
			log.error("Exception :"+e.getMessage());
			return new ResponseEntity<>(dashboardDto, HttpStatus.INTERNAL_SERVER_ERROR);
		}
	}
	
	@ApiOperation(value = "Get Simulator Response Details")
	@GetMapping(path = "/dashboard/simulatorResponses/{inboundMsgTypeId}/forDays/{days}")
	public ResponseEntity<List<SimulatorResponseDto>> displaySimulatorResposne(
			@PathVariable(value = "inboundMsgTypeId")String inboundMsgTypeId,
			@PathVariable(required = false, value = "days") int days){
		try {
			List<SimulatorResponseDto> reslist = dashboardService.displaySimulatorResposne(inboundMsgTypeId, days);
			return new ResponseEntity<>(reslist, HttpStatus.OK);
		} catch (Exception e) {
			e.printStackTrace();
			log.error("Exception :"+e.getMessage());
			return new ResponseEntity<>(null, HttpStatus.INTERNAL_SERVER_ERROR);
		}
	}
}
