package net.synechron.finlabs.isosimulator.enqrconfig.dao;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import net.synechron.finlabs.isosimulator.domain.IsoMessageMetaData;

/**
 * @author Amol.Mandlik
 *
 */
@Repository
public interface IsoMessageMetaDataDao extends JpaRepository<IsoMessageMetaData, String> {

	public IsoMessageMetaData findByNameAndVersionAndInboundMsgId(String name, String version,String inboundMsgId);
	
}
