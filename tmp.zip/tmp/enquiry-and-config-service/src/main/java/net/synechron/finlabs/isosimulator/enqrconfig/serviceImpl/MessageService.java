package net.synechron.finlabs.isosimulator.enqrconfig.serviceImpl;

import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.Reader;
import java.util.Arrays;
import java.util.List;
import java.util.Optional;

import javax.annotation.PostConstruct;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.io.ClassPathResource;
import org.springframework.core.io.ResourceLoader;
import org.springframework.stereotype.Service;
import org.springframework.util.FileCopyUtils;

import com.google.gson.Gson;

import net.synechron.finlabs.isosimulator.domain.IsoMessageMetaData;
import net.synechron.finlabs.isosimulator.enqrconfig.dao.SampleMsgDataDao;
import net.synechron.finlabs.isosimulator.enqrconfig.dto.ConfigMessageDto;
import net.synechron.finlabs.isosimulator.enqrconfig.dto.IsoMessageMetaDataDto;
import net.synechron.finlabs.isosimulator.enqrconfig.dto.ResponseMessageDto;
import net.synechron.finlabs.isosimulator.enqrconfig.dto.SampleMsgDataDto;
import net.synechron.finlabs.isosimulator.enqrconfig.service.ConfigService;

/**
 * @author Amol.Mandlik
 *
 */
@Service
public class MessageService {

	private static final Logger logger = LoggerFactory.getLogger(MessageService.class.getName());

	@Autowired
	ConfigService confService;
	
	@Autowired
	private SampleMsgDataDao sampleMsgDataDao;

	@Autowired
	ResourceLoader resourceLoader;

	@PostConstruct
	public void initapplication() throws Exception {

		try {
			ClassLoader classloader = Thread.currentThread().getContextClassLoader();
			InputStream is = classloader.getResourceAsStream("configservice/confmsg.json");
			Reader reader = new InputStreamReader(is);
			ConfigMessageDto[] congMsg = new Gson().fromJson(reader, ConfigMessageDto[].class);

			if (congMsg.length > 0) {
				for (ConfigMessageDto configMessageDto : congMsg) {

					if (!confService.findByNameAndVersionAndInboundMsgId(configMessageDto.getMsgTypeName(),
							configMessageDto.getVersion(), configMessageDto.getInboundMsgId())) {

						List<String> fileNames = Arrays.asList(configMessageDto.getXsdFilePath(),
								configMessageDto.getXslFilePath(), configMessageDto.getXmlFilePath());
						Optional<List<String>> fileList = Optional.ofNullable(fileNames);

						if (fileList.isPresent() && fileNames.size() >= 2) {

							IsoMessageMetaDataDto isoMessageMetadata = new IsoMessageMetaDataDto();

							for (String fileName : fileNames) {
								if (fileName != null && !fileName.isEmpty()) {
									ClassPathResource classPathResource = new ClassPathResource(fileName);
									byte[] binaryData = FileCopyUtils
											.copyToByteArray(classPathResource.getInputStream());

									isoMessageMetadata.setMsgId(configMessageDto.getMsgId());
									isoMessageMetadata.setMsgTypeName(configMessageDto.getMsgTypeName());
									isoMessageMetadata.setVersion(configMessageDto.getVersion());
									isoMessageMetadata.setDescription(configMessageDto.getDescription());
									isoMessageMetadata.setInboundMsgId(configMessageDto.getInboundMsgId());
									isoMessageMetadata.setMsgType(configMessageDto.getMsgType());
									isoMessageMetadata.setPaymentMsgIdXpath(configMessageDto.getPaymentMsgIdXpath());

									String xsdxslid = confService.uploadFile(fileName.split("/")[1], binaryData);

									if (!xsdxslid.startsWith("fail")) {
										if (xsdxslid.endsWith(".xsd")) {
											isoMessageMetadata.setXsdObjectId(xsdxslid);
											isoMessageMetadata
													.setXmlns(confService.getXsdNS(classPathResource.getInputStream()));
										} else if (xsdxslid.contains(".xsl"))
											isoMessageMetadata.setXslObjectId(xsdxslid);
									//	else if (xsdxslid.contains(".xml"))
									//		isoMessageMetadata.setXmlObjectId(xsdxslid);
									}
								}
								IsoMessageMetaData confMsg = confService.saveConfigMessage(isoMessageMetadata);
								logger.info("config message inserted :" + confMsg);
							}
						} else if (fileNames.size() == 1) {
							logger.error("both xsd and xsl files are required");
						} else {
							logger.error("Xsd and xsl files are not found in given src/configservice folder");
						}
					}
				}
			} else {
				logger.info("config json object are missing in confmsg.json file");
			}
			
			//Start : Logic for sample data.
			if (congMsg.length > 0) {
				SampleMsgDataDto sampleMsgData;
				String path="configservice/";
				for (ConfigMessageDto configMessageDto : congMsg) {
					String filename=configMessageDto.getMsgTypeName() + "." + configMessageDto.getVersion();
					if((configMessageDto.getInboundMsgId() == null && sampleMsgDataDao.findByxmlObjectId(filename+".xml") == null)
							&& (configMessageDto.getMsgType() != null && configMessageDto.getMsgType().equalsIgnoreCase("0")))
					{
						ClassPathResource classPathResource = new ClassPathResource(path+filename+".xml");
						byte[] binaryData = FileCopyUtils.copyToByteArray(classPathResource.getInputStream());

						sampleMsgData = new SampleMsgDataDto();
						sampleMsgData.setIsoMsgId(filename);
						sampleMsgData.setValid(true);
						sampleMsgData.setSize(String.valueOf(java.lang.Math.ceil(binaryData.length / 1024)) + " KB");
						sampleMsgData.setDescription(configMessageDto.getDescription());
						String xsdxslid = confService.uploadFile(filename+".xml", binaryData);

						if (!xsdxslid.startsWith("fail")) {
							sampleMsgData.setXmlObjectId(xsdxslid);
						}
						confService.saveSampleMsgData(sampleMsgData);
					}
				}
			}
			//End : Logic for sample data.
		
			InputStream is2 = classloader.getResourceAsStream("configservice/responsecodes.json");
			Reader reader2 = new InputStreamReader(is2);
			ResponseMessageDto[] respMsg = new Gson().fromJson(reader2, ResponseMessageDto[].class);

			if (respMsg.length > 0) {
				for (ResponseMessageDto responseMessageDto : respMsg) {
					confService.createResponseMessage(responseMessageDto.getIntiatorMsgTypeId(), responseMessageDto,
							responseMessageDto.getResponseMsgId());
				}
			} else {
				logger.info("response code json object are missing in responsecodes.json file");
			}
		} catch (Exception e) {
			logger.error("Exception :" + e.getMessage());
			e.printStackTrace();
		}
	}

}
