package net.synechron.finlabs.isosimulator.enqrconfig.serviceImpl;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.security.InvalidKeyException;
import java.security.NoSuchAlgorithmException;
import java.security.SecureRandom;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Base64;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.stream.Collectors;

import javax.xml.bind.JAXBContext;
import javax.xml.bind.Unmarshaller;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;
import javax.xml.transform.Result;
import javax.xml.transform.Source;
import javax.xml.transform.Templates;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;
import javax.xml.transform.stream.StreamSource;

import org.apache.commons.io.IOUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.jdbc.core.BeanPropertyRowMapper;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Service;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.xml.sax.SAXException;

import com.hazelcast.core.HazelcastInstance;
import com.hazelcast.core.IMap;

import io.minio.BucketExistsArgs;
import io.minio.MakeBucketArgs;
import io.minio.MinioClient;
import io.minio.errors.ErrorResponseException;
import io.minio.errors.InsufficientDataException;
import io.minio.errors.InternalException;
import io.minio.errors.InvalidBucketNameException;
import io.minio.errors.InvalidResponseException;
import io.minio.errors.ServerException;
import io.minio.errors.XmlParserException;
import net.synechron.finlabs.isosimulator.CommonFunction;
import net.synechron.finlabs.isosimulator.domain.IsoMessageMetaData;
import net.synechron.finlabs.isosimulator.domain.ReferenceData;
import net.synechron.finlabs.isosimulator.domain.ResponseMessage;
import net.synechron.finlabs.isosimulator.domain.SampleMsgData;
import net.synechron.finlabs.isosimulator.enqrconfig.config.ApplicationProperties;
import net.synechron.finlabs.isosimulator.enqrconfig.config.MinioClientConnection;
import net.synechron.finlabs.isosimulator.enqrconfig.dao.IsoMessageMetaDataDao;
import net.synechron.finlabs.isosimulator.enqrconfig.dao.ResponseMessageDao;
import net.synechron.finlabs.isosimulator.enqrconfig.dao.SampleMsgDataDao;
import net.synechron.finlabs.isosimulator.enqrconfig.domain.DocumentElement;
import net.synechron.finlabs.isosimulator.enqrconfig.dto.FileResponse;
import net.synechron.finlabs.isosimulator.enqrconfig.dto.IsoMessageMetaDataDto;
import net.synechron.finlabs.isosimulator.enqrconfig.dto.ReferenceDataDto;
import net.synechron.finlabs.isosimulator.enqrconfig.dto.ReferenceResponse;
import net.synechron.finlabs.isosimulator.enqrconfig.dto.ResponseMessageDto;
import net.synechron.finlabs.isosimulator.enqrconfig.dto.SampleMsgDataDto;
import net.synechron.finlabs.isosimulator.enqrconfig.service.ConfigService;
import net.synechron.finlabs.isosimulator.middleware.model.MessageDataField;

@Service
public class ConfigServiceImpl implements ConfigService {

	private static final Logger logger = LoggerFactory.getLogger(ConfigServiceImpl.class.getName());

	@Autowired
	private JdbcTemplate jdbcTemplate;

	@Autowired
	private StaticDataService staticDataServiceObj;

	@Autowired
	private ResponseMessageDao responseMessageDao;

	@Autowired
	private SampleMsgDataDao sampleMsgDataDao;

	@Autowired
	private ApplicationProperties appPropertiesObj;

	@Autowired
	private IsoMessageMetaDataDao isoMessageDao;

	@Autowired
	private HazelcastInstance hazelcastInstance;
	
	@Value(value = "${hazelcast.config.isomessages}")
	private String isoMessages;

	@Value(value = "${hazelcast.config.responseMessage}")
	private String responseMessages;

	@Override
	public IsoMessageMetaData saveConfigMessage(IsoMessageMetaDataDto configMessage) {
		IsoMessageMetaData isoMsg = new IsoMessageMetaData();
		try {
			IMap<String, IsoMessageMetaData> dataStore = hazelcastInstance.getMap(isoMessages);
			Optional<IsoMessageMetaData> optIso = isoMessageDao.findById(configMessage.getMsgId());

			if (!optIso.isPresent()) {
				isoMsg.setId(configMessage.getMsgId());
				isoMsg.setName(configMessage.getMsgTypeName());
				isoMsg.setVersion(configMessage.getVersion());
				isoMsg.setDescription(configMessage.getDescription());
				isoMsg.setXsdObjectId(configMessage.getXsdObjectId());
				isoMsg.setXslObjectId(configMessage.getXslObjectId());
				isoMsg.setXmlns(configMessage.getXmlns());
				isoMsg.setInboundMsgId(configMessage.getInboundMsgId());
				isoMsg.setMsgType(configMessage.getMsgType());
				isoMsg.setPaymentMsgIdXpath(configMessage.getPaymentMsgIdXpath());
			} else {
				IsoMessageMetaData msgMetadata = optIso.get();
				isoMsg.setId(msgMetadata.getId());
				isoMsg.setName(msgMetadata.getName());
				isoMsg.setVersion(msgMetadata.getVersion());
				isoMsg.setInboundMsgId(msgMetadata.getInboundMsgId());
				isoMsg.setMsgType(configMessage.getMsgType());
				if (Optional.ofNullable(configMessage.getDescription()).isPresent())
					isoMsg.setDescription(configMessage.getDescription());
				else
					isoMsg.setDescription(msgMetadata.getDescription());
				if (Optional.ofNullable(configMessage.getXsdObjectId()).isPresent())
					isoMsg.setXsdObjectId(configMessage.getXsdObjectId());
				else
					isoMsg.setXsdObjectId(msgMetadata.getXsdObjectId());
				if (Optional.ofNullable(configMessage.getXslObjectId()).isPresent())
					isoMsg.setXslObjectId(configMessage.getXslObjectId());
				else
					isoMsg.setXsdObjectId(msgMetadata.getXslObjectId());
				if (Optional.ofNullable(configMessage.getXmlns()).isPresent())
					isoMsg.setXmlns(configMessage.getXmlns());
				else
					isoMsg.setXmlns(msgMetadata.getXmlns());
				if (Optional.ofNullable(configMessage.getPaymentMsgIdXpath()).isPresent())
					isoMsg.setPaymentMsgIdXpath(configMessage.getPaymentMsgIdXpath());
				else
					isoMsg.setPaymentMsgIdXpath(msgMetadata.getPaymentMsgIdXpath());
			}
			dataStore.put(isoMsg.getId(), isoMsg);
		} catch (Exception e) {
			logger.error("Exception :" + e.getMessage());
			e.printStackTrace();
		}
		return isoMsg;
	}

	public String generateRandomBase64Token(int byteLength) {
		SecureRandom secureRandom = new SecureRandom();
		byte[] token = new byte[byteLength];
		secureRandom.nextBytes(token);
		return Base64.getUrlEncoder().withoutPadding().encodeToString(token); // base64 encoding
	}

	@Override
	public boolean findByNameAndVersionAndInboundMsgId(String name, String version, String inboundMsgId) {
		try {
			Optional<IsoMessageMetaData> optIso = Optional
					.ofNullable(isoMessageDao.findByNameAndVersionAndInboundMsgId(name, version, inboundMsgId));
			return optIso.isPresent();
		} catch (Exception e) {
			logger.error("Exception :" + e.getMessage());
			e.printStackTrace();
			return false;
		}
	}

	@Override
	public List<IsoMessageMetaData> getAllConfigMessages() {
		List<IsoMessageMetaData> confList = new ArrayList<>();
		try {
			IMap<String, IsoMessageMetaData> dataStore = hazelcastInstance.getMap(isoMessages);
			if (dataStore.isEmpty())
				dataStore.loadAll(true);
			for (Map.Entry<String, IsoMessageMetaData> entry : dataStore.entrySet()) {
				confList.add(entry.getValue());
			}
		} catch (Exception e) {
			logger.error("Exception :" + e.getMessage());
			e.printStackTrace();
		}
		return confList;
	}

	@Override
	public String uploadFile(String name, byte[] content) {
		File file = new File("/tmp/" + name); // TODO Remove the file on storing to Minio or error of method.
		file.canWrite();
		file.canRead();

		try {
			String bucketName = appPropertiesObj.getMinio().getMinioBucketNm();
			MinioClient minioClient = MinioClientConnection.getInstance(appPropertiesObj.getMinio().getMinioDBUrl(),
					appPropertiesObj.getMinio().getMinioDBUserNm(), appPropertiesObj.getMinio().getMinioDBPw());

			boolean bucketExist = minioClient.bucketExists(BucketExistsArgs.builder().bucket(bucketName).build());

			if (!bucketExist) {
				minioClient.makeBucket(MakeBucketArgs.builder().bucket(bucketName).build());
			}
			FileOutputStream iofs = new FileOutputStream(file);
			iofs.write(content);
			minioClient.putObject(bucketName, name, file.getAbsolutePath(), null);

		} catch (Exception e) {
			name = "fail" + e.getMessage();
			logger.error("Exception :" + e.getMessage());
			e.printStackTrace();
		}
		return name;
	}

	public byte[] downloadFile(String key) {
		byte[] content = new byte[1];
		try {

			MinioClient minioClient = MinioClientConnection.getInstance(appPropertiesObj.getMinio().getMinioDBUrl(),
					appPropertiesObj.getMinio().getMinioDBUserNm(), appPropertiesObj.getMinio().getMinioDBPw());
			String defaultBucketName = appPropertiesObj.getMinio().getMinioBucketNm();
			String defaultFlod = appPropertiesObj.getMinio().getMinioDFlod();

			InputStream obj = minioClient.getObject(defaultBucketName, defaultFlod + key);
			content = IOUtils.toByteArray(obj);
			obj.close();
			return content;
		} catch (Exception e) {
			logger.error("Exception :" + e.getMessage());
			e.printStackTrace();
		}
		return content;
	}
	
	public void deleteFile(String key) throws InvalidKeyException, ErrorResponseException, IllegalArgumentException,
			InsufficientDataException, InternalException, InvalidBucketNameException, InvalidResponseException,
			NoSuchAlgorithmException, ServerException, XmlParserException, IOException {
		MinioClient minioClient = MinioClientConnection.getInstance(appPropertiesObj.getMinio().getMinioDBUrl(),
				appPropertiesObj.getMinio().getMinioDBUserNm(), appPropertiesObj.getMinio().getMinioDBPw());
		String defaultBucketName = appPropertiesObj.getMinio().getMinioBucketNm();
		String defaultFlod = appPropertiesObj.getMinio().getMinioDFlod();

		minioClient.removeObject(defaultBucketName, defaultFlod + key);
	}

	@Override
	public boolean findById(String id) {
		return isoMessageDao.findById(id).isPresent();
	}

	@Override
	public List<ResponseMessageDto> getResponseMessages(String intiatorMsgTypeId) {
		List<ResponseMessageDto> respMsgs = new ArrayList<>();
		try {
			IMap<String, ResponseMessage> dataStore = hazelcastInstance.getMap(responseMessages);
			if (dataStore.isEmpty())
				dataStore.loadAll(true);
			for (Map.Entry<String, ResponseMessage> data : dataStore.entrySet()) {
				ResponseMessage resMsg = data.getValue();
				if (resMsg.getInitiatorMsgId().equals(intiatorMsgTypeId)) {

					respMsgs.add(new ResponseMessageDto(resMsg.getId(), resMsg.getCode(), resMsg.getName(),
							resMsg.getDefinition(), resMsg.getResponseMsgId(), resMsg.getInitiatorMsgId()));
				}
			}
		} catch (Exception e) {
			logger.error("Exception :" + e.getMessage());
			e.printStackTrace();
		}
		return respMsgs;
	}

	@Override
	public String createResponseMessage(String intiatorMsgTypeId, ResponseMessageDto responseMessageDto,
			String resMesgTypeId) {
		String response = null;
		try {

			Optional<ResponseMessage> respMsg = Optional.ofNullable(
					responseMessageDao.findByCodeAndResponseMsgIdAndInitiatorMsgId(responseMessageDto.getCode(),
							resMesgTypeId, intiatorMsgTypeId));
			if (!respMsg.isPresent()) {
				ResponseMessage responseMessage = new ResponseMessage();
				if (responseMessageDto.getId() != null && !responseMessageDto.getId().trim().isEmpty()) {
					responseMessage.setId(responseMessageDto.getId());
				} else {
					String resId = resMesgTypeId.substring(0,
							resMesgTypeId.length() - (intiatorMsgTypeId.length() + 1));
					responseMessage
							.setId(resId + "." + responseMessageDto.getCode() + "." + generateRandomBase64Token(16));
				}
				responseMessage.setResponseMsgId(resMesgTypeId);
				responseMessage.setCode(responseMessageDto.getCode());
				responseMessage.setName(responseMessageDto.getName());
				responseMessage.setDefinition(responseMessageDto.getDefinition());
				responseMessage.setInitiatorMsgId(intiatorMsgTypeId);
				// inserting responseMessage into dB through hazelcast
				IMap<String, ResponseMessage> dataStore = hazelcastInstance.getMap(responseMessages);
				dataStore.put(responseMessage.getId(), responseMessage);
				response = responseMessage.getId();
			} else {
				response = "Response message record with combination of Name,responseMsgId and intiatorMsgId already present";
				logger.info("Exception While creating response message");
			}
		} catch (Exception e) {
			response = "Exception While creating response message";
			logger.error("Exception While creating response message :" + e.getMessage());
			e.printStackTrace();
		}
		return response;
	}

	@Override
	public List<IsoMessageMetaDataDto> getAllInboundsConfigs() {
		List<IsoMessageMetaDataDto> responseList = null;

		try {
			String query = "select id as msgId, name as msgTypeName, version, description,xmlns as xmlns, xsd_object_id as xsdObjectId, "
					+ "xsl_object_id as xslObjectId, inbound_msg_id as inboundMsgId from iso_message_metadata where msg_type in ('0','2')";

			responseList = jdbcTemplate.query(query,
					new BeanPropertyRowMapper<IsoMessageMetaDataDto>(IsoMessageMetaDataDto.class));
		} catch (Exception e) {
			logger.error("Exception :" + e.getMessage());
			e.printStackTrace();
		}
		return responseList;
	}
	
	@Override
	public List<IsoMessageMetaDataDto> getInboundMsgId() {
		List<IsoMessageMetaDataDto> responseList = null;

		try {
			String query = "select id as msgId, name as msgTypeName, version, description,xmlns as xmlns, xsd_object_id as xsdObjectId, "
					+ "xsl_object_id as xslObjectId, inbound_msg_id as inboundMsgId from iso_message_metadata where msg_type in ('0','1')";

			responseList = jdbcTemplate.query(query,
					new BeanPropertyRowMapper<IsoMessageMetaDataDto>(IsoMessageMetaDataDto.class));
		} catch (Exception e) {
			logger.error("Exception :" + e.getMessage());
			e.printStackTrace();
		}
		return responseList;
	}

	@Override
	public boolean checkConfigMessagePresent(String id) {
		try {
			Optional<IsoMessageMetaData> isoMsg = isoMessageDao.findById(id);
			return !isoMsg.isPresent();
		} catch (Exception e) {
			logger.error("Exception :" + e.getMessage());
			e.printStackTrace();
			return false;
		}
	}

	@Override
	public boolean checkResponseMessagePresent(String code, String responseMsgId, String initiatorMsgId) {
		try {
			Optional<ResponseMessage> respMsg = Optional.ofNullable(responseMessageDao
					.findByCodeAndResponseMsgIdAndInitiatorMsgId(code, responseMsgId, initiatorMsgId));
			return !respMsg.isPresent();
		} catch (Exception e) {
			logger.error("Exception :" + e.getMessage());
			e.printStackTrace();
			return false;
		}
	}

	@Override
	public String deleteConfMessage(String id) {
		String response = null;
		try {
			isoMessageDao.deleteById(id);
			response = "Conf Message with Id " + id + " deleted successfuly";
		} catch (Exception e) {
			response = "Exception while deleting " + e.getMessage();
			logger.error("Exception while deleting " + e.getMessage());
			e.printStackTrace();
		}
		return response;
	}

	@Override
	public String deleteResponseMessage(String id) {
		String response = null;
		try {
			responseMessageDao.deleteById(id);
			response = "Response Message with id " + id + " deleted successfuly";
		} catch (Exception e) {
			response = "Exception while deleting Response message " + e.getMessage();
			logger.error("Exception while deleting Response message " + e.getMessage());
			e.printStackTrace();
		}
		return response;
	}

	@Override
	public String getXsdNS(InputStream imptStrObj) throws ParserConfigurationException, SAXException, IOException {
		String response = null;
		try {
			DocumentBuilderFactory dbfxsd = DocumentBuilderFactory.newInstance();
			DocumentBuilder dbxsd = dbfxsd.newDocumentBuilder();
			Document docXsd = dbxsd.parse(imptStrObj);
			Element root = docXsd.getDocumentElement();
			response = root.getAttributeNode("xmlns").getSchemaTypeInfo().toString().split("=")[1].replace("\"", "");
		} catch (Exception e) {
			logger.error("Exception while getting XsdNS :" + e.getMessage());
			e.printStackTrace();
		}
		return response;
	}

	@Override
	public List<String> getReferenceData(String datakey) {
		List<String> confList = new ArrayList<>();
		try {
			IMap<String, ReferenceData> refDataMap = hazelcastInstance.getMap("referenceData");

			if (refDataMap.isEmpty())
				refDataMap.loadAll(true);
			List<ReferenceData> refDataList = (List<ReferenceData>) refDataMap.get(datakey);
			for (ReferenceData refDataObj : refDataList) {
				confList.add(refDataObj.getValue());
			}
			Collections.sort(confList);
		} catch (Exception e) {
			logger.error("ReferenceData Exception :" + e.getMessage());
			e.printStackTrace();
		}
		return confList;
	}
	
	@Override
	public List<FileResponse> getInboundSampleMsgData() {
		StringBuilder query = new StringBuilder();
		query.append("SELECT smd.id as id, smd.xml_object_id as fileName,smd.xml_object_id as minioFileKey,smd.iso_msg_id as msgType,");
		query.append(" TO_CHAR(smd.date_modified,'dd-MM-yyyy HH:mm') as dateModified,smd.size as size, smd.is_valid as isValid");
		query.append(" FROM public.sample_msg_data smd ");
		query.append(" INNER JOIN iso_message_metadata imm on smd.iso_msg_id=imm.id ");
		query.append(" WHERE imm.msg_type in ('0','1')"); // inbound

		return jdbcTemplate.query(query.toString(),new BeanPropertyRowMapper<FileResponse>(FileResponse.class));
	}
	
	@Override
	public List<FileResponse> getOutboundSampleMsgData() {
		StringBuilder query = new StringBuilder();
		query.append("SELECT smd.id as id, smd.xml_object_id as fileName,smd.xml_object_id as minioFileKey,smd.iso_msg_id as msgType,");
		query.append(" TO_CHAR(smd.date_modified,'dd-MM-yyyy HH:mm') as dateModified,smd.size as size, smd.is_valid as isValid");
		query.append(" FROM public.sample_msg_data smd ");
		query.append(" INNER JOIN iso_message_metadata imm on smd.iso_msg_id=imm.id ");
		query.append(" WHERE imm.msg_type in ('0','2')"); // outbound

		return jdbcTemplate.query(query.toString(),new BeanPropertyRowMapper<FileResponse>(FileResponse.class));
	}

	@Override
	public ReferenceResponse insertReferenceData(ReferenceDataDto refDto) {
		Map<String, String[]> datakeyObj = new HashMap<>();
		List<ReferenceDataDto> listDto = new ArrayList<>();
		listDto.add(refDto);
		for (int i = 0; i < listDto.size(); i++) {
			datakeyObj.put(listDto.get(i).getDatakey(), listDto.get(i).getValues());
		}
		return staticDataServiceObj.insertReferenceMapData(datakeyObj);
	}

	public List<ReferenceDataDto> getAllReferenceData() {
		List<ReferenceDataDto> refData = new ArrayList<>();
		try {
			IMap<String, ReferenceData> refDataMap = hazelcastInstance.getMap("referenceData");
			if (refDataMap.isEmpty())
				refDataMap.loadAll(true);
			
			for (Map.Entry<String, ReferenceData> entry : refDataMap.entrySet()) {
				if (entry.getKey() != null && !entry.getKey().trim().equals("")) {
					List<ReferenceData> refValuedata = (List<ReferenceData>) entry.getValue();
					ReferenceDataDto refDto = new ReferenceDataDto();
					List<String> valList = new ArrayList<>();
					// List<Integer> idList = new ArrayList<>();
					for (ReferenceData refObj : refValuedata) {
						// idList.add(refObj.getId());
						valList.add(refObj.getValue());
					}
					// refDto.setId(idList);
					refDto.setDatakey(entry.getKey());
					refDto.setValues(valList.toArray(new String[valList.size()]));
					refData.add(refDto);

					refData = refData.stream().sorted(Comparator.comparing(ReferenceDataDto::getDatakey))
							.collect(Collectors.toList());
				}
			}
			System.out.print(" refData : "+refData);
		} catch (Exception e) {
			logger.error("Exception while loading All reference data :" + e.getMessage());
			e.printStackTrace();
		}
		return refData;
	}

	@Override
	public ReferenceResponse updateReferenceData(ReferenceDataDto refDto) {
		return staticDataServiceObj.updateReferenceMapData(refDto);
	}

	@Override
	public SampleMsgData saveSampleMsgData(SampleMsgDataDto sampleMsgData) {
		SampleMsgData isoMsg = new SampleMsgData();
		try {
			isoMsg.setDescription(sampleMsgData.getDescription());
			isoMsg.setValid(sampleMsgData.isValid());
			isoMsg.setIsoMsgId(sampleMsgData.getIsoMsgId());
			isoMsg.setXmlObjectId(sampleMsgData.getXmlObjectId());
			isoMsg.setDateModified(java.time.LocalDateTime.now());
			isoMsg.setSize(sampleMsgData.getSize());
			sampleMsgDataDao.save(isoMsg);
		} catch (Exception e) {
			logger.error("Exception in saveSampleMsgData :" + e.getMessage());
			e.printStackTrace();
		}
		return isoMsg;
	}

	@Override
	public String deleteSampleMsgData(String id) {
		String response = null;
		try {
			String xmlObjectId = (String) jdbcTemplate
					.queryForObject("select xml_object_id from sample_msg_data where id=" + id, String.class);
			deleteFile(xmlObjectId);
			sampleMsgDataDao.deleteById(Long.parseLong(id));
			response = "Conf Sample Message Data with Id " + id + " deleted successfuly";
		} catch (Exception e) {
			response = "Exception while deleting deleteSampleMsgData " + e.getMessage();
			logger.error("Exception while deleting deleteSampleMsgData " + e.getMessage());
			e.printStackTrace();
		}
		return response;
	}

	@Override
	public List<MessageDataField> loadMessageDataFields(Long id) throws Exception {
		SampleMsgData sampleMsgData = sampleMsgDataDao.findById(id).get();
		if (sampleMsgData != null && sampleMsgData.getXmlObjectId() != null) {
			return getLoadMessageDataFields(sampleMsgData.getXmlObjectId(), sampleMsgData.getIsoMsgId());
		} else {
			throw new Exception("Error while getting Sample File. ");
		}
	}

	@Override
	public List<MessageDataField> getLoadMessageDataFields(String xmlObjectId, String isoMsgId) throws Exception {

		List<MessageDataField> msgDataFeilds = null;
		IsoMessageMetaData isoMsgDataObj = (IsoMessageMetaData) hazelcastInstance.getMap(isoMessages).get(isoMsgId);

		JAXBContext jaxbContext = JAXBContext.newInstance(DocumentElement.class);
		Unmarshaller jaxbUnmarshaller = jaxbContext.createUnmarshaller();
		DocumentElement docuObj = (DocumentElement) jaxbUnmarshaller
				.unmarshal(xferXmlByAppyingXls(isoMsgDataObj.getXslObjectId(), xmlObjectId));
		if (docuObj.getMessageDataField() != null) {
			msgDataFeilds = docuObj.getMessageDataField();
			for (int i = 0; i < msgDataFeilds.size(); i++) {
				MessageDataField msgDataObj = msgDataFeilds.get(i);
				if (msgDataObj.getPatternType() != null && !msgDataObj.getPatternType().trim().equals("")) {
					String val = msgDataObj.getPatternType();
					msgDataObj.setPatternType(val.replace("\\\\", "\\"));
				}
			}
			new CommonFunction().getAutoGenerateFields(msgDataFeilds);
		}
		return msgDataFeilds;
	}

	
	private InputStream xferXmlByAppyingXls(String xslId, String xmlId)
			throws Exception {

		TransformerFactory factory = TransformerFactory.newInstance();
		OutputStream stream = new ByteArrayOutputStream();

		Templates template = factory
				.newTemplates(new StreamSource(downloadMinIOFile(xslId)));
		Transformer xformer = template.newTransformer();
		
		Source source = new DOMSource(DocumentBuilderFactory.newInstance().newDocumentBuilder().parse(downloadMinIOFile(xmlId)));
		
		Result result = new StreamResult(stream);
		xformer.transform(source, result);

		return new ByteArrayInputStream(((ByteArrayOutputStream) stream).toByteArray());
	}
	
	
	@SuppressWarnings("deprecation")
	public InputStream downloadMinIOFile(String key) throws Exception {
		try {

			MinioClient minioClient = MinioClientConnection.getInstance(appPropertiesObj.getMinio().getMinioDBUrl(),
					appPropertiesObj.getMinio().getMinioDBUserNm(), appPropertiesObj.getMinio().getMinioDBPw());
			String defaultBucketName = appPropertiesObj.getMinio().getMinioBucketNm();
			String defaultFlod = appPropertiesObj.getMinio().getMinioDFlod();

			return minioClient.getObject(defaultBucketName, defaultFlod + key);
		} catch (Exception e) {
			logger.error("Exception :" + e.getMessage());
			e.printStackTrace();
			throw e;
		}
	}
	
}