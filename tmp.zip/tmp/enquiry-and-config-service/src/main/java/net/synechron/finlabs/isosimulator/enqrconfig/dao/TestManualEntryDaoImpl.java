package net.synechron.finlabs.isosimulator.enqrconfig.dao;

import java.io.BufferedReader;
import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.nio.charset.StandardCharsets;
import java.time.format.DateTimeFormatter;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

import javax.xml.bind.JAXBException;
import javax.xml.parsers.ParserConfigurationException;
import javax.xml.transform.TransformerException;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;
import org.xml.sax.SAXException;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.JsonMappingException;

import lombok.extern.slf4j.Slf4j;
import net.synechron.finlabs.isosimulator.CommonFunction;
import net.synechron.finlabs.isosimulator.domain.IsoMessageMetaData;
import net.synechron.finlabs.isosimulator.domain.ResponseMessage;
import net.synechron.finlabs.isosimulator.enqrconfig.domain.TestManualEntryDataResp;
import net.synechron.finlabs.isosimulator.enqrconfig.dto.TestInputDataDto;
import net.synechron.finlabs.isosimulator.enqrconfig.entity.ValidationTest;
import net.synechron.finlabs.isosimulator.enqrconfig.serviceImpl.ConfigServiceImpl;
import net.synechron.finlabs.isosimulator.middleware.model.MessageDataField;

@Repository
@Slf4j
public class TestManualEntryDaoImpl implements TestManualEntryDao {

	@Autowired
	private PaymentDao paymentDao;

	@Autowired
	IsoMessageMetaDataDao isoMessageMetaDataDao;

	@Autowired
	private ConfigServiceImpl configServiceImpl;
	
	@Autowired
	private ResponseMessageDao responseMessageDao;
	
	@Autowired
	private JdbcTemplate jdbcTemplate;
	
	@Autowired
	private IsoMessageMetaDataDao isoMessageDao;
	
	@Override
	public TestManualEntryDataResp getManualEntryData(String runId) throws IOException, TransformerException,
			ParserConfigurationException, SAXException, JAXBException, ClassNotFoundException{

		ValidationTest validationTestData = paymentDao.findByRunId(Long.parseLong(runId));
		TestManualEntryDataResp dataResp = new TestManualEntryDataResp();
		dataResp.setRunId(validationTestData.getRunId().toString());
		dataResp.setTestName(validationTestData.getTestName());
		dataResp.setTestDesc(validationTestData.getDescription());
		DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm");
		String dateTime = formatter.format(validationTestData.getCreatedOn());
		dataResp.setCreatedOn(dateTime);
		dataResp.setTags(validationTestData.getTags());

		TestInputDataDto testInputdata = findInputData(validationTestData.getRunId());
		dataResp.setMsgTypeId(testInputdata.getMsgtype());
		dataResp.setFileName(testInputdata.getObjectName());
		dataResp.setFileDesc(testInputdata.getDescription());
		
		if (testInputdata.getResponseMsgId() != null && testInputdata.getResponseMsgId().trim().length() > 0) {
			String resCode[] = findInputResponseMsgId(validationTestData.getRunId()).split(",");
			Optional<ResponseMessage> responseMessageObj;
			String[] codeName = new String[resCode.length];
			for (int i = 0; i < resCode.length; i++) {
				responseMessageObj = responseMessageDao.findById(resCode[i]);
				codeName[i] = responseMessageObj.get().getName();
			}
			dataResp.setResponseMsgCodeNames(codeName);
		}
		
		Optional<IsoMessageMetaData> isoMessageMetaData = isoMessageMetaDataDao.findById(testInputdata.getMsgtype());
		if (isoMessageMetaData.isPresent()) {
			IsoMessageMetaData isoMsgData = isoMessageMetaData.get();
			dataResp.setMsgTypeName(isoMsgData.getName());
			dataResp.setMsgTypeVersion(isoMsgData.getVersion());
		}

		MessageDataField[] convertXslToXmlToJavaObj = convertXslToXmlToJavaObj(testInputdata.getMsgtype(),
				testInputdata.getObjectId());

		dataResp.setMessageDataFields(convertXslToXmlToJavaObj);

		return dataResp;
	}

	@Override
	public MessageDataField[] convertXslToXmlToJavaObj(String msgTypId, String objectId) {
		MessageDataField[] msgDataFeilds = null;
		try {
			CommonFunction jsoString = new CommonFunction();
			byte[] downloadFile = configServiceImpl.downloadFile(objectId);
			InputStream is = new ByteArrayInputStream(downloadFile);
			String json = new BufferedReader(new InputStreamReader(is, StandardCharsets.UTF_8)).lines()
					.collect(Collectors.joining("\n"));

			msgDataFeilds = jsoString.jsonStringIntoMsgDataField(json);
		} catch (JsonMappingException e) {
			log.error("Exception Message "+e.getMessage());
			e.printStackTrace();
		} catch (JsonProcessingException e) {
			e.printStackTrace();
		}
		return msgDataFeilds;
	}

	public TestInputDataDto findInputData(Long runId) {
		String query = "SELECT run_id as runId,description, input_type as inputType, msg_type_id as msgType, object_id as objectId, "
				+ "object_name as objectName, response_msg_id as responseMsgId,msg_id as msgId"
				+ " FROM test_input_data  WHERE run_id =" + runId + " LIMIT 1";
		List<TestInputDataDto> resultObj = jdbcTemplate.query(query,
				(rs, rowNum) -> new TestInputDataDto(rs.getLong("runId"), rs.getString("objectId"),rs.getString("objectName"),
						rs.getString("description"),rs.getString("inputType"), rs.getString("msgType"), 
						rs.getString("responseMsgId"), rs.getString("msgId")));
		return resultObj.get(0);
	}
	
	public String findInputResponseMsgId(Long runId) {
		String query = "SELECT STRING_AGG(response_msg_id,',') as response_msg_id FROM test_input_data WHERE run_id = "+runId;
		return jdbcTemplate.queryForMap(query).get("response_msg_id").toString();

	}
}
