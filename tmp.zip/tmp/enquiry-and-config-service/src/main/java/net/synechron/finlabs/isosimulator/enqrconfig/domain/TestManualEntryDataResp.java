package net.synechron.finlabs.isosimulator.enqrconfig.domain;

import java.io.Serializable;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.ToString;
import net.synechron.finlabs.isosimulator.middleware.model.MessageDataField;

@Data
@ToString
@NoArgsConstructor
@AllArgsConstructor
public class TestManualEntryDataResp implements Serializable{

	
	private static final long serialVersionUID = 1L;
	/**
	 * @author Pawan.Madne
	 */
	private String runId;
	private String testName;
	private String testDesc;
	private String createdOn;
	private String msgTypeId;
	private String msgTypeName;
	private String msgTypeVersion;
	private String fileName;
	private String fileDesc;
	private String tags;
	private String[] responseMsgCodeNames;
	private  MessageDataField[] messageDataFields;
}
