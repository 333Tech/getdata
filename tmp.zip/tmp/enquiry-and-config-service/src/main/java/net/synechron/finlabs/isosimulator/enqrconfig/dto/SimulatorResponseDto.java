package net.synechron.finlabs.isosimulator.enqrconfig.dto;

import java.time.LocalDateTime;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * @author Amol.Mandlik
 *
 */
@Data
@AllArgsConstructor
@NoArgsConstructor
public class SimulatorResponseDto {
	
	private LocalDateTime date;
	private long postiveResponses;
	private long negativeResponses;
}
