package net.synechron.finlabs.isosimulator.enqrconfig.entity;

import javax.persistence.Column;
import javax.persistence.ColumnResult;
import javax.persistence.ConstructorResult;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.NamedNativeQuery;
import javax.persistence.SqlResultSetMapping;
import javax.persistence.Table;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.ToString;
import net.synechron.finlabs.isosimulator.enqrconfig.dto.TestValidationError;

/**
 * @author Amol.Mandlik
 *
 */

@Data
@AllArgsConstructor
@NoArgsConstructor
@Entity
@ToString
@Table(name = "validation_error")
@NamedNativeQuery(
	    name = "find_validation_error_message",
	    query = "select v.xpath, v.xml_element as xmlElement, v.field_name as fieldName, "
	    		+ "v.data, v.error_message as error from validation_error v where v.run_id = :runId and v.object_id = :objectId",
	    resultSetMapping = "validation_error_dto"
	)
	@SqlResultSetMapping(
	    name = "validation_error_dto",
	    classes = @ConstructorResult(
	        targetClass = TestValidationError.class,
	        columns = {
	            @ColumnResult(name = "xpath", type = String.class),
	            @ColumnResult(name = "xmlElement", type = String.class),
	            @ColumnResult(name = "fieldName", type = String.class),
	            @ColumnResult(name = "data", type = String.class),
	            @ColumnResult(name = "error", type = String.class)
	        }
	    )
	)

public class ValidationError {

	@Id
    @GeneratedValue(strategy = GenerationType.AUTO)
	@Column(name = "id")
	private Long id;
	@Column(name = "run_id")
	private Long runId;
	@Column(name = "object_id")
	private String objectId;
	@Column(name = "msg_id")
	private String msgId;
	@Column(name = "xpath")
	private String xpath;
	@Column(name = "xml_element")
	private String xmlElelment;
	@Column(name = "field_name")
	private String fieldName;
	@Column(name = "data")
	private String data;
	@Column(name = "error_message")
	private String errorMessage;
	
}
