package net.synechron.finlabs.isosimulator.enqrconfig.config;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.autoconfigure.condition.ConditionalOnMissingBean;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import com.hazelcast.client.HazelcastClient;
import com.hazelcast.client.config.ClientConfig;
import com.hazelcast.core.HazelcastInstance;

@Configuration
public class CacheClient {
	
	@Value(value = "${hazelcast.server.url}")
	String url;

	@Value(value = "${hazelcast.config.invocationseconds}")
	String invocationseconds;

	@Value(value = "${hazelcast.config.attemptlimit}")
	int attemptlimit;

	@Value(value = "${hazelcast.config.attemptperiod}")
	int attemptperiod;

	@Bean
	public ClientConfig clientConfig() {
		ClientConfig clientConfig = new ClientConfig();

		clientConfig.getNetworkConfig().addAddress(url);
		clientConfig.setProperty("hazelcast.client.invocation.timeout.seconds", invocationseconds);
		clientConfig.getNetworkConfig().setConnectionAttemptLimit(attemptlimit);
		clientConfig.getNetworkConfig().setConnectionAttemptPeriod(attemptperiod);
		return clientConfig;
	}

	@Bean
	@ConditionalOnMissingBean(HazelcastInstance.class)
	public HazelcastInstance hazelcastInstance(ClientConfig clientConfig) {
		return HazelcastClient.newHazelcastClient(clientConfig);
	}
	
	/**
	 * <P>
	 * Temporary. Spring Boot should soon autoconfigure the
	 * {@code HazelcastInstance} bean.
	 * </P>
	 */
	
//	@Configuration
//	@ConditionalOnMissingBean(HazelcastInstance.class)
//	static class HazelcastClientConfiguration {
//
//		@Bean
//		public HazelcastInstance hazelcastInstance(ClientConfig clientConfig) {
//			return HazelcastClient.newHazelcastClient(clientConfig);
//		}
//	}

}