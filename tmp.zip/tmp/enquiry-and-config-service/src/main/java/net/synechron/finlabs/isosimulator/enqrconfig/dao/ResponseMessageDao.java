package net.synechron.finlabs.isosimulator.enqrconfig.dao;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import net.synechron.finlabs.isosimulator.domain.ResponseMessage;

/**
 * @author Amol.Mandlik
 *
 */

@Repository
public interface ResponseMessageDao extends JpaRepository<ResponseMessage, String>{

	public ResponseMessage findByCodeAndResponseMsgIdAndInitiatorMsgId(String code, 
										String responseMsgId,String initiatorMsgId);
	
}
