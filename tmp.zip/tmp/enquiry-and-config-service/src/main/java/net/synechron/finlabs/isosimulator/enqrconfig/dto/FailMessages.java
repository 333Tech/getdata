package net.synechron.finlabs.isosimulator.enqrconfig.dto;

import java.util.List;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * @author Amol.Mandlik
 *
 */

@Data
@AllArgsConstructor
@NoArgsConstructor
public class FailMessages {

	private String fileName;
	private String msgType;
	private String objectId;
	private String isInvalidXml;
	private List<TestValidationError> errors;
	
	
}
