package net.synechron.finlabs.isosimulator.enqrconfig.dto;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * @author Amol.Mandlik
 *
 */

@Data
@AllArgsConstructor
@NoArgsConstructor
public class PassFailCount {

	private long passCount;
	private long failCount;
}
