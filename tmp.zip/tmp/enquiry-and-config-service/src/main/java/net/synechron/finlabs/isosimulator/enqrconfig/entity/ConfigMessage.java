package net.synechron.finlabs.isosimulator.enqrconfig.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.ToString;

/**
 * @author Amol.Mandlik
 *
 */

@Data
@AllArgsConstructor
@NoArgsConstructor
@Entity
@ToString
@Table(name = "config_message")
public class ConfigMessage {
	
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	@Column(name = "msg_id")
	private Long msgId;
	@Column(name = "msg_type_name")
	private String msgTypeName;
	@Column(name = "version")
	private String version;
	@Column(name = "description")
	private String description;

}
