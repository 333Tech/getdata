package net.synechron.finlabs.isosimulator.enqrconfig.domain;

import java.io.Serializable;
import java.util.List;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;

import net.synechron.finlabs.isosimulator.middleware.model.MessageDataField;

@XmlRootElement(name = "Document")
@XmlAccessorType(XmlAccessType.FIELD)
public class DocumentElement implements Serializable{

	private static final long serialVersionUID = 1L;
	
	@XmlElement(name = "MessageDataField")
	private List<MessageDataField> messageDataField;
	
	public List<MessageDataField> getMessageDataField() {
		return messageDataField;
	}

	public void setMessageDataField(List<MessageDataField> messageDataField) {
		this.messageDataField = messageDataField;
	}
}
