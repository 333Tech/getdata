package net.synechron.finlabs.isosimulator.enqrconfig.dto;

import java.time.LocalDateTime;

import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class SampleMsgDataDto {

	private String Id;
	private String description;
	private String xmlObjectId;
	private String isoMsgId;
	@JsonProperty
	private boolean isValid;
	private String size;
	private LocalDateTime dateModified;
	
}
