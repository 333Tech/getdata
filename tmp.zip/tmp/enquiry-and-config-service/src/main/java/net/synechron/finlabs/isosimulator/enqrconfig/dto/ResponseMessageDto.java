package net.synechron.finlabs.isosimulator.enqrconfig.dto;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * @author Amol.Mandlik
 *
 */


@Data
@AllArgsConstructor
@NoArgsConstructor
public class ResponseMessageDto {

	private String id;
	private String code;
	private String name;
	private String definition;
	private String responseMsgId;
	private String intiatorMsgTypeId;
	
}
