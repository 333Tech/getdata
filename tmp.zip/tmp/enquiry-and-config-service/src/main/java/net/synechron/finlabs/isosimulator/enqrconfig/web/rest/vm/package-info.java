/**
 * View Models used by Spring MVC REST controllers.
 */
package net.synechron.finlabs.isosimulator.enqrconfig.web.rest.vm;
