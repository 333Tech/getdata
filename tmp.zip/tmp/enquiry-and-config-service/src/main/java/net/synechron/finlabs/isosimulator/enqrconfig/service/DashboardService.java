package net.synechron.finlabs.isosimulator.enqrconfig.service;

import java.util.List;

import org.springframework.stereotype.Service;

import net.synechron.finlabs.isosimulator.enqrconfig.dto.SimulatorResponseDto;
import net.synechron.finlabs.isosimulator.enqrconfig.dto.StatusCountDto;
import net.synechron.finlabs.isosimulator.enqrconfig.dto.TestsDto;


/**
 * @author Amol.Mandlik
 *
 */
@Service
public interface DashboardService {

	public StatusCountDto displayQuickSummaryDashboard();
	
	public List<TestsDto> recentTests(int recordCount);
	
	public List<SimulatorResponseDto> displaySimulatorResposne(String inboundMsgTypeId, int days);
	
	public Long getAllTestsCount();
}
