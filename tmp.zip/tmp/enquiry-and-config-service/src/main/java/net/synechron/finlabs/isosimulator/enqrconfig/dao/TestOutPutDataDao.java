package net.synechron.finlabs.isosimulator.enqrconfig.dao;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import net.synechron.finlabs.isosimulator.enqrconfig.dto.FailMessageDetailDto;
import net.synechron.finlabs.isosimulator.enqrconfig.dto.InProgressMessages;
import net.synechron.finlabs.isosimulator.enqrconfig.dto.OutboundPassDto;
import net.synechron.finlabs.isosimulator.enqrconfig.dto.PassMessages;
import net.synechron.finlabs.isosimulator.enqrconfig.entity.TestOutputData;

/**
 * @author Amol.Mandlik
 *
 */

@Repository
public interface TestOutPutDataDao extends JpaRepository<TestOutputData, String> {

	@Query(name = "find_passed_test_details", nativeQuery = true)
	public List<PassMessages> getPassedFileDetails(@Param("runId") Long runId);
	
	@Query(name = "find_inprogress_test_details", nativeQuery = true)
	public List<InProgressMessages> getInProgressFileDetails(@Param("runId") Long runId);
	
	@Query(name = "find_validation_error_details", nativeQuery = true)
	public List<FailMessageDetailDto> getFailedMessageDetails(@Param("runId") Long runId);
	
	@Query(name = "find_passed_outbound_test_details", nativeQuery = true)
	public List<OutboundPassDto> getPassedOutboundTestDetails(@Param("runId") Long runId);
	
	@Query(name = "find_inprogress_outbound_details", nativeQuery = true)
	public List<InProgressMessages> getInProgressOutboundDetails(@Param("runId") Long runId);
	
	@Query(name = "find_failed_outbound_test_details", nativeQuery = true)
	public List<FailMessageDetailDto> getFailedOutbounMessageDetails(@Param("runId") Long runId);
	
	public void deleteByRunIdIn(List<Long> runIds);
	
	@Query(value="SELECT OUT_OBJECT_ID FROM TEST_OUTPUT_DATA WHERE MSG_ID=:msgId", nativeQuery = true)
	public List<String> findByMsgId(@Param("msgId") String msgId);
}
