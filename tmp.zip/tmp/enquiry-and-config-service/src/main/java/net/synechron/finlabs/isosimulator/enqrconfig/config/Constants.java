package net.synechron.finlabs.isosimulator.enqrconfig.config;

/**
 * Application constants.
 */
public final class Constants {

    public static final String SYSTEM = "system";

    private Constants() {}
}
