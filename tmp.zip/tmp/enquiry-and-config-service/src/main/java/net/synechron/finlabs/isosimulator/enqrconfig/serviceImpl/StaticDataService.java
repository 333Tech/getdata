package net.synechron.finlabs.isosimulator.enqrconfig.serviceImpl;

import java.io.IOException;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.Enumeration;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Properties;
import javax.annotation.PostConstruct;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.hazelcast.core.HazelcastInstance;
import lombok.extern.slf4j.Slf4j;
import net.synechron.finlabs.isosimulator.domain.ReferenceData;
import net.synechron.finlabs.isosimulator.enqrconfig.dto.ReferenceDataDto;
import net.synechron.finlabs.isosimulator.enqrconfig.dto.ReferenceResponse;

@Slf4j
@Service
public class StaticDataService {

	@Autowired
	HazelcastInstance hazelcastInstance;

	@PostConstruct
	public void initapplication() {
		try {
			ClassLoader classloader = Thread.currentThread().getContextClassLoader();
			InputStream inStr = classloader.getResourceAsStream("staticdata.properties");
			Properties properties = new Properties();
			properties.load(inStr);
			Enumeration enuKeys = properties.keys();
			Map<String, String[]> mpObj = new HashMap<>();
			while (enuKeys.hasMoreElements()) {
				String key = (String) enuKeys.nextElement();
				String[] value = properties.getProperty(key).split(",");
				mpObj.put(key, value);
			}
			insertReferenceMapData(mpObj);
		} catch (IOException e) {
			log.error("Initiating Reference Data  :", e.getMessage());
			e.printStackTrace();
		}
	}

	public ReferenceResponse insertReferenceMapData(Map<String, String[]> mpObj) {
		ReferenceResponse refRes = new ReferenceResponse();
		try {
			Map<String, List<ReferenceData>> map = new HashMap<>();
			List<ReferenceData> list;
			for (Map.Entry<String, String[]> entry : mpObj.entrySet()) {
				String[] value = entry.getValue();
				list = new ArrayList<>();
				for (int i = 0; i < value.length; i++) {
					list.add(new ReferenceData(entry.getKey(), value[i].trim()));
				}
				map.put(entry.getKey(), list);
			}
			Map<String, List<ReferenceData>> referencedatamap = hazelcastInstance.getMap("referenceData");
			referencedatamap.putAll(map);
			refRes.setResponse("Reference Data Successfully Added.");
		} catch (Exception e) {
			refRes.setResponse(e.getMessage());
			log.error("Exception message :"+e.getMessage());
			e.printStackTrace();
		}
		return refRes;
	}

	public ReferenceResponse updateReferenceMapData(ReferenceDataDto referenceData) {
		ReferenceResponse refRes = new ReferenceResponse();
		try {
			Map<String, String[]> datakeyObj = new HashMap<>();
			datakeyObj.put(referenceData.getDatakey(), referenceData.getValues());
			Map<String, List<ReferenceData>> map = new HashMap<>();
			List<ReferenceData> list = new ArrayList<>();
			for (Map.Entry<String, String[]> entry : datakeyObj.entrySet()) {
				String[] value = entry.getValue();
				for (int i = 0; i < value.length; i++) {
					list.add(new ReferenceData(entry.getKey(), value[i].trim()));
				}
				map.put(entry.getKey(), list);
			}
			Map<String, List<ReferenceData>> referencedatamap = hazelcastInstance.getMap("referenceData");
			referencedatamap.putAll(map);
			refRes.setResponse(referenceData.getDatakey()+" Successfully Updated.");
		} catch (Exception e) {
			refRes.setResponse(e.getMessage());
			e.printStackTrace();
		}
		return refRes;
	}
	
}
