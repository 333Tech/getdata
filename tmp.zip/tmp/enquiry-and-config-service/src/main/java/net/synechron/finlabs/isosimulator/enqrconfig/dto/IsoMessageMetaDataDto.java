package net.synechron.finlabs.isosimulator.enqrconfig.dto;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * @author Amol.Mandlik
 *
 */

@Data
@AllArgsConstructor
@NoArgsConstructor
public class IsoMessageMetaDataDto {

	private String msgId;
	private String msgTypeName;
	private String version;
	private String xmlns;
	private String description;
	private String inboundMsgId;
	private String msgType;
	private String xsdObjectId;
	private String xslObjectId;
	private String paymentMsgIdXpath;
	
}
