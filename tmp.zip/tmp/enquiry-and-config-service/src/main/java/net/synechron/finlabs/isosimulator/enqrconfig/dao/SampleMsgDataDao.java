package net.synechron.finlabs.isosimulator.enqrconfig.dao;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import net.synechron.finlabs.isosimulator.domain.SampleMsgData;

@Repository
public interface SampleMsgDataDao extends JpaRepository<SampleMsgData, Long> {

	public SampleMsgData findByIsoMsgId(String isoMsgId);
	public SampleMsgData findByxmlObjectId(String xmlObjectId);
	
}
