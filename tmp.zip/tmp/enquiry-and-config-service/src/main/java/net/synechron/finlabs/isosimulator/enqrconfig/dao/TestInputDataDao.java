package net.synechron.finlabs.isosimulator.enqrconfig.dao;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import net.synechron.finlabs.isosimulator.enqrconfig.entity.TestInputData;

/**
 * @author Amol.Mandlik
 *
 */

@Repository
public interface TestInputDataDao extends JpaRepository<TestInputData, String> {

	public void deleteByRunIdIn(List<Long> runIds);
	
	public TestInputData findByRunId(Long runId);
	
	@Query("SELECT t.objectId FROM TestInputData t WHERE t.runId =:runId")
	public List<String> getTestInputDataObjectId(@Param("runId") Long runId);

}
