package net.synechron.finlabs.isosimulator.enqrconfig.dto;

import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * @author Amol.Mandlik
 *
 */

@Data
@AllArgsConstructor
@NoArgsConstructor
public class FileResponse {

	private String id;
	private String fileName;
	private String minioFileKey;
	private String msgType;
	private String dateModified;
	private String size;
	@JsonProperty
	private boolean isValid;
	
}
