package net.synechron.finlabs.isosimulator.enqrconfig.serviceImpl;

import java.io.IOException;
import java.io.InputStream;
import java.nio.charset.StandardCharsets;
import java.security.InvalidKeyException;
import java.security.NoSuchAlgorithmException;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;

import org.apache.commons.io.IOUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageImpl;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort.Order;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import io.minio.MinioClient;
import io.minio.RemoveObjectArgs;
import io.minio.errors.ErrorResponseException;
import io.minio.errors.InsufficientDataException;
import io.minio.errors.InternalException;
import io.minio.errors.InvalidBucketNameException;
import io.minio.errors.InvalidResponseException;
import io.minio.errors.ServerException;
import io.minio.errors.XmlParserException;
import lombok.Data;
import net.synechron.finlabs.isosimulator.enqrconfig.config.ApplicationProperties;
import net.synechron.finlabs.isosimulator.enqrconfig.config.MinioClientConnection;
import net.synechron.finlabs.isosimulator.enqrconfig.dao.PaymentDao;
import net.synechron.finlabs.isosimulator.enqrconfig.dao.TestInputDataDao;
import net.synechron.finlabs.isosimulator.enqrconfig.dao.TestOutPutDataDao;
import net.synechron.finlabs.isosimulator.enqrconfig.dao.ValidationErrorDao;
import net.synechron.finlabs.isosimulator.enqrconfig.dto.FailMessageDetailDto;
import net.synechron.finlabs.isosimulator.enqrconfig.dto.FailMessages;
import net.synechron.finlabs.isosimulator.enqrconfig.dto.InProgressMessages;
import net.synechron.finlabs.isosimulator.enqrconfig.dto.InboundFilesDto;
import net.synechron.finlabs.isosimulator.enqrconfig.dto.ManualEntry;
import net.synechron.finlabs.isosimulator.enqrconfig.dto.OutboundFilesDto;
import net.synechron.finlabs.isosimulator.enqrconfig.dto.OutboundPassDto;
import net.synechron.finlabs.isosimulator.enqrconfig.dto.PassFailCount;
import net.synechron.finlabs.isosimulator.enqrconfig.dto.PassMessages;
import net.synechron.finlabs.isosimulator.enqrconfig.dto.ReportDataDto;
import net.synechron.finlabs.isosimulator.enqrconfig.dto.ValidationDto;
import net.synechron.finlabs.isosimulator.enqrconfig.entity.ValidationTest;
import net.synechron.finlabs.isosimulator.enqrconfig.service.PaymentService;

/**
 * @author Amol.Mandlik
 *
 */

@Service
@Data
public class PaymentServiceImpl implements PaymentService {
	
	private final Logger log = LoggerFactory.getLogger(PaymentServiceImpl.class);
	
	@Autowired
	private PaymentDao paymentDao;
	
	@Autowired
	private JdbcTemplate jdbcTemplate;
	
	@Autowired
	private TestOutPutDataDao outputDao;
	
	@Autowired
	private TestInputDataDao inputDao;
	
	@Autowired
	private ValidationErrorDao valErrorDao;
	
	@Autowired
	private ApplicationProperties appPropertiesObj;
	
	@Override
	public InboundFilesDto getInboundTestDetails(Long runId) {

		ValidationTest valDto = paymentDao.findByRunId(runId);
		InboundFilesDto inboundValDetailsDto = new InboundFilesDto();
		try {
			inboundValDetailsDto.setRunId(valDto.getRunId());
			inboundValDetailsDto.setTestName(valDto.getTestName());
			inboundValDetailsDto.setTestDesc(valDto.getDescription());
			inboundValDetailsDto.setDatetime(valDto.getCreatedOn());
			inboundValDetailsDto.setStatus(valDto.getStatus());

			List<PassMessages> passDto = outputDao.getPassedFileDetails(runId);
			List<InProgressMessages> progressDto = outputDao.getInProgressFileDetails(runId);
			List<FailMessageDetailDto> failMsgDto = outputDao.getFailedMessageDetails(runId);

			List<FailMessages> failMsgDtoList = new ArrayList<>();
			
			failMsgDto.forEach(failmsg ->
				failMsgDtoList.add(new FailMessages(failmsg.getFileName(), failmsg.getMsgType(), 
					failmsg.getObjectId(), failmsg.getIsInvalidXml(), 
					 valErrorDao.getErrorMessage(runId, failmsg.getObjectId()))));

			inboundValDetailsDto.setPassMessages(passDto);
			inboundValDetailsDto.setInProgressMessages(progressDto);
			inboundValDetailsDto.setFailMessages(failMsgDtoList);
		} catch (Exception e) {
			log.error("Exception "+e.getMessage());
			e.printStackTrace();
		}
		return inboundValDetailsDto;
	}

	@Override
	public boolean findByRunId(Long runId) {
		Optional<ValidationTest> validation = paymentDao.findById(runId);
		return validation.isPresent();
	}

	@Override
	public OutboundFilesDto getOutboundTestDetails(Long runId) {
		
		ValidationTest valDto = paymentDao.findByRunId(runId);
		OutboundFilesDto outboundFilesDto = new OutboundFilesDto();
		try {
			outboundFilesDto.setRunId(valDto.getRunId());
			outboundFilesDto.setTestName(valDto.getTestName());
			outboundFilesDto.setTestDesc(valDto.getDescription());
			outboundFilesDto.setDatetime(valDto.getCreatedOn());
			outboundFilesDto.setStatus(valDto.getStatus());

			List<OutboundPassDto> passDto = outputDao.getPassedOutboundTestDetails(runId);
			List<InProgressMessages> progressDto = outputDao.getInProgressOutboundDetails(runId);
			List<FailMessageDetailDto> failMsgDto = outputDao.getFailedOutbounMessageDetails(runId);
			List<FailMessages> failMsgDtoList = new ArrayList<>();
			
			failMsgDto.forEach(failmsg ->
				failMsgDtoList.add(new FailMessages(failmsg.getFileName(), failmsg.getMsgType(), 
						failmsg.getObjectId(), failmsg.getIsInvalidXml(), 
						 valErrorDao.getErrorMessage(runId, failmsg.getObjectId()))));

			outboundFilesDto.setPassMessages(passDto);
			outboundFilesDto.setInProgressMessages(progressDto);
			outboundFilesDto.setFailMessages(failMsgDtoList);
		} catch (Exception e) {
			log.error("Exception "+e.getMessage());
			e.printStackTrace();
		}
		return outboundFilesDto;
	}

	@Override
	public Map<String, Object> findBypaymentType(String paymentType, Pageable pageable) {
		Page<ValidationTest> pageTuts = paymentDao.findBypaymentType(paymentType, pageable);
		return getValidationDtoData(pageTuts);
	}

	private Map<String, Object> getValidationDtoData(Page<ValidationTest> pageTuts){
		Map<String, Object> response = new LinkedHashMap<>();
		try {
			List<ValidationDto> dtoList = new ArrayList<>();
			
			pageTuts.forEach(validationTest -> 
				dtoList.add(new ValidationDto(validationTest.getRunId(), validationTest.getTestName(),
					validationTest.getDescription(), validationTest.getCreatedOn(), getNoOffileForRunid(validationTest.getRunId())
					, validationTest.getStatus()))
			 );
			
			response.put("validationTests", dtoList);
			response.put("currentPage", pageTuts.getNumber());
			response.put("totalRecords", pageTuts.getTotalElements());
			response.put("totalPages", pageTuts.getTotalPages());
		} catch (Exception e) {
			log.error("Exception "+e.getMessage());
			e.printStackTrace();
		}
		return response;
	}
	
	private PassFailCount getNoOffileForRunid(Long runId) {
		PassFailCount count = null;
		try {
			final String query = "select * from "
					+ "(select count(*) as passCount from test_output_data where status = 'Pass' and run_id = "+runId+") as passCount,"
					+ "(select count(*) as failCount from test_output_data where status != 'Pass' and run_id = "+runId+") as failCount";
			
			 count = jdbcTemplate.query(query, (ResultSet rs) -> {
				PassFailCount passFail = new PassFailCount();
				while(rs.next()) {
					passFail.setPassCount(rs.getLong("passCount"));
					passFail.setFailCount(rs.getLong("failCount"));
				}
				return passFail;
			});
		 
		} catch (Exception e) {
			log.error("Exception "+e.getMessage());
			e.printStackTrace();
		}
		return count;
	}

	@Override
	public Map<String, Object> getAllTestReports(Pageable pageable) {
		Page<ValidationTest> pageTuts = paymentDao.findAll(pageable);
		return getReportDtoData(pageTuts);
	}
	
	@Override
	public Map<String, Object> filterReportBasedOnTestName(String testName, Pageable pageable) {
		Page<ValidationTest> pageTuts = paymentDao.findByTestNameStartingWith(testName, pageable);
		return getReportDtoData(pageTuts);
	}


	@Override
	public Map<String, Object> filterReportBasedOnrunId(Long runId, Pageable pageable) {
		Page<ValidationTest> pageTuts = paymentDao.findByRunId(runId, pageable);
		return getReportDtoData(pageTuts);
	}
	
	private Map<String, Object> getReportDtoData(Page<ValidationTest> pageTuts) {
		Map<String, Object> response = new LinkedHashMap<>();
		try {
			List<ReportDataDto> reportList = new ArrayList<>();
			
			pageTuts.forEach(report ->
				reportList.add(new ReportDataDto(report.getRunId(), report.getTestName(),
						report.getDescription(), report.getCreatedOn(), report.getTags(), 
						report.getStatus(), report.getPaymentType(), getNoOffileForRunid(report.getRunId())))
			);
			response.put("validationTests", reportList);
			response.put("currentPage", pageTuts.getNumber());
			response.put("totalRecords", pageTuts.getTotalElements());
			response.put("totalPages", pageTuts.getTotalPages());
		} catch (Exception e) {
			log.error("Exception "+e.getMessage());
			e.printStackTrace();
		}
		return response;
	}

	@Override
	public Map<String, Object> filterReportBasedOnMonths(String monthRange, Pageable pageable,String sortName) {

		Map<String, Object> response = new LinkedHashMap<>();
	    Order order = !pageable.getSort().isEmpty() ? pageable.getSort().toList().get(0) : Order.desc(("run_id"));
	    try {
	    	String[] arr = monthRange.split("-");
	    	String month1 = arr[0];
			String month2 = arr[1];
	    	String query = "select run_id as runId, test_name as testName, description as testDesc, created_on as datetime, "
	    			+ "tags, status, payment_type as process from validation_test where TO_CHAR(created_on, 'Mon')"
	    			+ " in "+"('"+month1+"',"+"'"+month2+"')";
	    	 List<ReportDataDto> listDto = jdbcTemplate.query(query+" ORDER BY " + sortName + " "
	 	            + order.getDirection().name() + " LIMIT " + pageable.getPageSize() + " OFFSET " + pageable.getOffset(),
	 	            (rs, rowNum) -> mapReportResult(rs));
	    	 
			 Page<ReportDataDto> page = new PageImpl<>(listDto, pageable, listDto.size());
			 
	    	 response.put("validationTests", listDto);
	    	 response.put("currentPage", page.getNumber());
			 response.put("totalRecords", page.getTotalElements());
			 response.put("totalPages", page.getTotalPages());
		} catch (Exception e) {
			log.error("Exception "+e.getMessage());
			e.printStackTrace();
		}
		return response;
	}
	
	private ReportDataDto mapReportResult(final ResultSet rs) throws SQLException {
		ReportDataDto reDto = new ReportDataDto();
			Long runId = rs.getLong("runId");
			reDto.setRunId(runId);
			reDto.setTestName(rs.getString("testName"));
			reDto.setTestDesc(rs.getString("testDesc"));
			reDto.setDateTime(rs.getTimestamp("datetime").toLocalDateTime());
			reDto.setTags(rs.getString("tags"));
			reDto.setStatus(rs.getString("status"));
			reDto.setProcess(rs.getString("process"));
			reDto.setFilesCount(getNoOffileForRunid(runId));
		return reDto;
	}

	@Override
	public Map<String, Object> filterReportBasedOnMonthsandRunid(String monthRange, Long runId,
			Pageable pageable) {

		Map<String, Object> response = new LinkedHashMap<>();
	    Order order = !pageable.getSort().isEmpty() ? pageable.getSort().toList().get(0) : Order.desc(("run_id"));
	    try {
	    	String[] arr = monthRange.split("-");
			String month1 = arr[0];
			String month2 = arr[1];
	    	String query = "select run_id as runId, test_name as testName, description as testDesc, created_on as datetime, "
	    			+ "tags, status, payment_type as process from validation_test where run_id = "+runId+" and TO_CHAR(created_on, 'Mon')"
	    			+ " in "+"('"+month1+"',"+"'"+month2+"')";
	    	 List<ReportDataDto> listDto = jdbcTemplate.query(query+" ORDER BY " + order.getProperty() + " "
	 	            + order.getDirection().name() + " LIMIT " + pageable.getPageSize() + " OFFSET " + pageable.getOffset(),
	 	            (rs, rowNum) -> mapReportResult(rs));
	    	 
			 Page<ReportDataDto> page = new PageImpl<>(listDto, pageable, listDto.size());
			 
	    	 response.put("validationTests", listDto);
	    	 response.put("currentPage", page.getNumber());
			 response.put("totalRecords", page.getTotalElements());
			 response.put("totalPages", page.getTotalPages());
			 
		} catch (Exception e) {
			log.error("Exception "+e.getMessage());
			e.printStackTrace();
		}
		return response;
	}

	@Override
	public Map<String, Object> filterReportBasedOnMonthsandTestName(String monthRange, String testName, Pageable pageable,String sortName) {

		Map<String, Object> response = new LinkedHashMap<>();
	    Order order = !pageable.getSort().isEmpty() ? pageable.getSort().toList().get(0) : Order.desc(("run_id"));
	    try {
	    	String[] arr = monthRange.split("-");
	    	String month1 = arr[0];
			String month2 = arr[1];
	    	String query = "select run_id as runId, test_name as testName, description as testDesc, created_on as datetime, "
	    			+ "tags, status, payment_type as process from validation_test where test_name like '"+testName+"%' and TO_CHAR(created_on, 'Mon')"
	    			+ " in "+"('"+month1+"',"+"'"+month2+"')";
	    	 List<ReportDataDto> listDto = jdbcTemplate.query(query+" ORDER BY " + sortName + " "
	 	            + order.getDirection().name() + " LIMIT " + pageable.getPageSize() + " OFFSET " + pageable.getOffset(),
	 	            (rs, rowNum) -> mapReportResult(rs));
	    	 
			 Page<ReportDataDto> page = new PageImpl<>(listDto, pageable, listDto.size());
			 
	    	 response.put("validationTests", listDto);
	    	 response.put("currentPage", page.getNumber());
			 response.put("totalRecords", page.getTotalElements());
			 response.put("totalPages", page.getTotalPages());
			 
		} catch (Exception e) {
			log.error("Exception "+e.getMessage());
			e.printStackTrace();
		}
		return response;
	}

	@Override
	@Transactional
	public String deleteTests(List<Long> runId) {
		String response = null;
		boolean isPresent = true;
		try {
			if (!runId.isEmpty()) {
				if (runId.size()==1) {
					Optional<ValidationTest> optTest = paymentDao.findById(runId.get(0));
					if (!optTest.isPresent())
						isPresent = false;
				}
				if (isPresent) {
					deleteObjectMinio(runId);
					valErrorDao.deleteByRunIdIn(runId);
					inputDao.deleteByRunIdIn(runId);
					outputDao.deleteByRunIdIn(runId);
					paymentDao.deleteByRunIdIn(runId);
					response = "Test with "+runId+" are deleted successfuly";
				}else	
					response = "given runId not exist";
			}else
				response = "runId List is empty";
			
		} catch (Exception e) {
			response = "Exception while Deleting Test "+e.getMessage();
			log.error("Exception "+e.getMessage());
			e.printStackTrace();
		}
		return response;
	}
	
	private void deleteObjectMinio(List<Long> runId) {
		try {
			MinioClient minioClient = MinioClientConnection.getInstance(appPropertiesObj.getMinio().getMinioDBUrl(),
					appPropertiesObj.getMinio().getMinioDBUserNm(), appPropertiesObj.getMinio().getMinioDBPw());
			String bucketName = appPropertiesObj.getMinio().getMinioBucketNm();
			
			runId.forEach(id ->{
				List<String> input = inputDao.getTestInputDataObjectId(id);
				input.forEach(objId ->{
					try {
						minioClient.removeObject(RemoveObjectArgs.builder().bucket(bucketName).object(objId).build());
					} catch (InvalidKeyException | ErrorResponseException | IllegalArgumentException
							| InsufficientDataException | InternalException | InvalidBucketNameException
							| InvalidResponseException | NoSuchAlgorithmException | ServerException | XmlParserException
							| IOException e) {
						log.error("Exception Message "+e.getMessage());
						e.printStackTrace();
					}
					
				});
			});
		} catch (Exception e2) {
			e2.printStackTrace();
		}
	}

	@Override
	public Map<String, Object> findInputSourceType(String inputSourceType, String msgTypeId, Long runId, Pageable pageable) {
		Map<String, Object> response = new LinkedHashMap<>();
		try {
			
			Order order = !pageable.getSort().isEmpty() ? pageable.getSort().toList().get(0) : Order.desc(("run_id"));
			
			String query = "select v.run_id, v.test_name, v.description, v.created_on, v.tags, v.status from validation_test v "
					+ "where v.input_source_type = '"+inputSourceType+"' and v.run_id !="+runId
					+ " and v.run_id in (select i.run_id from test_input_data i where i.msg_type_id = '"+msgTypeId+"'"
					+ "	and i.run_id = v.run_id )";
			
			List<ManualEntry> listDto = jdbcTemplate.query(query+" ORDER BY run_id "+ order.getDirection().name()
	 	            +" LIMIT " + pageable.getPageSize() + " OFFSET " + pageable.getOffset(),
	 	            (rs, rowNum) -> new ManualEntry(rs.getLong("run_id"), rs.getString("test_name"),
	 	           rs.getString("description"), rs.getTimestamp("created_on").toLocalDateTime(), rs.getString("tags"), rs.getString("status")));
			
			 Page<ManualEntry> pageTuts = new PageImpl<>(listDto, pageable, listDto.size());
			
			 response.put("validationTests", listDto);
	    	 response.put("currentPage", pageTuts.getNumber());
			 response.put("totalRecords", pageTuts.getTotalElements());
			 response.put("totalPages", pageTuts.getTotalPages());
			
		} catch (Exception e) {
			log.error("Exception Message "+e.getMessage());
			e.printStackTrace();
		}
		return response;
	}

	@Override
	public String getOutObjectId(String paymentMsgId) {
		List<String> outObjectId=outputDao.findByMsgId(paymentMsgId);
		String result=null;
		if (outObjectId != null && outObjectId.size()>0) {
			String key = outObjectId.get(0);
			try {
				MinioClient minioClient = MinioClientConnection.getInstance(appPropertiesObj.getMinio().getMinioDBUrl(),
						appPropertiesObj.getMinio().getMinioDBUserNm(), appPropertiesObj.getMinio().getMinioDBPw());
				String defaultBucketName = appPropertiesObj.getMinio().getMinioBucketNm();
				String defaultFlod = appPropertiesObj.getMinio().getMinioDFlod();

				InputStream isFile = minioClient.getObject(defaultBucketName, defaultFlod + key);
				result = IOUtils.toString(isFile, StandardCharsets.UTF_8);
				return result;
			} catch (Exception e) {
				log.error("Exception :" + e.getMessage());
				e.printStackTrace();
			}
		}
		return result;
		
	}
}
