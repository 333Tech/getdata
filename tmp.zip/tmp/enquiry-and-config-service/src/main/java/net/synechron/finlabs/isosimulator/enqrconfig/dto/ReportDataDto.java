package net.synechron.finlabs.isosimulator.enqrconfig.dto;

import java.time.LocalDateTime;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * @author Amol.Mandlik
 *
 */

@Data
@AllArgsConstructor
@NoArgsConstructor
public class ReportDataDto {

	private Long runId;
	private String testName;
	private String testDesc;
	private LocalDateTime dateTime;
	private String tags;
	private String status;
	private String process;
	private PassFailCount filesCount;
	
}
