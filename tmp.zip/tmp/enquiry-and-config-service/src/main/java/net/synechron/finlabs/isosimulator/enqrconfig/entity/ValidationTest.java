package net.synechron.finlabs.isosimulator.enqrconfig.entity;

import java.time.LocalDateTime;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.ToString;

@Data
@Table(name = "validation_test")
@AllArgsConstructor
@NoArgsConstructor
@Entity
@ToString
public class ValidationTest {
	
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	@Column(name = "run_id")
	private Long runId;
	@Column(name = "test_name")
	private String testName;
	@Column(name = "description")
	private String description;
	@Column(name = "created_on")
	private LocalDateTime createdOn;
	@Column(name = "payment_type")
	private String paymentType;
	@Column(name = "status")
	private String status;
	@Column(name = "input_source_type")
	private String inputSourceType;
	@Column(name = "tags")
	private String tags;
	@Column(name = "user_id")
	private String userId;
	
}
