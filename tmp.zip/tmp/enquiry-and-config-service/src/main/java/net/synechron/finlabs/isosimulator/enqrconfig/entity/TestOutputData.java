package net.synechron.finlabs.isosimulator.enqrconfig.entity;

import javax.persistence.Column;
import javax.persistence.ColumnResult;
import javax.persistence.ConstructorResult;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.NamedNativeQuery;
import javax.persistence.SqlResultSetMapping;
import javax.persistence.Table;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.ToString;
import net.synechron.finlabs.isosimulator.enqrconfig.dto.FailMessageDetailDto;
import net.synechron.finlabs.isosimulator.enqrconfig.dto.InProgressMessages;
import net.synechron.finlabs.isosimulator.enqrconfig.dto.OutboundPassDto;
import net.synechron.finlabs.isosimulator.enqrconfig.dto.PassMessages;

/**
 * @author Amol.Mandlik
 *
 */

@Data
@AllArgsConstructor
@NoArgsConstructor
@Entity
@ToString
@Table(name = "test_output_data")
@NamedNativeQuery(
	    name = "find_passed_test_details",
	    query = "select distinct i.object_name as fileName, i.msg_type_id as msgType,"
	    		+ "(case when upper(v.input_source_type) = 'MANUALENTRY' then  o.out_object_id else i.object_id end) as objectId "
	    		+ "from validation_test v  inner join test_input_data i on i.run_id = v.run_id "
	    		+ "left join test_output_data o on i.run_id = o.run_id and "
	    		+ "i.object_id = o.input_object_id where i.run_id = :runId and o.status = 'Pass'",
	    resultSetMapping = "pass_message_dto"
	)
	@SqlResultSetMapping(
	    name = "pass_message_dto",
	    classes = @ConstructorResult(
	        targetClass = PassMessages.class,
	        columns = {
	            @ColumnResult(name = "fileName", type = String.class),
	            @ColumnResult(name = "msgType", type = String.class),
	            @ColumnResult(name = "objectId", type = String.class)
	        }
	    )
	)
@NamedNativeQuery(
	    name = "find_inprogress_test_details",
	    query = "select distinct i.object_name as fileName, i.msg_type_id as msgType, i.object_id as objectId "
	    		+ "from test_input_data i left join test_output_data o on i.run_id = o.run_id and "
	    		+ "i.object_id = o.input_object_id where i.run_id = :runId and o.status is null",
	    resultSetMapping = "in_progress_message_dto"
	)
	@SqlResultSetMapping(
	    name = "in_progress_message_dto",
	    classes = @ConstructorResult(
	        targetClass = InProgressMessages.class,
	        columns = {
	            @ColumnResult(name = "fileName", type = String.class),
	            @ColumnResult(name = "msgType", type = String.class),
	            @ColumnResult(name = "objectId", type = String.class)
	        }
	    )
	)

@NamedNativeQuery(
	    name = "find_validation_error_details",
	    query = "select distinct i.object_name as fileName, i.msg_type_id as msgType, "
	    		+ "i.object_id as objectId, (case when o.status = 'Fail' then 'false' else 'true' end) as isInvalidXml "
	    		+ "from validation_test v inner join test_input_data i on i.run_id = v.run_id "
	    		+ "left join test_output_data o on i.run_id = o.run_id "
	    		+ "where i.object_id = o.input_object_id and i.run_id = :runId and o.status in ('Fail','InvalidXML')",
	    resultSetMapping = "fail_message_dto"
	)
	@SqlResultSetMapping(
	    name = "fail_message_dto",
	    classes = @ConstructorResult(
	        targetClass = FailMessageDetailDto.class,
	        columns = {
	            @ColumnResult(name = "fileName", type = String.class),
	            @ColumnResult(name = "msgType", type = String.class),
	            @ColumnResult(name = "objectId", type = String.class),
	            @ColumnResult(name = "isInvalidXml", type = String.class)
	        }
	    )
	)
@NamedNativeQuery(
	    name = "find_passed_outbound_test_details",
	    query = "select distinct i.object_name as fileName, i.msg_type_id as msgType, i.object_id as objectId, "
	    		+ "o.out_object_id as outObjectId, o.out_object_name as outObjectName, o.response_msg_id as outMsgType "
	    		+ "from test_input_data i inner join test_output_data o on i.run_id = o.run_id and i.object_id = o.input_object_id"
	    		+ " where i.object_id = o.input_object_id and i.run_id = :runId and o.status = 'Pass'",
	    resultSetMapping = "pass_message_outbound"
	)
	@SqlResultSetMapping(
	    name = "pass_message_outbound",
	    classes = @ConstructorResult(
	        targetClass = OutboundPassDto.class,
	        columns = {
	            @ColumnResult(name = "fileName", type = String.class),
	            @ColumnResult(name = "msgType", type = String.class),
	            @ColumnResult(name = "objectId", type = String.class),
	            @ColumnResult(name = "outObjectId", type = String.class),
	            @ColumnResult(name = "outObjectName", type = String.class),
	            @ColumnResult(name = "outMsgType", type = String.class)
	        }
	    )
	)
@NamedNativeQuery(
	    name = "find_failed_outbound_test_details",
	    query = "select distinct i.object_name as fileName, i.msg_type_id as msgType, i.object_id as objectId, "
	    		+ "(case when o.status = 'Fail' then 'false' else 'true' end) as isInvalidXml "
	    		+ "from test_input_data i left join test_output_data o on i.run_id = o.run_id and i.object_id = o.input_object_id"
	    		+ " where i.run_id = :runId and o.status in ('Fail','InvalidXML')",
	    resultSetMapping = "fail_message_outbound"
	)
	@SqlResultSetMapping(
	    name = "fail_message_outbound",
	    classes = @ConstructorResult(
	        targetClass = FailMessageDetailDto.class,
	        columns = {
	            @ColumnResult(name = "fileName", type = String.class),
	            @ColumnResult(name = "msgType", type = String.class),
	            @ColumnResult(name = "objectId", type = String.class),
	            @ColumnResult(name = "isInvalidXml", type = String.class)
	        }
	    )
	)
@NamedNativeQuery(
	    name = "find_inprogress_outbound_details",
	    query = "select distinct i.object_name as fileName, i.msg_type_id as msgType, i.object_id as objectId "
	    		+ "from test_input_data i left join test_output_data o on o.run_id=i.run_id "
	    		+ "and i.object_id=o.input_object_id where i.run_id=:runId and o.status is null",
	    resultSetMapping = "in_progress_message_outbound"
	)
	@SqlResultSetMapping(
	    name = "in_progress_message_outbound",
	    classes = @ConstructorResult(
	        targetClass = InProgressMessages.class,
	        columns = {
	            @ColumnResult(name = "fileName", type = String.class),
	            @ColumnResult(name = "msgType", type = String.class),
	            @ColumnResult(name = "objectId", type = String.class)
	        }
	    )
	)
public class TestOutputData {

	@Id
    @GeneratedValue(strategy = GenerationType.AUTO)
	@Column(name = "id")
	private Long id;
	@Column(name = "run_id")
	private Long runId;
	@Column(name = "input_object_id")
	private String inputObjectId;
	@Column(name = "msg_id")
	private String msgId;
	@Column(name = "out_object_id")
	private String outObjectId;
	@Column(name = "out_object_name")
	private String outObjectName;
	@Column(name = "response_msg_id")
	private String responseMsgId;
	@Column(name = "status")
	private String status;
	
}
