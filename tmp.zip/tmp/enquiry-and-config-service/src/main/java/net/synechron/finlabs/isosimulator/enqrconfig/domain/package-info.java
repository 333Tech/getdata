/**
 * JPA domain objects.
 */
package net.synechron.finlabs.isosimulator.enqrconfig.domain;
