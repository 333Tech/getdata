package net.synechron.finlabs.isosimulator.enqrconfig.service;

import java.util.List;
import java.util.Map;

import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;

import net.synechron.finlabs.isosimulator.enqrconfig.dto.InboundFilesDto;
import net.synechron.finlabs.isosimulator.enqrconfig.dto.OutboundFilesDto;

/**
 * @author Amol.Mandlik
 *
 */

@Service
public interface PaymentService {

	public InboundFilesDto getInboundTestDetails(Long runId);
	
	public Map<String, Object> getAllTestReports(Pageable pageable);
	
	public boolean findByRunId(Long runId);
	
	public OutboundFilesDto getOutboundTestDetails(Long runId);
	
	public Map<String, Object> findBypaymentType(String paymentType, Pageable pageable);
	
	public Map<String, Object> filterReportBasedOnTestName(String testName, Pageable pageable);
	
	public Map<String, Object> filterReportBasedOnrunId(Long runId, Pageable pageable);
	
	public Map<String, Object> filterReportBasedOnMonths(String monthRange, Pageable pageable,String sortName);
	
	public Map<String, Object> filterReportBasedOnMonthsandRunid(String monthRange, Long runId, Pageable pageable);
	
	public Map<String, Object> filterReportBasedOnMonthsandTestName(String monthRange, String testName, Pageable pageable,String sortName);
	
	public String deleteTests(List<Long> runId);
	
	public Map<String, Object> findInputSourceType(String inputSourceType, String msgTypeId, Long runId, Pageable pageable);
	
	public String getOutObjectId(String paymentMsgId);
}
