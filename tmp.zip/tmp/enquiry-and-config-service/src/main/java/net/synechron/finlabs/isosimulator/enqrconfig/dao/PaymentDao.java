package net.synechron.finlabs.isosimulator.enqrconfig.dao;

import java.util.List;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import net.synechron.finlabs.isosimulator.enqrconfig.entity.ValidationTest;

@Repository
public interface PaymentDao extends JpaRepository<ValidationTest, Long>{
	
	public ValidationTest findByRunId(Long runId);
	
	public Page<ValidationTest> findBypaymentType(String paymentType, Pageable pageable);
	
	public Page<ValidationTest> findByTestNameStartingWith(String testName, Pageable pageable);
	
	public Page<ValidationTest> findByRunId(Long runId, Pageable pageable);
	
	public void deleteByRunIdIn(List<Long> runIds);
	
//	public Page<ValidationTest> findByinputSourceType(String inputSourceType, Pageable pageable);
	
}
