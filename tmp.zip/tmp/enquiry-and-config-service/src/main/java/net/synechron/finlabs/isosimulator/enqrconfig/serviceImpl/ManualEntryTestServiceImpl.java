package net.synechron.finlabs.isosimulator.enqrconfig.serviceImpl;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import javax.xml.bind.JAXBException;
import javax.xml.parsers.ParserConfigurationException;
import javax.xml.transform.TransformerException;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.xml.sax.SAXException;

import lombok.extern.slf4j.Slf4j;
import net.synechron.finlabs.isosimulator.CommonFunction;
import net.synechron.finlabs.isosimulator.enqrconfig.dao.TestInputDataDao;
import net.synechron.finlabs.isosimulator.enqrconfig.dao.TestManualEntryDao;
import net.synechron.finlabs.isosimulator.enqrconfig.dao.TestManualEntryDaoImpl;
import net.synechron.finlabs.isosimulator.enqrconfig.domain.TestManualEntryDataResp;
import net.synechron.finlabs.isosimulator.enqrconfig.entity.TestInputData;
import net.synechron.finlabs.isosimulator.enqrconfig.service.ManualEntryTestService;
import net.synechron.finlabs.isosimulator.middleware.model.MessageDataField;

@Service
@Slf4j
public class ManualEntryTestServiceImpl implements ManualEntryTestService {

	@Autowired
	private TestManualEntryDaoImpl testManualEntryTestDaoImpl;
	
	@Autowired
	private TestInputDataDao testInputDataDao;
	
	@Autowired
	private ConfigServiceImpl configServiceImpl;
	
	@Autowired
	private TestManualEntryDao testManualEntryTestDao;
	
	
	@Override
	public TestManualEntryDataResp getManualEntryData(String runId)
			throws IOException, TransformerException, ParserConfigurationException, SAXException, JAXBException, ClassNotFoundException {
		return testManualEntryTestDaoImpl.getManualEntryData(runId);
	}
	
	@Override
	public List<MessageDataField> loadMessageDataFields(Long runId) {
		List<MessageDataField> msgDataList = new ArrayList<>();
		try {
			TestInputData testInputDao = testInputDataDao.findByRunId(runId);			
			if (testInputDao != null && testInputDao.getObjectId().contains(".xml")) {
				msgDataList = configServiceImpl.getLoadMessageDataFields(testInputDao.getObjectId(),
						testInputDao.getMsgtype());
			} else {
				MessageDataField[] msgDataFeilds = testManualEntryTestDao
						.convertXslToXmlToJavaObj(testInputDao.getMsgtype(), testInputDao.getObjectId());
				msgDataList = Arrays.asList(msgDataFeilds);
				new CommonFunction().getAutoGenerateFields(msgDataList);
			}
		} catch (Exception e) {
			log.error("Exception Message " + e.getMessage());
			e.printStackTrace();
		}
		return msgDataList;
	}

}
