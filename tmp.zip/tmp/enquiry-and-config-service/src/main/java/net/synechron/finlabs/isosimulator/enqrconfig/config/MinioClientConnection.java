package net.synechron.finlabs.isosimulator.enqrconfig.config;

import io.minio.MinioClient;

public class MinioClientConnection {

	private static MinioClient instance;

	public static synchronized MinioClient getInstance(String url, String unm, String pw) {

		if (instance == null) {
			synchronized (MinioClientConnection.class) {
				if (instance == null) {
					instance = MinioClient.builder().endpoint(url).credentials(unm, pw).build();
				}
			}
		}
		return instance;
	}

	private MinioClientConnection() {
	}

}
