package net.synechron.finlabs.isosimulator.enqrconfig.controller;

import java.io.IOException;
import java.util.List;

import javax.xml.bind.JAXBException;
import javax.xml.parsers.ParserConfigurationException;
import javax.xml.transform.TransformerException;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import org.xml.sax.SAXException;

import io.swagger.annotations.ApiOperation;
import lombok.extern.slf4j.Slf4j;
import net.synechron.finlabs.isosimulator.enqrconfig.domain.TestManualEntryDataResp;
import net.synechron.finlabs.isosimulator.enqrconfig.service.ManualEntryTestService;
import net.synechron.finlabs.isosimulator.enqrconfig.serviceImpl.ManualEntryTestServiceImpl;
import net.synechron.finlabs.isosimulator.middleware.model.MessageDataField;

@RestController
@Slf4j
@RequestMapping(path = "/api/payments")
@CrossOrigin("*")
public class TestManualEntryController {
	
	@Autowired
	private ManualEntryTestServiceImpl manualEntryTestServiceImpl;
	
	@Autowired
	private ManualEntryTestService manualEntryTest;

	@ApiOperation(value = "Load Manual Entry data")
	@GetMapping(value = "/inbounds/tests/{runId}/manualEntry", produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<TestManualEntryDataResp> manualEntryData(@PathVariable String runId)
			throws IOException, TransformerException, ParserConfigurationException, SAXException, 
			JAXBException, ClassNotFoundException {
		log.info("===enter into TestManualEntryController manualEntryData===");		
		TestManualEntryDataResp manualEntryDataSave = manualEntryTestServiceImpl.getManualEntryData(runId);	
		return new ResponseEntity<>(manualEntryDataSave, HttpStatus.CREATED);
	}
	
	@ApiOperation(value = "Load Manual Entry Message Data Based on runId")
	@GetMapping(path = "/inbounds/tests/{runId}/manualEntryInputData")
	public ResponseEntity<List<MessageDataField>> fetchMessageDataFeilds(@PathVariable("runId") Long runId){		
		List<MessageDataField> msgDataFeilds = manualEntryTest.loadMessageDataFields(runId);
		if (!msgDataFeilds.isEmpty())
			return new ResponseEntity<>(msgDataFeilds, HttpStatus.OK);
		else	
			return new ResponseEntity<>(msgDataFeilds, HttpStatus.INTERNAL_SERVER_ERROR);
		
	}
	
	@ApiOperation(value = "Load Manual Entry Outbound data")
	@GetMapping(value = "/outbounds/tests/{runId}/manualEntry", produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<TestManualEntryDataResp> manualEntryOutbound(@PathVariable String runId)
			throws IOException, TransformerException, ParserConfigurationException, SAXException, 
			JAXBException, ClassNotFoundException {
		log.info("===enter into TestManualEntryController manualEntryOutbound===");		
		TestManualEntryDataResp manualEntryDataSave = manualEntryTestServiceImpl.getManualEntryData(runId);	
		return new ResponseEntity<>(manualEntryDataSave, HttpStatus.CREATED);
	}
	
}
