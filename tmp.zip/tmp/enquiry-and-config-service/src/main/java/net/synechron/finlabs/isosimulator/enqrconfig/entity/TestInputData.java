package net.synechron.finlabs.isosimulator.enqrconfig.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * @author Amol.Mandlik
 *
 */

@Data
@Table(name = "test_input_data")
@AllArgsConstructor
@NoArgsConstructor
@Entity
public class TestInputData {
	
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	@Column(name = "id")
	private Long id;
	@Column(name = "run_id")
	private Long runId;
	@Column(name = "object_id")
	private String objectId;
	@Column(name = "object_name")
	private String objectName;
	@Column(name = "description")
	private String description;
	@Column(name = "input_type")
	private String inputType;
	@Column(name = "msg_type_id")
	private String msgtype;
	@Column(name = "response_msg_id")
	private String responseMsgId;
	
//	@ManyToOne
//	private ValidationTest validationtest;

}
