package net.synechron.finlabs.isosimulator.enqrconfig.config;

import org.springframework.boot.context.properties.ConfigurationProperties;

/**
 * Properties specific to Enquiry Config Service.
 * <p>
 * Properties are configured in the {@code application.yml} file.
 * See {@link tech.jhipster.config.JHipsterProperties} for a good example.
 */
@ConfigurationProperties(prefix = "application", ignoreUnknownFields = false)
public class ApplicationProperties {
	
	private final Minio minio = new Minio();
	
	public Minio getMinio() {
		return minio;
	}
	
	public static class Minio {
		
		private String minioBucketNm = ApplicationDefault.Minio.minioBucketNm;
		private String minioDBUrl = ApplicationDefault.Minio.minioDBUrl;
		private String minioDBUserNm = ApplicationDefault.Minio.minioDBUserNm;
		private String minioDBPw = ApplicationDefault.Minio.minioDBPw;
		private String minioDFlod = ApplicationDefault.Minio.minioDFlod;

		public String getMinioBucketNm() {
			return minioBucketNm;
		}

		public void setMinioBucketNm(String minioBucketNm) {
			this.minioBucketNm = minioBucketNm;
		}

		public String getMinioDBUrl() {
			return minioDBUrl;
		}

		public void setMinioDBUrl(String minioDBUrl) {
			this.minioDBUrl = minioDBUrl;
		}

		public String getMinioDBUserNm() {
			return minioDBUserNm;
		}

		public void setMinioDBUserNm(String minioDBUserNm) {
			this.minioDBUserNm = minioDBUserNm;
		}

		public String getMinioDBPw() {
			return minioDBPw;
		}

		public void setMinioDBPw(String minioDBPw) {
			this.minioDBPw = minioDBPw;
		}

		public String getMinioDFlod() {
			return minioDFlod;
		}

		public void setMinioDFlod(String minioDFlod) {
			this.minioDFlod = minioDFlod;
		}
	}
	
}
