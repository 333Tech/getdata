package net.synechron.finlabs.isosimulator.enqrconfig.dto;

import java.time.LocalDateTime;
import java.util.List;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * @author Amol.Mandlik
 *
 */

@Data
@AllArgsConstructor
@NoArgsConstructor
public class InboundFilesDto {
	
	private Long runId;
	private String testName;
	private String testDesc;
	private LocalDateTime datetime;
	private String status;
	private List<PassMessages> passMessages;
	private List<InProgressMessages> inProgressMessages;
	private List<FailMessages> failMessages;
	

}
