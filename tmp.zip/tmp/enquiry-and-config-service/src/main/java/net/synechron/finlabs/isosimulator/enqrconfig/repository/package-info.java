/**
 * Spring Data JPA repositories.
 */
package net.synechron.finlabs.isosimulator.enqrconfig.repository;
