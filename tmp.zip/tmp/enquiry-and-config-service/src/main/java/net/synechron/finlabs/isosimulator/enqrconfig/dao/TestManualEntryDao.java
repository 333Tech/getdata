package net.synechron.finlabs.isosimulator.enqrconfig.dao;

import java.io.IOException;

import javax.xml.bind.JAXBException;
import javax.xml.parsers.ParserConfigurationException;
import javax.xml.transform.TransformerException;

import org.springframework.stereotype.Repository;
import org.xml.sax.SAXException;

import net.synechron.finlabs.isosimulator.enqrconfig.domain.TestManualEntryDataResp;
import net.synechron.finlabs.isosimulator.middleware.model.MessageDataField;

@Repository
public interface TestManualEntryDao {
	public TestManualEntryDataResp getManualEntryData(String runId)
			throws IOException, TransformerException, ParserConfigurationException, SAXException, JAXBException, ClassNotFoundException;
	
	public MessageDataField[] convertXslToXmlToJavaObj(String msgTypId, String objectId);
	
}
