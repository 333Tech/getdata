package net.synechron.finlabs.isosimulator.enqrconfig.dao;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import net.synechron.finlabs.isosimulator.enqrconfig.dto.TestValidationError;
import net.synechron.finlabs.isosimulator.enqrconfig.entity.ValidationError;

/**
 * @author Amol.Mandlik
 *
 */

@Repository
public interface ValidationErrorDao extends JpaRepository<ValidationError, String> {
	
	@Query(name = "find_validation_error_message", nativeQuery = true)
	public List<TestValidationError> getErrorMessage(@Param("runId")  Long runId,@Param("objectId") String objectId);

	public void deleteByRunIdIn(List<Long> runIds);
}
