package net.synechron.finlabs.isosimulator.enqrconfig.dto;

import java.time.LocalDateTime;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * @author Amol.Mandlik
 *
 */

@Data
@AllArgsConstructor
@NoArgsConstructor
public class TestsDto {

	private long runId;
	private String testName;
	private String paymentType;
	private String status;
	private LocalDateTime dateTime;
}
