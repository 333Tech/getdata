package net.synechron.finlabs.isosimulator.enqrconfig.service;

import java.io.IOException;
import java.io.InputStream;
import java.util.List;

import javax.xml.parsers.ParserConfigurationException;

import org.springframework.stereotype.Service;
import org.xml.sax.SAXException;

import net.synechron.finlabs.isosimulator.domain.IsoMessageMetaData;
import net.synechron.finlabs.isosimulator.domain.SampleMsgData;
import net.synechron.finlabs.isosimulator.enqrconfig.dto.FileResponse;
import net.synechron.finlabs.isosimulator.enqrconfig.dto.IsoMessageMetaDataDto;
import net.synechron.finlabs.isosimulator.enqrconfig.dto.ReferenceDataDto;
import net.synechron.finlabs.isosimulator.enqrconfig.dto.ReferenceResponse;
import net.synechron.finlabs.isosimulator.enqrconfig.dto.ResponseMessageDto;
import net.synechron.finlabs.isosimulator.enqrconfig.dto.SampleMsgDataDto;
import net.synechron.finlabs.isosimulator.middleware.model.MessageDataField;

@Service
public interface ConfigService {

	public IsoMessageMetaData saveConfigMessage(IsoMessageMetaDataDto configMessage);
	
	public SampleMsgData saveSampleMsgData(SampleMsgDataDto sampleMsgData);
	
	public String deleteSampleMsgData(String id);
	
	public String generateRandomBase64Token(int byteLength);

	public boolean findByNameAndVersionAndInboundMsgId(String name, String version, String inboundMsgId);

	public List<IsoMessageMetaData> getAllConfigMessages();

	public String uploadFile(String name, byte[] content);

	public byte[] downloadFile(String key);

	public boolean findById(String id);

	public List<ResponseMessageDto> getResponseMessages(String resMesgTypeId);

	public String createResponseMessage(String intiatorMsgTypeId, ResponseMessageDto responseMessageDto,
			String responseMsgTypeId);

	public List<IsoMessageMetaDataDto> getAllInboundsConfigs();

	public boolean checkConfigMessagePresent(String id);

	public boolean checkResponseMessagePresent(String code, String responseMsgId, String initiatorMsgId);

	public String deleteConfMessage(String id);

	public String deleteResponseMessage(String id);

	public String getXsdNS(InputStream imptStrObj) throws ParserConfigurationException, SAXException, IOException;

	public List<String> getReferenceData(String datakey);
	
	public ReferenceResponse insertReferenceData(ReferenceDataDto datakey);
	
	public List<ReferenceDataDto> getAllReferenceData();
	
	public ReferenceResponse updateReferenceData(ReferenceDataDto datakey);

	public List<MessageDataField> loadMessageDataFields(Long id) throws Exception;

	List<IsoMessageMetaDataDto> getInboundMsgId();

	List<FileResponse> getInboundSampleMsgData();

	List<FileResponse> getOutboundSampleMsgData();

	public List<MessageDataField> getLoadMessageDataFields(String xmlObjectId, String isoMsgId) throws Exception;

}
