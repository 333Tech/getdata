package net.synechron.finlabs.isosimulator.enqrconfig.dto;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * @author Amol.Mandlik
 *
 */

@Data
@AllArgsConstructor
@NoArgsConstructor
public class TestValidationError {

	private String xpath;
	private String xmlElement;
	private String fieldName;
	private String data;
	private String error;
}
