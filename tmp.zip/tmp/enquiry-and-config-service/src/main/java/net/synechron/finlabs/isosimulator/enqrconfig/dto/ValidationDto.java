package net.synechron.finlabs.isosimulator.enqrconfig.dto;

import java.time.LocalDateTime;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;


@Data
@AllArgsConstructor
@NoArgsConstructor
public class ValidationDto {

	private Long runId;
	private String testName;
	private String testDesc;
	private LocalDateTime datetime;
	private PassFailCount filesCount;
	private String status;
	
	
}
