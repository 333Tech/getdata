package net.synechron.finlabs.isosimulator.enqrconfig.dto;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class TestInputDataDto {
	
	private Long runId;
	private String objectId;
	private String objectName;
	private String description;
	private String inputType;
	private String msgtype;
	private String responseMsgId;
	private String msgId;
}
