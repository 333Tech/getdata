package net.synechron.finlabs.isosimulator.enqrconfig.service;

import java.io.IOException;
import java.util.List;

import javax.xml.bind.JAXBException;
import javax.xml.parsers.ParserConfigurationException;
import javax.xml.transform.TransformerException;

import org.springframework.stereotype.Service;
import org.xml.sax.SAXException;

import net.synechron.finlabs.isosimulator.enqrconfig.domain.TestManualEntryDataResp;
import net.synechron.finlabs.isosimulator.middleware.model.MessageDataField;


@Service
public interface ManualEntryTestService {

	public TestManualEntryDataResp getManualEntryData(String runId)
			throws IOException, TransformerException, ParserConfigurationException, SAXException, JAXBException, ClassNotFoundException;
	
	public List<MessageDataField> loadMessageDataFields(Long runId);
}
