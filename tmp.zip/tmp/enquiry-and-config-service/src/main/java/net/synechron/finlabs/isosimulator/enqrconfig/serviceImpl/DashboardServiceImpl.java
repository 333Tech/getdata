package net.synechron.finlabs.isosimulator.enqrconfig.serviceImpl;

import java.sql.ResultSet;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.BeanPropertyRowMapper;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Service;

import lombok.extern.slf4j.Slf4j;
import net.synechron.finlabs.isosimulator.enqrconfig.dao.PaymentDao;
import net.synechron.finlabs.isosimulator.enqrconfig.dto.SimulatorResponseDto;
import net.synechron.finlabs.isosimulator.enqrconfig.dto.StatusCountDto;
import net.synechron.finlabs.isosimulator.enqrconfig.dto.TestsDto;
import net.synechron.finlabs.isosimulator.enqrconfig.service.DashboardService;

/**
 * @author Amol.Mandlik
 *
 */

@Service
@Slf4j
public class DashboardServiceImpl implements DashboardService {

	@Autowired
	private JdbcTemplate jdbcTemplate;
	
	@Autowired
	private PaymentDao paymentDao;

	@Override
	public StatusCountDto displayQuickSummaryDashboard() {

		StatusCountDto statusCountDto = new StatusCountDto();

		try {
			String query = "select status, count(*) as count from validation_test group by status order by status";
			Map<String,Long> result = jdbcTemplate.query(query, (ResultSet rs) -> {
				Map<String,Long> results = new LinkedHashMap<>();
			    while (rs.next()) {
			    	results.put(rs.getString("status"), rs.getLong("count"));
			    }
			    return results;
			});
			statusCountDto.setDraft(result.get("Draft")==null ? 0 : result.get("Draft")
							+ (result.get("Inprogress")==null ? 0 : result.get("Inprogress")));
			statusCountDto.setProcessed(result.get("Processed")==null ? 0 : result.get("Processed"));
			statusCountDto.setPartial(result.get("Partial")==null ? 0 : result.get("Partial"));
			statusCountDto.setFailed(result.get("Failed")==null ? 0 : result.get("Failed"));
		} catch (Exception e) {
			e.printStackTrace();
		}
		return statusCountDto;
	}

	@Override
	public List<TestsDto> recentTests(int recordCount) {
		
		List<TestsDto> response = null;
		try {
			String query = "select run_id runId, test_name testName, payment_type as paymentType, status, created_on datetime "
					+ " from validation_test order by run_id desc LIMIT "+recordCount;
			
			response = jdbcTemplate.query(query, new BeanPropertyRowMapper<TestsDto>(TestsDto.class));
		} catch (Exception e) {
			e.printStackTrace();
		}
		return response;
	}
	
	@Override
	public List<SimulatorResponseDto> displaySimulatorResposne(String intiatorMsgid, int days) {
		
		List<SimulatorResponseDto> resList = null;
		try {
			String query = null;
			if (days > 0) {
				if (intiatorMsgid.contains("camt")) 
					 query = "select to_char(v.created_on,'yyyy-mm-dd') as date, "
							+ "sum((select count(*) from test_output_data to1 where to1.run_id = v.run_id and to1.response_msg_id  in "
							+ " (select rm1.id from response_message rm1 where rm1.code != 'RJCR' and rm1.initiator_msgid = '"+intiatorMsgid+"')))as postiveResponses, "
							+ "sum((select count(*) from test_output_data to2 where to2.run_id = v.run_id and to2.response_msg_id in "
							+ " (select rm2.id from response_message rm2 where rm2.code = 'RJCR' and rm2.initiator_msgid = '"+intiatorMsgid+"')))as negativeResponses "
							+ "from validation_test v where v.created_on > current_date - interval '"+days+" days' group by to_char(v.created_on,'yyyy-mm-dd')";
				else {
					 query = "select to_char(v.created_on,'yyyy-mm-dd') as date, "
							+ "sum((select count(*) from test_output_data to1 where to1.run_id = v.run_id and to1.response_msg_id  in "
							+ " (select rm1.id from response_message rm1 where rm1.code = 'ACCP' and rm1.initiator_msgid = '"+intiatorMsgid+"')))as postiveResponses, "
							+ "sum((select count(*) from test_output_data to2 where to2.run_id = v.run_id and to2.response_msg_id in "
							+ " (select rm2.id from response_message rm2 where rm2.code != 'ACCP' and rm2.initiator_msgid = '"+intiatorMsgid+"')))as negativeResponses "
							+ "from validation_test v where v.created_on > current_date - interval '"+days+" days' group by to_char(v.created_on,'yyyy-mm-dd')";
				}
			}else {
				if (intiatorMsgid.contains("camt")) 
					 query = "select to_char(v.created_on,'yyyy-mm-dd') as date, "
							+ "sum((select count(*) from test_output_data to1 where to1.run_id = v.run_id and to1.response_msg_id  in "
							+ " (select rm1.id from response_message rm1 where rm1.code != 'RJCR' and rm1.initiator_msgid = '"+intiatorMsgid+"')))as postiveResponses, "
							+ "sum((select count(*) from test_output_data to2 where to2.run_id = v.run_id and to2.response_msg_id in "
							+ " (select rm2.id from response_message rm2 where rm2.code = 'RJCR' and rm2.initiator_msgid = '"+intiatorMsgid+"')))as negativeResponses "
							+ "from validation_test v group by to_char(v.created_on,'yyyy-mm-dd')";
				else {
					 query = "select to_char(v.created_on,'yyyy-mm-dd') as date, "
							+ "sum((select count(*) from test_output_data to1 where to1.run_id = v.run_id and to1.response_msg_id  in "
							+ " (select rm1.id from response_message rm1 where rm1.code = 'ACCP' and rm1.initiator_msgid = '"+intiatorMsgid+"')))as postiveResponses, "
							+ "sum((select count(*) from test_output_data to2 where to2.run_id = v.run_id and to2.response_msg_id in "
							+ " (select rm2.id from response_message rm2 where rm2.code != 'ACCP' and rm2.initiator_msgid = '"+intiatorMsgid+"')))as negativeResponses "
							+ "from validation_test v group by to_char(v.created_on,'yyyy-mm-dd')";
				}
			}
			
			resList = jdbcTemplate.query(query, new BeanPropertyRowMapper<SimulatorResponseDto>(SimulatorResponseDto.class));
			
		} catch (Exception e) {
			log.error("Exception Message "+e.getMessage());
			e.printStackTrace();
		}
		return resList;
	}

	@Override
	public Long getAllTestsCount() {
		long count = 0;
		try {
			count = paymentDao.count();
		} catch (Exception e) {
			log.error("Exception Message "+e.getMessage());
			e.printStackTrace();
		}
		return count;
	}
	
}
