
package net.synechron.finlabs.isosimulator.enqrconfig.controller;

import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import io.swagger.annotations.ApiOperation;
import lombok.extern.slf4j.Slf4j;
import net.synechron.finlabs.isosimulator.enqrconfig.dto.InboundFilesDto;
import net.synechron.finlabs.isosimulator.enqrconfig.dto.OutboundFilesDto;
import net.synechron.finlabs.isosimulator.enqrconfig.service.PaymentService;


@RestController
@Slf4j
@RequestMapping("/api")
@CrossOrigin("*")
public class PaymentController {
	
	@Autowired
	private PaymentService paymentService;
	
	@ApiOperation(value = "Load All Inbound Tests")
	@GetMapping(path = "/payments/inbounds/tests")
	public ResponseEntity<Map<String, Object>> getAllTests(
	        @RequestParam(defaultValue = "0") int page,
			@RequestParam(defaultValue = "10") int size){
		
		try {
			Pageable paging = PageRequest.of(page, size,Sort.by("runId").descending());
			Map<String, Object> response = paymentService.findBypaymentType("Inbound", paging);
			return new ResponseEntity<>(response, HttpStatus.OK);
		} catch (Exception e) {
			log.error("Exception "+e.getMessage());
			return new ResponseEntity<>(null, HttpStatus.INTERNAL_SERVER_ERROR);
		}
	}
	
	@ApiOperation(value = "Load Inbound Test Based On runId")
	@GetMapping(path = "/payments/inbounds/tests/{runId}")
	public ResponseEntity<InboundFilesDto> getInboundTestDetails(@PathVariable("runId") Long runId){
		InboundFilesDto inbdDetails = new InboundFilesDto();
		if (paymentService.findByRunId(runId)) {
			inbdDetails = paymentService.getInboundTestDetails(runId);
			return new ResponseEntity<>(inbdDetails,HttpStatus.OK);
		}else
			return new ResponseEntity<>(inbdDetails,HttpStatus.NOT_FOUND);
	}
	
	@ApiOperation(value = "Load All Reports")
	@GetMapping(path = "/reports/tests")
	public ResponseEntity<Map<String, Object>> getAllTestReports(
	        @RequestParam(defaultValue = "0") int page,
			@RequestParam(defaultValue = "10") int size,
			@RequestParam(defaultValue = "runId") String sortBy,
			@RequestParam(defaultValue = "DESC") String sortOrder
			) {
		try {
			Pageable paging = sortOrder.equalsIgnoreCase("ASC") ? PageRequest.of(page, size, Sort.by(sortBy).ascending()) :
									PageRequest.of(page, size, Sort.by(sortBy).descending());

			Map<String, Object> response = paymentService.getAllTestReports(paging);
			return new ResponseEntity<>(response,HttpStatus.OK);
		} catch (Exception e) {
			log.error("Exception "+e.getMessage());
			return new ResponseEntity<>(null, HttpStatus.INTERNAL_SERVER_ERROR);
		}
	}
	
	@ApiOperation(value = "Load All Outbound Tests")
	@GetMapping(path = "/payments/outbounds/tests")
	public ResponseEntity<Map<String, Object>> getAllOutBoundsTests(
	        @RequestParam(defaultValue = "0") int page,
			@RequestParam(defaultValue = "10") int size){
		try {
			Pageable paging = PageRequest.of(page, size,Sort.by("runId").descending());
			Map<String, Object> response = paymentService.findBypaymentType("Outbound", paging);
			return new ResponseEntity<>(response, HttpStatus.OK);
		} catch (Exception e) {
			log.error("Exception "+e.getMessage());
			return new ResponseEntity<>(null, HttpStatus.INTERNAL_SERVER_ERROR);
		}
	
	}
	
	@ApiOperation(value = "Load Outbound Test based on runId")
	@GetMapping(path = "/payments/outbounds/tests/{runId}")
	public ResponseEntity<OutboundFilesDto> getOutboundTestDetails(@PathVariable("runId") Long runId){
		OutboundFilesDto outDetails = new OutboundFilesDto();
		if (paymentService.findByRunId(runId)) {
			outDetails = paymentService.getOutboundTestDetails(runId);
			return new ResponseEntity<>(outDetails,HttpStatus.OK);
		}else
			return new ResponseEntity<>(outDetails,HttpStatus.NOT_FOUND);
	}
	
	
	@ApiOperation(value = "Load Reports Based On Search Condition")
	@GetMapping(path = "/reports/tests/search")
    public ResponseEntity<Map<String, Object>> readReportsWithFilter (
    		@RequestParam(required = false,defaultValue = "null") String searchBy,
    		@RequestParam(required = false,defaultValue = "null") String monthRange,
    		@RequestParam(defaultValue = "0") int page,
			@RequestParam(defaultValue = "10") int size,
			@RequestParam(defaultValue = "runId") String sortBy,
			@RequestParam(defaultValue = "desc") String sortOrder) {
		try {
			Map<String, Object> response = null;
			String sortName = null;
			if(sortBy.equals("runId")) sortName = "run_id";
			else if(sortBy.equals("paymentType")) sortName = "payment_type";
			else sortName = sortBy;
			Pageable pageable = sortOrder.equals("asc") ? PageRequest.of(page, size, Sort.by(sortBy).ascending()) :
										PageRequest.of(page, size, Sort.by(sortBy).descending());

			if (!(monthRange.equals("null") || monthRange==null || monthRange.isEmpty()) && !(searchBy.equals("null") || searchBy==null)) {
				if (isInteger(searchBy, 10))
					response = paymentService.filterReportBasedOnMonthsandRunid(monthRange, Long.parseLong(searchBy), pageable);
				else
					response = paymentService.filterReportBasedOnMonthsandTestName(monthRange, searchBy, pageable, sortName);
			}
			else if (!(searchBy.equals("null") || searchBy==null) && (monthRange.equals("null") || monthRange.isEmpty())) {
					if (isInteger(searchBy, 10))
						response = paymentService.filterReportBasedOnrunId(Long.parseLong(searchBy), pageable);
					else
						response = paymentService.filterReportBasedOnTestName(searchBy, pageable);
			} 
			else if (!(monthRange.equals("null") || monthRange==null || monthRange.isEmpty()) && (searchBy.equals("null") || searchBy.isEmpty())) {
				response = paymentService.filterReportBasedOnMonths(monthRange, pageable,sortName);
			} else {
				response = paymentService.getAllTestReports(pageable);
			}
			return new ResponseEntity<>(response, HttpStatus.OK);
		} catch (Exception e) {
			e.printStackTrace();
			return new ResponseEntity<>(null, HttpStatus.INTERNAL_SERVER_ERROR);
		}
	}
	
	private static boolean isInteger(String s, int radix) {
	    if(s.isEmpty()) return false;
	    for(int i = 0; i < s.length(); i++) {
	        if(i == 0 && s.charAt(i) == '-') {
	            if(s.length() == 1) return false;
	            else continue;
	        }
	        if(Character.digit(s.charAt(i),radix) < 0) return false;
	    }
	    return true;
	}
	
	@ApiOperation(value = "Delete test Based On runId")
	@DeleteMapping(path = "/payments/tests")
	public ResponseEntity<String> deleteTests(@RequestBody List<Long> runId){
		 String response = paymentService.deleteTests(runId);
		 if(response.contains("successfuly"))
			 return new ResponseEntity<>(response,HttpStatus.OK);
		 else
			 return new ResponseEntity<>(response,HttpStatus.INTERNAL_SERVER_ERROR);
	}
	
	@ApiOperation(value = "Load Inbound Manual Entry Tests")
	@GetMapping(path = "/payments/inbounds/tests/manualEntry/{msgTypeId}/{currentRunId}")
	public ResponseEntity<Map<String, Object>> getAllManualEntry(
			@PathVariable("msgTypeId") String msgTypeId,
			@PathVariable("currentRunId") Long runId, 
			@RequestParam(defaultValue = "0") int page,
			@RequestParam(defaultValue = "10") int size){
		try {
			Pageable paging = PageRequest.of(page, size,Sort.by("runId").descending());
			Map<String, Object> response = paymentService.findInputSourceType("ManualEntry",msgTypeId,runId, paging);
			return new ResponseEntity<>(response, HttpStatus.OK);
		} catch (Exception e) {
			log.error("Exception Message :"+e.getMessage());
			return new ResponseEntity<>(null, HttpStatus.INTERNAL_SERVER_ERROR);
		}
	
	}
	
	@GetMapping(path = "/payments/outbounds/messageIds/{payment_message_id}/responseMsgXml")
	public ResponseEntity<String> getOutboundMessages(@PathVariable("payment_message_id") String paymentMsgId) {
		String result = paymentService.getOutObjectId(paymentMsgId);
		if(result!=null) {
			return new ResponseEntity<>(result, HttpStatus.OK);
		} else {
			return new ResponseEntity<>(result, HttpStatus.NO_CONTENT);
		}
	}
}
