package net.synechron.finlabs.isosimulator.enqrconfig.controller;

import java.io.IOException;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.io.ByteArrayResource;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.util.StringUtils;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestPart;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;

import io.swagger.annotations.ApiOperation;
import lombok.extern.slf4j.Slf4j;
import net.synechron.finlabs.isosimulator.domain.IsoMessageMetaData;
import net.synechron.finlabs.isosimulator.domain.SampleMsgData;
import net.synechron.finlabs.isosimulator.enqrconfig.dao.SampleMsgDataDao;
import net.synechron.finlabs.isosimulator.enqrconfig.dto.FileResponse;
import net.synechron.finlabs.isosimulator.enqrconfig.dto.IsoMessageMetaDataDto;
import net.synechron.finlabs.isosimulator.enqrconfig.dto.ReferenceDataDto;
import net.synechron.finlabs.isosimulator.enqrconfig.dto.ReferenceResponse;
import net.synechron.finlabs.isosimulator.enqrconfig.dto.ResponseMessageDto;
import net.synechron.finlabs.isosimulator.enqrconfig.dto.SampleMsgDataDto;
import net.synechron.finlabs.isosimulator.enqrconfig.service.ConfigService;
import net.synechron.finlabs.isosimulator.middleware.model.MessageDataField;

@RestController
@RequestMapping(path = "/api/payments")
@Slf4j
@CrossOrigin("*")
public class ConfigController {

	@Autowired
	ConfigService configService;
	
	@Autowired
	private SampleMsgDataDao sampleMsgDataDao;

	@ApiOperation(value = "Add Config Message")
	@PostMapping("/configs/messages")
	public ResponseEntity<String> saveConfigMessage(@RequestPart IsoMessageMetaDataDto isoMessageMetadata,
			@RequestPart List<MultipartFile> xslXsdFiles) {

		boolean isRecordExists = configService.findByNameAndVersionAndInboundMsgId(isoMessageMetadata.getMsgTypeName(),
				isoMessageMetadata.getVersion(),isoMessageMetadata.getInboundMsgId());

		if (!isRecordExists) {
			try {
				if (xslXsdFiles.size() >= 2) {
					for (MultipartFile file : xslXsdFiles) {
						String filename = StringUtils.cleanPath(file.getOriginalFilename());
						log.info("filename ::" + filename);
						String res = configService.uploadFile(filename, file.getBytes());
						
						if (!res.startsWith("fail")) {
							if (filename.contains(".xsl")) {
								isoMessageMetadata.setXslObjectId(res);
							} else if (filename.contains(".xsd")) {
								isoMessageMetadata.setXsdObjectId(res);
								isoMessageMetadata.setXmlns(configService.getXsdNS(file.getInputStream()));
							}
							if (isoMessageMetadata.getInboundMsgId() != null
									&& !isoMessageMetadata.getInboundMsgId().trim().isEmpty()) {
								isoMessageMetadata.setMsgId(isoMessageMetadata.getMsgTypeName() + "."
										+ isoMessageMetadata.getVersion() + "." + isoMessageMetadata.getInboundMsgId());
							} else {
								isoMessageMetadata.setMsgId(
										isoMessageMetadata.getMsgTypeName() + "." + isoMessageMetadata.getVersion());
							}
						}
					}
					IsoMessageMetaData confMsg = configService.saveConfigMessage(isoMessageMetadata);
					return new ResponseEntity<>(confMsg.getId() + " Added Successfully.", HttpStatus.CREATED);
				}else if (xslXsdFiles.size() == 1) {
					return new ResponseEntity<>("You have to upload one xsd and one xsl.", HttpStatus.INTERNAL_SERVER_ERROR);
				} else if (xslXsdFiles.size() == 2) {
					return new ResponseEntity<>("You have to upload one xsd, one xsl and one xml.", HttpStatus.INTERNAL_SERVER_ERROR);
				}else {
					return new ResponseEntity<>("You Must Have to Upload One xsd and One xsl.", HttpStatus.INTERNAL_SERVER_ERROR);
				}
			} catch (Exception e) {
				log.error("Error while inserting ConfigMessage " + e.getMessage());
				return new ResponseEntity<>(e.getMessage(), HttpStatus.INTERNAL_SERVER_ERROR);
			}
		} else {
			return new ResponseEntity<>("Combination of Name, Version and InboundId already present in the db.", HttpStatus.INTERNAL_SERVER_ERROR);
		}
	}

	@ApiOperation(value = "Update Config Message")
	@PutMapping("/configs/messages")
	public ResponseEntity<String> updateConfigMessage(@RequestPart IsoMessageMetaDataDto isoMessageMetadata,
			@RequestPart List<MultipartFile> xslXsdFiles) {

		try {
			Optional<IsoMessageMetaDataDto> isoMsgDto = Optional.ofNullable(isoMessageMetadata);
			if (isoMsgDto.isPresent()) {
				if (configService.findById(isoMessageMetadata.getMsgId())) {
					Optional<String> msgType = Optional.ofNullable(isoMsgDto.get().getMsgTypeName());
					Optional<String> version = Optional.ofNullable(isoMsgDto.get().getVersion());
					Optional<String> inboundId = Optional.ofNullable(isoMsgDto.get().getInboundMsgId());

					if (msgType.isPresent() || version.isPresent() || inboundId.isPresent()) {
						return new ResponseEntity<>("msgTypeName or version or inbound id cannot be update.", HttpStatus.INTERNAL_SERVER_ERROR);
					} else {
						if (!xslXsdFiles.isEmpty()) {
							for (MultipartFile file : xslXsdFiles) {
								String filename = StringUtils.cleanPath(file.getOriginalFilename());
								String res = configService.uploadFile(filename, file.getBytes());
								if (!res.startsWith("fail")) {
									if (filename.contains(".xsl"))
										isoMessageMetadata.setXslObjectId(res);
									else if (filename.contains(".xsd")) {
										isoMessageMetadata.setXsdObjectId(res);
										isoMessageMetadata.setXmlns(configService.getXsdNS(file.getInputStream()));
									}
								}
							}
						}
						IsoMessageMetaData confMsg = configService.saveConfigMessage(isoMessageMetadata);
						return new ResponseEntity<>(confMsg.getId() + " Updated Successfully", HttpStatus.CREATED);
					}
				} else {
					return new ResponseEntity<>("Record not exists for given msgId " + isoMessageMetadata.getMsgId(),
							HttpStatus.INTERNAL_SERVER_ERROR);
				}
			} else
				return new ResponseEntity<>("Values are not given to update the record.", HttpStatus.INTERNAL_SERVER_ERROR);
		} catch (Exception e) {
			e.printStackTrace();
			return new ResponseEntity<>("Exception While updating " + e.getMessage(), HttpStatus.INTERNAL_SERVER_ERROR);
		}
	}

	@ApiOperation(value = "Get All Config Messages")
	@GetMapping("/configs/messages")
	public ResponseEntity<List<IsoMessageMetaData>> getALlConfigMessages() {
		List<IsoMessageMetaData> confData = configService.getAllConfigMessages();
		if (!confData.isEmpty())
			return new ResponseEntity<>(confData, HttpStatus.OK);
		else
			return new ResponseEntity<>(confData, HttpStatus.INTERNAL_SERVER_ERROR);
	}

	@ApiOperation(value = "Download The XML file")	
	@GetMapping(path = "/download/files/{objectId}")
	public ResponseEntity<ByteArrayResource> uploadFile(@PathVariable(value = "objectId") String objectId)
			throws IOException {
		byte[] data = configService.downloadFile(objectId);
		ByteArrayResource resource = new ByteArrayResource(data);
		log.info("file downloaded successfully");
		return ResponseEntity.ok()
				.contentLength(data.length)
				.header("Content-type", "application/octet-stream")
				.header("Content-disposition", "attachment; filename=\"" + objectId + "\"")
				.body(resource);

	}

	@ApiOperation(value = "Get Config Messages Based on Initiator MsgTypeId")
	@GetMapping(path = "/configs/messages/{intiatorMsgTypeId}/responseCodes")
	public ResponseEntity<List<ResponseMessageDto>> getResponseMessage(
			@PathVariable(value = "intiatorMsgTypeId") String intiatorMsgTypeId) {
		List<ResponseMessageDto> respMsgs = configService.getResponseMessages(intiatorMsgTypeId);
		if (!respMsgs.isEmpty())
			return new ResponseEntity<>(respMsgs, HttpStatus.OK);
		else
			return new ResponseEntity<>(respMsgs, HttpStatus.INTERNAL_SERVER_ERROR);
	}

	@PostMapping(path = "/configs/messages/{intiatorMsgTypeId}/responseCodes/{responseMsgTypeId}")
	public ResponseEntity<String> createResponseMessage(
			@PathVariable(value = "intiatorMsgTypeId") String intiatorMsgTypeId,
			@PathVariable(value = "responseMsgTypeId") String responseMsgTypeId,
			@RequestBody ResponseMessageDto responseMessageDto) {
		String id = configService.createResponseMessage(intiatorMsgTypeId, responseMessageDto, responseMsgTypeId);
		if (id.contains("Exception") || id.contains("already present"))
			return new ResponseEntity<>(id, HttpStatus.NOT_FOUND);
		else
			return new ResponseEntity<>(id, HttpStatus.CREATED);

	}

	@ApiOperation(value = "Get Inbound Config Messages")
	@GetMapping(path = "/configs/messages/inbounds")
	public ResponseEntity<List<IsoMessageMetaDataDto>> getAllInboundsConfigs() {
		List<IsoMessageMetaDataDto> isoInboundList = configService.getAllInboundsConfigs();
		if (!isoInboundList.isEmpty())
			return new ResponseEntity<>(isoInboundList, HttpStatus.OK);
		else
			return new ResponseEntity<>(isoInboundList, HttpStatus.INTERNAL_SERVER_ERROR);
	}
	
	@ApiOperation(value = "Get Inbound Messsage Types")
	@GetMapping(path = "/configs/messages/initiator")
	public ResponseEntity<List<IsoMessageMetaDataDto>> getiInboundMsgId() {
		List<IsoMessageMetaDataDto> isoInboundList = configService.getInboundMsgId();
		if (!isoInboundList.isEmpty())
			return new ResponseEntity<>(isoInboundList, HttpStatus.OK);
		else
			return new ResponseEntity<>(isoInboundList, HttpStatus.INTERNAL_SERVER_ERROR);
	}

	@ApiOperation(value = "Delete Config Message based on id")
	@DeleteMapping(path = "/configs/messages/{id}")
	public ResponseEntity<String> deteleConfMessage(@PathVariable(value = "id") String id) {
		String res = configService.deleteConfMessage(id);
		if (res.contains("successfuly"))
			return new ResponseEntity<>(res, HttpStatus.OK);
		else
			return new ResponseEntity<>(res, HttpStatus.INTERNAL_SERVER_ERROR);

	}

	@ApiOperation(value = "Delete Response Message based on id")
	@DeleteMapping(path = "/configs/responseMessage/{id}")
	public ResponseEntity<String> deteleResponseMessage(@PathVariable(value = "id") String id) {
		String res = configService.deleteResponseMessage(id);
		if (res.contains("successfuly"))
			return new ResponseEntity<>(res, HttpStatus.OK);
		else
			return new ResponseEntity<>(res, HttpStatus.INTERNAL_SERVER_ERROR);
	}

	@ApiOperation(value = "Get Referecne Data based On key")
	@GetMapping(path = "/referencedata/{datakey}")
	public ResponseEntity<List<String>> getReferenceData(@PathVariable(value = "datakey") String datakey) {
		List<String> retObj = configService.getReferenceData(datakey);
		if (!retObj.isEmpty())
			return new ResponseEntity<>(retObj, HttpStatus.OK);
		else
			return new ResponseEntity<>(retObj, HttpStatus.INTERNAL_SERVER_ERROR);
	}
	
	@ApiOperation(value = "Add Reference Data")
	@PostMapping(path = "/referencedata")
	public ResponseEntity<ReferenceResponse> insertReferenceData(@RequestBody ReferenceDataDto datakey) {
		ReferenceResponse retObj = new ReferenceResponse();
		String[] values = datakey.getValues();
		if(!datakey.getDatakey().isEmpty() && values.length>0 && !"".equals(values[0].trim()))
			retObj = configService.insertReferenceData(datakey);
		else
			retObj.setResponse("Required fields to Insert the Reference data are found.");
		if (retObj.getResponse().contains("Successfully"))
			return new ResponseEntity<>(retObj, HttpStatus.OK);
		else
			return new ResponseEntity<>(retObj, HttpStatus.INTERNAL_SERVER_ERROR);
	}
	
	@ApiOperation(value = "Get All Reference Data")
	@GetMapping(path = "/referencedata")
	public ResponseEntity<List<ReferenceDataDto>> getAllReferenceData() {
		List<ReferenceDataDto> refData = configService.getAllReferenceData();
		if (!refData.isEmpty())
			return new ResponseEntity<>(refData , HttpStatus.OK);
		else
			return new ResponseEntity<>(refData, HttpStatus.INTERNAL_SERVER_ERROR);
	}
	
	@ApiOperation(value = "Update Reference Data")
	@PutMapping(path = "/referencedata")
	public ResponseEntity<ReferenceResponse> updatetReferenceData(@RequestBody ReferenceDataDto datakey) {
		ReferenceResponse refRes = new ReferenceResponse();
		String[] values = datakey.getValues();
		if(!datakey.getDatakey().isEmpty() && values.length > 0 && !"".equals(values[0].trim()))
			refRes = configService.updateReferenceData(datakey);
		else
			refRes.setResponse("Required fields to update the Reference data are found.");
		if (refRes.getResponse().contains("Successfully"))
			return new ResponseEntity<>(refRes, HttpStatus.OK);
		else
			return new ResponseEntity<>(refRes, HttpStatus.INTERNAL_SERVER_ERROR);
	}
	
	@ApiOperation(value = "Add Sample Message Data")
	@PostMapping("/configs/messages/samplemsgdata")
	public ResponseEntity<String> saveSampleMsgData(@RequestPart SampleMsgDataDto sampleMsgData,
			@RequestPart List<MultipartFile> xmlFiles) {
		try {
			if (!xmlFiles.isEmpty()) {
				String filename, res, result = "";
				for (MultipartFile xmlFile : xmlFiles) {
					filename = StringUtils.cleanPath(xmlFile.getOriginalFilename());
					if (sampleMsgDataDao.findByxmlObjectId(filename) == null && filename.contains(".xml")) {
						res = configService.uploadFile(filename, xmlFile.getBytes());
						if (res.startsWith("fail")) {
							throw new Exception();
						} else {
							sampleMsgData.setXmlObjectId(res);
							sampleMsgData.setSize(String.valueOf(java.lang.Math.ceil(xmlFile.getSize() / 1024)) + " KB");
							SampleMsgData confMsg = configService.saveSampleMsgData(sampleMsgData);
							result += confMsg.getId() + ",";
						}
					}
				}
				if (!result.trim().equals("")) {
					return new ResponseEntity<>(
							"Id : " + result.substring(0, result.length() - 1) + " added successfully.",
							HttpStatus.CREATED);
				} else {
					return new ResponseEntity<>("File name already exit or upload atleast one xml.",
							HttpStatus.CREATED);
				}
			} else {
				return new ResponseEntity<>("You Must Have to Upload One xml.", HttpStatus.INTERNAL_SERVER_ERROR);
			}
		} catch (Exception e) {
			log.error("Error while inserting Sample Message Data " + e.getMessage());
			return new ResponseEntity<>(e.getMessage(), HttpStatus.INTERNAL_SERVER_ERROR);
		}
	}
	
	@ApiOperation(value = "Delete Sample Message data")
	@DeleteMapping(path = "/configs/messages/samplemsgdata/{id}")
	public ResponseEntity<String> deteleSampleMsgData(@PathVariable(value = "id") String id) {
		String smplData = configService.deleteSampleMsgData(id);
		if (smplData.contains("successfuly"))
			return new ResponseEntity<>(smplData, HttpStatus.OK);
		else
			return new ResponseEntity<>(smplData, HttpStatus.INTERNAL_SERVER_ERROR);
	}
	
	@ApiOperation(value = "Get Inbound Sample Message Data")
	@GetMapping(path = "/sampledata/inbound")
	public ResponseEntity<List<FileResponse>> getInboundSampleMsgData(){
		
		List<FileResponse> fileResponse = configService.getInboundSampleMsgData();
		if (!fileResponse.isEmpty()) 
			return new ResponseEntity<>(fileResponse, HttpStatus.OK);
		else 
			return new ResponseEntity<>(fileResponse, HttpStatus.INTERNAL_SERVER_ERROR);
		
	}
	
	@ApiOperation(value = "Get Outbound Sample Message Data")
	@GetMapping(path = "/sampledata/outbound")
	public ResponseEntity<List<FileResponse>> getOutboundSampleMsgData(){
		
		List<FileResponse> fileResponse = configService.getOutboundSampleMsgData();
		if (!fileResponse.isEmpty()) 
			return new ResponseEntity<>(fileResponse, HttpStatus.OK);
		else 
			return new ResponseEntity<>(fileResponse, HttpStatus.INTERNAL_SERVER_ERROR);
		
	}
	
	@ApiOperation(value = "Get ManualEntry Sample Message Data")
	@GetMapping(path = "/configs/messages/samplemsgdata/{ID}/manualEntryInputData")
	public ResponseEntity<List<MessageDataField>> getSampaleDataByManualEntryImputDataById(
			@PathVariable(value = "ID") Long id) throws Exception{
		
		List<MessageDataField> msgDataFeilds = configService.loadMessageDataFields(id);
		
		if (msgDataFeilds!=null)
			return new ResponseEntity<>(msgDataFeilds, HttpStatus.OK);
		else	
			return new ResponseEntity<>(msgDataFeilds, HttpStatus.INTERNAL_SERVER_ERROR);
	}

}
