# Central configuration sources details

When running the consul.yml or app.yml docker-compose files, files located in `central-server-config/`
will get automatically loaded in Consul's K/V store. Adding or editing files will trigger a reloading.

For more info, refer to https://www.jhipster.tech/consul/
