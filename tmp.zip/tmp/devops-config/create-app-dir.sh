mkdir -p ./app-data/minio/data/
mkdir -p ./app-data/pgsql/data/
mkdir -p ./app-data/pgsql/conf/
mkdir -p ./app-data/rabbitmq/data/
mkdir -p ./app-data/rabbitmq/logs/
mkdir -p ./app-data/consul/data/
mkdir -p ./app-data/bridge-server/