--
-- PostgreSQL database cluster dump
--

SET default_transaction_read_only = off;

SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;

--
-- Drop databases (except postgres and template1)
--

DROP DATABASE IF EXISTS isosimulator_app_db;
DROP DATABASE IF EXISTS isosimulator_gateway_db;

--
-- PostgreSQL database dump
--

-- Dumped from database version 13.4 (Debian 13.4-4.pgdg110+1)
-- Dumped by pg_dump version 13.4 (Debian 13.4-4.pgdg110+1)

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

CREATE DATABASE isosimulator_app_db WITH TEMPLATE = template0 ENCODING = 'UTF8' LOCALE = 'en_US.utf8';

ALTER DATABASE isosimulator_app_db OWNER TO postgres;

CREATE DATABASE isosimulator_gateway_db WITH TEMPLATE = template0 ENCODING = 'UTF8' LOCALE = 'en_US.utf8';


ALTER DATABASE isosimulator_gateway_db OWNER TO postgres;

\connect isosimulator_app_db

CREATE SEQUENCE public.hibernate_sequence
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.hibernate_sequence OWNER TO postgres;

CREATE SEQUENCE public.sequence_generator
    START WITH 1050
    INCREMENT BY 50
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.sequence_generator OWNER TO postgres;


CREATE TABLE public.test_input_data (
    id bigint NOT NULL,
    description character varying(255),
    input_type character varying(255),
    msg_type_id character varying(255),
    object_id character varying(255),
    object_name character varying(255),
    response_msg_id character varying(255),
    run_id bigint,
    validationtest_run_id bigint
);


ALTER TABLE public.test_input_data OWNER TO postgres;

--
-- Name: test_output_data; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.test_output_data (
    id bigint NOT NULL,
    input_object_id character varying(255),
    msg_id character varying(255),
    out_object_id character varying(255),
    out_object_name character varying(255),
    response_msg_id character varying(255),
    run_id bigint,
    status character varying(255)
);


ALTER TABLE public.test_output_data OWNER TO postgres;

--
-- Name: validation_error; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.validation_error (
    id bigint NOT NULL,
    data character varying(255),
    error_message character varying(255),
    field_name character varying(255),
    msg_id character varying(255),
    object_id character varying(255),
    run_id bigint,
    xml_element character varying(255),
    xpath character varying(255)
);


ALTER TABLE public.validation_error OWNER TO postgres;

--
-- Name: validation_test; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.validation_test (
    run_id bigint NOT NULL,
    created_on timestamp without time zone,
    description character varying(255),
    input_source_type character varying(255),
    payment_type character varying(255),
    status character varying(255),
    tags character varying(255),
    test_name character varying(255),
    user_id character varying(255)
);


ALTER TABLE public.validation_test OWNER TO postgres;

--
-- Data for Name: test_input_data; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.test_input_data (id, description, input_type, msg_type_id, object_id, object_name, response_msg_id, run_id, validationtest_run_id) FROM stdin;
686	\N	XML	pacs.008.001.08	1647405686672_685.xml	pacs.008.001.008_valid.xml	\N	685	\N
689	\N	XML	pacs.008.001.08	1647405817111_688.xml	pacs.008.001.008_invalid-MsgId.xml	\N	688	\N
693	\N	XML	pacs.008.001.08	1647406083666_692.xml	pacs008.001.008_invalid-format-MsgId.xml	\N	692	\N
696	\N	XML	pacs.008.001.08	1647409897654_695.xml	pacs.008.001.008_invalid-InstrPrty.xml	\N	695	\N
700	\N	XML	pacs.008.001.08	1647410176680_699.xml	pacs.008.001.008_invalid-BICFI.xml	\N	699	\N
704	\N	XML	pacs.008.001.08	1647410495618_703.xml	pacs.008.001.008_invalid-ClrChanl.xml	\N	703	\N
708	\N	XML	pacs.008.001.08	1647411459966_707.xml	pacs.008.001.008_invalid-BICFI.xml	\N	707	\N
709	\N	XML	pacs.008.001.08	1647411459985_707.xml	pacs.008.001.008_invalid-ClrChanl.xml	\N	707	\N
710	\N	XML	pacs.008.001.08	1647411460018_707.xml	pacs.008.001.008_invalid-InstrPrty.xml	\N	707	\N
711	\N	XML	pacs.008.001.08	1647411460072_707.xml	pacs.008.001.008_invalid-CreDtTm.xml	\N	707	\N
729	\N	XML	pacs.008.001.08	1647416347569_728.xml	pacs.008.001.008_valid.xml	\N	728	\N
730	\N	XML	pacs.008.001.08	1647416347587_728.xml	pacs.008.001.008_valid2.xml	\N	728	\N
731	\N	XML	pacs.008.001.08	1647416347613_728.xml	pacs.008.001.008_valid3.xml	\N	728	\N
736	\N	XML	pacs.008.001.08	1647417013950_735.xml	pacs.008.001.008_valid.xml	pacs.002.001.10.ACCP	735	\N
739	\N	XML	pacs.008.001.08	1647417098757_738.xml	pacs.008.001.008_valid.xml	pacs.002.001.10.AC01	738	\N
742	\N	XML	pacs.008.001.08	1647417199383_741.xml	pacs.008.001.008_valid.xml	pacs.002.001.10.AC04	741	\N
745	\N	XML	pacs.008.001.08	1647417591890_744.xml	pacs.008.001.008_valid2.xml	pacs.002.001.10.AG02	744	\N
746	\N	XML	pacs.008.001.08	1647417591952_744.xml	pacs.008.001.008_valid.xml	pacs.002.001.10.AM03	744	\N
747	\N	XML	pacs.008.001.08	1647417592012_744.xml	pacs.008.001.008_valid3.xml	pacs.002.001.10.AG01	744	\N
748	\N	XML	pacs.008.001.08	1647417592036_744.xml	pacs.008.001.008_valid4.xml	pacs.002.001.10.AM02	744	\N
754	\N	XML	pacs.008.001.08	1647417815980_753.xml	pacs.008.001.008_valid.xml	pacs.002.001.10.AC04	753	\N
757	\N	XML	pacs.008.001.08	1647418044629_756.xml	pacs.008.001.008_valid.xml	pacs.002.001.10.ACCP	756	\N
758	\N	XML	pacs.008.001.08	1647418044650_756.xml	pacs.008.001.008_valid3.xml	pacs.002.001.10.ACCP	756	\N
759	\N	XML	pacs.008.001.08	1647418044677_756.xml	pacs.008.001.008_invalid-MsgId.xml	pacs.002.001.10.ACCP	756	\N
760	\N	XML	pacs.008.001.08	1647418044706_756.xml	pacs.008.001.008_invalid-BICFI.xml	pacs.002.001.10.ACCP	756	\N
768	\N	XML	pacs.008.001.08	1647418285736_767.xml	pacs.008.001.008_invalid-MsgId.xml	pacs.002.001.10.AG01	767	\N
769	\N	XML	pacs.008.001.08	1647418285755_767.xml	pacs.008.001.008_invalid-CreDtTm.xml	pacs.002.001.10.AG01	767	\N
770	\N	XML	pacs.008.001.08	1647418285775_767.xml	pacs.008.001.008_valid.xml	pacs.002.001.10.AG01	767	\N
771	\N	XML	pacs.008.001.08	1647418285792_767.xml	pacs.008.001.008_valid2.xml	pacs.002.001.10.AG01	767	\N
779	\N	XML	pacs.008.001.08	1647418477318_778.xml	pacs.008.001.008_invalid-InstrPrty.xml	pacs.002.001.10.AG02	778	\N
780	\N	XML	pacs.008.001.08	1647418477339_778.xml	pacs.008.001.008_invalid-ClrChanl.xml	pacs.002.001.10.AG02	778	\N
781	\N	XML	pacs.008.001.08	1647418477398_778.xml	pacs.008.001.008_valid.xml	pacs.002.001.10.AG02	778	\N
782	\N	XML	pacs.008.001.08	1647418477430_778.xml	pacs.008.001.008_valid3.xml	pacs.002.001.10.AG02	778	\N
793	\N	XML	camt.056.001.08	1647419184871_792.xml	camt.056.001.08_invalid-CreDtTm.xml	camt.029.001.09.CNCL	792	\N
797	\N	XML	camt.056.001.08	1647419304321_796.xml	camt.056.001.08_valid.xml	camt.029.001.09.CNCL	796	\N
800	\N	XML	camt.056.001.08	1647419406866_799.xml	camt.056.001.08_invalid-OrgnlEndToEndId.xml	camt.029.001.09.RJCR	799	\N
804	\N	XML	camt.056.001.08	1647419488344_803.xml	camt.056.001.08_invalid-OriginalInterbankSettlementAmount.xml	camt.029.001.09.PDCR	803	\N
808	\N	XML	camt.056.001.08	1647421874385_807.xml	camt.056.001.08_valid2.xml	camt.029.001.09.RJCR	807	\N
809	\N	XML	camt.056.001.08	1647421874400_807.xml	camt.056.001.08_valid.xml	camt.029.001.09.CNCL	807	\N
810	\N	XML	camt.056.001.08	1647421874430_807.xml	camt.056.001.08_valid3.xml	camt.029.001.09.PDCR	807	\N
815	\N	XML	camt.056.001.08	1647422016559_814.xml	camt.056.001.08_valid2.xml	camt.029.001.09.CNCL	814	\N
816	\N	XML	camt.056.001.08	1647422016579_814.xml	camt.056.001.08_valid.xml	camt.029.001.09.CNCL	814	\N
820	\N	XML	camt.056.001.08	1647422225899_819.xml	camt.056.001.08_valid.xml	\N	819	\N
823	\N	XML	camt.056.001.08	1647422288332_822.xml	camt.056.001.08_invalid-Cd.xml	\N	822	\N
827	\N	XML	camt.056.001.08	1647422370777_826.xml	camt.056.001.08_invalid-Cd.xml	\N	826	\N
828	\N	XML	camt.056.001.08	1647422370796_826.xml	camt.056.001.08_invalid-CreDtTm.xml	\N	826	\N
829	\N	XML	camt.056.001.08	1647422370836_826.xml	camt.056.001.08_invalid-Id.xml	\N	826	\N
830	\N	XML	camt.056.001.08	1647422370855_826.xml	camt.056.001.08_valid.xml	\N	826	\N
\.


--
-- Data for Name: test_output_data; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.test_output_data (id, input_object_id, msg_id, out_object_id, out_object_name, response_msg_id, run_id, status) FROM stdin;
687	1647405686672_685.xml	34634754753463475475346388	\N	\N	\N	685	Pass
690	1647405817111_688.xml	3463475475346347549999999999999999999999999999999975346388	\N	\N	\N	688	Fail
694	1647406083666_692.xml	34634754@534#34754999999999$%999977	\N	\N	\N	692	Pass
697	1647409897654_695.xml	34634754753463475475346388	\N	\N	\N	695	Fail
701	1647410176680_699.xml	34634754753463475475346388	\N	\N	\N	699	Fail
705	1647410495618_703.xml	34634754753463475475346388	\N	\N	\N	703	Fail
712	1647411459966_707.xml	34634754753463475475346388	\N	\N	\N	707	Fail
714	1647411459985_707.xml	34634754753463475475346388	\N	\N	\N	707	Fail
716	1647411460018_707.xml	34634754753463475475346388	\N	\N	\N	707	Fail
718	1647411460072_707.xml	34634754753463475475346388	\N	\N	\N	707	Fail
732	1647416347569_728.xml	34634754753463475475346388	\N	\N	\N	728	Pass
733	1647416347587_728.xml	34634754553463475475334388	\N	\N	\N	728	Pass
734	1647416347613_728.xml	34543754553463432175224388	\N	\N	\N	728	Pass
737	1647417013950_735.xml	34634754753463475475346388	1647417015369_735.xml	pacs.002.001.10.ACCP.1647417013950_735.xml	pacs.002.001.10.ACCP	735	Pass
740	1647417098757_738.xml	34634754753463475475346388	1647417099993_738.xml	pacs.002.001.10.AC01.1647417098757_738.xml	pacs.002.001.10.AC01	738	Pass
743	1647417199383_741.xml	34634754753463475475346388	1647417200681_741.xml	pacs.002.001.10.AC04.1647417199383_741.xml	pacs.002.001.10.AC04	741	Pass
749	1647417591890_744.xml	34634754553463475475334388	1647417593476_744.xml	pacs.002.001.10.AG02.1647417591890_744.xml	pacs.002.001.10.AG02	744	Pass
750	1647417591952_744.xml	34634754753463475475346388	1647417594534_744.xml	pacs.002.001.10.AM03.1647417591952_744.xml	pacs.002.001.10.AM03	744	Pass
751	1647417592012_744.xml	34543754553463432175224388	1647417595370_744.xml	pacs.002.001.10.AG01.1647417592012_744.xml	pacs.002.001.10.AG01	744	Pass
752	1647417592036_744.xml	34543754553463432175224388	1647417596181_744.xml	pacs.002.001.10.AM02.1647417592036_744.xml	pacs.002.001.10.AM02	744	Pass
755	1647417815980_753.xml	34634754753463475475346388	1647417817039_753.xml	pacs.002.001.10.AC04.1647417815980_753.xml	pacs.002.001.10.AC04	753	Pass
761	1647418044629_756.xml	34634754753463475475346388	1647418046082_756.xml	pacs.002.001.10.ACCP.1647418044629_756.xml	pacs.002.001.10.ACCP	756	Pass
762	1647418044650_756.xml	34543754553463432175224388	1647418046852_756.xml	pacs.002.001.10.ACCP.1647418044650_756.xml	pacs.002.001.10.ACCP	756	Pass
763	1647418044677_756.xml	3463475475346347549999999999999999999999999999999975346388	\N	\N	\N	756	Fail
765	1647418044706_756.xml	34634754753463475475346388	\N	\N	\N	756	Fail
772	1647418285736_767.xml	3463475475346347549999999999999999999999999999999975346388	\N	\N	\N	767	Fail
774	1647418285755_767.xml	34634754753463475475346388	\N	\N	\N	767	Fail
776	1647418285775_767.xml	34634754753463475475346388	1647418288605_767.xml	pacs.002.001.10.AG01.1647418285775_767.xml	pacs.002.001.10.AG01	767	Pass
777	1647418285792_767.xml	34634754553463475475334388	1647418289333_767.xml	pacs.002.001.10.AG01.1647418285792_767.xml	pacs.002.001.10.AG01	767	Pass
783	1647418477318_778.xml	34634754753463475475346388	\N	\N	\N	778	Fail
785	1647418477339_778.xml	34634754753463475475346388	\N	\N	\N	778	Fail
787	1647418477398_778.xml	34634754753463475475346388	1647418480494_778.xml	pacs.002.001.10.AG02.1647418477398_778.xml	pacs.002.001.10.AG02	778	Pass
788	1647418477430_778.xml	34543754553463432175224388	1647418481305_778.xml	pacs.002.001.10.AG02.1647418477430_778.xml	pacs.002.001.10.AG02	778	Pass
794	1647419184871_792.xml	346347547534634754757777	\N	\N	\N	792	Fail
798	1647419304321_796.xml	346347547534634754757777	1647419304865_796.xml	camt.029.001.09.CNCL.1647419304321_796.xml	camt.029.001.09.CNCL	796	Pass
801	1647419406866_799.xml	346347547534634754757777	\N	\N	\N	799	Fail
805	1647419488344_803.xml	346347547534634754757777	\N	\N	\N	803	Fail
811	1647421874385_807.xml	346347547534634754347777	1647421875023_807.xml	camt.029.001.09.RJCR.1647421874385_807.xml	camt.029.001.09.RJCR	807	Pass
812	1647421874400_807.xml	346347547534634754757777	1647421875482_807.xml	camt.029.001.09.CNCL.1647421874400_807.xml	camt.029.001.09.CNCL	807	Pass
813	1647421874430_807.xml	346347543234634754757777	1647421875937_807.xml	camt.029.001.09.PDCR.1647421874430_807.xml	camt.029.001.09.PDCR	807	Pass
817	1647422016559_814.xml	346347547534634754347777	1647422016975_814.xml	camt.029.001.09.CNCL.1647422016559_814.xml	camt.029.001.09.CNCL	814	Pass
818	1647422016579_814.xml	346347547534634754757777	1647422017395_814.xml	camt.029.001.09.CNCL.1647422016579_814.xml	camt.029.001.09.CNCL	814	Pass
821	1647422225899_819.xml	346347547534634754757777	\N	\N	\N	819	Pass
824	1647422288332_822.xml	346347547534634754757777	\N	\N	\N	822	Fail
831	1647422370777_826.xml	346347547534634754757777	\N	\N	\N	826	Fail
833	1647422370796_826.xml	346347547534634754757777	\N	\N	\N	826	Fail
835	1647422370836_826.xml	3463475475346347547588888888888888888887777777778888887777	\N	\N	\N	826	Fail
837	1647422370855_826.xml	346347547534634754757777	\N	\N	\N	826	Pass
\.


--
-- Data for Name: validation_error; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.validation_error (id, data, error_message, field_name, msg_id, object_id, run_id, xml_element, xpath) FROM stdin;
691	3463475475346347549999999999999999999999999999999975346388	Invalid Value. The value length should be in between 1 to 35	MessageIdentification	\N	1647405817111_688.xml	688	MsgId	FIToFICstmrCdtTrf/GrpHdr/MsgId
698	NORMAL	Invalid value. More at link : /configs/metadata/InstPrt	InstructionPriority	\N	1647409897654_695.xml	695	InstrPrty	FIToFICstmrCdtTrf/CdtTrfTxInf/PmtTpInf/InstrPrty
702	CHASUS33$#%00123	Pattern check failed. Pattern : [A-Z0-9]{4,4}[A-Z]{2,2}[A-Z0-9]{2,2}([A-Z0-9]{3,3}){0,1}	BICFI	\N	1647410176680_699.xml	699	BICFI	FIToFICstmrCdtTrf/CdtTrfTxInf/ChrgsInf/Agt/FinInstnId/BICFI
706	RTGGSS	Invalid value. More at link : /configs/metadata/ClrChanl	ClearingChannel	\N	1647410495618_703.xml	703	ClrChanl	FIToFICstmrCdtTrf/CdtTrfTxInf/PmtTpInf/ClrChanl
713	CHASUS33$#%00123	Pattern check failed. Pattern : [A-Z0-9]{4,4}[A-Z]{2,2}[A-Z0-9]{2,2}([A-Z0-9]{3,3}){0,1}	BICFI	\N	1647411459966_707.xml	707	BICFI	FIToFICstmrCdtTrf/CdtTrfTxInf/ChrgsInf/Agt/FinInstnId/BICFI
715	RTGGSS	Invalid value. More at link : /configs/metadata/ClrChanl	ClearingChannel	\N	1647411459985_707.xml	707	ClrChanl	FIToFICstmrCdtTrf/CdtTrfTxInf/PmtTpInf/ClrChanl
717	NORMAL	Invalid value. More at link : /configs/metadata/InstPrt	InstructionPriority	\N	1647411460018_707.xml	707	InstrPrty	FIToFICstmrCdtTrf/CdtTrfTxInf/PmtTpInf/InstrPrty
719	2020-03-23	Invalid date value or format. Date Pattern: yyyy-MM-dd'T'HH:mm:ss.ss+HH:mm	CreationDateTime	\N	1647411460072_707.xml	707	CreDtTm	FIToFICstmrCdtTrf/GrpHdr/CreDtTm
764	3463475475346347549999999999999999999999999999999975346388	Invalid Value. The value length should be in between 1 to 35	MessageIdentification	\N	1647418044677_756.xml	756	MsgId	FIToFICstmrCdtTrf/GrpHdr/MsgId
766	CHASUS33$#%00123	Pattern check failed. Pattern : [A-Z0-9]{4,4}[A-Z]{2,2}[A-Z0-9]{2,2}([A-Z0-9]{3,3}){0,1}	BICFI	\N	1647418044706_756.xml	756	BICFI	FIToFICstmrCdtTrf/CdtTrfTxInf/ChrgsInf/Agt/FinInstnId/BICFI
773	3463475475346347549999999999999999999999999999999975346388	Invalid Value. The value length should be in between 1 to 35	MessageIdentification	\N	1647418285736_767.xml	767	MsgId	FIToFICstmrCdtTrf/GrpHdr/MsgId
775	2020-03-23	Invalid date value or format. Date Pattern: yyyy-MM-dd'T'HH:mm:ss.ss+HH:mm	CreationDateTime	\N	1647418285755_767.xml	767	CreDtTm	FIToFICstmrCdtTrf/GrpHdr/CreDtTm
784	NORMAL	Invalid value. More at link : /configs/metadata/InstPrt	InstructionPriority	\N	1647418477318_778.xml	778	InstrPrty	FIToFICstmrCdtTrf/CdtTrfTxInf/PmtTpInf/InstrPrty
786	RTGGSS	Invalid value. More at link : /configs/metadata/ClrChanl	ClearingChannel	\N	1647418477339_778.xml	778	ClrChanl	FIToFICstmrCdtTrf/CdtTrfTxInf/PmtTpInf/ClrChanl
795	2022-01-03T19:	Invalid date value or format. Date Pattern: yyyy-MM-dd'T'HH:mm:ss.ss+HH:mm	CreationDateTime	\N	1647419184871_792.xml	792	CreDtTm	FIToFIPmtCxlReq/Assgnmt/CreDtTm
802	34345E@#$%*%!TRD3423	Pattern check failed. Pattern : [0-9a-zA-Z/\\\\-\\\\?:\\\\(\\\\)\\\\.,\\\\+ ]+	OriginalEndToEndIdentification	\N	1647419406866_799.xml	799	OrgnlEndToEndId	FIToFIPmtCxlReq/Undrlyg/TxInf/OrgnlEndToEndId
806	12345.0024324329d843201	Invalid amount value. The size of a fractional part of the amount should be between 5 and 14	OriginalInterbankSettlementAmount	\N	1647419488344_803.xml	803	OrgnlIntrBkSttlmAmt	FIToFIPmtCxlReq/Undrlyg/TxInf/OrgnlIntrBkSttlmAmt
825	ATBLZZZ	Invalid value. More at link : /configs/metadata/ClearingSystemId	Code	\N	1647422288332_822.xml	822	Cd	FIToFIPmtCxlReq/Assgnmt/Assgnr/Agt/FinInstnId/ClrSysMmbId/ClrSysId/Cd
832	ATBLZZZ	Invalid value. More at link : /configs/metadata/ClearingSystemId	Code	\N	1647422370777_826.xml	826	Cd	FIToFIPmtCxlReq/Assgnmt/Assgnr/Agt/FinInstnId/ClrSysMmbId/ClrSysId/Cd
834	2022-01-03T19:	Invalid date value or format. Date Pattern: yyyy-MM-dd'T'HH:mm:ss.ss+HH:mm	CreationDateTime	\N	1647422370796_826.xml	826	CreDtTm	FIToFIPmtCxlReq/Assgnmt/CreDtTm
836	3463475475346347547588888888888888888887777777778888887777	Invalid Value. The value length should be in between 1 to 35	Id	\N	1647422370836_826.xml	826	Id	FIToFIPmtCxlReq/Assgnmt/Id
\.


--
-- Data for Name: validation_test; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.validation_test (run_id, created_on, description, input_source_type, payment_type, status, tags, test_name, user_id) FROM stdin;
688	2022-03-16 10:13:00	FI to FI Customer Credit Transfer Message Failed, MsgId is greater than  35 character	FileUpload	Inbound	Failed	\N	Pacs.008 MsgId is greater than  35 character	\N
692	2022-03-16 10:17:00	Message Failed, MsgId is not as per format (  0-9a-zA-Z/\\\\\\\\-\\\\\\\\?:\\\\\\\\(\\\\\\\\)\\\\\\\\.,\\\\\\\\+ ]+)	FileUpload	Inbound	Processed	\N	Pacs.008 MsgId is not as per format	\N
685	2022-03-16 10:11:00	Message successfully validated (Fields and Business Validation)	FileUpload	Inbound	Processed	\N	Pacs.008 FI to FI Customer Credit Transfer	\N
695	2022-03-16 11:21:00	Message Failed as InstrPrty is not from list (HIGH, NORM)	FileUpload	Inbound	Failed	\N	Pacs.008 invalid InstrPrty value and not from list (HIGH, NORM)	\N
699	2022-03-16 11:25:00	Pacs.008 FI to FI Customer Credit Transfer Message Failed as BICFI not as per format  pattern	FileUpload	Inbound	Failed	\N	Pacs.008 Failed as BICFI not as per format  pattern	\N
703	2022-03-16 11:31:00	FI to FI Customer Credit Transfer Message Failed as invalid ClrChanl	FileUpload	Inbound	Failed	\N	pacs.008.001.008 has invalid ClrChanl	\N
707	2022-03-16 11:47:00	Pacs.008 FI to FI Customer Credit Transfer - Multiple Messages validation Failed	FileUpload	Inbound	Failed	\N	Pacs.008 multi files validation failed	\N
728	2022-03-16 13:09:00	Pacs.008 FI to FI Customer Credit Transfer Multiple Messages Validation Passed	FileUpload	Inbound	Processed	\N	Pacs.008 Multi Messages Validation Pass	\N
735	2022-03-16 13:20:00	Creating pacs.002 accepted response for given pacs.008 message	FileUpload	Outbound	Processed	\N	pacs.002 gives positive response for pacs.008 message	\N
738	2022-03-16 13:21:00	pacs.002 gives negative response for pacs.008 message with  AC01-IncorrectAccountNumber	FileUpload	Outbound	Processed	\N	pacs.002 gives negative response AC01-IncorrectAccountNumber	\N
741	2022-03-16 13:23:00	pacs.002 gives negative response for pacs.008 message with  AC04 -ClosedAccountNumber	FileUpload	Outbound	Processed	\N	pacs.002 gives negative response with AC04 -ClosedAccountNumber	\N
744	2022-03-16 13:25:00	pacs.002 gives negative responses for multiple pacs.008 messages	FileUpload	Outbound	Processed	\N	pacs.002 gives negative responses for multiple pacs.008 messages	\N
753	2022-03-16 13:33:00	pacs.002 gives negative response AC04 - ClosedAccountNumber	FileUpload	Outbound	Processed	\N	pacs.002 gives negative response AC04	\N
756	2022-03-16 13:35:00	Pacs.008 FI to FI Customer Credit Transfer Message successfully validated ( Fields and Business Validation )	FileUpload	Outbound	Partial	\N	Pacs.008 FI to FI Customer Credit Transfer Message successfully validated ( Fields and Business Validation )	\N
767	2022-03-16 13:40:00	pacs.002 gives negative response for pacs.008 message with  AG01 -TransactionForbidden	FileUpload	Outbound	Partial	\N	pacs.002 gives negative response for pacs.008 message with  AG01 -TransactionForbidden	\N
778	2022-03-16 13:43:00	pacs.002 gives negative response for pacs.008 message with  AG02 -NotAllowedAmount	FileUpload	Outbound	Partial	\N	pacs.002 gives negative response for pacs.008 message with  AG02 -NotAllowedAmount	\N
792	2022-03-16 13:56:00	Cant create CAMT.029 message as CAMT.056 message verification failed	FileUpload	Outbound	Failed	\N	Failed to create CAMT.029 message as CAMT.056 message is not valid	\N
796	2022-03-16 13:58:00	CAMT.029 Cancellation rejection of CAMT.056 message  verified successfully (Fields and Business validation)	FileUpload	Outbound	Processed	\N	Create CAMT.029 with Cancellation rejection of CAMT.056 message verified successfully	\N
799	2022-03-16 14:00:00	CAMT.029 Rejection of Camt.056 message Failed as OriginalEndToEndIdentification length more than 35 character	FileUpload	Outbound	Failed	\N	CAMT.029 Rejection of Camt.056 message Failed as OriginalEndToEndIdentification is invalid	\N
803	2022-03-16 14:01:00	CAMT.029 Rejection of Camt.056 message Failed as OriginalInterbankSettlementAmount exceed size of fractional part beyond 14 digits	FileUpload	Outbound	Failed	\N	CAMT.029 Rejection of Camt.056 message Failed as OriginalInterbankSettlementAmount is invalid	\N
807	2022-03-16 14:41:00	Generation of CAMT.029 message for each of provided CAMT.056 files	FileUpload	Outbound	Processed	\N	Generate CAMT.029 message for each provided CAMT.056 messages	\N
814	2022-03-16 14:43:00	Generate CAMT.029 with Cancellation for CAMT.056 message on successful verification	FileUpload	Outbound	Processed	\N	Generate CAMT.029 with Cancellation for CAMT.056 message	\N
819	2022-03-16 14:47:00	CAMT.056 cancellation of  Credit Transfer message verified successfully (Fields and Business validation)	FileUpload	Inbound	Processed	\N	CAMT.056 cancellation of  Credit Transfer message verified successfully	\N
822	2022-03-16 14:48:00	CAMT.056 cancellation of Credit Transfer message Failed as Clearing System ID code is invalid	FileUpload	Inbound	Failed	\N	CAMT.056 cancellation of Credit Transfer message Failed as ClrSysId/cd is invalid	\N
826	2022-03-16 14:49:00	CAMT.056 cancellation of Credit Transfer Message validation	FileUpload	Inbound	Partial	\N	CAMT.056 multiple files validation	\N
\.

--
-- Name: hibernate_sequence; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.hibernate_sequence', 32779, true);


--
-- Name: sequence_generator; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.sequence_generator', 1050, false);

--
-- Name: test_input_data test_input_data_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.test_input_data
    ADD CONSTRAINT test_input_data_pkey PRIMARY KEY (id);


--
-- Name: test_output_data test_output_data_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.test_output_data
    ADD CONSTRAINT test_output_data_pkey PRIMARY KEY (id);


--
-- Name: validation_error validation_error_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.validation_error
    ADD CONSTRAINT validation_error_pkey PRIMARY KEY (id);


--
-- Name: validation_test validation_test_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.validation_test
    ADD CONSTRAINT validation_test_pkey PRIMARY KEY (run_id);


--
-- Name: test_input_data fk1xaaf4v667p37ietqlxy0rndp; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.test_input_data
    ADD CONSTRAINT fk1xaaf4v667p37ietqlxy0rndp FOREIGN KEY (validationtest_run_id) REFERENCES public.validation_test(run_id);


--
-- Name: test_input_data fkd9vum8plr5wjdqc6dvycxnc8c; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.test_input_data
    ADD CONSTRAINT fkd9vum8plr5wjdqc6dvycxnc8c FOREIGN KEY (run_id) REFERENCES public.validation_test(run_id);
