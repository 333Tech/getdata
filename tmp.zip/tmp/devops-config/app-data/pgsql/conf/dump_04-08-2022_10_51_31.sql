--
-- PostgreSQL database cluster dump
--

SET default_transaction_read_only = off;

SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;

--
-- Drop databases (except postgres and template1)
--

DROP DATABASE isosimulator_app_db;
DROP DATABASE isosimulator_gateway_db;




--
-- Drop roles
--

DROP ROLE postgres;


--
-- Roles
--

CREATE ROLE postgres;
ALTER ROLE postgres WITH SUPERUSER INHERIT CREATEROLE CREATEDB LOGIN REPLICATION BYPASSRLS PASSWORD 'md53175bce1d3201d16594cebf9d7eb3f9d';






--
-- Databases
--

--
-- Database "template1" dump
--

--
-- PostgreSQL database dump
--

-- Dumped from database version 13.4 (Debian 13.4-4.pgdg110+1)
-- Dumped by pg_dump version 13.4 (Debian 13.4-4.pgdg110+1)

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

UPDATE pg_catalog.pg_database SET datistemplate = false WHERE datname = 'template1';
DROP DATABASE template1;
--
-- Name: template1; Type: DATABASE; Schema: -; Owner: postgres
--

CREATE DATABASE template1 WITH TEMPLATE = template0 ENCODING = 'UTF8' LOCALE = 'en_US.utf8';


ALTER DATABASE template1 OWNER TO postgres;

\connect template1

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: DATABASE template1; Type: COMMENT; Schema: -; Owner: postgres
--

COMMENT ON DATABASE template1 IS 'default template for new databases';


--
-- Name: template1; Type: DATABASE PROPERTIES; Schema: -; Owner: postgres
--

ALTER DATABASE template1 IS_TEMPLATE = true;


\connect template1

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: DATABASE template1; Type: ACL; Schema: -; Owner: postgres
--

REVOKE CONNECT,TEMPORARY ON DATABASE template1 FROM PUBLIC;
GRANT CONNECT ON DATABASE template1 TO PUBLIC;


--
-- PostgreSQL database dump complete
--

--
-- Database "isosimulator_app_db" dump
--

--
-- PostgreSQL database dump
--

-- Dumped from database version 13.4 (Debian 13.4-4.pgdg110+1)
-- Dumped by pg_dump version 13.4 (Debian 13.4-4.pgdg110+1)

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: isosimulator_app_db; Type: DATABASE; Schema: -; Owner: postgres
--

CREATE DATABASE isosimulator_app_db WITH TEMPLATE = template0 ENCODING = 'UTF8' LOCALE = 'en_US.utf8';


ALTER DATABASE isosimulator_app_db OWNER TO postgres;

\connect isosimulator_app_db

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: databasechangelog; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.databasechangelog (
    id character varying(255) NOT NULL,
    author character varying(255) NOT NULL,
    filename character varying(255) NOT NULL,
    dateexecuted timestamp without time zone NOT NULL,
    orderexecuted integer NOT NULL,
    exectype character varying(10) NOT NULL,
    md5sum character varying(35),
    description character varying(255),
    comments character varying(255),
    tag character varying(255),
    liquibase character varying(20),
    contexts character varying(255),
    labels character varying(255),
    deployment_id character varying(10)
);


ALTER TABLE public.databasechangelog OWNER TO postgres;

--
-- Name: databasechangeloglock; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.databasechangeloglock (
    id integer NOT NULL,
    locked boolean NOT NULL,
    lockgranted timestamp without time zone,
    lockedby character varying(255)
);


ALTER TABLE public.databasechangeloglock OWNER TO postgres;

--
-- Name: hibernate_sequence; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.hibernate_sequence
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.hibernate_sequence OWNER TO postgres;

--
-- Name: iso_message_metadata; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.iso_message_metadata (
    id character varying(255) NOT NULL,
    description character varying(255),
    name character varying(255),
    version character varying(255),
    xml_object_id character varying(255),
    xmlns character varying(255),
    xsd_object_id character varying(255),
    xsl_object_id character varying(255)
);


ALTER TABLE public.iso_message_metadata OWNER TO postgres;

--
-- Name: reference_data; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.reference_data (
    id integer NOT NULL,
    datakey character varying(255),
    value character varying(255)
);


ALTER TABLE public.reference_data OWNER TO postgres;

--
-- Name: response_message; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.response_message (
    id character varying(255) NOT NULL,
    code character varying(255),
    definition character varying(255),
    initiator_msgid character varying(255),
    name character varying(255),
    response_msgid character varying(255)
);


ALTER TABLE public.response_message OWNER TO postgres;

--
-- Name: sequence_generator; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.sequence_generator
    START WITH 1050
    INCREMENT BY 50
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.sequence_generator OWNER TO postgres;

--
-- Name: test_input_data; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.test_input_data (
    id bigint NOT NULL,
    description character varying(255),
    input_type character varying(255),
    msg_type_id character varying(255),
    object_id character varying(255),
    object_name character varying(255),
    response_msg_id character varying(255),
    run_id bigint,
    validationtest_run_id bigint
);


ALTER TABLE public.test_input_data OWNER TO postgres;

--
-- Name: test_output_data; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.test_output_data (
    id bigint NOT NULL,
    input_object_id character varying(255),
    msg_id character varying(255),
    out_object_id character varying(255),
    out_object_name character varying(255),
    response_msg_id character varying(255),
    run_id bigint,
    status character varying(255)
);


ALTER TABLE public.test_output_data OWNER TO postgres;

--
-- Name: validation_error; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.validation_error (
    id bigint NOT NULL,
    data character varying(255),
    error_message character varying(255),
    field_name character varying(255),
    msg_id character varying(255),
    object_id character varying(255),
    run_id bigint,
    xml_element character varying(255),
    xpath character varying(255)
);


ALTER TABLE public.validation_error OWNER TO postgres;

--
-- Name: validation_test; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.validation_test (
    run_id bigint NOT NULL,
    created_on timestamp without time zone,
    description character varying(255),
    input_source_type character varying(255),
    payment_type character varying(255),
    status character varying(255),
    tags character varying(255),
    test_name character varying(255),
    user_id character varying(255)
);


ALTER TABLE public.validation_test OWNER TO postgres;

--
-- Data for Name: databasechangelog; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.databasechangelog (id, author, filename, dateexecuted, orderexecuted, exectype, md5sum, description, comments, tag, liquibase, contexts, labels, deployment_id) FROM stdin;
00000000000000	jhipster	config/liquibase/changelog/00000000000000_initial_schema.xml	2022-05-12 08:11:18.841497	1	EXECUTED	8:b8c27d9dc8db18b5de87cdb8c38a416b	createSequence sequenceName=sequence_generator		\N	4.5.0	\N	\N	2343078398
00000000000001	jhipster	config/liquibase/changelog/00000000000000_initial_schema.xml	2022-05-12 08:11:18.867827	2	EXECUTED	8:d41d8cd98f00b204e9800998ecf8427e	empty		\N	4.5.0	\N	\N	2343078398
\.


--
-- Data for Name: databasechangeloglock; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.databasechangeloglock (id, locked, lockgranted, lockedby) FROM stdin;
1	f	\N	\N
\.


--
-- Data for Name: iso_message_metadata; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.iso_message_metadata (id, description, name, version, xml_object_id, xmlns, xsd_object_id, xsl_object_id) FROM stdin;
\.


--
-- Data for Name: reference_data; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.reference_data (id, datakey, value) FROM stdin;
\.


--
-- Data for Name: response_message; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.response_message (id, code, definition, initiator_msgid, name, response_msgid) FROM stdin;
\.


--
-- Data for Name: test_input_data; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.test_input_data (id, description, input_type, msg_type_id, object_id, object_name, response_msg_id, run_id, validationtest_run_id) FROM stdin;
2	\N	XML	pacs.008.001.08	1643029905033_1.xml	pacs.008.001.008_valid.xml	\N	1	\N
5	\N	XML	pacs.008.001.08	1643030095661_4.xml	pacs.008.001.008_invalid-MsgId.xml	\N	4	\N
9	\N	XML	pacs.008.001.08	1643030334190_8.xml	pacs.008.001.008_invalid-format-MsgId.xml	\N	8	\N
12	\N	XML	pacs.008.001.08	1643031404412_11.xml	pacs.008.001.008_invalid-InstrPrty.xml	\N	11	\N
16	\N	XML	pacs.008.001.08	1643031753801_15.xml	pacs.008.001.008_invalid-BIC-format.xml	\N	15	\N
20	\N	XML	pacs.008.001.08	1643032068394_19.xml	pacs.008.001.008_invalid-ClrChanl.xml	\N	19	\N
24	\N	XML	pacs.008.001.08	1643032316159_23.xml	pacs.008.001.008_invalid-BIC-format.xml	\N	23	\N
25	\N	XML	pacs.008.001.08	1643032316239_23.xml	pacs.008.001.008_invalid-ClrChanl.xml	\N	23	\N
26	\N	XML	pacs.008.001.08	1643032316274_23.xml	pacs.008.001.008_invalid-CreDtTm.xml	\N	23	\N
27	\N	XML	pacs.008.001.08	1643032316303_23.xml	pacs.008.001.008_invalid-InstrPrty.xml	\N	23	\N
37	\N	XML	pacs.008.001.08	1643032487012_36.xml	pacs.008.no-issue.xml	\N	36	\N
38	\N	XML	pacs.008.001.08	1643032487069_36.xml	pacs.008.notconfident.xml	\N	36	\N
39	\N	XML	pacs.008.001.08	1643032487086_36.xml	pacs.008.valid-msg.xml	\N	36	\N
44	\N	XML	camt.056.001.08	1643032682234_43.xml	camt.056.001.08_valid.xml	\N	43	\N
47	\N	XML	camt.056.001.08	1643033094288_46.xml	camt.056.001.08_invalid-Cd.xml	\N	46	\N
51	\N	XML	camt.056.001.08	1643033155724_50.xml	camt.056.001.08_invalid-Cd.xml	\N	50	\N
52	\N	XML	camt.056.001.08	1643033155749_50.xml	camt.056.001.08_invalid-CreDtTm.xml	\N	50	\N
53	\N	XML	camt.056.001.08	1643033155772_50.xml	camt.056.001.08_invalid-Id.xml	\N	50	\N
54	\N	XML	camt.056.001.08	1643033155806_50.xml	camt.056.001.08_valid.xml	\N	50	\N
63	\N	XML	pacs.008.001.08	1643033287573_62.xml	pacs.008.001.008_valid.xml	pacs.002.001.10.ACCP	62	\N
66	\N	XML	pacs.008.001.08	1643033541746_65.xml	pacs.008.001.008_valid.xml	pacs.002.001.10.AC01	65	\N
69	\N	XML	pacs.008.001.08	1643033773020_68.xml	pacs.008.001.008_valid.xml	pacs.002.001.10.AC04	68	\N
72	\N	XML	pacs.008.001.08	1643033882207_71.xml	pacs.008.001.008_valid.xml	pacs.002.001.10.AG02	71	\N
73	\N	XML	pacs.008.001.08	1643033882236_71.xml	pacs.008.no-issue.xml	pacs.002.001.10.AM03	71	\N
74	\N	XML	pacs.008.001.08	1643033882256_71.xml	pacs.008.notconfident.xml	pacs.002.001.10.AG01	71	\N
75	\N	XML	pacs.008.001.08	1643033882282_71.xml	pacs.008.valid-msg.xml	pacs.002.001.10.AM05	71	\N
81	\N	XML	camt.056.001.08	1643034378863_80.xml	camt.056.001.08_invalid-CreDtTm.xml	camt.029.001.09.PDCR	80	\N
85	\N	XML	camt.056.001.08	1643034548955_84.xml	camt.056.001.08_valid.xml	camt.029.001.09.CNCL	84	\N
88	\N	XML	camt.056.001.08	1643034840957_87.xml	camt.056.001.08_invalid-OrgnlEndToEndId.xml	camt.029.001.09.RJCR	87	\N
92	\N	XML	camt.056.001.08	1643035474091_91.xml	camt.056.001.08_invalid-OriginalInterbankSettlementAmount.xml	camt.029.001.09.RJCR	91	\N
96	\N	XML	camt.056.001.08	1643035823388_95.xml	camt.056.001.08_valid.xml	camt.029.001.09.RJCR	95	\N
97	\N	XML	camt.056.001.08	1643035823432_95.xml	camt.056.001.08_valid-2.xml	camt.029.001.09.CNCL	95	\N
98	\N	XML	camt.056.001.08	1643035823459_95.xml	camt.056.001.08_valid-3.xml	camt.029.001.09.PDCR	95	\N
103	\N	XML	pacs.008.001.08	1643048349906_102.xml	pacs.008.001.008_valid.xml	pacs.002.001.10.AC04	102	\N
106	\N	XML	camt.056.001.08	1643048620967_105.xml	camt.056.001.08_valid.xml	camt.029.001.09.CNCL	105	\N
107	\N	XML	camt.056.001.08	1643048620987_105.xml	camt.056.001.08_valid-2.xml	camt.029.001.09.CNCL	105	\N
111	\N	XML	pacs.008.001.08	1643105698873_110.xml	PACS.Custom_test_008.001.008_Dev Team - Copy (2).xml	pacs.002.001.10.ACCP	110	\N
112	\N	XML	pacs.008.001.08	1643105698897_110.xml	PACS.Custom_test_008.001.008_Dev Team - Copy (4).xml	pacs.002.001.10.AC06	110	\N
113	\N	XML	pacs.008.001.08	1643105698916_110.xml	PACS.Custom_test_008.001.008_Dev Team - Copy (3).xml	pacs.002.001.10.ACCP	110	\N
114	\N	XML	pacs.008.001.08	1643105698936_110.xml	PACS.Custom_test_008.001.008_Dev Team_demo.xml	pacs.002.001.10.ACCP	110	\N
147	\N	XML	pacs.008.001.08	1643879462506_146.xml	PACS.Custom_test_008.001.008_Dev Team - Copy (2).xml	\N	146	\N
148	\N	XML	pacs.009.001.08	1643879462905_146.xml	PACS.Custom_test_008.001.008_Dev Team 009.xml	\N	146	\N
149	\N	XML	pacs.008.001.08	1643879462945_146.xml	PACS.Custom_test_008.001.008_Dev Team - Copy (4).xml	\N	146	\N
150	\N	XML	pacs.008.001.08	1643879462977_146.xml	PACS.Custom_test_008.001.008_Dev Team - Copy (3).xml	\N	146	\N
151	\N	XML	pacs.008.001.08	1643879463018_146.xml	PACS.Custom_test_008.001.008_Dev Team_demo.xml	\N	146	\N
161	\N	XML	pacs.008.001.08	1643879525156_160.xml	PACS.Custom_test_008.001.008_Dev Team - Copy (3).xml	pacs.002.001.10.AC01	160	\N
162	\N	XML	pacs.008.001.08	1643879525196_160.xml	PACS.Custom_test_008.001.008_Dev Team_demo.xml	pacs.002.001.10.AC01	160	\N
163	\N	XML	pacs.008.001.08	1643879525250_160.xml	PACS.Custom_test_008.001.008_Dev Team - Copy (2).xml	pacs.002.001.10.AG01	160	\N
164	\N	XML	pacs.008.001.08	1643879525297_160.xml	PACS.Custom_test_008.001.008_Dev Team - Copy (4).xml	pacs.002.001.10.AC06	160	\N
172	\N	XML	pacs.008.001.08	1643879592341_171.xml	PACS.Custom_test_008.001.008_Dev Team - Copy (4).xml	pacs.002.001.10.AC04	171	\N
173	\N	XML	pacs.008.001.08	1643879592365_171.xml	PACS.Custom_test_008.001.008_Dev Team - Copy (3).xml	pacs.002.001.10.AC04	171	\N
174	\N	XML	pacs.008.001.08	1643879592407_171.xml	PACS.Custom_test_008.001.008_Dev Team - Copy (2).xml	pacs.002.001.10.AC04	171	\N
175	\N	XML	pacs.008.001.08	1643879592438_171.xml	PACS.Custom_test_008.001.008_Dev Team_demo.xml	pacs.002.001.10.AC04	171	\N
\.


--
-- Data for Name: test_output_data; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.test_output_data (id, input_object_id, msg_id, out_object_id, out_object_name, response_msg_id, run_id, status) FROM stdin;
3	1643029905033_1.xml	34634754753463475475346388	\N	\N	\N	1	Pass
6	1643030095661_4.xml	3463475475346347549999999999999999999999999999999975346388	\N	\N	\N	4	Fail
10	1643030334190_8.xml	34634754@534#34754999999999$%999977	\N	\N	\N	8	Pass
13	1643031404412_11.xml	34634754753463475475346388	\N	\N	\N	11	Fail
17	1643031753801_15.xml	34634754753463475475346388	\N	\N	\N	15	Fail
21	1643032068394_19.xml	34634754753463475475346388	\N	\N	\N	19	Fail
28	1643032316159_23.xml	34634754753463475475346388	\N	\N	\N	23	Fail
30	1643032316239_23.xml	34634754753463475475346388	\N	\N	\N	23	Fail
32	1643032316274_23.xml	34634754753463475475346388	\N	\N	\N	23	Fail
34	1643032316303_23.xml	34634754753463475475346388	\N	\N	\N	23	Fail
40	1643032487012_36.xml	3463475475346347547534638	\N	\N	\N	36	Pass
41	1643032487069_36.xml	3463475475346347547534638	\N	\N	\N	36	Pass
42	1643032487086_36.xml	3463475475346347547534638	\N	\N	\N	36	Pass
45	1643032682234_43.xml	346347547534634754757777	\N	\N	\N	43	Pass
48	1643033094288_46.xml	346347547534634754757777	\N	\N	\N	46	Fail
55	1643033155724_50.xml	346347547534634754757777	\N	\N	\N	50	Fail
57	1643033155749_50.xml	346347547534634754758	\N	\N	\N	50	Fail
59	1643033155772_50.xml	3463475475346347547588888888888888888887777777778888887777	\N	\N	\N	50	Fail
61	1643033155806_50.xml	346347547534634754757777	\N	\N	\N	50	Pass
64	1643033287573_62.xml	34634754753463475475346388	1643033287890_62.xml	pacs.002.001.10.ACCP.1643033287573_62.xml	pacs.002.001.10.ACCP	62	Pass
67	1643033541746_65.xml	34634754753463475475346388	1643033542103_65.xml	pacs.002.001.10.AC01.1643033541746_65.xml	pacs.002.001.10.AC01	65	Pass
70	1643033773020_68.xml	34634754753463475475346388	1643033773325_68.xml	pacs.002.001.10.AC04.1643033773020_68.xml	pacs.002.001.10.AC04	68	Pass
76	1643033882207_71.xml	34634754753463475475346388	1643033882524_71.xml	pacs.002.001.10.AG02.1643033882207_71.xml	pacs.002.001.10.AG02	71	Pass
77	1643033882236_71.xml	3463475475346347547534638	1643033882646_71.xml	pacs.002.001.10.AM03.1643033882236_71.xml	pacs.002.001.10.AM03	71	Pass
78	1643033882256_71.xml	3463475475346347547534638	1643033882744_71.xml	pacs.002.001.10.AG01.1643033882256_71.xml	pacs.002.001.10.AG01	71	Pass
79	1643033882282_71.xml	3463475475346347547534638	1643033882845_71.xml	pacs.002.001.10.AM05.1643033882282_71.xml	pacs.002.001.10.AM05	71	Pass
82	1643034378863_80.xml	346347547534634754758	\N	\N	\N	80	Fail
86	1643034548955_84.xml	346347547534634754757777	1643034549209_84.xml	camt.029.001.09.CNCL.1643034548955_84.xml	camt.029.001.09.CNCL	84	Pass
89	1643034840957_87.xml	346347547534634754757777	\N	\N	\N	87	Fail
93	1643035474091_91.xml	346347547534634754757777	\N	\N	\N	91	Fail
99	1643035823388_95.xml	346347547534634754757777	1643035823656_95.xml	camt.029.001.09.RJCR.1643035823388_95.xml	camt.029.001.09.RJCR	95	Pass
100	1643035823432_95.xml	IBRTM34634545344757777	1643035823867_95.xml	camt.029.001.09.CNCL.1643035823432_95.xml	camt.029.001.09.CNCL	95	Pass
101	1643035823459_95.xml	CBWLHDF534634754757777	1643035824008_95.xml	camt.029.001.09.PDCR.1643035823459_95.xml	camt.029.001.09.PDCR	95	Pass
104	1643048349906_102.xml	34634754753463475475346388	1643048350213_102.xml	pacs.002.001.10.AC04.1643048349906_102.xml	pacs.002.001.10.AC04	102	Pass
108	1643048620967_105.xml	346347547534634754757777	1643048621194_105.xml	camt.029.001.09.CNCL.1643048620967_105.xml	camt.029.001.09.CNCL	105	Pass
109	1643048620987_105.xml	IBRTM34634545344757777	1643048621270_105.xml	camt.029.001.09.CNCL.1643048620987_105.xml	camt.029.001.09.CNCL	105	Pass
115	1643105698873_110.xml	3463475475346346347547534634634754753463463475475346346347547534634634754753463463475475346	\N	\N	\N	110	Fail
117	1643105698897_110.xml	123456789123456789123456789123456789123456789123456789123456789123456789123456789123456789123456789123456789123456789123456789123456789123456789	\N	\N	\N	110	Fail
119	1643105698916_110.xml	3463475475346	1643105699368_110.xml	pacs.002.001.10.ACCP.1643105698916_110.xml	pacs.002.001.10.ACCP	110	Pass
120	1643105698936_110.xml	34634754753	1643105699518_110.xml	pacs.002.001.10.ACCP.1643105698936_110.xml	pacs.002.001.10.ACCP	110	Pass
152	1643879462905_146.xml	\N	\N	\N	\N	146	InvalidXML
154	1643879462506_146.xml	3463475475346346347547534634634754753463463475475346346347547534634634754753463463475475346	\N	\N	\N	146	Fail
156	1643879462945_146.xml	123456789123456789123456789123456789123456789123456789123456789123456789123456789123456789123456789123456789123456789123456789123456789123456789	\N	\N	\N	146	Fail
158	1643879462977_146.xml	3463475475346	\N	\N	\N	146	Pass
159	1643879463018_146.xml	34634754753	\N	\N	\N	146	Pass
165	1643879525156_160.xml	3463475475346	1643879525530_160.xmll	pacs.002.001.10.AC01.1643879525156_160.xmll	pacs.002.001.10.AC01	160	Pass
166	1643879525250_160.xm	3463475475346346347547534634634754753463463475475346346347547534634634754753463463475475346	\N	\N	\N	160	Fail
168	1643879525196_160.xm	34634754753	1643879525842_160.xml	pacs.002.001.10.AC01.1643879525196_160.xml	pacs.002.001.10.AC01	160	Pass
169	1643879525297_160.xm	123456789123456789123456789123456789123456789123456789123456789123456789123456789123456789123456789123456789123456789123456789123456789123456789	\N	\N	\N	160	Fail
176	1643879592341_171.xm	123456789123456789123456789123456789123456789123456789123456789123456789123456789123456789123456789123456789123456789123456789123456789123456789	\N	\N	\N	171	Fail
178	1643879592365_171.xm	3463475475346	1643879592799_171.xml	pacs.002.001.10.AC04.1643879592365_171.xml	pacs.002.001.10.AC04	171	Pass
179	1643879592407_171.xm	3463475475346346347547534634634754753463463475475346346347547534634634754753463463475475346	\N	\N	\N	171	Fail
181	1643879592438_171.xm	34634754753	1643879593071_171.xml	pacs.002.001.10.AC04.1643879592438_171.xml	pacs.002.001.10.AC04	171	Pass
\.


--
-- Data for Name: validation_error; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.validation_error (id, data, error_message, field_name, msg_id, object_id, run_id, xml_element, xpath) FROM stdin;
7	3463475475346347549999999999999999999999999999999975346388	Invalid Value. The value length should be in between 1 to 35	MessageIdentification	\N	1643030095661_4.xml	4	MsgId	\N
14	HEGH	Invalid value. More at link : /configs/metadata/instprt	InstructionPriority	\N	1643031404412_11.xml	11	InstrPrty	\N
18	CHAS$%$#%US33001	Pattern check failed. Pattern : [A-Z0-9]{4,4}[A-Z]{2,2}[A-Z0-9]{2,2}([A-Z0-9]{3,3}){0,1}	BICFI	\N	1643031753801_15.xml	15	BICFI	\N
22	RTGSSS	Invalid value. More at link : /configs/metadata/clrChanl	ClearingChannel	\N	1643032068394_19.xml	19	ClrChanl	\N
29	CHAS$%$#%US33001	Pattern check failed. Pattern : [A-Z0-9]{4,4}[A-Z]{2,2}[A-Z0-9]{2,2}([A-Z0-9]{3,3}){0,1}	BICFI	\N	1643032316159_23.xml	23	BICFI	\N
31	RTGSSS	Invalid value. More at link : /configs/metadata/clrChanl	ClearingChannel	\N	1643032316239_23.xml	23	ClrChanl	\N
33	1980-03-23	Invalid date value or format. Date Pattern: yyyy-MM-ddTHH:mm:ss.SSS	CreationDateTime	\N	1643032316274_23.xml	23	CreDtTm	\N
35	HEGH	Invalid value. More at link : /configs/metadata/instprt	InstructionPriority	\N	1643032316303_23.xml	23	InstrPrty	\N
49	ATBLZZZ	Invalid value. More at link : /configs/metadata/clearingsystemId	Code	\N	1643033094288_46.xml	46	Cd	\N
56	ATBLZZZ	Invalid value. More at link : /configs/metadata/clearingsystemId	Code	\N	1643033155724_50.xml	50	Cd	\N
58	2022-01-03	Invalid date value or format. Date Pattern: yyyy-MM-ddTHH:mm:ss.ss+HH:mm	CreationDateTime	\N	1643033155749_50.xml	50	CreDtTm	\N
60	3463475475346347547588888888888888888887777777778888887777	Pattern check failed. Pattern : [[0-9a-zA-Z/\\\\\\\\-\\\\\\\\?:\\\\\\\\(\\\\\\\\)\\\\\\\\.,\\\\\\\\+ ]+]{1,35}	Id	\N	1643033155772_50.xml	50	Id	\N
83	2022-01-03	Invalid date value or format. Date Pattern: yyyy-MM-ddTHH:mm:ss.ss+HH:mm	CreationDateTime	\N	1643034378863_80.xml	80	CreDtTm	\N
90	34345E@#$%*%!TRD3423	Pattern check failed. Pattern : [[0-9a-zA-Z/\\\\\\\\-\\\\\\\\?:\\\\\\\\(\\\\\\\\)\\\\\\\\.,\\\\\\\\+ ]+]{1,35}	OriginalEndToEndIdentification	\N	1643034840957_87.xml	87	OrgnlEndToEndId	\N
94	12345.0024324329d843201	Invalid amount value. The size of a fractional part of the amount should be between 5 and 14	OriginalInterbankSettlementAmount	\N	1643035474091_91.xml	91	OrgnlIntrBkSttlmAmt	\N
116	3463475475346346347547534634634754753463463475475346346347547534634634754753463463475475346	Invalid Value. The value length should be in between 1 to 35	MessageIdentification	\N	1643105698873_110.xml	110	MsgId	\N
118	123456789123456789123456789123456789123456789123456789123456789123456789123456789123456789123456789123456789123456789123456789123456789123456789	Invalid Value. The value length should be in between 1 to 35	MessageIdentification	\N	1643105698897_110.xml	110	MsgId	\N
153	\N	isomessages object from Hazelcast should not be null.	\N	\N	1643879462905_146.xml	146	\N	\N
155	3463475475346346347547534634634754753463463475475346346347547534634634754753463463475475346	Invalid Value. The value length should be in between 1 to 35	MessageIdentification	\N	1643879462506_146.xml	146	MsgId	\N
157	123456789123456789123456789123456789123456789123456789123456789123456789123456789123456789123456789123456789123456789123456789123456789123456789	Invalid Value. The value length should be in between 1 to 35	MessageIdentification	\N	1643879462945_146.xml	146	MsgId	\N
167	3463475475346346347547534634634754753463463475475346346347547534634634754753463463475475346	Invalid Value. The value length should be in between 1 to 35	MessageIdentification	\N	1643879525250_160.xml	160	MsgId	\N
170	123456789123456789123456789123456789123456789123456789123456789123456789123456789123456789123456789123456789123456789123456789123456789123456789	Invalid Value. The value length should be in between 1 to 35	MessageIdentification	\N	1643879525297_160.xml	160	MsgId	\N
177	123456789123456789123456789123456789123456789123456789123456789123456789123456789123456789123456789123456789123456789123456789123456789123456789	Invalid Value. The value length should be in between 1 to 35	MessageIdentification	\N	1643879592341_171.xml	171	MsgId	\N
180	3463475475346346347547534634634754753463463475475346346347547534634634754753463463475475346	Invalid Value. The value length should be in between 1 to 35	MessageIdentification	\N	1643879592407_171.xml	171	MsgId	\N
\.


--
-- Data for Name: validation_test; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.validation_test (run_id, created_on, description, input_source_type, payment_type, status, tags, test_name, user_id) FROM stdin;
1	2022-01-24 18:35:00	Message successfully validated ( Fields and Business Validation )	FileUpload	Inbound	Processed	\N	Pacs.008 FI to FI Customer Credit Transfer	\N
4	2022-01-24 18:39:00	FI to FI Customer Credit Transfer Message Failed, MsgId is greater than  35 character	FileUpload	Inbound	Failed	\N	Pacs.008 MsgId is greater than  35 character	\N
8	2022-01-24 18:43:00	Message Failed, MsgId is not as per format (  0-9a-zA-Z/\\\\-\\\\?:\\\\(\\\\)\\\\.,\\\\+ ]+)	FileUpload	Inbound	Processed	\N	Pacs.008 MsgId is not as per format	\N
11	2022-01-24 19:01:00	Message Failed as InstrPrty is not from list (HIGH, NORM)	FileUpload	Inbound	Failed	\N	Pacs.008 invalid InstrPrty value and not from list (HIGH, NORM)	\N
15	2022-01-24 19:07:00	Pacs.008 FI to FI Customer Credit Transfer Message Failed as BIC not as per format  pattern	FileUpload	Inbound	Failed	\N	Pacs.008 Failed as BIC not as per format  pattern	\N
19	2022-01-24 19:12:00	FI to FI Customer Credit Transfer Message Failed as invalid ClrChanl	FileUpload	Inbound	Failed	\N	pacs.008.001.008 has invalid ClrChanl	\N
23	2022-01-24 19:16:00	Pacs.008 FI to FI Customer Credit Transfer - Multiple Messages validation Failed	FileUpload	Inbound	Failed	\N	Pacs.008 multi files validation failed	\N
36	2022-01-24 19:19:00	Pacs.008 FI to FI Customer Credit Transfer Multiple Messages Validation Passed	FileUpload	Inbound	Processed	\N	Pacs.008 Multi Messages Validation Pass	\N
43	2022-01-24 19:22:00	CAMT.056 cancellation of  Credit Transfer message verified successfully (Fields and Business validation)	FileUpload	Inbound	Processed	\N	CAMT.056 cancellation of  Credit Transfer message verified successfully	\N
46	2022-01-24 19:29:00	CAMT.056 cancellation of Credit Transfer message Failed as Clearing System ID code is invalid	FileUpload	Inbound	Failed	\N	CAMT.056 cancellation of Credit Transfer message Failed as ClrSysId/cd is invalid	\N
50	2022-01-24 19:30:00	CAMT.056 cancellation of Credit Transfer Message validation	FileUpload	Inbound	Partial	\N	CAMT.056 multiple files validation	\N
62	2022-01-24 19:32:00	Creating pacs.002 accepted response for given pacs.008 message	FileUpload	Outbound	Processed	\N	pacs.002 gives positive response for pacs.008 message	\N
65	2022-01-24 19:36:00	pacs.002 gives negative response for pacs.008 message with  AC01-IncorrectAccountNumber	FileUpload	Outbound	Processed	\N	pacs.002 gives negative response AC01-IncorrectAccountNumber	\N
68	2022-01-24 19:40:00	pacs.002 gives negative response for pacs.008 message with  AC04 -ClosedAccountNumber	FileUpload	Outbound	Processed	\N	pacs.002 gives negative response with AC04 -ClosedAccountNumber	\N
71	2022-01-24 19:41:00	pacs.002 gives negative responses for multiple pacs.008 messages	FileUpload	Outbound	Processed	\N	pacs.002 gives negative responses for multiple pacs.008 messages	\N
80	2022-01-24 19:50:00	Cant create CAMT.029 message as CAMT.056 message verification failed	FileUpload	Outbound	Failed	\N	Failed to create CAMT.029 message as CAMT.056 message is not valid	\N
84	2022-01-24 19:53:00	CAMT.029 Cancellation rejection of CAMT.056 message  verified successfully (Fields and Business validation)	FileUpload	Outbound	Processed	\N	Create CAMT.029 with Cancellation rejection of CAMT.056 message  verified successfully	\N
87	2022-01-24 19:58:00	CAMT.029 Rejection of Camt.056 message Failed as OriginalEndToEndIdentification length more than 35 character	FileUpload	Outbound	Failed	\N	CAMT.029 Rejection of Camt.056 message Failed as OriginalEndToEndIdentification is invalid	\N
91	2022-01-24 20:08:00	CAMT.029 Rejection of Camt.056 message Failed as OriginalInterbankSettlementAmount exceed size of fractional part beyond 14 digits	FileUpload	Outbound	Failed	\N	CAMT.029 Rejection of Camt.056 message Failed as OriginalInterbankSettlementAmount is invalid	\N
95	2022-01-24 20:14:00	Generation of CAMT.029 message for each of provided CAMT.056 files	FileUpload	Outbound	Processed	\N	Generate CAMT.029 message for each provided CAMT.056 messages	\N
102	2022-01-24 23:43:00	pacs.002 gives negative response AC04 - ClosedAccountNumber	FileUpload	Outbound	Processed	\N	pacs.002 gives negative response AC04	\N
105	2022-01-24 23:48:00	Generate CAMT.029 with Cancellation for CAMT.056 message on successful verification	FileUpload	Outbound	Processed	\N	Generate CAMT.029 with Cancellation for CAMT.056 message	\N
110	2022-01-25 15:42:00	Pacs.008 FI to FI Customer Credit Transfer Message successfully validated ( Fields and Business Validation )	FileUpload	Outbound	Partial	\N	Pacs.008 FI to FI Customer Credit Transfer Message successfully validated ( Fields and Business Validation )	\N
146	2022-02-03 14:40:00	Pacs.008 FI to FI Customer Credit Transfer Message successfully validated ( Fields and Business Validation )	FileUpload	Inbound	Partial	\N	Pacs.008 FI to FI Customer Credit Transfer Message successfully validated ( Fields and Business Validation )	\N
160	2022-02-03 14:41:00	pacs.002 gives negative response for pacs.008 message with  AG01 -TransactionForbidden	FileUpload	Outbound	Partial	\N	pacs.002 gives negative response for pacs.008 message with  AG01 -TransactionForbidden	\N
171	2022-02-03 14:42:00	pacs.002 gives negative response for pacs.008 message with  AG02 -NotAllowedAmount	FileUpload	Outbound	Partial	\N	pacs.002 gives negative response for pacs.008 message with  AG02 -NotAllowedAmount	\N
\.


--
-- Name: hibernate_sequence; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.hibernate_sequence', 181, true);


--
-- Name: sequence_generator; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.sequence_generator', 1050, false);


--
-- Name: databasechangeloglock databasechangeloglock_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.databasechangeloglock
    ADD CONSTRAINT databasechangeloglock_pkey PRIMARY KEY (id);


--
-- Name: iso_message_metadata iso_message_metadata_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.iso_message_metadata
    ADD CONSTRAINT iso_message_metadata_pkey PRIMARY KEY (id);


--
-- Name: reference_data reference_data_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.reference_data
    ADD CONSTRAINT reference_data_pkey PRIMARY KEY (id);


--
-- Name: response_message response_message_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.response_message
    ADD CONSTRAINT response_message_pkey PRIMARY KEY (id);


--
-- Name: test_input_data test_input_data_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.test_input_data
    ADD CONSTRAINT test_input_data_pkey PRIMARY KEY (id);


--
-- Name: test_output_data test_output_data_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.test_output_data
    ADD CONSTRAINT test_output_data_pkey PRIMARY KEY (id);


--
-- Name: validation_error validation_error_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.validation_error
    ADD CONSTRAINT validation_error_pkey PRIMARY KEY (id);


--
-- Name: validation_test validation_test_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.validation_test
    ADD CONSTRAINT validation_test_pkey PRIMARY KEY (run_id);


--
-- Name: test_input_data fk1xaaf4v667p37ietqlxy0rndp; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.test_input_data
    ADD CONSTRAINT fk1xaaf4v667p37ietqlxy0rndp FOREIGN KEY (validationtest_run_id) REFERENCES public.validation_test(run_id);


--
-- Name: test_input_data fkd9vum8plr5wjdqc6dvycxnc8c; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.test_input_data
    ADD CONSTRAINT fkd9vum8plr5wjdqc6dvycxnc8c FOREIGN KEY (run_id) REFERENCES public.validation_test(run_id);


--
-- PostgreSQL database dump complete
--

--
-- Database "isosimulator_gateway_db" dump
--

--
-- PostgreSQL database dump
--

-- Dumped from database version 13.4 (Debian 13.4-4.pgdg110+1)
-- Dumped by pg_dump version 13.4 (Debian 13.4-4.pgdg110+1)

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: isosimulator_gateway_db; Type: DATABASE; Schema: -; Owner: postgres
--

CREATE DATABASE isosimulator_gateway_db WITH TEMPLATE = template0 ENCODING = 'UTF8' LOCALE = 'en_US.utf8';


ALTER DATABASE isosimulator_gateway_db OWNER TO postgres;

\connect isosimulator_gateway_db

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: databasechangelog; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.databasechangelog (
    id character varying(255) NOT NULL,
    author character varying(255) NOT NULL,
    filename character varying(255) NOT NULL,
    dateexecuted timestamp without time zone NOT NULL,
    orderexecuted integer NOT NULL,
    exectype character varying(10) NOT NULL,
    md5sum character varying(35),
    description character varying(255),
    comments character varying(255),
    tag character varying(255),
    liquibase character varying(20),
    contexts character varying(255),
    labels character varying(255),
    deployment_id character varying(10)
);


ALTER TABLE public.databasechangelog OWNER TO postgres;

--
-- Name: databasechangeloglock; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.databasechangeloglock (
    id integer NOT NULL,
    locked boolean NOT NULL,
    lockgranted timestamp without time zone,
    lockedby character varying(255)
);


ALTER TABLE public.databasechangeloglock OWNER TO postgres;

--
-- Name: jhi_authority; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.jhi_authority (
    name character varying(50) NOT NULL
);


ALTER TABLE public.jhi_authority OWNER TO postgres;

--
-- Name: jhi_user; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.jhi_user (
    id bigint NOT NULL,
    login character varying(50) NOT NULL,
    password_hash character varying(60) NOT NULL,
    first_name character varying(50),
    last_name character varying(50),
    email character varying(191),
    image_url character varying(256),
    activated boolean NOT NULL,
    lang_key character varying(10),
    activation_key character varying(20),
    reset_key character varying(20),
    created_by character varying(50) NOT NULL,
    created_date timestamp without time zone,
    reset_date timestamp without time zone,
    last_modified_by character varying(50),
    last_modified_date timestamp without time zone
);


ALTER TABLE public.jhi_user OWNER TO postgres;

--
-- Name: jhi_user_authority; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.jhi_user_authority (
    user_id bigint NOT NULL,
    authority_name character varying(50) NOT NULL
);


ALTER TABLE public.jhi_user_authority OWNER TO postgres;

--
-- Name: jhi_user_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

ALTER TABLE public.jhi_user ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME public.jhi_user_id_seq
    START WITH 1050
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Data for Name: databasechangelog; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.databasechangelog (id, author, filename, dateexecuted, orderexecuted, exectype, md5sum, description, comments, tag, liquibase, contexts, labels, deployment_id) FROM stdin;
00000000000001	jhipster	config/liquibase/changelog/00000000000000_initial_schema.xml	2022-05-12 07:51:03.744147	1	EXECUTED	8:06225dfc05215e6b13d8a4febd3fd90f	createTable tableName=jhi_user; createTable tableName=jhi_authority; createTable tableName=jhi_user_authority; addPrimaryKey tableName=jhi_user_authority; addForeignKeyConstraint baseTableName=jhi_user_authority, constraintName=fk_authority_name, ...		\N	4.3.5	\N	\N	2341862812
\.


--
-- Data for Name: databasechangeloglock; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.databasechangeloglock (id, locked, lockgranted, lockedby) FROM stdin;
1	f	\N	\N
\.


--
-- Data for Name: jhi_authority; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.jhi_authority (name) FROM stdin;
ROLE_ADMIN
ROLE_USER
\.


--
-- Data for Name: jhi_user; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.jhi_user (id, login, password_hash, first_name, last_name, email, image_url, activated, lang_key, activation_key, reset_key, created_by, created_date, reset_date, last_modified_by, last_modified_date) FROM stdin;
1	admin	$2a$10$gSAhZrxMllrbgj/kkK9UceBPpChGWJA7SYIb1Mqo.n5aNLq1/oRrC	Administrator	Administrator	admin@localhost		t	en	\N	\N	system	\N	\N	system	\N
2	user	$2a$10$VEjxo0jq2YG9Rbk2HmX9S.k1uZBGYUHdUcid3g/vfiEl7lwWgOH/K	User	User	user@localhost		t	en	\N	\N	system	\N	\N	system	\N
\.


--
-- Data for Name: jhi_user_authority; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.jhi_user_authority (user_id, authority_name) FROM stdin;
1	ROLE_ADMIN
1	ROLE_USER
2	ROLE_USER
\.


--
-- Name: jhi_user_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.jhi_user_id_seq', 1050, false);


--
-- Name: databasechangeloglock databasechangeloglock_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.databasechangeloglock
    ADD CONSTRAINT databasechangeloglock_pkey PRIMARY KEY (id);


--
-- Name: jhi_authority jhi_authority_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.jhi_authority
    ADD CONSTRAINT jhi_authority_pkey PRIMARY KEY (name);


--
-- Name: jhi_user_authority jhi_user_authority_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.jhi_user_authority
    ADD CONSTRAINT jhi_user_authority_pkey PRIMARY KEY (user_id, authority_name);


--
-- Name: jhi_user jhi_user_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.jhi_user
    ADD CONSTRAINT jhi_user_pkey PRIMARY KEY (id);


--
-- Name: jhi_user ux_user_email; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.jhi_user
    ADD CONSTRAINT ux_user_email UNIQUE (email);


--
-- Name: jhi_user ux_user_login; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.jhi_user
    ADD CONSTRAINT ux_user_login UNIQUE (login);


--
-- Name: jhi_user_authority fk_authority_name; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.jhi_user_authority
    ADD CONSTRAINT fk_authority_name FOREIGN KEY (authority_name) REFERENCES public.jhi_authority(name);


--
-- Name: jhi_user_authority fk_user_id; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.jhi_user_authority
    ADD CONSTRAINT fk_user_id FOREIGN KEY (user_id) REFERENCES public.jhi_user(id);


--
-- PostgreSQL database dump complete
--

--
-- Database "postgres" dump
--

--
-- PostgreSQL database dump
--

-- Dumped from database version 13.4 (Debian 13.4-4.pgdg110+1)
-- Dumped by pg_dump version 13.4 (Debian 13.4-4.pgdg110+1)

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

DROP DATABASE postgres;
--
-- Name: postgres; Type: DATABASE; Schema: -; Owner: postgres
--

CREATE DATABASE postgres WITH TEMPLATE = template0 ENCODING = 'UTF8' LOCALE = 'en_US.utf8';


ALTER DATABASE postgres OWNER TO postgres;

\connect postgres

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: DATABASE postgres; Type: COMMENT; Schema: -; Owner: postgres
--

COMMENT ON DATABASE postgres IS 'default administrative connection database';


--
-- PostgreSQL database dump complete
--

--
-- PostgreSQL database cluster dump complete
--

