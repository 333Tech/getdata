cd ..

cd ./iso-simulator-commons
git pull
bash ./mvnw clean install -DskipTests
cd ..

cd ./hz-cache-server
git pull
bash ./mvnw clean package -Pdocker -DskipTests
cd ..

cd ./iso-simulator-gateway
git pull
bash ./mvnw clean package -Pdocker -DskipTests
cd ..

cd ./message-handler-service
git pull
bash ./mvnw clean package -Pdocker -DskipTests
cd ..

cd ./enquiry-and-config-service
git pull
bash ./mvnw clean package -Pdocker -DskipTests
cd ..

cd ./message-validator-service
git pull
bash ./mvnw clean package -Pdocker -DskipTests
cd ..

cd ./xml-message-transformer-service
git pull
bash ./mvnw clean package -Pdocker -DskipTests
cd ..