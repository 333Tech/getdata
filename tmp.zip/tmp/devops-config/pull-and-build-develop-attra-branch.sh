cd ..

cd ./iso-simulator-commons
git checkout develop_attra
git pull
bash ./mvnw clean install -DskipTests
cd ..

cd ./hz-cache-server
git checkout develop_attra
git pull
bash ./mvnw clean package -Pdocker -DskipTests
cd ..

cd ./iso-simulator-gateway
git checkout develop_attra
git pull
bash ./mvnw clean package -Pdocker -DskipTests
cd ..

cd ./message-handler-service
git checkout develop_attra
git pull
bash ./mvnw clean package -Pdocker -DskipTests
cd ..

cd ./enquiry-and-config-service
git checkout develop_attra
git pull

bash ./mvnw clean package -Pdocker -DskipTests
cd ..

cd ./message-validator-service
git checkout develop_attra
git pull
bash ./mvnw clean package -Pdocker -DskipTests
cd ..

cd ./xml-message-transformer-service
git checkout develop_attra
git pull
bash ./mvnw clean package -Pdocker -DskipTests
cd ..