cd ..

cd ./iso-simulator-commons
bash ./mvnw clean install -DskipTests
cd ..

cd ./hz-cache-server
bash ./mvnw clean package -Pdocker -DskipTests
cd ..

cd ./iso-simulator-gateway
bash ./mvnw clean package -Pdocker -DskipTests
cd ..

cd ./message-handler-service
bash ./mvnw clean package -Pdocker -DskipTests
cd ..


cd ./enquiry-and-config-service
bash ./mvnw clean package -Pdocker -DskipTests
cd ..


cd ./message-validator-service
bash ./mvnw clean package -Pdocker -DskipTests
cd ..


cd ./xml-message-transformer-service
bash ./mvnw clean package -Pdocker -DskipTests
cd ..

